# 原文

![[20. resource/b. audio/The growth of bike-sharing schemes around the world.mp3]]

The growth of bike-sharing schemes around the world

**A**   The original idea for an urban bike-sharing scheme dates back to a summer's day in Amsterdam in 1965. Provo, the organisation that came up with the idea, was a group of Dutch activists who wanted to change society. They believed the scheme, which was known as the Witte Fietsenplan, was an answer to the perceived threats of air pollution and consumerism. In the centre of Amsterdam, they painted a small number of used bikes white. They also distributed leaflets describing the dangers of cars and inviting people to use the white bikes. The bikes were then left unlocked at various locations around the city, to be used by anyone in need of transport.

**B**   Luud Schimmelpennink, a Dutch industrial engineer who still lives and cycles in Amsterdam, was heavily involved in the original scheme. He recalls how the scheme succeeded in attracting a great deal of attention - particularly when it came to publicising Provo's aims - but struggled to get off the ground. The police were opposed to Provo's initiatives and almost as soon as the white bikes were distributed around the city, they removed them. However, for Schimmelpennink and for bike-sharing schemes in general, this was just the beginning. 'The first Witte Fietsenplan was just a symbolic thing,' he says. 'We painted a few bikes white, that was all. Things got more serious when I became a member of the Amsterdam city council two years later.'

**C**   Schimmelpennink seized this opportunity to present a more elaborate Witte Fietsenplan to the city council. 'My idea was that the municipality of Amsterdam would distribute 10,000 white bikes over the city, for everyone to use,' he explains. 'I made serious calculations. It turned out that a white bicycle - per person, per kilometer - would cost the municipality only 10% of what it contributed to public transport per person per kilometre.' Nevertheless, the council unanimously rejected the plan. 'They said that the bicycle belongs to the past. They saw a glorious future for the car,' says Schimmelpennink. But he was not in the least discouraged.

**D**   Schimmelpennink never stopped believing in bike- sharing, and in the mid-90s, two Danes asked for his help to set up a system in Copenhagen. The result was the world's first large-scale bike-share programme. It worked on a deposit: 'You dropped a coin in the bike and when you returned it, you got your money back.' After setting up the Danish system, Schimmelpennink decided to try his luck again in the Netherlands - and this time he succeeded in arousing the interest of the Dutch Ministry of Transport. 'Times had changed,' he recalls. 'People had become more environmentally conscious, and the Danish experiment had proved that bike-sharing was a real possibility' A new Witte Fietsenplan was launched in 1999 in Amsterdam. However, riding a white bike was no longer free; it cost one guilder per trip and payment was made with a chip card developed by the Dutch bank Postbank. Schimmelpennink designed conspicuous, sturdy white bikes locked in special racks which could be opened with the chip card - the plan started with 250 bikes, distributed over five stations.

**E**  Theo Molenaar, who was a system designer for the project, worked alongside Schimmelpennink. 'I remember when we were testing the bike racks, he announced that he had already designed better ones. But of course, we had to go through with the ones we had.' The system, however, was prone to vandalism and theft. 'After every weekend there would always be a couple of bikes missing,' Molenaar says. 'I really have no idea what people did with them, because they could instantly be recognised as white bikes.' But the biggest blow came when Postbank decided to abolish the chip card, because it wasn't profitable. 'That chip card was pivotal to the system,' Molenaar says. 'To continue the project we would have needed to set up another system, but the business partner had lost interest.'

**F**   Schimmelpennink was disappointed, but - characteristically - not for long, In 2002 he got a call from the French advertising corporation JC Decaux, who wanted to setup his bike -sharing scheme in Vienna. 'That went really well. After Vienna, they setup a system in Lyon. Then in 2007, Paris followed. That was a decisive moment in the history of bike-sharing.' The huge and unexpected success of the Parisian bike-sharing programme, which now boasts more than 20,000 bicycles, inspired cities all over the world to set up their own schemes, all modelled on Schimmelpennink's. ‘It's wonderful that this happened,' he says. 'But financially I didn't really benefit from it, because I never filed for a patent.'

**G**   In Amsterdam today, 38% of all trips are made by bike and, along with Copenhagen, it is regarded as one of the two most cycle-friendly capitals in the world - but the city never got another Witte Fietsenplan. Molenaar believes this may be because everybody in Amsterdam already has a bike. Schimmelpennink, however, cannot see that this changes Amsterdam's need for a bike-sharing scheme. 'People who travel on the underground don't carry their bikes around. But often they need additional transport to reach their final destination.' Although he thinks it is strange that a city like Amsterdam does not have a successful bike-sharing scheme, he is optimistic about the future. 'In the '60s we didn't stand a chance because people were prepared to give their lives to keep cars in the city. But that mentality has totally changed. Today everybody longs for cities that are not dominated by cars.'


# 单词

| 意思单位 | 核心词 | 释义 | 拆解 |
| --- | --- | --- | --- |
|  | withdraw | v. 收回; 撤回; 退出; 取款 | with-(向后, 相反), draw(拉)<br>向后拉回，因此表示撤回、退出或取款 |
| dominated by cars.' | dominate | v. 控制; 支配; 占主导地位 | domin(统治, 控制), -ate(做, 使)<br>对他人或局面实施统治控制 |
| filed for a patent | file | v. 申请; 存档; 提交<br>n. 文件; 档案 | fil(线), e(连接字母)<br>原指用线串起的一组材料，后来发展为文件或档案 |
| boasts more than 20 | boast | v. 自夸; 以拥有某事物而自豪<br>n. 自夸 | 中古英语已有该词，深层来源不明<br>核心义为夸耀自己的成就；名词与动词同形转化 |
| arousing the interest | arouse | v. 激起; 唤醒; 引起 | a-(一再等加强意义), rouse(词：唤醒)<br>使充分醒来，引申为激起情绪或反应 |
| recalls how the scheme | recall | v. 召回; 回想起; 取消<br>n. 召回; 回忆; 撤销 | re-(再次, 重新), call(词：叫；想起)<br>再次唤回，引申为回忆或召回 |
| publicising Provo's aims | publicise | v. 宣传; 公布; 宣扬 | public(词：公众), -ise(…化, 使成)<br>使公众知晓，因而宣传或公布 |
| perceived threats | perceive | v. 感知; 察觉; 认为; 理解 | per-(通过, 贯穿), ceive(抓夺)<br>把感官获得的信息完整抓住，因此表示察觉、理解 |
|  | reputation | n. 名声; 名誉; 声望 | re-(回, 向后), put(思考, 认为), -ation(行为, 过程, 结果)<br>反复作出的评价 |
| a system in Copenhagen | Copenhagen | n. 哥本哈根（丹麦首都） | 丹麦首都的地名专名<br>文中指最早建立大型公共自行车系统的城市 |
| filed for a patent | patent | n. 专利权; 专利证书<br>adj. 专利的; 显然的<br>v. 为……取得专利 | 源自拉丁语 patere“敞开”形成的 patens“公开的”<br>letters patent 原指公开文书，后来专指专利 |
| a system in Lyon | Lyon | n. 里昂（法国城市） | 法国城市的地名专名<br>文中指继维也纳之后建立共享单车系统的城市 |
|  | saving | n. 节省; 储蓄（常用复数 savings） | sav(救助, 保存), -ing(行为, 过程)<br>围绕“救助”这一核心含义构成，表示“节约，节省” |
| biggest blow came | blow | n. 打击; 吹; 殴打<br>v. 吹; 刮风 | 古英语 blawan“吹气”延续至今<br>使空气流动，即吹；动词转化出吹击、打击名词 |
| special racks | rack | n. 货架; 行李架; 拷问架<br>v. 折磨; 使痛苦 | 源自中古荷兰语 rec“横杆、架”，与 recken“伸展”相关<br>由横向伸展的支架发展为架子 |
| one guilder per | guilder | n. 荷兰盾（旧货币单位） | 源自荷兰语 gulden“金的”<br>原指金币，后成为荷兰旧货币单位 |
| again in the Netherlands | Netherlands | n. 荷兰 | 欧洲国家的专名<br>名称本义为“低地国家”，文中指自行车共享计划的发源地 |
| city council two | council | n. 委员会; 理事会; 地方议会 | 经古法语 concile 进入英语，源自拉丁语 concilium（集会、会议） |
| the municipality of | municipality | n. 市政当局; 自治市; 市辖区 | municipal(词：市政的), -ity(性质, 状态)<br>具有市政自治性质的地区或管理机构 |
| threats of air pollution and consumerism | consumerism | n. 消费主义; 保护消费者利益运动 | consume→consumer(词:消费者), -ism(主义)<br>围绕消费者和消费形成的社会观念或运动 |
| Dutch activists who | activist | n. 活动家; 积极分子 | active→activ(词:积极的), -ist(人)<br>积极参与社会或政治行动的人 |
| was prone to vandalism | vandalism | n. 蓄意破坏; 破坏行为 | 源自 Vandal（汪达尔人）<br>因汪达尔人被后世描述为破坏文化财产而引申为蓄意破坏行为 |
| vandalism and theft | theft | n. 偷窃; 盗窃罪 | 五种构词法均不适用<br>核心记忆：秘密拿走不属于自己的财物，即偷窃或盗窃罪 |
|  | dichotomy | n. 二分法; 对立两分 | di-(两, 双), tomy(切, 割)<br>把事物切分成两个相对的部分，即二分或对立两分 |
| Amsterdam in | Amsterdam | n. 阿姆斯特丹（荷兰首都） | 荷兰首都的地名专名<br>文中是最早提出共享单车构想的城市 |
| bike-sharing schemes around | scheme | n. 计划; 方案; 阴谋<br>v. 计划; 策划 | 14世纪经古法语及拉丁语借入，源自希腊语 skhēma“形态、构形”<br>由结构形式发展为计划或方案 |
| Dutch activists | Dutch | n. 荷兰人; 荷兰语<br>adj. 荷兰的; 荷兰人的; 荷兰语的 | 与荷兰及其居民、语言相关的专名<br>文中指荷兰的活动家和工程师 |
| a decisive moment | decisive | adj. 决定性的; 果断的; 坚定的 | 与 decide“切断、决定”同源，最终来自拉丁语 decidere<br>能够切断犹豫、确定结果的 |
| was disappointed | disappointed | adj. 失望的; 沮丧的 | disappoint(词:使失望), -ed(…的)<br>未达到预期而感到失望或沮丧 |
| was pivotal to | pivotal | adj. 关键的; 中枢的<br>n. 关键事物 | pivot(词:支点), -al(…的)<br>像支点一样决定整体转动的位置，因而关键 |
| wasn't profitable | profitable | adj. 有利可图的; 赚钱的; 有益的 | profit(词：利润), -able(可…的)<br>能够产生利润的，即"有利可图的" |
| was prone to | prone | adj. 易于……的; 有……倾向的; 俯卧的 | 源自拉丁语 pronus“向前俯伏的”<br>由身体前倾引申为易于、倾向于 |
| sturdy white | sturdy | adj. 强健的; 结实的; 坚定的 | 经古法语 estourdi“鲁莽、强硬”相关形式进入英语<br>后来发展为结实耐用的 |
| designed conspicuous | conspicuous | adj. 显著的; 显而易见的 | con-(与, 共同), spic(看), -uous(…的)<br>清楚进入众人视线，因此表示显眼的、明显的 |
| more elaborate Witte | elaborate | adj. 精心制作的; 详尽的<br>v. 精心制作; 详细阐述 | e-(出, 向外), labor(工作), -ate(做, 使)<br>经过大量劳动精心做成，因此表示精巧复杂的；作动词指详述 |
| more serious when | serious | adj. 严肃的; 严重的; 认真的 | 源自拉丁语 serius“严肃的、重要的”<br>需要认真对待的，因而严肃、严重 |
| characteristically not | characteristically | adv. 典型地; 有代表性地 | characteristic→characteristically<br>以某事物特有的典型方式发生 |
| the council unanimously rejected the | unanimously | adv. 全体一致地 | unanimous→unanimously<br>所有人持同一意见地，即一致地 |


# 短语

| English | 中文 | 例句 |
| --- | --- | --- |
| date back to sth | phr. 追溯到某时；始于某时 | The original idea for an urban bike-sharing scheme dates back to a summer's day in Amsterdam in 1965. |
| come up with sth | phr. 想出；提出某事 | Provo, the organisation that came up with the idea, was a group of Dutch activists who wanted to change society. |
| be known as sth | phr. 被称为某事 | They believed the scheme, which was known as the Witte Fietsenplan, was an answer to the perceived threats of air pollution and consumerism. |
| an answer to sth | phr. 解决某事的办法 | They believed the scheme, which was known as the Witte Fietsenplan, was an answer to the perceived threats of air pollution and consumerism. |
| in need of sth | phr. 需要某事 | The bikes were then left unlocked at various locations around the city, to be used by anyone in need of transport. |
| be involved in sth | phr. 参与某事 | Luud Schimmelpennink, a Dutch industrial engineer who still lives and cycles in Amsterdam, was heavily involved in the original scheme. |
| attract attention | phr. 吸引注意；受到关注 | He recalls how the scheme succeeded in attracting a great deal of attention - particularly when it came to publicising Provo's aims - but struggled to get off the ground. |
| when it comes to sth/doing sth | phr. 谈到；涉及某事或做某事时 | He recalls how the scheme succeeded in attracting a great deal of attention - particularly when it came to publicising Provo's aims - but struggled to get off the ground. |
| get off the ground | phr. 顺利启动；开始取得进展 | He recalls how the scheme succeeded in attracting a great deal of attention - particularly when it came to publicising Provo's aims - but struggled to get off the ground. |
| be opposed to sth | phr. 反对某事 | The police were opposed to Provo's initiatives and almost as soon as the white bikes were distributed around the city, they removed them. |
| be distributed around sth | phr. 被分布或投放在某处各处 | The police were opposed to Provo's initiatives and almost as soon as the white bikes were distributed around the city, they removed them. |
| seize an opportunity | phr. 抓住机会 | Schimmelpennink seized this opportunity to present a more elaborate Witte Fietsenplan to the city council. |
| turn out that ... | phr. 结果发现…… | It turned out that a white bicycle - per person, per kilometer - would cost the municipality only 10% of what it contributed to public transport per person per kilometre. |
| set up a system | phr. 建立一个系统 | Schimmelpennink never stopped believing in bike- sharing, and in the mid-90s, two Danes asked for his help to set up a system in Copenhagen. |
| try one's luck | phr. 碰碰运气；再次尝试 | After setting up the Danish system, Schimmelpennink decided to try his luck again in the Netherlands - and this time he succeeded in arousing the interest of the Dutch Ministry of Transport. |
| arouse the interest of sb | phr. 激起某人的兴趣 | After setting up the Danish system, Schimmelpennink decided to try his luck again in the Netherlands - and this time he succeeded in arousing the interest of the Dutch Ministry of Transport. |
| be distributed over sth | phr. 分布在某范围内 | Schimmelpennink designed conspicuous, sturdy white bikes locked in special racks which could be opened with the chip card - the plan started with 250 bikes, distributed over five stations. |
| go through with sth | phr. 把某事坚持做完 | But of course, we had to go through with the ones we had. |
| be prone to sth | phr. 容易遭受；易发生某事 | The system, however, was prone to vandalism and theft. |
| be recognised as sth | phr. 被认作；被识别为某事 | I really have no idea what people did with them, because they could instantly be recognised as white bikes. |
| be pivotal to sth | phr. 对某事至关重要 | That chip card was pivotal to the system,' Molenaar says. |
| lose interest | phr. 失去兴趣 | To continue the project we would have needed to set up another system, but the business partner had lost interest. |
| a decisive moment | phr. 决定性时刻 | That was a decisive moment in the history of bike-sharing. |
| be modelled on sth | phr. 以某事为模型；仿照某事 | The huge and unexpected success of the Parisian bike-sharing programme, which now boasts more than 20,000 bicycles, inspired cities all over the world to set up their own schemes, all modelled on Schimmelpennink's. |
| benefit from sth | phr. 从某事中获益 | But financially I didn't really benefit from it, because I never filed for a patent. |
| file for a patent | phr. 申请专利 | But financially I didn't really benefit from it, because I never filed for a patent. |
| along with sth | phr. 与某事一起；连同某事 | In Amsterdam today, 38% of all trips are made by bike and, along with Copenhagen, it is regarded as one of the two most cycle-friendly capitals in the world - but the city never got another Witte Fietsenplan. |
| be regarded as sth | phr. 被视为；被认为是某事 | In Amsterdam today, 38% of all trips are made by bike and, along with Copenhagen, it is regarded as one of the two most cycle-friendly capitals in the world - but the city never got another Witte Fietsenplan. |
| stand a chance | phr. 有成功的可能；有机会 | In the '60s we didn't stand a chance because people were prepared to give their lives to keep cars in the city. |
| long for sth | phr. 渴望某事 | Today everybody longs for cities that are not dominated by cars. |
| be dominated by sth | phr. 被某事支配；以某事为主 | Today everybody longs for cities that are not dominated by cars. |
