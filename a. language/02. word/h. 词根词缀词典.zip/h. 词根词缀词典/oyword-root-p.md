## oyword-root-p


### paci

和平

| 单词 | 拆解 |
| --- | --- |
| pacify<br><br>v. 使镇定; 抚慰; 平定; 缓靖 | **paci(和平)**, -fy(…化, 做…)<br>围绕“和平”这一核心含义构成, 表示“使镇定, 抚慰” |
| pacific<br><br>adj. 平静的; 和平的; 爱和平的; 太平洋的<br>n. 太平洋 | **paci(和平)**, -fic(造成…的, 产生…的)<br>使和平的 |
| pacification<br><br>n. 镇定; 平定; 绥靖; 和约 | **paci(和平)**, -fication(…化, 做…)<br>在前词基础上加“-fication”构成名词, 表示“镇定” |
| pacifier<br><br>n. 安抚奶嘴; 安抚物; 抚慰者; 平定者 | **paci(和平)**, -fier(做…的人或物)<br>使归于平静的人或物, 引申为安抚奶嘴、安抚物及抚慰者等 |


### pack

包

| 单词 | 拆解 |
| --- | --- |
| package<br><br>n. 包裹; 包; 一揽子交易(或计划; 建议等)<br>v. 包装 | **pack(包)**, -age(总称, 集合)<br>围绕“包”这一核心含义构成, 表示“包裹, 包” |
| packer<br><br>n. 包装工人; 打包机 | **pack(包)**, -er(人)<br>表示从事或具有“包”特征的人, 即“包装工人” |
| packet<br><br>n. 小包; 数据包<br>v. 打包; 包装 | **pack(包)**, -et(小)<br>围绕“包”这一核心含义构成, 表示“小包(裹), 小捆” |
| packing<br><br>n. 包装; 打包 | **pack(包)**, -ing(行为, 过程)<br>围绕“包”这一核心含义构成, 表示“包装” |


### pact

约定, 协议; 压紧, 打入

| 单词 | 拆解 |
| --- | --- |
| impact<br><br>n. 影响; 冲击<br>v. 影响 | im-(向内, 进入), **pact(压紧, 打入)**<br>猛烈打入并压紧产生的冲击, 引申为重大影响 |
| compact<br><br>adj. (空间上)紧凑的 | com-(与, 共同), **pact(压紧, 打入)**<br>把各部分共同压紧在一起, 即紧凑的; 也可转化为小型物品或协议 |


### ped(o), paed(o)

儿童

| 单词 | 拆解 |
| --- | --- |
| paediatrics<br><br>n. 儿科学; 小儿科 | paediatric→paediatr(词: 儿科), -ics(…学)<br>在前词基础上加“-ics”构成名词, 表示“儿科学” |
| paediatrician<br><br>n. 儿科医师; 儿科专家 | paediatric→paediatr(词: 儿科), -ician(人)<br>在前词基础上加“-ician”构成名词, 表示“儿科医师” |
| pedagogics<br><br>n. 教育学; 教学法; 教师职业 | **ped(儿童)**, **agog(引导, 带领)**, -ics(…学)<br>以“儿童、引导”为研究对象的学科, 即“教育学” |
| pedagogy<br><br>n. 教育学; 教学法; 教师职业 | **ped(儿童)**, **agog(引导, 带领)**, -y(活动)<br>引导儿童学习的活动和理论, 即教育学 |
| pedant<br><br>n. 迂腐的教师; 学究; 卖弄学问的人 | 源自意大利语 pedante“教师、学究”<br>后来表示拘泥细节并卖弄学问的人 |
| pedantry<br><br>n. 自夸有学问; 卖弄学问; 迂腐 | pedant(词: 自夸学问的人), -ry(行为, 状态)<br>在前词基础上加“-ry”构成名词, 表示“自夸有学问” |
| paediatric<br><br>adj. 儿科学的; 小儿科的 | **paed(儿童)**, **iatr(医生, 治疗)**, -ic(…的)<br>与儿童医疗有关的, 即小儿科的 |


### ped(e), ped(i)

脚

| 单词 | 拆解 |
| --- | --- |
| peddle<br><br>v. 沿街叫卖; 挨户兜售; 零售 | 源自 peddler“沿街小贩”反向形成的动词<br>表示挨户兜售, 也引申为散播消息或观点 |
| biped<br><br>n. 两足动物<br>adj. 有两足的 | bi-(两, 双), **ped(脚)**<br>有两只脚的动物, 即两足动物 |
| centipede<br><br>n. 蜈蚣 | **centi(百)**, **pede(脚)**<br>名称意为‘百足’, 指有许多足的蜈蚣 |
| expedition<br><br>n. 探险; 考察; 考察队; 远征 | ex-(出, 向外), **ped(脚)**, -ition(行为, 结果)<br>双脚向外行进的过程, 引申为远征或考察 |
| pedal<br><br>n. 踏板; 脚蹬<br>v. 踩踏板; 骑车<br>adj. 脚踏的 | **ped(脚)**, -al(…的)<br>与脚有关的; 名词化后指用脚踩的踏板 |
| pedestal<br><br>n. 柱脚; 基座; 支撑 | 源自意大利语 piedistallo“脚下的支座”<br>支撑柱子、雕像等物体的基座 |
| pedestrian<br><br>n. 行人; 步行者<br>adj. 徒步的; 平淡无奇的 | 源自拉丁语 pedester（步行的）, 核心 pes、ped- 意为脚<br>用双脚行走的人, 即行人 |
| pedicab<br><br>n. 人力三轮车; 脚踏三轮车 | **pedi(脚)**, cab(词: 出租车)<br>用脚踩踏提供动力的人力出租车, 即脚踏三轮车 |
| pedicure<br><br>n. 脚病治疗; 脚病医生; 足医 | **pedi(脚)**, **cur(关心, 注意)**, e(连接字母)<br>护理和修整脚部、脚趾甲, 因此表示足部护理; 并非仅指脚病治疗 |


### pale(o)

旧, 古

| 单词 | 拆解 |
| --- | --- |
| paleobotany<br><br>n. 古植物学 | paleo-(古, 旧), botany(词: 植物学)<br>由“古”与“植物学”共同限定词义, 表示“古植物学” |
| paleography<br><br>n. 古文书(学); 古字体 | 由 paleo“古老”与 graphy“书写研究”构成<br>研究古代文字和手稿的学科 |


### pan

面包

| 单词 | 拆解 |
| --- | --- |
| accompany<br><br>v. 陪伴; 伴随 | ac-(到, 朝, 向), com-(与, 共同), **pan(面包)**, y(连接字母)<br>原指共同吃面包的伙伴, 后来表示陪伴同行 |
| companion<br><br>n. 同伴; 伴侣 | 经古法语 compagnon 进入英语, 历史意象是共同分享面包的人, 即伙伴 |
| company<br><br>n. 公司; 陪伴; 同伴; 剧团 | 经古法语 compagnie 进入英语, 历史意象是共同分享面包的一群伙伴 |
| pancake<br><br>n. 薄煎饼 | pan(词: 平底锅), cake(词: 饼)<br>在平底锅中煎成的饼, 即薄煎饼 |
| pantry<br><br>n. 餐具室; 食品间 | 经古法语 paneterie 借入, 核心拉丁语 panis 表示面包<br>原为存放面包的房间, 后泛指食品储藏室 |


### pand, pans

扩展, 扩大

| 单词 | 拆解 |
| --- | --- |
| expand<br><br>v. 扩大; 膨胀; 扩张; 扩充; 扩展 | ex-(出, 向外), **pand(扩展, 扩大)**<br>向外扩展开来, 即"扩大" |
| expanse<br><br>n. 广阔 (空间); 辽阔 | ex-(出, 向外), **pans(扩展, 扩大)**, e(连接字母)<br>向外伸展形成的广大区域, 因此表示辽阔区域 |
| expansion<br><br>n. 扩大; 扩充; 扩张; 膨胀 | ex-(出, 向外), **pans(扩展, 扩大)**, -ion(行为, 结果)<br>向外伸展并扩大, 因此表示扩张、膨胀 |
| pandemic<br><br>adj. 大流行的; 普遍的; 全世界的 | pan-(全, 总, 泛), **dem(人民)**, -ic(…的)<br>影响所有地区广大人群的, 即大流行的 |
| expansive<br><br>adj. 扩张的; 普遍的; 广泛的 | 与 expand“向外展开”同源<br>广阔的; 愿意畅谈的 |


### par

相等; 生, 产

| 单词 | 拆解 |
| --- | --- |
| compare<br><br>v. 比较; 对比; 把……比作; 比得上 | com-(与, 共同), **par(相等)**, e(连接字母)<br>把事物放在一起衡量异同 |
| disparage<br><br>v. 轻视; 贬低 | dis-(否定, 相反), **par(相等)**, -age(行为, 结果)<br>否定某人与他人处于同等地位, 引申为贬低 |
| disparate<br><br>n. 无法相比的东西<br>adj. 根本不同的; 全异的; 不相干的 | dis-(否定, 相反), **par(相等)**, -ate(…的)<br>不相等、不相似的, 即迥异的 |
| disparity<br><br>n. 不相等; 不齐; 差异; 悬殊 | dis-(否定, 相反), **par(相等)**, -ity(性质, 状态)<br>不相等的状态, 即差异或悬殊 |
| parity<br><br>n. 相等; 同等; 相齐; 相同 | **par(相等)**, -ity(性质, 状态)<br>相等或同等的状态 |
| parent<br><br>n. 父亲; 母亲; 根源; 父母; [复] 双亲 | **par(生, 产)**, -ent(人; 物)<br>生育或养育子女的人, 即父母 |
| parentage<br><br>n. 出身; 家系; 门第 | 由 parent“父母、来源”派生<br>父母身份、血统或来源 |
| comparable<br><br>adj. 可比较的; 比得上的 | com-(与, 共同), **par(相等)**, -able(可…的)<br>能够放在一起衡量是否相等的, 即可比较的 |
| comparative<br><br>adj. 比较的 | 源自拉丁语 comparativus, 与 compare“比较”同源<br>涉及比较的; 语法中表示比较级 |
| incomparable<br><br>adj. 不可比较的; 无比的; 无双的 | in-(无, 不, 非), com-(与, 共同), **par(相等)**, -able(可…的)<br>无法放在一起比较的, 即无与伦比的 |
| nonpareil<br><br>adj. 无比的; 无上的 | 借自法语 nonpareil, 由 non“没有”与 pareil“相等者”构成<br>无与伦比的人或物 |
| parental<br><br>adj. 父母的 | parent(词: 父母), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“父母的” |


### par, pear

出现

| 单词 | 拆解 |
| --- | --- |
| appear<br><br>v. 出现; 显露; 来到; 看来好像; 似乎 | ap-(到, 朝, 向), **pear(出现)**<br>来到眼前并显现出来, 因此表示出现、显露 |
| apparition<br><br>n. 幻象(或怪影; 鬼怪等)的出现; 鬼怪; 幽灵; (行星; 彗星等隐没后的)初现 | ap-(到, 朝, 向), **par(出现)**, -ition(行为, 结果)<br>突然显现出来的形象, 常指幻影或幽灵 |
| appearance<br><br>n. 出现; 露面; 外观; 面貌; 外貌 | appear(词: 出现), -ance(性质, 状态)<br>表示与“出现”有关的性质或状态, 即“外表” |
| transparence<br><br>n. 透明; 透明性; 透明度; 透光度 | trans-(横过, 越过), **par(出现)**, -ence(性质, 状态)<br>光能穿过并显现的性质, 即透明 |
| transparency<br><br>n. 透明; 透明性; 透明度 | trans-(横过, 越过), **par(出现)**, -ency(性质, 状态)<br>光能穿过并显现的性质, 即透明度或公开性 |
| apparent<br><br>adj. 明显的; 表面上的 | ap-(到, 朝, 向), **par(出现)**, -ent(…的)<br>显现到眼前的, 因此表示明显的或表面上的 |
| transparent<br><br>adj. 透明的; 清透的; 易看穿的 | trans-(横过, 越过), **par(出现)**, -ent(…的)<br>能够让光穿过并显现另一侧的, 即透明的 |


### parl

说

| 单词 | 拆解 |
| --- | --- |
| parlance<br><br>n. 用语; 讲话; (尤指正式辩论或谈判中的)发言; [总称] 说法 | **parl(说)**, -ance(性质, 状态)<br>表示与“说”有关的性质或状态, 即“说法, 用语” |
| parley<br><br>n. 和谈; 会谈<br>v. 和谈; 谈判 | **parl(说)**, e(连接字母), -y(性质, 状态)<br>围绕“说”这一核心含义构成, 表示“会谈” |
| parliament<br><br>n. 议会; 国会; 英国议会(包括下议院和上议院) | 源自法语 parlement（谈话、议事会）, 与 parler“说话”同源; 记忆锚点是通过讨论处理公共事务的议会 |
| parliamentarian<br><br>n. 国会议员 | parliament(词: 国会), -arian(人)<br>在前词基础上加“-arian”构成名词, 表示“国会议员” |
| parlo(u)r<br><br>n. 客厅; 会客室; 私人谈话室 | 经古法语 parler“说话”相关形式进入英语<br>原指谈话房间, 英式拼作 parlour, 美式拼作 parlor |
| parliamentary<br><br>adj. 议会的; 国会的; 议员的 | parliament(词: 议会), -ary(…的)<br>在前词基础上加“-ary”构成形容词, 表示“议会的” |


### part

部分; 分开

| 单词 | 拆解 |
| --- | --- |
| party<br><br>n. 党; 党派; 政党 | part 分, -y 名词后缀; 由整体“分出来的”---部分人所结成的组织 |
| depart<br><br>v. (人)离开; 启程; 离去; (火车)开出 | de-(脱离, 取消, 除去), **part(分开)**<br>由“离去”与“分开”共同限定词义, 表示“(人)离开, 启程, 离去” |
| partake<br><br>v. 参与; 参加; 分担; 分享 | 由 part“部分”与 take“取”合成, 两个成分在 t 处重合<br>取得或分享其中一部分, 即参与或分享 |
| participate<br><br>v. 参与; 参加; 分享; 分担 | **part(部分)**, i(连接字母), **cip(抓夺)**, -ate(做, 使)<br>取得整体中的一部分, 由此表示参与、参加 |
| apartment<br><br>n. 一套公寓房间 | apart(词: 分开), -ment(场所)<br>从建筑整体中分隔出来供独立居住的一套房间 |
| departure<br><br>n. 离开; 出发; 离职; 违背; 背离 | de-(脱离, 取消, 除去), **part(分开)**, -ure(行为, 结果)<br>从原位置分离离去的行为, 即出发或离开 |
| impartiality<br><br>n. 不偏袒; 不偏不倚; 公正 | im-(无, 不, 非), **part(部分)**, i(连接字母), -ality(性质, 状态)<br>不偏向任何一方的状态, 即公正 |
| partiality<br><br>n. 偏心; 不公正; 偏爱; 癖好 | **part(部分)**, -ial(…的), -ity(性质, 状态)<br>表示与“部分”有关的性质或状态, 即“偏心, 不公正” |
| participant<br><br>n. 参加者; 参与者 | **part(部分)**, i(连接字母), **cip(抓夺)**, -ant(人; 物)<br>取得整体中的一部分、参与其中的人 |
| particle<br><br>n. 粒子; 颗粒; 微粒; 小品词(与动词构成短语动词的副词或介词); 极小量 | **part(部分)**, -icle(小)<br>从整体分出的小部分, 即微粒或粒子 |
| particularity<br><br>n. 特殊性; 特征; 细节; 讲究; 挑剔 | particular(词: 一项), -ity(性质, 状态)<br>由“一项”派生为当前词义 |
| particulate<br><br>n. 微粒<br>adj. 微粒的 | 源自拉丁语 particula“小部分、微粒”<br>由细小粒子组成的; 微粒 |
| parting<br><br>n. 告别; 分歧处; 分界点<br>adj. 离别的; 逝去的; 分隔的 | **part(分开)**, -ing(…的)<br>正在分开或用于分隔的; 名词化后表示离别、分界或分开物 |
| partisan<br><br>n. 党羽; 虔诚信徒; 同党<br>adj. 党派的; 偏袒的; 效忠的 | **part(部分)**, i(连接字母), s(连接字母), -an(…的)<br>围绕“部分”这一核心含义构成, 表示“同党, 同伙, 敌后游击队员” |
| partition<br><br>n. 分开; 划分; 分隔; 隔开部分 | **part(分开)**, -ition(行为, 结果)<br>围绕“分开”这一核心含义构成, 表示“分开, 划分, 分隔” |
| partitive<br><br>adj. 区分的; 表示部分的<br>n. 表示部分的词 | **part(部分)**, -itive(…的)<br>在前词基础上加“-itive”构成名词或形容词, 表示“区分的” |
| impartial<br><br>adj. 公正的; 无偏见的 | im-(无, 不, 非), **part(部分)**, -ial(…的)<br>不分别对待的 |
| parted<br><br>adj. 分开的; 分成部分的 | **part(分开)**, -ed(…的)<br>围绕“部分”这一核心含义构成, 表示“分开的, 分成部分的” |
| particular<br><br>adj. 特殊的; 独特的; 个别的 | **part(部分)**, -icular(…的)<br>分出来的 |
| apart<br><br>adv. 相隔; 分离; 除去; 撇开 | a-(无, 不, 非), **part(分开)**<br>各部分彼此分开, 因此表示相隔、拆开或撇开 |


### pass, pati

忍受; 走, 通过

| 单词 | 拆解 |
| --- | --- |
| compassion<br><br>n. 怜悯; 同情 | com-(与, 共同), **pass(忍受)**, -ion(行为, 结果)<br>与他人共同承受痛苦, 因此表示怜悯、同情 |
| passion<br><br>n. 激情; 热情; 酷爱 | **pass(忍受)**, -ion(行为, 结果)<br>围绕“忍受”这一核心含义构成, 表示“激情, 热情” |
| passivity<br><br>n. 被动(性); 消极状态; 忍受; 服从 | **pass(忍受)**, -ivity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“被动” |
| patience<br><br>n. 耐心; 忍耐力 | **pati(忍受)**, -ence(性质, 状态)<br>表示与“忍受”有关的性质或状态, 即“忍受, 耐心” |
| patient<br><br>adj. 忍耐的; 容忍的; 有耐性的<br>n. 病人; 承受者 | **pati(忍受)**, -ent(…的)<br>承受疾病或治疗的人, 即病人 |
| compatible<br><br>adj. 相容的; 共存的; 适宜的 | 经法语借自中世纪拉丁语 compatibilis, 来自 compati“共同承受”<br>能够相容、共存的 |
| impatient<br><br>adj. 不耐烦的; 急躁的 | im-(无, 不, 非), **pati(忍受)**, -ent(…的)<br>否定或缺少“忍受”所指的性质, 因此表示“不耐烦的, 急躁的” |
| passive<br><br>adj. 消极的; 被动的 | **pass(忍受)**, -ive(…的)<br>表示与“忍受”有关或具有该特征, 即“被动的, 消极的” |


### past

走, 通过; 喂, 食

| 单词 | 拆解 |
| --- | --- |
| encompass<br><br>v. 包含; 包围; 围绕; 围住 | en-(进入, 包围), com-(与, 共同), **pass(走, 通过)**<br>绕行一周把事物纳入范围, 即包围或包含 |
| surpass<br><br>v. 超过; 胜过; 优于 | sur-(超), **pass(走, 通过)**<br>走到某人或某物之上、之外, 即超过 |
| compass<br><br>n. 罗盘(仪); [ 复 ] 圆规 | com-(与, 共同), **pass(走, 通过)**<br>共同绕行并量定范围, 后来指圆规或罗盘 |
| passage<br><br>n. 通道; 走廊; (文章等的)段落; 通过; 流逝 | **pass(走, 通过)**, -age(行为, 结果)<br>通过的过程、路径或文字中的一段 |
| passenger<br><br>n. 乘客; 旅客; 过路人 | 经古法语 passager（过路人、旅客）进入英语, 表示乘客 |
| passer<br><br>n. 过路人; 过客 | **pass(走, 通过)**, -er(人)<br>经过某处的人, 即过路人、过客 |
| passport<br><br>n. 护照 | **pass(走, 通过)**, port(词: 港口)<br>准许持有人通过港口或边境的证件, 即护照 |
| past<br><br>n. 过去; 昔时; 往事<br>adj. 过去的; 结束的; 卸任的<br>prep. 越过; 晚于; 超越 | 由 pass 的历史过去分词 passed 缩合为 past, 后经转化成为形容词、名词和介词<br>核心记忆点是“已经经过的” |
| pastime<br><br>n. 休闲; 娱乐; 消遣 | pass→pas(词: 度过), time(词: 时间)<br>用于度过空闲时间的活动 |
| pastor<br><br>n. (基督教的)牧师; 精神生活方面的指路人; 牧(羊)人 | **past(喂, 食)**, -or(人)<br>表示从事或具有“喂”特征的人, 即“(基督教的)牧师” |
| pastoralism<br><br>n. 畜牧; 田园作品的风格 | 由 pastoral“牧业的、田园的”形成 pastoralism<br>以畜牧为生的生产方式, 或田园作品风格 |
| pastoralist<br><br>n. 放牧者; 畜牧者; 田园诗的作者 | pastoral(词: 牧歌), -ist(人)<br>由“牧歌”派生为当前词义 |
| pasturage<br><br>n. 放牧; 牧场 | 由 pasture“牧场、放牧”形成 pasturage<br>用于放牧的草地或放牧活动 |
| pasture<br><br>n. 牧场; 草地; 牧草<br>v. 放牧; 吃草 | **past(喂, 食)**, -ure(行为, 结果)<br>围绕“喂”这一核心含义构成, 表示“牧场, 放牧” |
| pastureland<br><br>n. 牧场 | pasture(词: 牧场), land(词: 土地)<br>用作放牧的土地 |
| repast<br><br>n. 餐; 就餐<br>v. 享用; 就餐 | re-(回, 向后, 再次), **past(喂, 食)**<br>再次用食物补充体力的一餐, 即餐食、宴席 |
| passable<br><br>adj. 可通行的; 能通过的; 过得去的; 合格的 | **pass(走, 通过)**, -able(可…的)<br>可以通过的, 也引申为勉强合格的 |
| passing<br><br>adj. 经过的; 穿过的; 越过的 | pass(词: 经过), -ing(…的)<br>正在经过或穿过的 |
| pastoral<br><br>adj. 牧(羊)人的; (关于)牧人的生活方式的; 乡村的; 田园诗的 | pastor(词: 牧人), -al(…的)<br>与牧人及牧放生活有关, 引申为乡村或田园诗的 |


### path, pathothy

感情; 疾病, 疗法

| 单词 | 拆解 |
| --- | --- |
| sympathize<br><br>v. 同情 | sym-(共同), **path(感情)**, -ize(…化, 使成)<br>使“感情”共同结合或发挥作用, 因此表示“同情” |
| antipathy<br><br>n. 反感; 厌恶 | anti-(反对, 相反), **pathy(感情)**<br>由“反对”与“感情”共同限定词义, 表示“反感, 厌恶” |
| pathologist<br><br>n. 病理学者 | **patho(感情)**, -logist(…学家)<br>围绕“疾病”这一核心含义构成, 表示“病理学者” |
| pathology<br><br>n. 病理学 | **patho(疾病, 疗法)**, -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“病理学” |
| psychopathy<br><br>n. 心理病态; 精神变态 | **psycho(心灵, 精神)**, **pathy(疾病, 疗法)**<br>由“精神”与“疾病”共同限定词义, 表示“心理病态, 精神变态” |
| sympathy<br><br>n. 同情; 赞同 | sym-(共同), **path(感情)**, -y(性质, 状态)<br>与他人共同感受的状态, 即同情或共鸣 |
| apathetic<br><br>adj. 无情的; 无感情的; 冷漠的; 无动于衷的; 漠不关心的 | a-(无, 不, 非), **path(感情)**, -etic(…的)<br>缺少情感和兴趣, 因此表示冷漠的、无动于衷的 |
| pathogenetic<br><br>adj. 发病的; 致病的; 病原的 | **patho(疾病, 疗法)**, **gen(出生, 产生)**, -etic(…的)<br>与疾病产生或发展有关的, 即发病的 |
| unsympathetic<br><br>adj. 无同情心的 | un-(无, 不, 非), sym-(共同), **path(感情)**, -etic(…的)<br>否定或缺少“感情”所指的性质, 因此表示“无同情心的” |


### pater, patr(i)

父祖; 祖国

| 单词 | 拆解 |
| --- | --- |
| expatriate<br><br>n. 移居国外者; 侨民; 被流放者<br>v. 逐出国外; 脱离国籍; 放逐 | ex-(出, 向外), **patri(祖国)**, -ate(做, 使)<br>离开祖国到国外生活的人, 也可表示放逐、移居国外 |
| patronize<br><br>v. 庇护; 保护 | patron(词: 庇护人), -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“庇护” |
| repatriate<br><br>n. 被遣返回国者<br>v. 把...遣返; 回国 | re-(回, 向后, 再次), **patri(祖国)**, -ate(做, 使)<br>把人送回祖国, 因此表示遣返回国、归国 |
| compatriot<br><br>n. 同国人<br>adj. 同国的; 同胞的 | com-(与, 共同), **patri(祖国)**, -ot(人)<br>使“父”共同结合或发挥作用, 因此表示“同胞” |
| expatriation<br><br>n. 逐出国外 | expatriate→expatriat(词: 移居国外者), -ion(行为, 结果)<br>由“移居国外者”派生为当前词义 |
| paternalism<br><br>n. 家长式统治; 家长作风 | 由 paternal“父亲式的”形成 paternalism<br>像家长替他人作主的治理方式, 即家长作风 |
| paternity<br><br>n. 父亲的身份; 父权; 父系; 渊源 | **pater(父祖)**, n(连接字母), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“父亲的身份” |
| patriarch<br><br>n. 家长; 族长 | **patri(父祖)**, **arch(统治)**<br>父系家族中居首并统领众人的人, 即家长、族长 |
| patriarchy<br><br>n. 父权制; 父权制社会 | **patri(父祖)**, **archy(为首)**<br>围绕“首领”这一核心含义构成, 表示“父权制(社会)” |
| patrimony<br><br>n. 祖传的财物; 遗产; 继承物 | **patri(父祖)**, -mony(状态, 结果)<br>围绕“祖”这一核心含义构成, 表示“祖传的财物, 遗产” |
| patriot<br><br>n. 爱国(主义)者; 爱国者 | **patri(祖国)**, -ot(人)<br>围绕“祖国”这一核心含义构成, 表示“爱国(主义)者” |
| patriotism<br><br>n. 爱国主义; 爱国精神; 爱国心 | patriot(词: 爱国主义者), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“爱国主义” |
| patron<br><br>n. 赞助人; 资助人; 老主顾; 常客; 顾客 | 源自拉丁语 patronus“保护者”, 与 pater“父亲”相关<br>指提供保护、资金或长期支持的人 |
| patronage<br><br>n. 庇护人(或保护人; 赞助人等)的身份(或影响; 作用等); 庇护; 保护 | 由 patron“庇护人、赞助人”形成 patronage<br>庇护人提供的支持、影响或其身份 |
| patronymic<br><br>adj. 源于父名的<br>n. 父系的姓; 源于父名的姓 | **patr(父祖)**, **onym(名)**, -ic(…的)<br>由“父”与“名”共同限定词义, 表示“源于父名(或祖先名)的(姓)” |
| paternal<br><br>adj. (像)父亲的; 父系的 | **pater(父祖)**, n(连接字母), -al(…的)<br>表示与“父”有关或具有该特征, 即“(像)父亲的” |
| patrilineal<br><br>adj. 父系的 | **patri(父祖)**, line(词: 线), -al(…的)<br>由“父”与“线”共同限定词义, 表示“父系的” |
| patronizing<br><br>adj. 以恩人自居的; 屈尊俯就的; 傲慢的 | 词形来源：patronize + ing-form |


### pel, puls

推, 驱逐

| 单词 | 拆解 |
| --- | --- |
| compel<br><br>v. 强迫; 迫使 | com-(与, 共同), **pel(推, 驱逐)**<br>强化“推”这一动作或状态, 因此表示“强迫, 迫使” |
| dispel<br><br>v. 驱散 | dis-(否定, 相反), **pel(推, 驱逐)**<br>由“否定”与“驱”共同限定词义, 表示“驱散” |
| expel<br><br>v. 排出; 把…开除(或除名); 驱逐出境; 喷出 | ex-(出, 向外), **pel(推, 驱逐)**<br>把人或物向外驱赶, 因此表示驱逐、排出 |
| propel<br><br>v. 推进; 推动; 驱使 | pro-(向前, 前进), **pel(推, 驱逐)**<br>由“前进”与“推”共同限定词义, 表示“推进, 推动” |
| repel<br><br>v. 击退; 反击; 抵抗; 防 | re-(回, 向后, 再次), **pel(推, 驱逐)**<br>把来物重新向后推开, 因此表示击退、排斥 |
| repulse<br><br>v. 击退; 拒绝; 反驳 | re-(回, 向后, 再次), **puls(推动, 脉动)**, e(连接字母)<br>用力把来者推回, 因此表示击退、拒绝 |
| impeller<br><br>n. 推动者; 推动器 | impel→impell(词: 推动), -er(人)<br>推动行动的人; 也可引申指推动流体的旋转部件 |
| propeller<br><br>n. 推进者; 推进器; 螺旋桨 | propel→propell(词: 推进), -er(物)<br>产生推进力的螺旋桨 |
| pulse<br><br>n. 脉搏; 脉冲<br>v. 搏动; 跳动 | **puls(推动, 脉动)**, e(连接字母)<br>有节律的推动和搏动, 即脉搏、脉冲 |
| repellent<br><br>adj. 抵抗的; 排斥的; 令人讨厌的<br>n. 防水布; 防护剂 | repel→repell(词: 逐退), -ent(…的)<br>由“逐退”派生为当前词义 |
| compulsory<br><br>adj. 必须做的; 义务的; 强制的; 强迫的 | com-(与, 共同), **puls(推动, 脉动)**, -ory(…的)<br>受到强力推动而不得不做, 因此表示强制的、必修的 |


### pen, penn, pinn

羽毛

| 单词 | 拆解 |
| --- | --- |
| pen<br><br>n. 笔 | 书写工具义来自古法语 penne“羽毛”, 最终源自拉丁语 penna“羽毛”<br>由羽毛笔发展为笔 |
| pennant<br><br>n. 细长三角旗; 尖旗 | 源自 pennon“细长旗帜”的变体<br>表示细长的三角旗或尖旗 |
| pinna<br><br>n. 正羽; 翼 | **pinn(羽毛)**, a(连接字母)<br>围绕“羽毛”这一核心含义构成, 表示“正羽, 翼” |
| pinnate<br><br>adj. 羽状的 | 构词锚点：pinn 表示“羽毛”; -ate 在此为形容词词尾, 不取动词义<br>围绕“羽毛”这一核心含义构成, 表示“羽状的” |


### pen, pent, pun

痛, 罚

| 单词 | 拆解 |
| --- | --- |
| penalize<br><br>v. 对…处以刑事惩罚; 处罚 | penal(词: 刑事的), -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“对…处以刑事惩罚” |
| punish<br><br>v. 惩罚 | **pun(痛, 罚)**, -ish(…的)<br>围绕“罚”这一核心含义构成, 表示“惩罚” |
| repent<br><br>v. 后悔; 悔悟; 悔改; 忏悔 | re-(回, 向后, 再次), **pent(痛, 罚)**<br>由“向后”与“痛”共同限定词义, 表示“后悔” |
| impunity<br><br>n. 不受惩罚 | im-(无, 不, 非), **pun(痛, 罚)**, -ity(性质, 状态)<br>否定或缺少“罚”所指的性质, 因此表示“不受惩罚” |
| penalty<br><br>n. 处罚; 刑罚; 罚金; 害处; 点球 | penal(词: 有关处罚的), -ty(性质, 状态)<br>在前词基础上加“-ty”构成名词, 表示“处罚” |
| penance<br><br>n. 自我惩罚; 忏悔; 悔过<br>v. 使悔罪; 使赎罪 | 经古法语借自拉丁语 paenitentia“悔罪”<br>为悔罪而接受的惩罚或补赎 |
| punishment<br><br>n. 惩罚; 处罚 | punish(词: 惩罚), -ment(行为, 过程)<br>在前词基础上加“-ment”构成名词, 表示“惩罚” |
| repentance<br><br>n. 悔悟; 悔改; 忏悔 | 经古法语借入, 与 repent“悔悟”同源<br>对过错感到悔恨的状态 |
| penal<br><br>adj. 刑事的; 刑法上的; (当)受刑罚的; 刑罚场所的 | 源自拉丁语 poenalis“惩罚的”, 核心 poena 表示处罚<br>与刑罚有关的 |
| punitive<br><br>adj. 给予惩罚的; 惩罚性的 | **pun(痛, 罚)**, -itive(…的)<br>围绕“罚”这一核心含义构成, 表示“给予惩罚的, 惩罚性的” |
| repentant<br><br>adj. 悔悟的; 悔改的; 后悔的 | 经古法语借入, 为 repentir“悔悟”的现在分词形式<br>感到悔悟的 |


### pend, pens

称量, 付钱; 吊, 悬挂

| 单词 | 拆解 |
| --- | --- |
| append<br><br>v. 挂上; 附加 | ap-(到, 朝, 向), **pend(吊, 悬挂)**<br>把一部分悬挂或附加到主体上, 因此表示附加 |
| depend<br><br>v. 取决于; 依赖 | de-(下降, 降低), **pend(吊, 悬挂)**<br>悬挂依附于其上, 即"取决于, 依赖" |
| suspend<br><br>v. 挂; 悬; 悬而未决; 中止; 暂停 | sus-(在下, 从下支撑), **pend(吊, 悬挂)**<br>吊在…之下 |
| poise<br><br>v. 使平衡; 使悬着; 保持...姿势<br>n. 平衡; 均衡; 姿势 | 经古法语 pois“重量”借入, 源自拉丁语 pensum“称量之物”<br>由重量平衡引申为镇定、姿态 |
| ponder<br><br>v. 考虑; 沉思 | 源自拉丁语 ponderare“称重”, 核心 pondus 表示重量<br>在心中衡量, 即深思 |
| spend<br><br>n. 开支<br>v. 花钱; 花费; 消耗(时间) | s(连接字母), **pend(称量, 付钱)**<br>付出金钱、时间或精力 |
| appendage<br><br>n. 附加物; 附属物 | 由 append“附加”形成 appendage<br>附着在主体上的额外部分, 即附属物 |
| appendix<br><br>n. 附加物; 附录; 阑尾 | 源自拉丁语 appendix（悬挂在后面的东西）, 由附属物发展为附录及阑尾 |
| dependency<br><br>n. 依赖; 从属; 属地; 属国 | 由 dependent“依赖的”派生<br>依赖他人或他物的状态 |
| independence<br><br>n. 独立; 自主 | in-(无, 不, 非), de-(下降, 降低), **pend(吊, 悬挂)**, -ence(性质, 状态)<br>不依附、不悬挂在他者之下的状态, 即独立 |
| pendant<br><br>n. 垂饰; 下垂物; 补充的东西 | **pend(吊, 悬挂)**, -ant(人; 物)<br>悬挂下来的饰物 |
| pendency<br><br>n. 悬挂; 悬而未决; 未定 | **pend(吊, 悬挂)**, -ency(性质, 状态)<br>围绕“悬挂”这一核心含义构成, 表示“悬挂” |
| propensity<br><br>n. 趋向; 倾向 | pro-(向前, 前进), **pens(吊, 悬挂)**, -ity(性质, 状态)<br>由“向前”与“悬挂”共同限定词义, 表示“趋向, 倾向” |
| suspense<br><br>n. 悬念; 未定 | sus-(在下, 从下支撑), **pens(吊, 悬挂)**, e(连接字母)<br>由“在下”与“悬挂”共同限定词义, 表示“悬念, 未定” |
| pensioner<br><br>n. 领取养老金者 | pension(词: 养老金), -er(人)<br>在前词基础上加“-er”构成名词, 表示“领取养老金者” |
| dependable<br><br>adj. 可依靠的; 可依赖的; 可靠的 | depend(词: 靠), -able(可…的)<br>在前词基础上加“-able”构成形容词, 表示“可依靠的” |
| impending<br><br>adj. 逼近的; 即将的 | im-(向内, 进入), **pend(吊, 悬挂)**, -ing(…的)<br>悬在头顶、即将落到眼前的, 即迫近的 |
| pendulous<br><br>adj. 悬垂的; 摆动的 | **pend(吊, 悬挂)**, -ulous(…的)<br>围绕“悬挂”这一核心含义构成, 表示“悬垂的” |
| perpendicular<br><br>adj. 垂直的; 竖立的 | per-(通过, 贯穿), **pend(吊, 悬挂)**, -icular(…的)<br>像重物悬线一样笔直向下, 因此表示垂直的 |


### peps, pept

消化

| 单词 | 拆解 |
| --- | --- |
| dyspepsia<br><br>n. 消化不良 | dys-(不良, 坏的), **peps(消化)**, -ia(性质, 状态)<br>由“不良”与“消化”共同限定词义, 表示“消化不良” |
| peptic<br><br>adj. 有助消化的; 胃液素的; 胃蛋白酶的<br>n. 健胃剂; 促进消化物质 | **pept(消化)**, -ic(…的)<br>围绕“消化”这一核心含义构成, 表示“消化性的, 助消化的, 可消化的, 消化液的” |
| peptone<br><br>n. 消化蛋白质; 胨 | **pept(消化)**, -one(酮类化合物)<br>围绕“消化”这一核心含义构成, 表示“消化蛋白质, 胨” |
| dyspeptic<br><br>adj. 消化不良的 | dys-(不良, 坏的), **pept(消化)**, -ic(…的)<br>由“不良”与“消化”共同限定词义, 表示“消化不良的” |


### peri

试验, 尝试

| 单词 | 拆解 |
| --- | --- |
| experience<br><br>n. 经验; 经历<br>v. 经历; 体验 | 源自拉丁语 experientia（试验、经验）, 核心 experiri 意为尝试 |
| experiment<br><br>n. 实验; 试验<br>v. 进行实验; 尝试 | 源自拉丁语 experimentum（试验、验证）, 表示实验 |
| expert<br><br>n. 专家<br>adj. 专业的; 熟练的 | 源自拉丁语 expertus（经过试验、经验丰富的）, 表示专家或熟练的 |
| peril<br><br>n. 危机; 危险; 冒险 | 经古法语进入英语, 源自拉丁语 periculum“危险、试验”<br>表示严重危险 |
| experienced<br><br>adj. 有经验的; 经验丰富的; 老练的 | experience→experienc(词: 经验), -ed(…的)<br>具有经验的, 即有经验的 |
| experimental<br><br>adj. 实验(性)的; 试验(性)的 | experiment(词: 试验), -al(…的)<br>以实际试验来检验想法, 因此表示实验的、试验性的 |
| perilous<br><br>adj. 危险的 | peril(词: 危险), -ous(…的)<br>在前词基础上加“-ous”构成形容词, 表示“危险的” |


### pet, peat

追求, 争夺

| 单词 | 拆解 |
| --- | --- |
| compete<br><br>v. 竞争; 角逐; 比赛 | com-(与, 共同), **pet(追求, 争夺)**, e(连接字母)<br>共同追求争夺同一目标, 即"竞争" |
| appetite<br><br>n. 食欲; 强烈欲望 | 源自拉丁语 appetitus“欲求”, 由 ad“朝向”与 petere“追求”形成<br>朝食物或目标产生追求欲望, 即食欲、欲望 |
| appetizer<br><br>n. 开胃品 | appetize→appetiz(词: 使开胃), -er(物)<br>用于刺激食欲的开胃菜 |
| competition<br><br>n. 竞争; 角逐; 比赛 | com-(与, 共同), **pet(追求, 争夺)**, -ition(行为, 结果)<br>共同追逐争夺的行为, 即"竞争" |
| impetus<br><br>n. 推动力; 促进; 动量; 惯性 | im-(向内, 进入), **pet(追求, 争夺)**, -us(名词词尾)<br>推动事物向前追求目标的力量, 即动力 |
| petition<br><br>n. 请愿书; 诉状<br>v. 请愿; 申诉 | **pet(追求, 争夺)**, -ition(行为, 结果)<br>围绕“追求”这一核心含义构成, 表示“申请, 请求, 请愿” |
| petitioner<br><br>n. 请求者; 请愿者 | petition(词: 正式请求), -er(人)<br>在前词基础上加“-er”构成名词, 表示“请求者” |
| repeat<br><br>n. 重复; 重播<br>v. 重复; 重说<br>adj. 重复的 | re-(回, 向后, 再次), **peat(追求, 争夺)**<br>由“重新”与“追求”共同限定词义, 表示“重复” |
| repetition<br><br>n. 反复; 重复 | re-(回, 向后, 再次), **pet(追求, 争夺)**, -ition(行为, 结果)<br>再次做或说同一内容的过程 |
| centripetal<br><br>adj. 向心的 | **centr(中心)**, i(连接字母), **pet(追求, 争夺)**, -al(…的)<br>由“中心”与“追求”共同限定词义, 表示“向心的” |
| competent<br><br>adj. 胜任的; 有能力的; 能干的 | com-(与, 共同), **pet(追求, 争夺)**, -ent(…的)<br>能与人一同竞争角逐的, 即"有能力的" |
| impetuous<br><br>adj. 冲动的; 猛烈的; 刺激的 | im-(向内, 进入), **pet(追求, 争夺)**, u(连接字母), -ous(…的)<br>被内在冲力驱使着猛然向前追求的, 即冲动、迅猛的 |
| perpetual<br><br>adj. 永久的; 终身的; 持续不断的; 一再重复的 | per-(通过, 贯穿), **pet(追求, 争夺)**, -ual(…的)<br>不断持续向前的, 即永久或反复不断的 |
| propitious<br><br>adj. 幸运的; 顺意的; 慈悲的 | 源自拉丁语 propitius“有利、仁慈的”<br>条件有利、预示成功的 |
| repeated<br><br>adj. 一再的; 再三的 | 词形来源：repeat + ed-form |


### petr(o), petr(i)

石, 岩石

| 单词 | 拆解 |
| --- | --- |
| petrify<br><br>v. (使)石化; (使)僵化; (使)发呆 | **petri(石, 岩石)**, -fy(…化, 做…)<br>使事物呈现“石”与“…化, 做…”所表达的状态, 即“(使)石化” |
| petrography<br><br>n. 岩相学; 岩类学 | **petro(石, 岩石)**, **graph(写, 画)**, -y(活动)<br>对岩石进行描述、记录和分类的研究 |
| petrol<br><br>n. 汽油; 石油 | **petr(石, 岩石)**, -ol(醇; 油)<br>来自 petroleum oil 的缩略, 原意为‘岩石之油’, 即汽油 |


### phag

吃, 食

| 单词 | 拆解 |
| --- | --- |
| macrophage<br><br>n. 巨噬细胞 | **magn(i), macr(o)(长, 大)**, **phag(吃, 食)**<br>免疫系统中体积巨大且能吞噬消化外来病原体的大细胞 |
| geophagy<br><br>n. 食土癖; 吃土 | **ge(o)(地)**, **phag(吃, 食)**, -y(活动)<br>某些动物或人类食用泥土矿物的行为习性 |


### phil(o)

爱

| 单词 | 拆解 |
| --- | --- |
| Anglophile<br><br>n. 亲英派的人 | anglo(词: 英国人), **phil(爱)**, e(连接字母)<br>由“盎格鲁、英国”与“爱”共同限定词义, 表示“亲英派的人” |
| philanthropist<br><br>n. 博爱主义者; 慈善家 | **phil(爱)**, **anthrop(人类)**, -ist(人)<br>由“爱”与“人类”共同限定词义, 表示“博爱主义者, 慈善家” |
| philanthropy<br><br>n. 博爱主义; 慈善; 善心 | 由希腊语 philos“爱”与 anthropos“人类”构成<br>对人类的关爱, 即慈善 |
| philologist<br><br>n. 语文学家; 语言学家 | **philo(爱)**, **log(说, 言)**, -ist(人)<br>爱好并研究语言文字的人, 即语言学者或文献学者 |
| philology<br><br>n. 语文(文献)学; 语言学 | 由希腊语 philos“爱”与 logos“语言、学问”构成<br>对语言和文献的研究 |
| thermophilic<br><br>adj. 喜温的 | **thermo(热)**, **phil(爱)**, -ic(…的)<br>偏爱温热环境并在其中生长良好, 因此表示喜温的 |


### phob

怕, 厌恶

| 单词 | 拆解 |
| --- | --- |
| acrophobia<br><br>n. 恐高症 | **acro(尖锐)**, **phob(怕, 厌恶)**, -ia(性质, 状态)<br>对“高处”产生强烈恐惧或厌恶, 即“恐高症” |
| hydrophobia<br><br>n. 恐水病 | **hydro(水)**, **phob(怕, 厌恶)**, -ia(性质, 状态)<br>对“水”产生强烈恐惧或厌恶, 即“恐水病” |
| photophobia<br><br>n. 怕光; 畏光; 羞明 | **photo(光)**, **phob(怕, 厌恶)**, -ia(性质, 状态)<br>对“光”产生强烈恐惧或厌恶, 即“怕光, 畏光, 羞明” |
| xenophobe<br><br>n. 畏惧和憎恨外国人(或事物)的人 | **xeno(异)**, **phob(怕, 厌恶)**, e(连接字母)<br>对“异”产生强烈恐惧或厌恶, 即“畏惧和憎恨外国人(或事物)的人” |
| xenophobic<br><br>adj. 畏惧和憎恨外国人(或事物)的 | xenophobia→xenophob(词: 无端畏惧和憎恨外国人), -ic(…的)<br>在前词基础上加“-ic”构成形容词, 表示“畏惧和憎恨外国人的” |


### phon(o)

声音

| 单词 | 拆解 |
| --- | --- |
| dysphonia<br><br>n. 发音困难 | dys-(不良, 坏的), **phon(声音)**, -ia(性质, 状态)<br>由“不良”与“声音”共同限定词义, 表示“发音困难” |
| euphony<br><br>n. 悦耳的声音 | eu-(良好, 优美), **phon(声音)**, -y(活动)<br>由“良好”与“声音”共同限定词义, 表示“悦耳的声音” |
| gramophone<br><br>n. 留声机 | **gram(书写, 记录)**, o(连接元音), **phon(声音)**, e(连接字母)<br>由“书写”与“声音”共同限定词义, 表示“留声机” |
| microphone<br><br>n. 扩音器; 麦克风; 话筒 | **micro(微, 小)**, **phon(声音)**, e(连接字母)<br>把微小声音放大 |
| phonetics<br><br>n. 语音学; 发音学 | 源自希腊语 phōnētikos（声音的）形成, 指研究语音的学科 |
| phonics<br><br>n. 声学; 基础语音教学法 | **phon(声音)**, -ics(…学)<br>以“声音”为研究对象的学科, 即“声学” |
| phonogram<br><br>n. 音标文字; 表音符号; 唱片; 录音片 | **phono(声音)**, **gram(书写, 记录)**<br>由“声音”与“文字”共同限定词义, 表示“音标文字, 表音符号” |
| phonology<br><br>n. 音位学; 音韵学 | **phono(声音)**, -logy(…学, …研究)<br>以“声音”为研究对象的学科, 即“音位学” |
| phonorecord<br><br>n. 唱片 | **phono(声音)**, record(词: 记录)<br>记录声音并可重放的载体, 即唱片、录音记录 |
| polyphone<br><br>n. 多音字母; 多音符号 | poly-(多, 复), **phon(声音)**, e(连接字母)<br>由“多”与“声音”共同限定词义, 表示“多音字母” |
| symphony<br><br>n. 交响乐; 交响曲 | 源自希腊语 symphōnia（声音和谐一致）, 记忆锚点是多种声音共同组织成和谐的音乐作品 |
| telephone<br><br>n. 电话 | **tele(远)**, **phon(声音)**, e(连接字母)<br>由远处(通过电)传来的声音 |
| cacophonous<br><br>adj. 音调不和谐的 | **caco(不良)**, **phon(声音)**, -ous(…的)<br>由“不良”与“声音”共同限定词义, 表示“音调不和谐的” |
| symphonic<br><br>adj. 交响乐的 | sym-(共同), **phon(声音)**, -ic(…的)<br>多种声音共同和谐组合, 因此表示交响乐的 |


### phor

携带, 承载

| 单词 | 拆解 |
| --- | --- |
| phosphor<br><br>n. 磷光体; 黄磷; [P.] 晓星; 启明星; 金星 | **phosphor(磷, 磷光)**<br>表示发光物质或磷光体 |
| phosphorus<br><br>n. 磷; 磷光体 | **phosphor(磷, 磷光)**, -us(名词词尾)<br>词根本身即表示“磷”, 整词沿用该义 |
| phosphorous<br><br>adj. 磷的; 含磷的 | **phosphor(磷, 磷光)**, -ous(…的)<br>在前词基础上加“-ous”构成形容词, 表示“磷的” |


### phosph(o), phosphor(o)

磷, 磷光

| 单词 | 拆解 |
| --- | --- |
| phosphate<br><br>n. 磷酸盐; 磷酸脂 | 构词锚点：phosph 表示“磷, 磷光”; -ate 在此为化学命名词尾, 不取动词义<br>围绕“磷”这一核心含义构成, 表示“磷酸盐” |
| phosphide<br><br>n. 磷化物 | **phosph(磷, 磷光)**, -ide(化合物)<br>围绕“磷”这一核心含义构成, 表示“磷化物” |
| phosphite<br><br>n. 亚磷酸盐 | **phosph(磷, 磷光)**, -ite(矿物)<br>含亚磷酸根的物质, 即亚磷酸盐 |
| phosphor<br><br>n. 磷光体; 黄磷; [P.] 晓星; 启明星; 金星 | **phosphor(磷, 磷光)**<br>表示发光物质或磷光体 |
| phosphorescence<br><br>n. 磷光(现象) | **phosphor(磷, 磷光)**, -escence(开始或正在形成某种状态)<br>在前词基础上加“-escence”构成名词, 表示“磷光” |
| phosphorus<br><br>n. 磷; 磷光体 | **phosphor(磷, 磷光)**, -us(名词词尾)<br>词根本身即表示“磷”, 整词沿用该义 |
| phosphorescent<br><br>adj. 发磷光的 | **phosphor(磷, 磷光)**, -escent(开始或正在形成…的)<br>在前词基础上加“-escent”构成形容词, 表示“发磷光的” |
| phosphoric<br><br>adj. 磷的; 像磷的; 含磷的; 含有五价磷的 | **phosphor(磷, 磷光)**, -ic(…的)<br>表示与“磷”有关或具有该特征, 即“磷的” |


### phot(o)

光

| 单词 | 拆解 |
| --- | --- |
| photoemission<br><br>n. 光电发射 | 由 photo“光”与 emission“发射”构成<br>光照引起电子等粒子发射 |
| photograph<br><br>n. 照片<br>v. 拍照; 摄影 | **photo(光)**, **graph(写, 画)**<br>把实物的影子录下来 |
| photometry<br><br>n. 光度学; 测光法 | **photo(光)**, meter→metr(词: 测量), -y(性质, 状态)<br>测量光强等光学量的活动和学科 |


### phren(o)

膈, 精神

| 单词 | 拆解 |
| --- | --- |
| phrenic<br><br>adj. 膈的; 精神的, 心理的 | **phren(膈, 精神)**, -ic(…的)<br>表示与“膈”有关或具有该特征, 即“膈的” |
| phrenology<br><br>n. 颅相学, 骨相学 | **phreno(膈, 精神)**, -logy(…学, …研究)<br>以“膈”为研究对象的学科, 即“颅相学, 骨相学” |


### physi(o)

自然; 物理; 身体机能

| 单词 | 拆解 |
| --- | --- |
| physicalism<br><br>n. 物理主义 | physical(词: 物理学的), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“物理主义” |
| physician<br><br>n. 医师; (尤指)内科医生 | 经法语和拉丁语进入英语, 远源与希腊语 physis“自然”及医术研究相关<br>指接受专业训练的医生 |
| physicist<br><br>n. 物理学家; 物理学研究者 | **physi(物理)**, c(连接字母), -ist(人)<br>从事物理学研究的人, 即物理学家 |
| physics<br><br>n. 物理学 | **phys(物理)**, -ics(…学)<br>以“物理”为研究对象的学科, 即“物理学” |
| physiography<br><br>n. 地文学; 自然地理学 | **physio(自然)**, **graph(写, 画)**, -y(活动)<br>记录或描绘“自然”的方法, 即“地文学, 自然地理学” |
| physiology<br><br>n. 生理学 | **physio(自然)**, -logy(…学, …研究)<br>以“自然”为研究对象的学科, 即“生理学” |
| physique<br><br>n. 体格 | 借自法语 physique“体格”, 原为 physique naturelle“自然科学”的简称用法之一<br>指人体外形和体格 |
| physical<br><br>adj. 物质的; 自然 (界) 的; 物理的; 身体的 | **phys(物理)**, -ical(…的)<br>与自然、物质或身体有关, 因此表示物理的、物质的或身体的 |


### phyll(o)

叶

| 单词 | 拆解 |
| --- | --- |
| chlorophyll<br><br>n. 叶绿素 | **chloro(绿, 氯)**, **phyll(叶)**<br>由“绿”与“叶”共同限定词义, 表示“叶绿素” |
| mesophyll<br><br>n. 叶肉 | **meso(中间)**, **phyll(叶)**<br>叶中间的部分 |


### phyt(o)

植物

| 单词 | 拆解 |
| --- | --- |
| phytochemistry<br><br>n. 植物化学 | **phyto(植物)**, chemistry(词: 化学)<br>由“植物”与“化学”共同限定词义, 表示“植物化学” |
| phytopathology<br><br>n. 植物病理学 | **phyto(植物)**, **patho(感情)**, -logy(…学, …研究)<br>以“植物、疾病”为研究对象的学科, 即“植物病理学” |
| phytotherapy<br><br>n. 植物治疗法; 本草疗法 | **phyto(植物)**, **therapy(治疗, 疗法)**<br>由“植物”与“治疗”共同限定词义, 表示“植物治疗法, 本草疗法” |
| phytotoxicity<br><br>n. 植物毒性 | **phyto(植物)**, **tox(毒)**, -icity(性质, 状态)<br>由“植物”与“毒”共同限定词义, 表示“植物毒性” |
| xerophyte<br><br>n. 旱生植物 | **xero(干燥)**, **phyt(植物)**, e(连接字母)<br>由“干燥”与“植物”共同限定词义, 表示“旱生植物” |


### pi

忠诚, 献身

| 单词 | 拆解 |
| --- | --- |
| impiety<br><br>n. 不虔诚; 不敬; 不孝; 不敬 (或不孝) 的行为 (或言论) | im-(无, 不, 非), **pi(忠诚, 献身)**, -ety(性质, 状态)<br>否定或缺少“忠诚”所指的性质, 因此表示“不虔诚” |
| impious<br><br>adj. 不虔诚的; 不敬的; 不孝的 | im-(无, 不, 非), **pi(忠诚, 献身)**, -ous(…的)<br>否定或缺少“忠诚”所指的性质, 因此表示“不虔诚的” |


### pict, pig

画, 描绘

| 单词 | 拆解 |
| --- | --- |
| depict<br><br>v. 描述; 描绘; 描写; 描画 | de-(一再等加强意义), **pict(画, 描绘)**<br>反复描画呈现, 即"描绘" |
| pictograph<br><br>n. 象形文字 | **pict(画, 描绘)**, o(连接元音), **graph(写, 画)**<br>记录或描绘“画”的方法, 即“象形文字” |
| picture<br><br>n. 绘画; 图画; 画像; 图片 | **pict(画, 描绘)**, -ure(行为, 结果)<br>围绕“画”这一核心含义构成, 表示“绘画, 图画” |
| pigment<br><br>n. 色素; 颜料 | **pig(画, 描绘)**, -ment(物)<br>用于描画或赋予颜色的物质, 即颜料或色素 |
| pigmentation<br><br>n. 着色(作用); 色素沉着 | pigment(词: 色素), -ation(行为, 结果)<br>由“色素”派生为当前词义 |
| pictographic<br><br>adj. 象形文字的 | pictograph(词: 象形文字), -ic(…的)<br>在前词基础上加“-ic”构成形容词, 表示“象形文字的” |
| picturesque<br><br>adj. 风景如画的; 独特的 | picture→pictur(词: 图画), -esque(…的)<br>在前词基础上加“-esque”构成形容词, 表示“如画的” |


### pil, pill

柱, 堆; 掠夺; 药丸

| 单词 | 拆解 |
| --- | --- |
| compile<br><br>v. 编纂; 汇编 | 源自“把材料聚集到一起”的构词意象<br>表示收集整理成作品, 或把程序转换成可执行形式 |
| pilfer<br><br>v. 小偷小摸; 偷窃 | **pil(掠夺)**, **fer(带, 拿)**<br>把东西偷偷掠走、拿走, 即偷窃 |
| pile<br><br>n. 一堆; 叠; 桩<br>v. 堆积; 叠放 | **pil(柱, 堆)**, e(连接字母)<br>物体堆叠形成的一堆, 也可转化作动词 |
| piling<br><br>n. 桩; 桩基; 桩材; 打桩(工程) | **pil(柱, 堆)**, -ing(物)<br>用于支撑地基的一组桩, 即桩基 |
| pillar<br><br>n. 柱; 台柱; 栋梁; 中坚; 柱子 | **pill(柱, 堆)**, -ar(…的)<br>围绕“柱”这一核心含义构成, 表示“柱子” |
| pill<br><br>n. 药丸; 丸剂 | 经中古荷兰语或中古低地德语借入, 最终与拉丁语 pilula“小球”相关<br>因药剂制成小球状而表示药丸 |
| pillbox<br><br>n. 药丸盒 | pill(词: 药丸), box(词: 盒子)<br>盛放药丸的小盒 |
| pilferage<br><br>n. 小偷小摸; 偷窃; 赃物 | 由 pilfer“小偷小摸”形成 pilferage<br>零星偷窃的行为或所得赃物 |
| pillage<br><br>n. 掠夺; 掠夺物<br>v. 掠夺; 劫掠 | 经古法语 pillage 进入英语<br>表示在战争或骚乱中抢掠财物 |


### pisc(i)

鱼

| 单词 | 拆解 |
| --- | --- |
| pisciculture<br><br>n. 养鱼学; 养鱼术; 鱼类养殖; 养鱼业 | **pisci(鱼)**, **cult(耕作, 培养)**, -ure(行为, 结果)<br>由“鱼”与“养殖”共同限定词义, 表示“养鱼, 鱼类养殖, 养鱼业” |
| piscine<br><br>adj. 鱼(类)的; 似鱼的 | **pisc(鱼)**, -ine(…的)<br>词根本身即表示“鱼”, 整词沿用该义 |


### plac

使平静; 使愉快

| 单词 | 拆解 |
| --- | --- |
| placate<br><br>v. 抚慰; 安抚 | **plac(使平静)**, -ate(做, 使)<br>围绕“使平静”这一核心含义构成, 表示“抚慰, 安抚” |
| placebo<br><br>n. 安慰剂; 安慰物; 宽慰话 | 直接来自拉丁语 placebo“我将取悦”, 源自 placere“使愉快”<br>原指安慰性治疗, 现指安慰剂 |
| placid<br><br>adj. 平静的; 安静的; 温和的 | **plac(使平静)**, -id(…的)<br>围绕“使平静”这一核心含义构成, 表示“平静的, 安静的, 温和的” |


### plan(o), plan(i), plain

平坦, 清楚

| 单词 | 拆解 |
| --- | --- |
| explain<br><br>v. 解释; 说明 | ex-(出, 向外), **plain(平坦, 清楚)**<br>说明清楚 |
| explanation<br><br>n. 解释; 说明 | ex-(出, 向外), **plan(平坦, 清楚)**, -ation(行为, 结果)<br>把原本复杂或隐蔽的内容展开讲清, 因此表示解释、说明 |
| plain<br><br>adj. 清楚的; 朴素的; 平常的; 坦率的<br>n. 平原 | **plain(平坦, 清楚)**<br>平坦的地面即平原; 由无阻碍引申为清楚、朴素 |
| plainsman<br><br>n. 平原居民 | plain(词: 平原), s(连接字母), man(词: 人)<br>生活在平原地区的人 |
| plan<br><br>n. 计划; 方案 | **plan(平坦, 清楚)**<br>围绕“平坦”这一核心含义构成, 表示“计划” |
| plane<br><br>n. 平面; 扁平物; 机翼<br>v. 将...刨平; 刨平; 掠过水面<br>adj. 平的; 平面的 | **plan(平坦, 清楚)**, e(连接字母)<br>平坦的面, 即平面; 也可转化作形容词 |
| planisphere<br><br>n. 平面球体图 | **plani(平坦, 清楚)**, sphere(词: 球体)<br>由“平坦”与“球”共同限定词义, 表示“平面球体图” |
| planar<br><br>adj. 平(面)的 | **plan(平坦, 清楚)**, -ar(…的)<br>围绕“平坦”这一核心含义构成, 表示“平(面)的” |


### plan(o)

平坦, 清楚

| 单词 | 拆解 |
| --- | --- |
| planet<br><br>n. 行星 | **plan(平坦, 清楚)**, -et(小)<br>围绕“流动的”这一核心含义构成, 表示“行星” |
| planetarium<br><br>n. 太阳系仪; 天象仪; 天文馆 | planet(词: 行星), -arium(场所, 地点)<br>围绕“行星”这一核心含义构成, 表示“太阳系仪, 天象仪” |
| planetoid<br><br>n. 小行星; 类似行星的物体 | planet(词: 行星), -oid(似…的（物）)<br>在前词基础上加“-oid”构成名词, 表示“小行星” |
| planetary<br><br>adj. 行星的; 像行星般运动的; 流动的; 迁移不定的 | planet(词: 行星), -ary(…的)<br>在前词基础上加“-ary”构成形容词, 表示“行星的” |


### plas, plast

形成, 塑造

| 单词 | 拆解 |
| --- | --- |
| hypoplasia<br><br>n. 发育不全; 细胞减生(现象) | hypo-(在下, 低于), **plas(形成, 塑造)**, -ia(性质, 状态)<br>由“不足”与“形成”共同限定词义, 表示“发育不全” |
| plastic<br><br>adj. 有塑性的; 塑料的<br>n. 塑料 | **plast(形成, 塑造)**, -ic(…的)<br>表示与“塑造”有关或具有该特征, 即“可塑的” |
| plasticity<br><br>n. 可塑性 | plastic(词: 可塑性物质), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“可塑性” |
| hypoplastic<br><br>adj. 发育不全的 | hypo-(在下, 低于), **plast(形成, 塑造)**, -ic(…的)<br>由“不足”与“形成”共同限定词义, 表示“发育不全的” |


### plasm, plast

原生质, 原浆

| 单词 | 拆解 |
| --- | --- |
| plasma<br><br>n. 血浆; 淋巴液; 原生质; 等离子体 | **plasm(原生质, 原浆)**, a(连接字母)<br>围绕“原浆”这一核心含义构成, 表示“血浆, 淋巴液” |
| plasmin<br><br>n. 胞质素; 胞浆素 | **plasm(原生质, 原浆)**, -in(…素)<br>在前词基础上加“-in”构成名词, 表示“胞质素, 胞浆素” |
| protoplast<br><br>n. 原物; 原型; 原人(指人类的始祖); 原生质体 | **proto(第一, 原始)**, **plast(形成, 塑造)**<br>由“原始”与“形成”共同限定词义, 表示“原物, 原型” |


### plat, platy

平, 扁平

| 单词 | 拆解 |
| --- | --- |
| plate<br><br>n. 盘子; 板块; 牌照<br>v. 镀金/银; 电镀 | **plat(平, 扁平)**, e(连接字母)<br>扁平的片状物, 由此表示盘、薄板并可转化作动词 |
| plateau<br><br>n. 高原 | 直接借自法语 plateau（平坦高地、托盘）, 表示高原或稳定阶段 |
| platelet<br><br>n. 血小板 | plate(词: 片状物), -let(小)<br>字面为“小片”, 因血小板形态而得名 |
| platform<br><br>n. 平台; 台; 站台; 月台 | **plat(平, 扁平)**, -form(…形状的)<br>围绕“平”这一核心含义构成, 表示“平台, 台” |
| platitude<br><br>n. 老生常谈; 陈词滥调; 平凡; 陈腐 | **plat(平, 扁平)**, -itude(性质, 状态)<br>围绕“平”这一核心含义构成, 表示“老生常谈, 陈词滥调” |


### plaud, plaus

鼓, 掌

| 单词 | 拆解 |
| --- | --- |
| applaud<br><br>v. 喝彩; 欢呼; 鼓舞; 称赞 | ap-(到, 朝, 向), **plaud(鼓, 掌)**<br>朝表演者拍手表达赞赏, 因此表示鼓掌、称赞 |
| applause<br><br>n. 鼓掌欢迎; 欢呼 | ap-(到, 朝, 向), **plaus(鼓, 掌)**, e(连接字母)<br>朝表演者拍手欢呼, 因此表示掌声、喝彩 |
| plausible<br><br>adj. (解释或叙述) 看似合理的; 看似道理的; 貌似可信的; 巧言令色的; 花言巧语的 | **plaus(鼓, 掌)**, -ible(可…的)<br>可让人拍手称好的 |


### pleo

多

| 单词 | 拆解 |
| --- | --- |
| pleomorphic<br><br>adj. 多形的; 多形态的 | **pleo(多)**, **morph(o)(形)**, -ic(…的)<br>具有多种不同形态或表现形式的 |
| pleonasm<br><br>n. 赘词; 冗词 | **pleo(多)**, n(连接字母), -asm(结果, 状态)<br>使用过多且语义冗余重复的词句表达 |


### plod, plos

拍手, 鼓掌; 爆裂

| 单词 | 拆解 |
| --- | --- |
| explode<br><br>v. (使)爆炸; 急剧扩大; 激增; (情感)迸发; 爆发 | ex-(出, 向外), **plod(爆裂)**, e(连接字母)<br>向外爆裂, 即爆炸 |
| implode<br><br>v. 内爆; 从内部崩溃 | im-(向内, 进入), **plod(爆裂)**, e(连接字母)<br>向内爆裂或从内部崩塌 |
| explosion<br><br>n. 爆炸; 激增; 爆发; 迸发 | ex-(出, 向外), **plos(爆裂)**, -ion(行为, 结果)<br>向外爆裂的过程或结果, 即爆炸 |
| explosive<br><br>adj. 易爆发的; 爆炸的; 暴躁的<br>n. 炸药; 爆破音 | explode→explos(词: 爆炸), -ive(…的)<br>能够爆炸的物质 |
| implosion<br><br>n. 爆聚; 内向爆炸; 内破裂 | im-(向内, 进入), **plos(爆裂)**, -ion(行为, 结果)<br>向内爆裂的过程, 即内爆 |


### ple, pli, ply, plen(i)

满, 全

| 单词 | 拆解 |
| --- | --- |
| accomplish<br><br>v. 完成; 实现 | ac-(到, 朝, 向), com-(与, 共同), **pl(满, 全)**, -ish(…的)<br>把事情推进到完全完成的状态, 因此表示完成、实现 |
| complete<br><br>v. 完成; 完工; 使圆满<br>adj. 完全的; 十足的; 完成的 | 经古法语或直接借自拉丁语 completus“填满、完成”<br>填满而无缺失, 即完整的 |
| comply<br><br>v. 服从; 顺从(命令) | com-(与, 共同), **ply(折, 折叠)**<br>使自己的行为顺着规则折合一致, 因此表示遵守、顺从 |
| implement<br><br>n. 工具<br>v. 完成; 贯彻; 履行; 把⋯填满; 补充 | 源自拉丁语 implementum（填充物、完成手段）, 后来指工具或实施 |
| supply<br><br>n. 供应; 供给量; 补给品<br>v. 供应; 提供 | sup-(在下, 向下), **ply(折, 折叠)**<br>从下方补足缺少的部分, 因此表示供应、提供 |
| accomplishment<br><br>n. 完成; 实现 | accomplish(词: 完成), -ment(结果)<br>完成某事后取得的结果, 即成就 |
| complement<br><br>n. 补充物; 补足物<br>v. 补充; 补足; 使完美; 使更具吸引力 | com-(与, 共同), **ple(满, 全)**, -ment(物)<br>共同填满缺失部分的事物, 即补足物; 也可转化作动词 |
| compliance<br><br>n. 依从; 屈从 | com-(与, 共同), **pli(满, 全)**, -ance(性质, 状态)<br>完全听别人的 |
| compliment<br><br>n. 恭维(的话或行为); 问候; 致意 | 源自意大利语 complimento（礼貌表示）, 记忆锚点是用赞美的话向对方表达敬意或问候 |
| supplement<br><br>n. 补充物; 增刊<br>v. 增补; 补充 | 源自拉丁语 supplementum（补足物）, 核心 supplere 意为填满 |
| plenipotentiary<br><br>adj. 有全权的; 全权代表的<br>n. 全权大使; 全权代表 | 源自拉丁语 plenus“完全”与 potentia“权力”<br>拥有全权的使节 |
| plenitude<br><br>n. 完全; 充分; 充足; 丰富 | **plen(满, 全)**, -itude(性质, 状态)<br>围绕“全”这一核心含义构成, 表示“完全, 充分” |
| compliant<br><br>adj. 依从的; 屈从的 | com-(与, 共同), **pli(满, 全)**, -ant(…的)<br>在前词基础上加“-ant”构成形容词, 表示“依从的” |
| plenary<br><br>adj. 完全的; 全部的; 充分的; 绝对的 | **plen(满, 全)**, -ary(…的)<br>围绕“全”这一核心含义构成, 表示“完全的, 全部的, 充分的” |


### plex

编织, 交错; 重叠

| 单词 | 拆解 |
| --- | --- |
| perplex<br><br>v. 使复杂化; 使纠缠不清; 使困惑 | per-(通过, 贯穿), **plex(编织, 交错)**<br>把事物彻底交叠缠绕, 使人难以理清, 因此表示使困惑、使复杂 |
| supplicate<br><br>v. 恳求; 哀求 | sup-(在下, 向下), **plic(折, 折叠)**, -ate(做, 使)<br>折下腰 |
| complex<br><br>n. 综合体; 情结; 络合物<br>adj. 复杂的; 组合的 | com-(与, 共同), **plex(编织, 交错)**<br>许多部分交叠、编结在一起, 因此表示复杂的或综合体 |
| complexity<br><br>n. 复杂 (性) | com-(与, 共同), **plex(编织, 交错)**, -ity(性质, 状态)<br>许多部分交织在一起的复杂状态 |
| reply<br><br>n. 答复; 回信<br>v. 回复; 答复 | re-(回, 向后, 再次), **ply(折, 折叠)**<br>把话折返回对方, 因此表示回复、答复 |
| duplex<br><br>adj. 二重的; 二倍的; 双的 | **du(二, 双)**, **plex(重叠)**<br>由两个部分重叠或组成的, 即复式或双工的 |
| multiplex<br><br>adj. 多重的 | multi-(多), **plex(编织, 交错)**<br>由“多”与“重叠”共同限定词义, 表示“多重的” |


### plic, ply

折

| 单词 | 拆解 |
| --- | --- |
| apply<br><br>v. 申请; 请求; 适用; 运用 | ap-(到, 朝, 向), **ply(折, 折叠)**<br>把一个事物贴合、折向另一个事物, 因此表示应用、申请 |
| complicate<br><br>v. 使复杂化; 使混乱 | com-(与, 共同), **plic(折, 折叠)**, -ate(做, 使)<br>把许多部分折叠缠在一起, 因此表示使复杂、复杂的 |
| explicate<br><br>v. 解释; 说明; 阐明 | ex-(出, 向外), **plic(折, 折叠)**, -ate(做, 使)<br>揭出深奥之处 |
| implicate<br><br>v. 含有⋯⋯的意思; 牵连; 使卷入 | im-(向内, 进入), **plic(折, 折叠)**, -ate(做, 使)<br>包在里面 |
| imply<br><br>n. V・暗指; 意味着<br>v. 意味; 表明; 暗示 | im-(向内, 进入), **ply(折, 折叠)**<br>把意思折叠包含在话语内部, 因此表示暗指、意味着 |
| multiply<br><br>v. (使)增加; (使)繁殖; 乘; 使相乘; （使）成倍增加 | multi-(多), **ply(折, 折叠)**<br>使数量多次折叠增加, 因此表示乘、繁殖或增加 |
| complication<br><br>n. 复杂; 混乱; 纠纷 | com-(与, 共同), **plic(折, 折叠)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“复杂” |
| complicity<br><br>n. 同谋关系; 共犯关系 | com-(与, 共同), **plic(折, 折叠)**, -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“同谋关系” |
| multiplicity<br><br>n. 多重性; 多倍; 多样; 复杂 | multi-(多), **plic(折, 折叠)**, -ity(性质, 状态)<br>由“多”与“折”共同限定词义, 表示“多重性” |
| explicit<br><br>adj. 详述的; 明晰的 | ex-(出, 向外), **plic(折, 折叠)**, -it(具有…性质或状态的)<br>把折叠隐藏之物向外展开, 即"清晰的" |
| implicit<br><br>adj. 含蓄的; 内在的; 暗示的; 不怀疑的; 无保留的 | 源自拉丁语 implicitus“折入其中的”, 是 implicare“缠绕、折叠”的过去分词<br>意义折叠在内部而未明说, 即含蓄的 |
| pliable<br><br>adj. 顺从的; 易被操纵的 | **pli(满, 全)**, -able(可…的)<br>围绕“满”这一核心含义构成, 表示“易弯的” |


### plor

哭, 喊

| 单词 | 拆解 |
| --- | --- |
| deplore<br><br>v. 懊悔; 悲叹 | de-(一再等加强意义), **plor(哭, 喊)**, e(连接字母)<br>为某事深切哭喊、悲叹, 因此表示哀叹、强烈反对 |
| implore<br><br>v. 乞求; 恳求; 哀求 | 16世纪经法语或拉丁语 implorare“含泪呼求”传入<br>带着强烈感情乞求、恳求 |
| deplorable<br><br>adj. 可叹的; 悲惨的 | de-(一再等加强意义), **plor(哭, 喊)**, -able(可…的)<br>值得为之哭喊悲叹, 因此表示悲惨的、可叹的 |
| imploring<br><br>adj. 乞求的; 恳求的; 哀求的 | 词形来源：implore + ing-form |


### ploy, ploit

使用

| 单词 | 拆解 |
| --- | --- |
| deploy<br><br>v. 展开; 调度; 部署 | de-(一再等加强意义), **ploy(使用)**<br>把原先折叠的队伍或资源展开并安排使用, 因此表示部署 |
| employ<br><br>v. 雇佣; 采用; 运用; 雇用 | 经古法语 employer 进入英语, 核心意象是把人或物投入使用<br>表示雇用或运用 |
| exploit<br><br>n. 功绩; 英勇行为<br>v. 开发; 开采; (不正当地)利用; 开拓 | ex-(出, 向外), **ploit(使用)**<br>把潜在用途发挥出来; 也可表示为自身利益利用他人 |
| employee<br><br>n. 雇员 | em-(使...(成为)), **ploy(使用)**, -ee(接受动作的人)<br>在前词基础上加“-ee”构成名词, 表示“雇员” |
| employer<br><br>n. 雇主; 老板 | em-(使...(成为)), **ploy(使用)**, -er(人)<br>在前词基础上加“-er”构成名词, 表示“雇主” |
| employment<br><br>n. 工作; 职业; 雇用 | em-(使...(成为)), **ploy(使用)**, -ment(状态)<br>人力被使用、受雇工作的状态, 也指工作或职业 |
| exploitation<br><br>n. 剥削; 开发; 利用 | exploit(词: 剥削), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“剥削” |
| exploiter<br><br>n. 剥削者; 开发者 | exploit(词: 剥削), -er(人)<br>在前词基础上加“-er”构成名词, 表示“剥削者” |


### plut(o)

财

| 单词 | 拆解 |
| --- | --- |
| plutocracy<br><br>n. 财阀统治; 富豪统治 | **pluto(财)**, **cracy(统治, 政体)**<br>围绕“财”这一核心含义构成, 表示“财阀统治, 富豪统治” |
| plutocrat<br><br>n. 富豪; 财阀; 凭借财富拥有统治权的人 | **plut(o)(财)**, **crat(统治者)**<br>凭借巨额财富掌控政治或经济实权的大财阀统治者 |


### pod

足, 脚

| 单词 | 拆解 |
| --- | --- |
| apod<br><br>n. 无足动物; 无腹鳍的鱼<br>adj. 无足的; 无腹鳍的 | a-(无, 不, 非), **pod(足, 脚)**<br>否定或缺少“足”所指的性质, 因此表示“无足的(动物)” |
| chiropodist<br><br>n. 手足病医生 (尤指足病医生) | **chiro(手)**, **pod(足, 脚)**, -ist(人)<br>由“手”与“足”共同限定词义, 表示“手足病医生 (尤指足病医生)” |
| gastropod<br><br>n. 腹足纲的软体动物 | **gastro(胃, 腹)**, **pod(足, 脚)**<br>由“腹”与“足”共同限定词义, 表示“腹足纲的软体动物” |
| hexapod<br><br>n. 昆虫; 六足节肢动物<br>adj. 六脚的 | hexa-(六), **pod(足, 脚)**<br>由“六”与“足”共同限定词义, 表示“有六足的” |
| tetrapod<br><br>n. 四足动物<br>adj. 四足动物的 | tetra-(四), **pod(足, 脚)**<br>由“四”与“足”共同限定词义, 表示“四足动物 (的)” |
| tripod<br><br>n. 三脚桌; 三脚凳; 三脚架 | tri-(三, 三次), **pod(足, 脚)**<br>由“三”与“脚”共同限定词义, 表示“三脚桌” |


### point, punct, pung

点, 刺

| 单词 | 拆解 |
| --- | --- |
| appoint<br><br>v. 任命; 委派; 约定; 指定 (时间; 地点) | ap-(到, 朝, 向), **point(点, 刺)**<br>把人明确指向一个职位或任务, 因此表示任命、指定 |
| disappoint<br><br>v. 使失望; 使受挫折 | dis-(否定, 相反), ap-(到, 朝, 向), **point(点, 刺)**<br>使原先约定或期待的安排落空, 因此表示使失望 |
| puncture<br><br>v. 刺穿; 穿孔 | **punct(点, 刺)**, -ure(行为, 结果)<br>围绕“刺”这一核心含义构成, 表示“刺穿, 穿孔” |
| acupuncture<br><br>n. 针刺 (疗法); 针灸治疗; 中医针灸疗法 | **acu(尖锐)**, **punct(点, 刺)**, -ure(行为, 结果)<br>用尖锐的针刺入特定穴位的疗法, 即针灸 |
| appointment<br><br>n. 任命; 委派; 约定; 约会; 指派 | appoint(词: 任命), -ment(行为, 过程)<br>正式指定某人或约定时间的行为 |
| compunction<br><br>n. 内疚; 良心的责备; 后悔 | com-(与, 共同), **punct(点, 刺)**, -ion(行为, 结果)<br>良心受到刺痛 |
| punctuality<br><br>n. 准时; 严守时刻 | punctual(词: 准时), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“准时” |
| punctuation<br><br>n. 点标点; 标点法; 标点符号 | **punct(点, 刺)**, u(连接字母), -ation(行为, 结果)<br>围绕“点”这一核心含义构成, 表示“点标点, 标点法” |
| pungency<br><br>n. 刺激; 辛辣 | **pung(点, 刺)**, -ency(性质, 状态)<br>围绕“刺”这一核心含义构成, 表示“刺激” |
| poignant<br><br>adj. 刺激的; 强烈的; 深刻的 | 经古法语借入, 源自拉丁语 pungere“刺”<br>像刺一样触动感情, 即辛酸动人的 |
| pointed<br><br>adj. 尖的; 尖角的; 尖锐的; 犀利的; 突出的 | **point(点, 刺)**, -ed(…的)<br>围绕“点”这一核心含义构成, 表示“尖的, 尖角的” |
| pointy<br><br>adj. 非常尖的 | **point(点, 刺)**, -y(充满…的, 有…特征的, 像…的)<br>在前词基础上加“-y”构成形容词, 表示“非常尖的” |
| punctual<br><br>adj. 准时的; 守时的; 精确的 | **punct(点, 刺)**, -ual(…的)<br>围绕“点”这一核心含义构成, 表示“准点的, 守时的” |
| pungent<br><br>adj. 刺激的; 尖刻的 | **pung(点, 刺)**, -ent(…的)<br>在前词基础上加“-ent”构成形容词, 表示“刺激的” |


### polar(i), polar(o)

极

| 单词 | 拆解 |
| --- | --- |
| polarize<br><br>v. (使) 极化; (使) 偏振; (使) 两极分化 | **polar(极)**, -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“使” |
| polarimeter<br><br>n. 偏振计; 旋光计; 极化计 | **polari(极)**, **meter(测量器, 仪表)**<br>测量“极”的仪器或方法, 即“偏振计, 旋光计, 极化计” |
| polarimetry<br><br>n. 测极化 (术); 偏振测定 (法); 旋光测定 (法) | 由 polar“偏振的”与表示“测量”的 -imetry 结合<br>指测量旋光或偏振性质的方法 |
| polarity<br><br>n. 极性; (思想; 感情等的) 归向; 倾向; (性格; 行动等的) 截然相反 | **polar(极)**, -ity(性质, 状态)<br>表示与“极”有关的性质或状态, 即“极性” |
| polaroid<br><br>n. (人造) 偏振片 | **polar(极)**, -oid(似…的（物）)<br>形状像“极”, 即“(人造) 偏振片” |
| polaron<br><br>n. 极化子 | **polar(极)**, -on(粒子)<br>围绕“极”这一核心含义构成, 表示“极化子” |


### polis, polit

城市

| 单词 | 拆解 |
| --- | --- |
| acropolis<br><br>n. (古希腊城市的) 卫城 | **acro(尖锐)**, **polis(城市)**<br>高城 |
| cosmopolis<br><br>n. 国际都市 | **cosmo(世界, 宇宙)**, **polis(城市)**<br>由“世界”与“城市”共同限定词义, 表示“国际都市” |
| cosmopolitanism<br><br>n. 世界主义 | **cosmo(世界, 宇宙)**, **polit(政治)**, -an(…的), -ism(主义)<br>把自己视为世界共同体成员的思想 |
| megalopolis<br><br>n. 特大的城市 | **megalo(特大)**, **polis(城市)**<br>由“特大”与“城市”共同限定词义, 表示“特大的城市” |
| metropolis<br><br>n. 大城市; 大都会; 首府 | **metro(母)**, **polis(城市)**<br>母城 |
| necropolis<br><br>n. 坟地 | **necro(死, 死尸)**, **polis(城市)**<br>死者之城 |
| cosmopolitan<br><br>adj. 世界主义的; 全世界的 | **cosmo(世界, 宇宙)**, **polit(政治)**, -an(…的)<br>把整个世界视为共同城邦, 因此表示世界性的、四海为家的 |


### polit, politic(o)

政治

| 单词 | 拆解 |
| --- | --- |
| politicize<br><br>v. 搞政治; 谈论政治; 使具有政治性 | **politic(政治)**, -ize(…化, 使成)<br>使事物呈现“政治”与“…化, 使成”所表达的状态, 即“搞政治” |
| politician<br><br>n. 政治家; 政客 | **polit(政治)**, -ician(人)<br>围绕“政治”这一核心含义构成, 表示“政治家” |
| politico<br><br>n. 政客 | politic(词: 政治), o(连接字母)<br>口语中从事政治活动的人, 即政客 |
| politics<br><br>n. 政治学; 政治; 政治事务 | **polit(政治)**, -ics(…学)<br>研究和处理公共权力事务的活动领域 |
| polity<br><br>n. 政治形态; 政体; 政治组织; 国家组织 | **polit(政治)**, -y(活动)<br>围绕“政治”这一核心含义构成, 表示“政治形态, 政体” |
| politic<br><br>adj. 政治的 | **polit(政治)**, -ic(…的)<br>表示与“政治”有关或具有该特征, 即“政治的” |
| political<br><br>adj. 政治 (上) 的; 党派政治的; 政党的 | **polit(政治)**, -ical(…的)<br>表示与“政治”有关或具有该特征, 即“政治的” |


### pon, pound

放置

| 单词 | 拆解 |
| --- | --- |
| expound<br><br>v. 解释; 详细说明 | ex-(出, 向外), **pound(放置)**<br>把观点摆出来并详细展开, 因此表示阐述、解释 |
| postpone<br><br>v. 延期; 延迟; 暂缓; 推迟 | post-(在后, 之后), **pon(放置)**, e(连接字母)<br>把事情放到较后的时间, 因此表示推迟、延期 |
| propone<br><br>v. 提出; 提议; 建议 | pro-(向前, 前进), **pon(放置)**, e(连接字母)<br>向前放 |
| component<br><br>adj. 组成的; 构成的<br>n. 元件; 组件; 成分 | com-(与, 共同), **pon(放置)**, -ent(…的)<br>与其他部分放在一起构成整体的部件 |
| compound<br><br>n. 化合物; 复合物<br>v. 加剧; 混合<br>adj. 复合的 | com-(与, 共同), **pound(放置)**<br>把多个成分共同放在一起, 因此表示复合物、化合物或复合的 |
| exponent<br><br>n. 倡导者; 代表人物; 指数 | ex-(出, 向外), **pon(放置)**, -ent(人; 物)<br>把观点摆出来说明或倡导的人; 数学中亦指指数 |
| opponent<br><br>adj. 对立的; 敌对的<br>n. 对手; 敌手 | op-(对着, 朝向, 在前; 反对, 阻碍), **pon(放置)**, -ent(人; 物)<br>被放置在对立面的人, 即对手 |
| proponent<br><br>n. 支持者; 倡导者; n-拥护者 | pro-(向前, 前进), **pon(放置)**, -ent(人; 物)<br>把主张向前提出的人, 即支持者、倡导者 |


### popul, publ

人民

| 单词 | 拆解 |
| --- | --- |
| popularize<br><br>v. (使)大众化; (使)普及; 推广 | popular(词: 通俗的), -ize(…化, 使成)<br>由“通俗的”派生为当前词义 |
| populate<br><br>v. 使人口聚居于⋯中; 移民于; 殖民于 | **popul(人民)**, -ate(做, 使)<br>围绕“人民”这一核心含义构成, 表示“使人口聚居于⋯中” |
| publish<br><br>v. 出版; 发行; 公布; 发表 | **publ(人民)**, -ish(…的)<br>使内容面向大众公开, 即"出版" |
| repopulate<br><br>v. 使人民重新聚居在⋯中 | re-(回, 向后, 再次), **popul(人民)**, -ate(做, 使)<br>由“重新”与“人民”共同限定词义, 表示“使人民重新聚居在⋯中” |
| depopulation<br><br>n. 人口减少 | 由 de“去除”与 population“人口”构成<br>人口减少或清空 |
| populace<br><br>n. 平民; 大众 | **popul(人民)**, -ace(构成名词)<br>围绕“人民”这一核心含义构成, 表示“平民, 大众” |
| popularity<br><br>n. 大众性; 通俗性 | popular(词: 大众的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“大众性” |
| population<br><br>n. 人口; 全体居民 | **popul(人民)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“人口” |
| public<br><br>adj. 公众的; 公共的; 公立的<br>n. 公众; 民众 | **publ(人民)**, -ic(…的)<br>围绕“人民”这一核心含义构成, 表示“公共的, 公用的, 公众的, 公开的” |
| republic<br><br>n. 共和国; 共和政体 | 源自拉丁语 res publica（公共事务）, 记忆锚点是把国家视为公众共同事务的政体, 即共和国 |
| popular<br><br>adj. 人民的; 通俗的; 大众(化)的 | **popul(人民)**, -ar(…的)<br>围绕“人民”这一核心含义构成, 表示“人民的, 大众(化)的, 通俗的” |
| populous<br><br>adj. 人口稠密的 | **popul(人民)**, -ous(…的)<br>表示与“人民”有关或具有该特征, 即“人口稠密的” |
| republican<br><br>adj. 共和国的; 共和政体的 | republic(词: 共和国), -an(…的)<br>与共和国或共和政体有关, 也指拥护共和政体的人 |


### port

携带, 运送

| 单词 | 拆解 |
| --- | --- |
| support<br><br>n. 支持; 支撑; 援助<br>v. 支援; 支撑; 帮助 | sup-(在下, 向下), **port(携带, 运送)**<br>自下持撑 |
| transport<br><br>n. 运输; 交通工具<br>v. 运输; 运送 | trans-(横过, 越过), **port(携带, 运送)**<br>跨越运送过去, 即"运输" |
| transportation<br><br>n. 运输; 运输系统; 运输工具 | trans-(横过, 越过), **port(携带, 运送)**, -ation(行为, 结果)<br>把人或物运送越过空间的过程或系统 |


### pos, posit

放, 放置; 能力

| 单词 | 拆解 |
| --- | --- |
| compose<br><br>v. 组成; 构成; 创作; 写 | com-(与, 共同), **pos(放, 放置)**, e(连接字母)<br>放在一起构成 |
| depose<br><br>v. 罢…的官; 废黜 | de-(下降, 降低), **pos(放, 放置)**, e(连接字母)<br>放下不用 |
| deposit<br><br>n. 存款; 押金; 沉积物; 矿床<br>v. 存放; 存钱; 放置; (使)沉积; 付(定金) | de-(下降, 降低), **posit(放, 放置)**<br>把某物向下放置并留下, 即存放、沉积或押金 |
| interpose<br><br>v. 插入; 介入其中; 干预 | inter-(在...之间), **pos(放, 放置)**, e(连接字母)<br>把人或物放到两者之间, 因此表示插入、介入 |
| oppose<br><br>v. 反对; 反抗; 对抗 | op-(对着, 朝向, 在前), **pos(放, 放置)**, e(连接字母)<br>放在对面 |
| propose<br><br>v. 计划; 提议; 求婚 | pro-(向前, 前进), **pos(放, 放置)**, e(连接字母)<br>把想法摆到众人面前, 因此表示提出、提议 |
| composer<br><br>n. 创作者; 作曲者 | compose→compos(词: 组成), -er(人)<br>由“组成”派生为当前词义 |
| composition<br><br>n. 成分; 构成; 创作; 作曲; 作文 | com-(与, 共同), **posit(放, 放置)**, -ion(行为, 结果)<br>把多个部分共同放在一起形成的整体或创作过程 |
| disposal<br><br>n. 排列; 布置; 处理 | dispose→dispos(词: 处置; 安排), -al(行为, 过程)<br>处置或安排某物的行为 |
| exposure<br><br>n. 揭露; 揭发; 暴露 | ex-(出, 向外), **pos(放, 放置)**, -ure(行为, 结果)<br>把事物放到外面、不再遮盖的状态, 即暴露、揭露 |
| interposition<br><br>n. 插入; 介入其中; 干预 | 由 inter“在……之间”与 position“放置”构成<br>插入两者之间的行为 |
| opposite<br><br>n. 对立物; 对立面<br>adj. 对面的; 相反的; 截然不同的<br>prep. 在……对面 | op-(对着, 朝向, 在前), **posit(放, 放置)**, e(连接字母)<br>由“对着”与“放”共同限定词义, 表示“对立物” |
| position<br><br>n. 职位; 姿势; 立场<br>v. 安置; 安装; 使处于 | **pos(放, 放置)**, -ition(行为, 结果)<br>放置的地方 |
| preposition<br><br>n. 前置词; 介词 | pre-(先于, 预先), **posit(放, 放置)**, -ion(行为, 结果)<br>通常放在名词短语前面的词, 即介词 |
| transposition<br><br>n. 对换位置; 换位; 调换 | trans-(横过, 越过), position(词: 位置)<br>由“横过”与“位置”共同限定词义, 表示“对换位置, 换位, 调换” |


### post

后, 在后

| 单词 | 拆解 |
| --- | --- |
| posterity<br><br>n. 后裔; 后代 | 源自拉丁语 posteritas“后来者”<br>未来世代、后裔 |
| postern<br><br>n. 后门; 便门; 旁门<br>adj. 后面的; 后门的; 便门的 | 经古法语 posterne 借自晚期拉丁语 posterula“小后门”<br>城堡等的后门或侧门 |
| postlude<br><br>n. 尾曲 | 由 post“之后”与 lude“演奏”构成<br>主体作品结束后的音乐 |
| postdoctoral<br><br>adj. 博士后的 | post-(在后, 之后), doctor(词: 博士), -al(…的)<br>由“在后”与“博士”共同限定词义, 表示“博士后的” |
| posterior<br><br>adj. (时间上) 以后的; (次序上) 其次的; (位置上) 后面的 | 直接借自拉丁语 posterior“较后的”, 为 posterus“后面的”比较级<br>位于后部或时间较后的 |
| posthumous<br><br>adj. 死亡的; 身后的; 遗腹的 | 源自拉丁语 postumus“最后出生的”, 后来受 post humum“埋葬之后”联想影响<br>现代表示在某人死后发生或出版的 |
| preposterous<br><br>adj. 荒谬的; 无道理的 | 源自拉丁语 praeposterus（前后颠倒的）, 由次序荒谬发展为荒唐的 |


### pot

能力

| 单词 | 拆解 |
| --- | --- |
| impotency<br><br>n. 无力; 软弱无能 | im-(无, 不, 非), **pot(能力)**, -ency(性质, 状态)<br>否定或缺少“能力”所指的性质, 因此表示“无力” |
| omnipotence<br><br>n. 全能; 无限权力 | omni-(全, 总, 泛), **pot(能力)**, -ence(性质, 状态)<br>由“全”与“能力”共同限定词义, 表示“全能” |
| plenipotentiary<br><br>adj. 有全权的; 全权代表的<br>n. 全权大使; 全权代表 | 源自拉丁语 plenus“完全”与 potentia“权力”<br>拥有全权的使节 |
| potency<br><br>n. 力量; 权力; 权势 | **pot(能力)**, -ency(性质, 状态)<br>围绕“能力”这一核心含义构成, 表示“力量” |
| potentate<br><br>n. 当权者 | **pot(能力)**, -ent(…的), -ate(人; 物)<br>拥有强大权力的人, 即当权者 |
| potential<br><br>adj. 潜在的; 可能的<br>n. 潜力; 可能性 | **pot(能力)**, -ent(…的), -ial(…的)<br>表示与“能力”有关或具有该特征, 即“潜在的” |
| potentiality<br><br>n. 可能性; 潜在性 | potential(词: 可能性), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“可能性” |
| impotent<br><br>adj. 无力的; 软弱无能的 | 源自拉丁语 impotens, 由 im“无”与 potens“有能力的”构成<br>无力、无能的 |
| multipotent<br><br>adj. 多能的 | multi-(多), **pot(能力)**, -ent(…的)<br>由“多”与“能力”共同限定词义, 表示“多能的” |


### potam(o)

河

| 单词 | 拆解 |
| --- | --- |
| hippopotamus<br><br>n. 河马 | **hippo(马)**, **potam(河)**, -us(名词词尾)<br>名称意为‘河中的马’, 即河马; -us 只是名词词尾 |
| potamic<br><br>adj. 河流的; 江河的 | **potam(o)(河)**, -ic(…的)<br>与河流或内陆水系相关的 |


### prec(i), pric, priz, prais

价格, 价值

| 单词 | 拆解 |
| --- | --- |
| appreciate<br><br>v. 欣赏; 赏识; 感激; 意识到; 增值<br>n. 领会; 欣赏 | ap-(到, 朝, 向), **preci(价格, 价值)**, -ate(做, 使)<br>认清某物的价值, 因此表示"欣赏, 感激"; 引申指意识到其本质, 也指价值本身"增值" |
| depreciate<br><br>v. 降低⋯的价值; 跌价; 贬值; 轻视 | de-(下降, 降低), **preci(价格, 价值)**, -ate(做, 使)<br>由“降低”与“价值”共同限定词义, 表示“降低⋯的价值” |
| praise<br><br>v. 赞扬; 称赞<br>n. 赞美; 赞扬 | **prais(价格, 价值)**, e(连接字母)<br>围绕“价格”这一核心含义构成, 表示“赞扬, 表扬” |
| prize<br><br>v. 珍视; 珍惜<br>n. 奖品; 奖金<br>adj. 获奖的 | **priz(价格, 价值)**, e(连接字母)<br>围绕“价格”这一核心含义构成, 表示“奖赏, 奖金, 奖品” |
| appraisal<br><br>n. 评估; 评价; 鉴定 | ap-(到, 朝, 向), **prais(价格, 价值)**, -al(行为, 过程)<br>确定某物价格或价值的过程, 即评价、估价 |
| appreciation<br><br>n. 欣赏; 感激; 领会 | ap-(到, 朝, 向), **preci(价格, 价值)**, -ation(行为, 结果)<br>认定其价值所在的行为, 即"欣赏" |
| price<br><br>n. 价格; 代价; 价值<br>v. 定...的价格 | 或标价<br>表示为物品标定的价值, 即价格, 也可表示定价 |
| precious<br><br>adj. 宝贵的; 珍贵的 | **preci(价格, 价值)**, -ous(…的)<br>表示与“价格”有关或具有该特征, 即“宝贵的” |


### press

压, 逼迫

| 单词 | 拆解 |
| --- | --- |
| compress<br><br>v. 压缩; 压紧 | com-(与, 共同), **press(压, 逼迫)**<br>使“压”共同结合或发挥作用, 因此表示“压紧, 压缩” |
| depress<br><br>v. 压低; 使沮丧; 萧条 | de-(下降, 降低), **press(压, 逼迫)**<br>由“降低”与“压”共同限定词义, 表示“压低” |
| express<br><br>n. 快车; 快递<br>v. 表达; 表明<br>adj. 明确的; 快速的 | ex-(出, 向外), **press(压, 逼迫)**<br>把内心的想法彻底挤压出来, 即"表达"; 引申指快速运送的"快递"、"特快列车" |
| impress<br><br>v. 给⋯深刻的印象; 使铭记; 印; 压印; 给……深刻印象 | im-(向内, 进入), **press(压, 逼迫)**<br>像按压留下痕迹一样在心中留下深刻印象 |
| oppress<br><br>v. 压迫; 压制; 使压抑 | op-(对着, 朝向, 在前), **press(压, 逼迫)**<br>由“对着”与“压”共同限定词义, 表示“压迫, 压制” |
| suppress<br><br>v. 镇压; 压制; 抑制; 忍住; 查禁 | sup-(在下, 向下), **press(压, 逼迫)**<br>往下压 |
| depression<br><br>n. 沮丧; 萧条; 不景气; 消沉 | de-(下降, 降低), **press(压, 逼迫)**, -ion(行为, 结果)<br>向下压低的状态, 引申为低洼、萧条或抑郁 |
| expression<br><br>n. 表达; 表情; 措辞; 词句 | ex-(出, 向外), **press(压, 逼迫)**, -ion(行为, 结果)<br>把内在思想或情感向外压出, 即表达 |
| impression<br><br>n. 印象; 感想; 印记; 压痕 | impress(词: 印象), -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“印象” |
| pressure<br><br>n. 压(力); 压强; 强制; 压迫; 压力 | **press(压, 逼迫)**, -ure(行为, 结果)<br>围绕“压”这一核心含义构成, 表示“压(力), 压强” |
| suppressor<br><br>n. (干扰)抑制器; 消除器 | suppress(词: 镇压), -or(物)<br>由“镇压”派生为当前词义 |
| impressive<br><br>adj. 给人印象深刻的; 感人的 | impress(词: 留下印象), -ive(…的)<br>能够给人留下强烈印象的 |
| suppressed<br><br>adj. 被抑制的; 被忍住的 | suppress(词: 抑制), -ed(…的)<br>在前词基础上加“-ed”构成形容词, 表示“被抑制的” |


### pri, prin, prim, prem,

第一, 首要

| 单词 | 拆解 |
| --- | --- |
| premise<br><br>v. 假定; 提出前提<br>n. 前提; 经营场所 | pre-(先于, 预先), **mis(投放, 发送)**, e(连接字母)<br>预先放在论证前面的命题, 即前提 |
| premier<br><br>n. 总理; 首相; (加拿大的)省总理; 地区总理<br>adj. 首要的; 最著名的; 最成功的; 第一的; 最好的 | **prem(压制)**, -ier(人)<br>围绕“压制”这一核心含义构成, 表示“总理, 首相” |
| primal<br><br>adj. 最初的; 原始的; 首要的; 根本的 | **prim(第一, 首要)**, -al(…的)<br>表示与“第一”有关或具有该特征, 即“最初的, 原始的” |


### pris

抓

| 单词 | 拆解 |
| --- | --- |
| comprise<br><br>v. 包含; 由...组成; 构成; 组成 | com-(与, 共同), **pris(抓)**, e(连接字母)<br>把各部分共同抓合在一起, 即"由…组成" |
| imprison<br><br>v. 关押; 监禁 | im-(向内, 进入), prison(词: 监狱)<br>把人关入监狱, 即监禁 |
| surprise<br><br>v. 使诧异; 使惊奇; 突然袭击; 撞见 | sur-(超), **pris(抓)**, e(连接字母)<br>在对方没有防备时突然抓住, 因此表示使惊讶或突袭 |
| enterprise<br><br>n. 事业 (单位); 企业单位; 事业心; 进取心 | 源自古法语 entreprendre“承担、着手”<br>表示着手承担的事业, 进而指企业或进取心 |
| prison<br><br>n. 监狱 | 英语内部没有可靠的同步构词边界<br>指依法拘禁人员的场所 |
| prisoner<br><br>n. 囚徒 | prison(词: 监狱), -er(物)<br>由“监狱”派生为当前词义 |
| reprisal<br><br>n. 报复; 报复行动 | re-(回, 向后, 再次), **pris(抓)**, -al(行为, 过程)<br>把对方的行为抓回来反击的行为, 即报复 |


### priv

个人, 私下

| 单词 | 拆解 |
| --- | --- |
| deprive<br><br>v. 剥夺; 免职(特指圣职) | 源自“完全拿走、使失去”的构词意象; 现代英语内部没有可靠的同步切分<br>使某人失去原本拥有之物, 即剥夺 |
| privacy<br><br>n. 隐私; 隐居; 独处; 私下秘密 | **priv(个人, 私下)**, -acy(性质, 状态)<br>表示与“个人”有关的性质或状态, 即“隐退, 隐居” |
| privilege<br><br>n. 特权; 优惠; 特免 | **priv(个人, 私下)**, i(连接字母), **leg(法)**, e(连接字母)<br>个人的法 |
| privity<br><br>n. 私下知悉; 默契 | **priv(个人, 私下)**, -ity(性质, 状态)<br>表示与“私下”有关的性质或状态, 即“私下知悉” |
| private<br><br>adj. 私人的; 个人的; 秘密的; 私下的 | 构词锚点：priv 表示“个人, 私人, 私下”; -ate 在此为形容词词尾, 不取动词义<br>围绕“个人”这一核心含义构成, 表示“私人的, 个人的” |
| privileged<br><br>adj. 有特权的; 特许的 | privilege→privileg(词: 特权), -ed(…的)<br>拥有普通人没有的特权的 |
| privy<br><br>adj. 个人的; 私人的; 隐密的 | **priv(个人, 私下)**, -y(充满…的, 有…特征的, 像…的)<br>围绕“个人”这一核心含义构成, 表示“个人的, 私人的” |


### proach, proxim

接近, 靠近

| 单词 | 拆解 |
| --- | --- |
| approach<br><br>n. 途径; 方法; 接近<br>v. 靠近; 接近; 着手处理 | ap-(到, 朝, 向), **proach(接近, 靠近)**<br>朝某物靠近, 因此表示接近, 也可指处理问题的方法 |
| proximity<br><br>n. 最近; 接近; 亲近; 近似 | **proxim(接近, 靠近)**, -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“最近” |
| approachable<br><br>adj. 和蔼可亲的; 可接近的 | approach(词: 接近), -able(可…的)<br>在前词基础上加“-able”构成形容词, 表示“可接近的” |
| approximate<br><br>v. 接近<br>adj. 大概的; 近似的 | 构词锚点：ap 表示“到, 朝, 向”; proxim 表示“接近, 靠近”; -ate 在此为形容词词尾, 不取动词义<br>接近但不完全达到准确值, 因此表示近似的、大约的 |
| proximal<br><br>adj. 最接近的; 近似的; 邻近的 | **proxim(接近, 靠近)**, -al(…的)<br>表示与“接近”有关或具有该特征, 即“最接近的, 近似的” |
| proximate<br><br>adj. 最接近的; 贴近的; 近似的; 即将到来的 | 构词锚点：proxim 表示“接近, 靠近”; -ate 在此为形容词词尾, 不取动词义<br>围绕“接近”这一核心含义构成, 表示“最接近的, 贴近的” |
| approximately<br><br>adv. 大约; 大概; 约莫 | approximate(词: 接近的), -ly(…地)<br>在数量或程度上接近而非完全精确地 |


### prob

检验, 验证

| 单词 | 拆解 |
| --- | --- |
| probate<br><br>n. 遗嘱查验; 遗嘱查讫证<br>v. 查验; 处以缓刑 | **prob(检验, 验证)**, -ate(做, 使)<br>围绕“检验”这一核心含义构成, 表示“遗嘱检验, 验证的遗嘱” |
| probability<br><br>n. 或有; 可能性; 或然性; [逻]盖然性 | **prob(检验, 验证)**, -ability(可…性)<br>围绕“检验”这一核心含义构成, 表示“或有” |
| probation<br><br>n. 检验; 验证; 鉴定 | **prob(检验, 验证)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“检验” |
| probe<br><br>n. 探针; 探测器; 调查<br>v. 调查; 探查 | **prob(检验, 验证)**, e(连接字母)<br>用于检验、探查的探针, 也可转化作动词 |
| probity<br><br>n. 正直; 诚实; 笃实 | **prob(检验, 验证)**, -ity(性质, 状态)<br>经得起检验的 |
| probable<br><br>adj. 或有的; 或然的; 很可能的; 很有希望的 | **prob(检验, 验证)**, -able(可…的)<br>围绕“检验”这一核心含义构成, 表示“或有的, 或然的, 很可能的” |
| probative<br><br>adj. 检验的; 鉴定的; 证明的 | **prob(检验, 验证)**, -ative(…的)<br>在前词基础上加“-ative”构成形容词, 表示“检验的” |


### proli

后裔, 子孙

| 单词 | 拆解 |
| --- | --- |
| proliferate<br><br>v. 激增; 增殖; 剧增 | **proli(后裔, 子孙)**, **fer(产生)**, -ate(做, 使)<br>不断产生后代或新个体, 即繁殖、激增 |
| proliferation<br><br>n. 繁殖; 增殖 | 与 proliferate“增殖”同源, 核心 proles 表示后代<br>数量迅速增多的过程 |
| prolific<br><br>adj. 多产的; 多育的; 富于创造力的 | **proli(后裔, 子孙)**, -fic(造成…的, 产生…的)<br>围绕“后裔”这一核心含义构成, 表示“多产的, 多育的” |


### proper, propri

适当; 自有, 所属

| 单词 | 拆解 |
| --- | --- |
| appropriate<br><br>v. 拨出(款项); 占用; 挪用<br>adj. 合适的; 适当的; 相称的 | ap-(到, 朝, 向), **propri(自有, 所属)**, -ate(…的)<br>使某物归自己或归特定用途, 因此表示占用、拨用 |
| appropriation<br><br>n. 专用; 私用; 经费 | ap-(到, 朝, 向), **propri(自有, 所属)**, -ation(行为, 结果)<br>把某物划归自己或特定用途, 因此表示占用、拨款 |
| property<br><br>n. 特性; 财产; 资产; 所有物 | **proper(自有, 所属)**, -ty(性质, 状态)<br>表示与“本身所有的”有关的性质或状态, 即“财产, 资产, 所有物” |
| proprietor<br><br>n. 业主; 房东; 经营者 | **propri(自有, 所属)**, -et(小), -or(人)<br>围绕“适当的”这一核心含义构成, 表示“业主, 房东, 经营者” |
| inappropriate<br><br>adj. 不适宜的; 不适当的; 不合适的 | 构词锚点：in 表示“无, 不, 非”; ap 表示“到, 朝, 向”; propri 表示“适当的, 本身所有的”; -ate 在此为形容词词尾, 不取动词义<br>否定或缺少“适当的”所指的性质, 因此表示“不适宜的, 不适当的” |
| properly<br><br>adv. 完全地; 适当地 | **proper(适当)**, -ly(…地)<br>围绕“适当的”这一核心含义构成, 表示“适当地, 正当地” |


### proto

第一, 原始

| 单词 | 拆解 |
| --- | --- |
| prototype<br><br>n. 原型机; 样品; 雏形 | **proto(第一, 原始)**, type(词: 类型)<br>最早制成、供后续版本参考的原型 |
| protozoan<br><br>n. 原生动物 | **proto(第一, 原始)**, **zo(动物, 生命)**, -an(…的)<br>由“原始”与“动物”共同限定词义, 表示“原生动物” |


### prov, proof

验证, 证明

| 单词 | 拆解 |
| --- | --- |
| prove<br><br>v. 证明; 证实; 结果是; 原本是 | **prov(验证, 证明)**, e(连接字母)<br>通过检验确认事实, 即证明 |
| reprove<br><br>v. 指责; 责骂 | re-(回, 向后, 再次), **prov(验证, 证明)**, e(连接字母)<br>不为…作证 |


### psych(o)

心灵, 精神; 心理

| 单词 | 拆解 |
| --- | --- |
| psychoanalysis<br><br>n. 精神分析(学) | **psycho(心灵, 精神)**, analysis(词: 分析)<br>由“精神”与“分析”共同限定词义, 表示“精神分析(学)” |
| psychobiology<br><br>n. 心理生物学; 生物心理学 | **psycho(心灵, 精神)**, **bio(生命, 生物)**, -logy(…学, …研究)<br>以“心理、生物”为研究对象的学科, 即“心理生物学, 生物心理学” |
| psychologist<br><br>n. 心理学家 | **psycho(心灵, 精神)**, -logist(…学家)<br>围绕“心理”这一核心含义构成, 表示“心理学家” |
| psychology<br><br>n. 心理学; 心理状态; 心理特征 | **psycho(心理)**, -logy(…学, …研究)<br>以“心理”为研究对象的学科, 即“心理学” |
| psychometrics<br><br>n. 心理测验学 | **psycho(心理)**, metrics(词: 测量指标)<br>对心理能力和特质进行量化测量的学科 |
| psychopathology<br><br>n. 心理病理学; 精神病理学 | **psycho(心灵, 精神)**, **patho(感情)**, -logy(…学, …研究)<br>以“心理、疾病”为研究对象的学科, 即“心理病理学, 精神病理学” |
| psychophysics<br><br>n. 心理物理学 | **psycho(心灵, 精神)**, physics(词: 物理学)<br>由“心理”与“物理学”共同限定词义, 表示“心理物理学” |
| psychosis<br><br>n. 精神病; 精神变态 | **psych(心理)**, -osis(状态, 过程)<br>围绕“精神”这一核心含义构成, 表示“精神病, 精神变态” |
| psychotherapy<br><br>n. 心理疗法; 精神疗法 | **psycho(心灵, 精神)**, **therapy(治疗, 疗法)**<br>由“精神”与“疗法”共同限定词义, 表示“心理疗法, 精神疗法” |
| psychopathic<br><br>adj. 心理病态的; 精神变态的 | **psycho(心灵, 精神)**, **path(疾病, 疗法)**, -ic(…的)<br>由“精神”与“疾病”共同限定词义, 表示“心理病态的, 精神变态的” |
| psychophysiological<br><br>adj. 心理生理学的; 精神生理学的 | **psycho(心灵, 精神)**, **physio(自然)**, -logical(…学的)<br>由“精神”与“自然”共同限定词义, 表示“心理生理学的, 精神生理学的” |
| psychotic<br><br>adj. 精神病的; 狂乱的 | **psych(心理)**, -otic(…的)<br>围绕“精神”这一核心含义构成, 表示“(患) 精神病的” |


### pter

翼, 翅

| 单词 | 拆解 |
| --- | --- |
| helicopter<br><br>n. 直升飞机; 直升机<br>v. 用直升机载送; 乘直升机旅行 | **helico(螺旋)**, **pter(翼, 翅)**<br>靠旋转的翼片升空飞行的航空器, 即直升机 |
| Hemiptera<br><br>n. [动] 半翅目 | hemi-(半), **pter(翼, 翅)**, a(连接字母)<br>由“半”与“翅”共同限定词义, 表示“半翅目” |


### puls

推动, 脉动; 驱, 逐

| 单词 | 拆解 |
| --- | --- |
| pulsate<br><br>v. 搏动; 跳动; 震动; 脉动 | **puls(推动, 脉动)**, -ate(做, 使)<br>围绕“推动”这一核心含义构成, 表示“搏动, 跳动” |
| impulse<br><br>n. 推动; 冲动; 刺激; 心血来潮 | im-(向内, 进入), **puls(推动, 脉动)**, e(连接字母)<br>从内部推动人采取行动的力量, 即冲动、推动力 |
| pulsar<br><br>n. 脉冲星 | **puls(推动, 脉动)**, -ar(…的)<br>围绕“脉动”这一核心含义构成, 表示“脉冲星” |
| pulsation<br><br>n. 跳动; 有节奏的鼓动; 震动; 脉动 | **puls(推动, 脉动)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“跳动” |
| pulse<br><br>n. 脉搏; 脉冲<br>v. 搏动; 跳动 | **puls(推动, 脉动)**, e(连接字母)<br>有节律的推动和搏动, 即脉搏、脉冲 |
| pulsion<br><br>n. 推进 | **puls(推动, 脉动)**, -ion(行为, 结果)<br>围绕“推动”这一核心含义构成, 表示“推进” |
| impulsive<br><br>adj. 易冲动的; 感情用事的 | 与 impulse“推动、冲动”同源<br>受一时推动而行动的 |
| pulsatile<br><br>adj. 脉动的; 跳动的; 敲打的 | 源自拉丁语 pulsare“反复敲击、搏动”<br>有节律搏动的 |


### pur(i), purg

清, 净

| 单词 | 拆解 |
| --- | --- |
| expurgate<br><br>v. 使清洁; 删除 | ex-(出, 向外), **purg(清, 净)**, -ate(做, 使)<br>把不洁或不当内容清除出去, 因此表示净化、删节 |
| purify<br><br>v. 使净化; 使纯净; 精炼; 提纯 | **pur(清, 净)**, -ify(…化, 做…)<br>使事物变得清洁纯净 |
| depuration<br><br>n. 净化; 提纯 | 源自拉丁语 depurare“净化”, 核心 purus 表示纯净<br>除去杂质的过程 |
| impurity<br><br>n. 不纯; 不洁 | im-(无, 不, 非), **pur(清, 净)**, -ity(性质, 状态)<br>否定或缺少“纯洁”所指的性质, 因此表示“不纯” |
| purgation<br><br>n. 净化; 清洗; 涤罪; 通便 | **purg(清, 净)**, -ation(行为, 结果)<br>围绕“清”这一核心含义构成, 表示“净化, 清洗” |
| purification<br><br>n. 纯化; 净化; 提纯; 精炼 | **puri(清, 净)**, -fication(…化, 做…)<br>围绕“净”这一核心含义构成, 表示“纯化, 净化” |
| purifier<br><br>n. 提纯者; 精炼者; 提纯器; 精炼器 | **puri(清, 净)**, -fier(做…的人或物)<br>围绕“清”这一核心含义构成, 表示“提纯者, 精炼者” |
| Puritan<br><br>n. 清教徒<br>adj. 清教徒的; 道德严苛的 | 源自 pure“纯洁”形成的宗教派别名称<br>指强调净化教会与严格道德生活的清教徒 |


### put

思考, 认为

| 单词 | 拆解 |
| --- | --- |
| compute<br><br>v. 计算; 估计 | com-(与, 共同), **put(思考, 认为)**, e(连接字母)<br>把多个数共同思量、计算, 因此表示计算 |
| computer<br><br>n. 计算机, 电脑 | compute→comput(词: 计算), -er(物)<br>由“计算”派生为当前词义 |
| deputy<br><br>n. 代理人; 副手 | 经古法语进入英语, 源自表示“委派、指定”的拉丁语形式<br>指被指定代替上级履行职责的人 |
| dispute<br><br>n. 争端; 争论; 辩论<br>v. 争论; 争吵 | dis-(否定, 相反), **put(思考, 认为)**, e(连接字母)<br>不同看法 |
| indisputable<br><br>adj. 不容置疑的; 明白的 | 由 in“不可”与 disputable“可争论的”构成<br>无可争辩的 |
| putative<br><br>adj. 推定的; 被公认的, 被称为…的; 假定的 | **put(思考, 认为)**, -ative(…的)<br>围绕“思考”这一核心含义构成, 表示“推定的” |
| reputation<br><br>n. 名誉; 声望; 声誉 | re-(回, 向后, 再次), **put(思考, 认为)**, -ation(行为, 结果)<br>反复作出的评价 |


### putr(e)

腐烂, 腐败

| 单词 | 拆解 |
| --- | --- |
| putrefy<br><br>v. (使)化脓; (使)腐烂; (使)腐败; (使)堕落 | **putre(腐烂, 腐败)**, -fy(…化, 做…)<br>围绕“腐烂”这一核心含义构成, 表示“(使)化脓” |
| putrefaction<br><br>n. 腐烂(作用); 腐败(作用); 腐烂的东西 | **putre(腐烂, 腐败)**, **fact(做)**, -ion(行为, 结果)<br>由“腐烂”与“作”共同限定词义, 表示“腐烂(作用), 腐败(作用)” |
| putrid<br><br>adj. 腐烂的; 腐败的; 堕落的 | **putr(腐烂, 腐败)**, -id(…的)<br>围绕“腐烂”这一核心含义构成, 表示“腐烂的, 腐败的” |


### pyr(o)

火

| 单词 | 拆解 |
| --- | --- |
| antipyretic<br><br>adj. 退热的<br>n. 退热剂 | anti-(反对, 相反), **pyr(火)**, -etic(…的)<br>对抗身体如火般的发热, 因此表示退热的、退热药 |
| pyre<br><br>n. 供燃烧的大堆木料 | 经拉丁语借自希腊语 pura“火葬柴堆”, 核心 pyr 表示火<br>焚烧尸体的柴堆 |
| pyrogen<br><br>n. 发热源; 致热质 | **pyro(火)**, **gen(出生, 产生)**<br>能够产生发热反应的物质, 即致热原 |
| pyromania<br><br>n. 放火狂; 放火癖 | **pyro(火)**, **mania(狂热, 精神失常)**<br>由“火”与“狂热”共同限定词义, 表示“放火狂, 放火癖” |
| pyrometer<br><br>n. 高温计 | **pyro(火)**, **meter(测量器, 仪表)**<br>测量“火”的仪器或方法, 即“高温计” |
| pyrotechnics<br><br>n. 烟火制造(或施放)技术 | **pyro(火)**, **techn(技术, 工艺)**, -ics(…学)<br>以“火、技术”为研究对象的学科, 即“烟火制造(或施放)技术” |
| pyroelectric<br><br>adj. 热电的 | **pyro(火)**, **electr(电)**, -ic(…的)<br>由“火”与“电”共同限定词义, 表示“热电的” |
| pyrogenic<br><br>adj. 发热的; 火成的 | pyrogen(词: 发热原), -ic(…的)<br>在前词基础上加“-ic”构成形容词, 表示“发热的” |
