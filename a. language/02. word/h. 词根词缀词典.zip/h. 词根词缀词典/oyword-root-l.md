## oyword-root-l


### labi(o)

唇

| 单词 | 拆解 |
| --- | --- |
| labial<br><br>adj. 唇的; 唇音的; 唇状的 | **labi(唇)**, -al(…的)<br>表示与“唇”有关或具有该特征, 即“唇的” |
| bilabial<br><br>adj. 双唇音的<br>n. 双唇音 | bi-(二, 两, 双), **labi(o)(唇)**, -al(…的)<br>由上下双唇共同闭合或接触发出的声音 |


### labor, labour

工作

| 单词 | 拆解 |
| --- | --- |
| collaborate<br><br>v. 合作; 协作 | col-(与, 共同), **labor(工作)**, -ate(做, 使)<br>使“工作”共同结合或发挥作用, 因此表示“合作” |
| elaborate<br><br>v. 详尽阐述; 精心制作<br>adj. 复杂的; 精心制作的 | e-(出, 向外), **labor(工作)**, -ate(做, 使)<br>经过大量劳动精心做成, 因此表示精巧复杂的; 作动词指详述 |
| collaboration<br><br>n. 合作; 协作; 合作成果(或作品); 通敌 | col-(与, 共同), **labor(工作)**, -ation(行为, 结果)<br>共同劳动、一起完成事情, 因此表示合作、协作 |
| laboratory<br><br>n. 实验室; 实验大楼; 研究室 | **labor(工作)**, -atory(场所)<br>围绕“工作”这一核心含义构成, 表示“实验室, 实验大楼” |
| laborious<br><br>adj. 勤劳的; 吃力的 | **labor(工作)**, -ious(…的)<br>表示与“工作”有关或具有该特征, 即“勤劳的, 吃力的” |


### lact(i), lact(o), galact

乳

| 单词 | 拆解 |
| --- | --- |
| prolactin<br><br>n. 催乳激素 | pro-(向前, 前进), **lact(乳)**, -in(…素)<br>使乳汁向外流出 |
| lactose<br><br>n. 乳糖 | **lact(i), lact(o), galact(乳)**, -ose(糖)<br>乳汁中特有的糖类成分 |


### langu

虚弱, 疲倦

| 单词 | 拆解 |
| --- | --- |
| languish<br><br>v. 衰弱; 凋萎 | **langu(虚弱, 疲倦)**, -ish(…的)<br>围绕“虚弱”这一核心含义构成, 表示“衰弱, 凋萎” |
| languor<br><br>n. 倦怠; 衰弱 | 源自拉丁语 languor“虚弱、疲倦”<br>表示倦怠、衰弱的状态 |
| languid<br><br>adj. 倦怠的; 无精神的 | **langu(虚弱, 疲倦)**, -id(…的)<br>围绕“疲倦”这一核心含义构成, 表示“倦怠的, 无精神的” |
| languishing<br><br>adj. 衰弱下去的; 焦思的 | 词形来源：languish + ing-form |


### lapi, lapid, lapil

石

| 单词 | 拆解 |
| --- | --- |
| lapidary<br><br>adj. 宝石雕刻的; 宝石的<br>n. 宝石工艺匠; 宝石鉴定家 | **lapid(石)**, -ary(…的)<br>围绕“石”这一核心含义构成, 表示“宝石工, 宝石商” |
| dilapidate<br><br>v. (使)破损; (使)荒废; (使)倾塌 | di-(分开, 分离), **lapi, lapid, lapil(石)**, -ate(做, 使)<br>石头瓦块零散脱落, 引申为建筑物破败坍塌 |


### laps

滑, 落

| 单词 | 拆解 |
| --- | --- |
| collapse<br><br>n. 倒塌; 崩溃<br>v. 倒塌; 瓦解; 崩溃 | col-(与, 共同; 彻底, 完全, 加强), **laps(滑, 落)**, e(连接字母)<br>各部分一起滑落、塌下, 因此表示倒塌、崩溃 |
| relapse<br><br>v. 旧病复发; 故态复萌 | re-(回, 向后, 再次), **laps(滑, 落)**, e(连接字母)<br>滑回 |
| elapse<br><br>n. (时间的)流逝; 过去<br>v. (时间)流逝; 逝去 | e-(出, 向外), **laps(滑, 落)**, e(连接字母)<br>滑出 |
| lapse<br><br>n. 过失; 流逝; 失效<br>v. 犯错; 堕落; 减退 | **laps(滑, 落)**, e(连接字母)<br>由滑落引申为状态失效或一时失误 |
| lapsus<br><br>n. 失误 | **laps(滑, 落)**, -us(名词词尾)<br>滑落 |
| prolapse<br><br>n. 脱垂; 下垂; [医] 脱出症 | pro-(向前, 前进), **laps(滑, 落)**, e(连接字母)<br>向外滑 |


### laryng(o)

喉

| 单词 | 拆解 |
| --- | --- |
| laryngitis<br><br>n. 喉炎 | **laryng(o)(喉)**, -itis(…炎)<br>喉部黏膜因过度用嗓或受凉感染引起的声带发炎病症, 即喉炎 |
| laryngology<br><br>n. 喉科学 | **laryngo(喉)**, -logy(…学, …研究)<br>围绕“喉”这一核心含义构成, 表示“喉科学” |
| laryngoscope<br><br>n. 喉镜 | **laryngo(喉)**, **scop(镜, 观察)**, e(连接字母)<br>由“喉”与“镜”共同限定词义, 表示“喉镜” |
| laryngoscopy<br><br>n. 喉镜诊察(法) | **laryngo(喉)**, **scop(镜, 观察)**, y(连接字母)<br>在前词基础上加“-y”构成名词, 表示“喉镜诊察” |
| larynx<br><br>n. 喉; 喉头 | larynx←laryng<br>laryng- 的名词形式, 表示喉 |
| otorhinolaryngology<br><br>n. 耳鼻喉科学 | **oto(耳)**, **rhino(鼻)**, **laryngo(喉)**, -logy(…学, …研究)<br>以“耳、鼻、喉”为研究对象的学科, 即“耳鼻喉科学” |
| laryngeal<br><br>adj. 喉部的 | **laryng(喉)**, -eal(…的)<br>围绕“喉”这一核心含义构成, 表示“喉部的” |


### lat

持, 带

| 单词 | 拆解 |
| --- | --- |
| ablate<br><br>v. 切除 | ab-(脱离, 离去), **lat(持, 带)**, e(连接字母)<br>把组织或物质从主体上带走, 因此表示切除、消融 |
| collate<br><br>v. 对照; 核对; 校对 | col-(与, 共同), **lat(持, 带)**, e(连接字母)<br>把不同材料拿到一起逐项比较、整理, 因此表示校对、整理 |
| legislate<br><br>v. 立法; 制定（或通过）法律 | **legis(法)**, **lat(持, 带)**, e(连接字母)<br>通过或设立法律 |
| relate<br><br>v. 联系; 讲述; 叙述; 使有联系 | re-(回, 向后, 再次), **lat(持, 带)**, e(连接字母)<br>把事情带回叙述或联系起来, 即联系、讲述 |
| ablation<br><br>n. 部分切除; 脱离 | 源自拉丁语 ablatio“拿走”, 由 ab“离开”与 lat“携带”构成<br>记忆为把物质拿走、去除 |
| collator<br><br>n. 校对者; 核对者 | collate→collat(词: 校对), -or(人)<br>由“校对”派生为当前词义 |
| legislature<br><br>n. 立法机关 | **legis(法)**, **lat(持, 带)**, -ure(行为, 结果)<br>在前词基础上加“-ure”构成名词, 表示“立法机关” |
| relativity<br><br>n. 相关性; 相对论 | relative→relativ(词: 亲戚), -ity(性质, 状态)<br>由“亲戚”派生为当前词义 |
| superlative<br><br>adj. 最上的; 无比的; 过度的<br>n. 最好的人; 最高程度; 最高级 | super-(超), **lat(持, 带)**, -ive(…的)<br>被抬到其他事物之上, 因此表示最高的或最高级 |
| translation<br><br>n. 翻译; 译文; 转化 | trans-(横过, 越过), **lat(持, 带)**, -ion(行为, 结果)<br>拿过去 |
| ventilator<br><br>n. 通风装置; 送风机 | ventilate→ventilat(词: 通风), -or(物)<br>使空气流通的装置 |
| prolate<br><br>adj. 延长的; 扩展的 | pro-(向前, 前进), **lat(持, 带)**, e(连接字母)<br>向前拉长, 因此表示延长的、长球形的 |


### later(o)

边

| 单词 | 拆解 |
| --- | --- |
| bilateral<br><br>adj. 双方的; 双边的; (身体部位)双侧的; (大脑)两半球的<br>n. 双边会议; 双边会谈 | bi-(两, 双), **later(边)**, -al(…的)<br>由“双”与“边”共同限定词义, 表示“双边的, 双方面的” |
| laterality<br><br>n. 偏重一侧 | **later(边)**, -ality(性质, 状态)<br>围绕“边”这一核心含义构成, 表示“偏重一侧” |
| equilateral<br><br>adj. 等边的 | **equi(相等)**, **later(边)**, -al(…的)<br>由“相等”与“边”共同限定词义, 表示“等边的” |
| lateral<br><br>adj. 旁边的; 侧面的 | **later(边)**, -al(…的)<br>表示与“边”有关或具有该特征, 即“旁边的” |
| multilateral<br><br>adj. 多边的; 多方面的 | multi-(多), **later(边)**, -al(…的)<br>涉及多个侧面或多个参与方, 因此表示多边的 |
| unilateral<br><br>adj. 单边的; 单方面的; 片面的 | uni-(一, 单一), **later(边)**, -al(…的)<br>由“单一”与“边”共同限定词义, 表示“单边的, 单方面的, 片面的” |


### later, latr, latry

崇拜

| 单词 | 拆解 |
| --- | --- |
| idolatry<br><br>n. 偶像崇拜; 盲目崇拜 | idol(词: 偶像), **atry(崇拜)**<br>对偶像的崇拜, 即偶像崇拜、盲目崇拜 |
| idolatrous<br><br>adj. 盲目崇拜的; 偶像崇拜的 | idol(词: 偶像), **latr, latry(崇拜)**, -ous(…的)<br>具有盲目偶像崇拜特征的 |


### lav, luv, lut

冲, 洗

| 单词 | 拆解 |
| --- | --- |
| dilute<br><br>v. 稀释; 冲淡<br>adj. 稀释的; 稀释了的; 减弱了的 | di-(分开, 分离), **lut(冲, 洗)**, e(连接字母)<br>把浓缩物分散洗开, 即稀释 |
| lave<br><br>v. 洗浴; 汲取 | **lav(冲, 洗)**, e(连接字母)<br>围绕“洗”这一核心含义构成, 表示“洗浴” |
| lavish<br><br>adj. 大方的; 丰富的; 浪费的<br>v. 浪费; 滥用; 慷慨给予 | 源自古法语 lavasse（倾盆大雨）, 核心意象是像大水一样毫无节制地倾泻, 引申为挥霍或大量给予 |
| deluge<br><br>n. 洪水; 暴雨 | 经古法语借自拉丁语 diluvium“大洪水”<br>由洪水引申为大量涌来 |
| lava<br><br>n. (火山) 熔岩 | **lav(冲, 洗)**, a(连接字母)<br>流体 |
| lavage<br><br>n. 灌洗; 洗出 | 源自法语 lavage“清洗”, 与 laver“洗”相关<br>用液体冲洗身体腔道的操作, 即灌洗 |
| lavatory<br><br>n. 盥洗室; 厕所 | **lav(冲, 洗)**, -atory(…的)<br>围绕“洗”这一核心含义构成, 表示“盥洗室, 厕所” |
| laver<br><br>n. (古代) 盥洗用具; [宗教] 洗礼水 | **lav(冲, 洗)**, -er(物)<br>用于盥洗或宗教洗礼的器具 |


### lax, leas

松弛, 放松

| 单词 | 拆解 |
| --- | --- |
| relax<br><br>n. V-放松<br>v. (使) 松弛; 放松 | re-(回, 向后, 再次), **lax(松弛, 放松)**<br>把拉紧状态重新放松, 因此表示放松、松弛 |
| release<br><br>n. 释放; 发行<br>v. 释放; 发布 | re-(回, 向后, 再次), **leas(松弛, 放松)**, e(连接字母)<br>把束缚重新放松, 使人或物获得自由, 因此表示释放、解除 |
| lease<br><br>n. 租约<br>v. 租赁; 出租; 租用 | 经古法语进入英语, 核心意义是出租或租用的合同关系<br>表示在一定期限内授予使用权 |
| relaxation<br><br>n. 松弛; 减轻 | relax(词: 松弛), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“松弛” |


### lect, leg, lig

收, 选择; 读, 言

| 单词 | 拆解 |
| --- | --- |
| collect<br><br>v. 收集; 聚集; 集合; 收藏 | col-(与, 共同), **lect(收, 选择)**<br>把分散事物选取并收拢到一起, 即收集 |
| allege<br><br>v. 宣称; 主张 | al-(到, 朝, 向), **leg(法)**, e(连接字母)<br>把某事作为证据援引, 由此表示宣称、主张 |
| collectivist<br><br>n. 集体主义者 | collective→collectiv(词: 集体的), -ist(人)<br>由“集体的”派生为当前词义 |
| election<br><br>n. 选举 | e-(出, 向外), **lect(收, 选择)**, -ion(行为, 结果)<br>从候选对象中作出选择的过程, 即选举 |
| elegance<br><br>n. 漂亮; 优美; 雅致; 文雅; 典雅 | e-(出, 向外), **leg(收, 选择)**, -ance(性质, 状态)<br>从多种可能中挑选得恰到好处的状态, 即优雅 |
| eligible<br><br>adj. 有资格的; 合格的; 符合条件的; 合意的; (尤指作为结婚对象)合适的<br>n. 合适的人 | e-(出, 向外), **lig(收, 选择)**, -ible(可…的)<br>可以从候选者中选出来的, 即符合资格、合适的 |
| intellect<br><br>n. 智力; 才智; 智慧 | intel-(在...之间), **lect(收, 选择)**<br>在事物之间辨别和选择的能力, 即智力 |
| intellectual<br><br>adj. 智力的; 脑力的<br>n. 知识分子 | intel-(在...之间), **lect(收, 选择)**, -ual(…的)<br>能在事物之间辨别选择的, 与智力相关的 |
| intelligentsia<br><br>n. 知识分子; [总称] 知识界 | 19世纪借自俄语 intelligentsiya, 源自拉丁语 intelligentia“理解力”<br>指知识分子阶层 |
| selector<br><br>n. 选择者; 选择器 | se-(离开, 分开), **lect(收, 选择)**, -or(人)<br>作出选择的人; 也可引申指选择器 |
| college<br><br>n. 学院; 大学 | col-(与, 共同), **leg(收, 选择)**, e(连接字母)<br>原指共同选出或联合组成的一群人, 后指学院 |
| dialect<br><br>n. 方言; 土语; 地方话 | dia-(通过, 穿过), **lect(读, 言)**<br>由“通过”与“言”共同限定词义, 表示“方言, 土语” |
| dialectics<br><br>n. 辩证法 | 源自希腊语 dialektike“辩论的艺术”<br>通过对立观点推进论证的辩证法 |
| dialectology<br><br>n. 方言学 | dia-(通过, 穿过), **lect(读, 言)**, o(连接元音), -logy(…学, …研究)<br>以“通过、言”为研究对象的学科, 即“方言学” |
| lectern<br><br>n. (教堂中的)读经台 | **lect(读, 言)**, -ern(方向, 地点)<br>围绕“读”这一核心含义构成, 表示“(教堂中的)读经台” |
| lection<br><br>n. (做礼拜时)诵读的经文 | **lect(读, 言)**, -ion(行为, 结果)<br>围绕“读”这一核心含义构成, 表示“(做礼拜时)诵读的经文” |
| lecturer<br><br>n. (英)(大学的)讲师 | lecture→lectur(词: 讲课), -er(人)<br>负责讲授课程的人 |
| legend<br><br>n. 传奇; 小说; 传奇文学 | **leg(读, 言)**, -end(应被…的)<br>原指应当被诵读的故事, 后指传说 |
| legibility<br><br>n. 可读(性) | **leg(读, 言)**, -ibility(可…性)<br>文字能够被读清的性质, 即可读性 |
| collective<br><br>adj. 聚集的; 集合的; 集体的 | col-(与, 共同), **lect(收, 选择)**, -ive(…的)<br>把多个个体共同收拢起来的, 即集体的 |
| elegant<br><br>adj. 漂亮的; 优美的; 雅致的 | e-(出, 向外), **leg(收, 选择)**, -ant(…的)<br>经过精心选择而得体精致的, 即优雅的 |
| intelligent<br><br>adj. 聪明的; 有理解力的; 有才智的 | intel-(在...之间), **lig(收, 选择; 读, 言)**, -ent(…的)<br>能够在不同信息之间作出选择和理解的, 即聪明的 |
| negligent<br><br>adj. 玩忽的; 疏忽的; 粗心大意的 | **neg(否定)**, **lig(收, 选择)**, -ent(…的)<br>没有认真选择、收拢注意力的, 即疏忽的 |
| negligible<br><br>adj. 可以忽略的; 微不足道的 | **neg(否定)**, **lig(收, 选择)**, -ible(可…的)<br>小到可以不纳入考虑的 |
| dialectic<br><br>adj. 辩证(法)的 | dia-(通过, 穿过), **lect(读, 言)**, -ic(…的)<br>通过双方言语往返来辨析问题, 即辩证法或辩证的 |
| illegible<br><br>adj. 不可读的; 难读的 | il-(无, 不, 非), **leg(读, 言)**, -ible(可…的)<br>无法读出的, 即字迹难以辨认的 |


### leg, legis

法

| 单词 | 拆解 |
| --- | --- |
| allegiance<br><br>n. 效忠; 忠诚 | al-(到, 朝, 向), **legi(法)**, -ance(性质, 状态)<br>原指对领主的忠诚, 后来泛指忠诚、效忠 |
| legality<br><br>n. 合法性 | **leg(法)**, -ality(性质, 状态)<br>围绕“法”这一核心含义构成, 表示“合法性” |
| legalization<br><br>n. 合法化; 法律认可 | **leg(法)**, -al(…的), -ization(行为, …化)<br>围绕“法”这一核心含义构成, 表示“认为合法” |
| legislation<br><br>n. 立法; 法规 | **legis(法)**, **lat(持, 带)**, -ion(行为, 结果)<br>由“法”与“持”共同限定词义, 表示“立法” |
| legislator<br><br>n. 立法者; 立法机关的成员 | **legis(法)**, **lat(持, 带)**, -or(人)<br>在前词基础上加“-or”构成名词, 表示“立法者” |
| privilege<br><br>n. 特权; 优惠; 特免 | **priv(个人, 私下)**, i(连接字母), **leg(法)**, e(连接字母)<br>个人的法 |
| extralegal<br><br>adj. 法律权力以外的 | extra-(在外, 向外), **leg(法)**, -al(…的)<br>由“以外”与“法”共同限定词义, 表示“法律权力以外的” |
| illegal<br><br>adj. 不合法的; 非法的; 不正当的 | il-(无, 不, 非), **leg(法)**, -al(…的)<br>不合乎法律的, 即"不合法的" |
| privileged<br><br>adj. 有特权的; 特许的 | privilege→privileg(词: 特权), -ed(…的)<br>拥有普通人没有的特权的 |


### leuc(o), leuk(o)

白

| 单词 | 拆解 |
| --- | --- |
| leucine<br><br>n. 白氨酸 | **leuc(白)**, -ine(…的)<br>围绕“白”这一核心含义构成, 表示“白氨酸” |
| leucocyte<br><br>n. 白细胞; 白血球 | **leuco(白)**, **cyt(细胞)**, e(连接字母)<br>围绕“白”这一核心含义构成, 表示“白细胞, 白血球” |
| leuk(a)emia<br><br>n. 白血病 | 由希腊语 leukos“白”与 haima“血”构成, 词尾 -ia 表示状态<br>字面为“白血状态”, 即白血病 |
| leukocyte<br><br>n. 白细胞; 白血球 | **leuko(白)**, **cyt(细胞)**, e(连接字母)<br>围绕“白”这一核心含义构成, 表示“白细胞, 白血球” |
| leukopenia<br><br>n. 白细胞减少; 白血球减少 | 由希腊语 leuko“白”与 penia“缺乏”构成<br>白细胞数量不足 |


### lev

举, 升

| 单词 | 拆解 |
| --- | --- |
| alleviate<br><br>v. 减轻; 使缓和; 缓解 | al-(到, 朝, 向), **lev(举, 升)**, i(连接字母), -ate(做, 使)<br>把压在身上的重量举起一些, 因此表示减轻、缓和 |
| elevate<br><br>v. 抬起; 提高; 提拔; 晋升; 使精神振奋 | e-(出, 向外), **lev(举, 升)**, -ate(做, 使)<br>把事物向上抬升, 因此表示提高、举起 |
| levitate<br><br>v. (使) 升在空中; (使) 飘浮在空中 | levity→levit(词: 轻盈), -ate(做, 使)<br>使变得轻盈并升离地面, 即悬浮 |
| elevation<br><br>n. 提升; 提高; 高度 | e-(出, 向外), **lev(举, 升)**, -ation(行为, 结果)<br>向上升起的行为或高度, 即"海拔" |
| elevator<br><br>n. 电梯; 升降机; 起重工人 | e-(出, 向外), **lev(举, 升)**, -ator(物)<br>把人或物向上举升的装置, 即电梯、升降机 |
| lever<br><br>n. 杠; 杠杆; 手段; 方法; 操纵杆<br>v. 撬动 | **lev(举, 升)**, -er(物)<br>用于撬起物体的杠杆 |
| leverage<br><br>n. 筹码; 谈判砝码 | 由 lever“杠杆”形成 leverage<br>由杠杆作用引申为可用于谈判的优势、筹码 |
| levity<br><br>n. 轻率; 轻浮 | **lev(举, 升)**, -ity(性质, 状态)<br>表示与“举”有关的性质或状态, 即“轻率, 轻浮” |
| levy<br><br>n. 征税; 税款<br>v. 征税; 征收 | 经古法语 levée“举起、征集”进入英语<br>由召集人员或筹集款项发展为征收、征召 |


### levo

左

| 单词 | 拆解 |
| --- | --- |
| levorotatory<br><br>adj. 左旋的; 逆时针方向旋转的 | **levo(左)**, **rot(转, 轮)**, -ate(…的), -ory(…的)<br>化学中使偏振光的偏振平面沿逆时针向左旋转的旋光性质, 即左旋的 |
| levogyrate<br><br>adj. 左旋的 | **levo(左)**, **gyr(o)(环, 旋转)**, -ate(…的)<br>偏振光或结构向左侧旋转的 |


### liber, liver

自由

| 单词 | 拆解 |
| --- | --- |
| deliver<br><br>v. 递送; 发表(讲话); 兑现; 接生; 解救 | de-(脱离, 取消, 除去), **liver(自由)**<br>原指使脱离束缚而获得自由, 后来扩展为交付、递送 |
| liberate<br><br>v. 解放; 使获自由 | **liber(自由)**, -ate(做, 使)<br>围绕“自由”这一核心含义构成, 表示“解放, 使获自由” |
| delivery<br><br>n. 交货; 传送; 转让; 分娩; 演讲 | deliver→deliver(词: 递送; 解救), -y(活动)<br>递送或交付的行为 |
| liberal<br><br>adj. 开明的; 自由的; 慷慨的; 宽泛不严格的<br>n. 自由主义者 | **liber(自由)**, -al(…的)<br>表示与“自由”有关或具有该特征, 即“慷慨的, 大方的” |
| liberalization<br><br>n. 自由化 | liberal(词: 自由主义者), -ization(行为, …化)<br>使事物呈现“自由的”所表达的状态, 即“自由化” |
| liberation<br><br>n. 解放; 摆脱束缚; [化] 释放 | **liber(自由)**, -ation(行为, 结果)<br>围绕“自由”这一核心含义构成, 表示“解放, 摆脱束缚, [化] 释放” |
| libertarian<br><br>n. 自由意志主义支持者; 行动自由者<br>adj. 自由意志主义支持者的; 主张个人思想的 | **liber(自由)**, t(连接字母), -arian(人)<br>围绕“自由”这一核心含义构成, 表示“自由意志论者(的)” |
| libertine<br><br>n. 浪子, 放荡的人 | **liber(自由)**, t(连接字母), -ine(…的)<br>围绕“自由”这一核心含义构成, 表示“浪子, 放荡的人” |
| liberty<br><br>n. 自由(自己选择生活方式而不受政府或权威限制); 自作主张的行为; 冒犯的举动; 放肆的行为 | **liber(自由)**, -ty(性质, 状态)<br>表示与“自由”有关的性质或状态, 即“自由(自己选择生活方式而不受政府或权威限制)” |


### lic

许可; 离开; 诱惑, 诱使

| 单词 | 拆解 |
| --- | --- |
| elicit<br><br>v. 引出(某种情绪); 探出; 套出 | 源自拉丁语 elicere“引出、诱出”<br>使隐藏的回答、反应或信息显现出来 |
| licence<br><br>n. 执照; 许可证; 特许<br>v. 许可; 特许; 认可 | **lic(许可)**, -ence(性质, 状态)<br>表示与“许可”有关的性质或状态, 即“许可(证), 特许(证), 执照” |
| licensee<br><br>n. 领有许可证(或执照)者 | license→licens(词: 许可), -ee(接受动作的人)<br>在前词基础上加“-ee”构成名词, 表示“领有许可证(或执照)者” |
| licensure<br><br>n. 许可证的发给 | license→licens(词: 许可), -ure(行为, 结果)<br>在前词基础上加“-ure”构成名词, 表示“许可证的发给” |
| licentiate<br><br>n. (从大学或学会等)领有开业证书的人 | 源自中世纪拉丁语 licentiatus“获许可者”<br>取得执业许可或特定学位的人 |
| elicitation<br><br>n. 引出; 导出; 启发 | elicit(词: 引出), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“引出” |
| illicit<br><br>adj. 违法的; 禁止的 | 源自拉丁语 illicitus“不被允许的”<br>表示未经许可、违反法律或规则的 |
| licenced<br><br>adj. 得到许可(或批准)的; 领有执照的 | licence→licenc(词: 许可), -ed(…的)<br>已经获得许可或执照的 |
| licit<br><br>adj. 合法的; 正当的 | 源自拉丁语 licitus“被允许的”<br>表示法律或规则所许可的 |
| delicate<br><br>adj. 精巧的; 脆弱的; 娇柔的; 微妙的; 鲜美的 | 经法语借自拉丁语 delicatus“令人愉悦、精美的”, 更早来源未定<br>由精美引申为精巧、娇弱及需谨慎处理的 |
| delicious<br><br>adj. 美味的; 可口的; 怡人的 | de-(一再等加强意义), **lic(诱惑, 诱使)**, -ious(…的)<br>强烈诱发愉悦感的, 即美味的、令人愉悦的 |


### lig, li

捆绑, 连接

| 单词 | 拆解 |
| --- | --- |
| liaise<br><br>v. 建立(或维持)联络关系; 充当联络官 | 20世纪由 liaison“联络”逆构出的动词<br>建立联络、协调 |
| oblige<br><br>v. 以誓言(或契约等)束缚(某人); 迫使; 责成 | ob-(对着, 朝向, 在前), lig(捆绑, 连接), e(连接字母)<br>以义务或情势约束某人, 即迫使; 也引申为帮忙 |
| rely<br><br>v. 依赖; 信任 | 经古法语 relier（系紧、联合）进入英语, 由依附发展为依赖 |
| alliance<br><br>n. 同盟; 联盟; 联姻 | al-(到, 朝, 向), li(捆绑, 连接), -ance(性质, 状态)<br>把各方联结在一起, 因此表示联盟、联合 |
| ally<br><br>n. 同盟国; 盟友<br>v. 结盟; 联合 | 经古法语借自拉丁语 alligare, 由 ad“向”与 ligare“绑”构成<br>绑在一起的人或国家, 即盟友 |
| league<br><br>n. 联盟; 同盟; 联赛; 级别 | 经法语 ligue 进入英语, 源自拉丁语 ligare“捆绑”<br>把成员联结在一起的联盟 |
| liability<br><br>n. 责任; 义务; 负债; [复]债务 | li(捆绑, 连接), -ability(可…性)<br>被绑定担负义务的状态, 即"法律责任" |
| liaison<br><br>n. 私通; 勾芡; (尤指军队中的)联络; [语]连音 | 借自法语 liaison“连接”, 来自 lier“绑、连接”<br>连接双方的人或关系 |
| obligation<br><br>n. 义务; 责任; 合约 | ob-(对着, 朝向, 在前), lig(捆绑, 连接), -ation(行为, 结果)<br>像被法律或承诺捆住一样必须履行的责任 |
| obligee<br><br>n. 权利人; 债权人; 债主 | ob-(对着, 朝向, 在前), lig(捆绑, 连接), -ee(接受动作的人)<br>在前词基础上加“-ee”构成名词, 表示“权利人” |
| obligor<br><br>n. 义务人; 债务人; 欠债者 | ob-(对着, 朝向, 在前), lig(捆绑, 连接), -or(人)<br>在前词基础上加“-or”构成名词, 表示“义务人” |
| reliance<br><br>n. 依赖; 依靠; 信赖 | rely→reli(词: 信赖), -ance(性质, 状态)<br>由“信赖”派生为当前词义 |
| religion<br><br>n. 宗教 | re-(回, 向后, 再次), **lig(读, 言)**, -ion(行为, 结果)<br>可能源于反复研读或重新联结的观念, 词源有争议; 现代义为宗教 |
| religiosity<br><br>n. 笃信宗教; 宗教狂 | 由 religious“宗教的”派生<br>宗教虔诚或宗教性 |
| liable<br><br>adj. 有法律责任的; 有义务的; 可能的; 有…倾向的 | li(捆绑, 连接), -able(可…的)<br>围绕“捆”这一核心含义构成, 表示“有(法律)责任的, 有义务的” |
| obligatory<br><br>adj. 有义务的; 有责任的; 强制性的; 必须履行的 | ob-(对着, 朝向, 在前), lig(捆绑, 连接), -atory(…的)<br>在前词基础上加“-atory”构成形容词, 表示“有义务的” |
| obliging<br><br>adj. (道义或法律上)必须履行的; 应尽的; 强制性的 | ob-(对着, 朝向, 在前), lig(捆绑, 连接), -ing(…的)<br>受义务约束的; 也可引申为愿意帮忙的 |
| reliable<br><br>adj. 可靠的; 可信赖的 | re-(回, 向后, 再次), li(捆绑, 连接), -able(可…的)<br>能够把信任牢牢系在其上的, 因此表示可靠的 |


### lim,limin,limit

界限

| 单词 | 拆解 |
| --- | --- |
| eliminate<br><br>v. 消除; 除掉(威胁) | e-(出, 向外), **limin(界限)**, -ate(做, 使)<br>使被排除到界限之外, 即"消除" |
| eliminator<br><br>n. 排除者; 消除器 | eliminate→eliminat(词: 除去), -or(人)<br>执行消除的人; 也可引申指消除装置 |
| limitation<br><br>n. 限制; 限度; 局限; (诉讼) 时效 | **limit(界限)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“限制” |
| liminal<br><br>adj. [心] 阈限的 | **limin(界限)**, -al(…的)<br>表示与“界限”有关或具有该特征, 即“阈限的” |
| limited<br><br>adj. 有限的 | **limit(界限)**, -ed(…的)<br>在前词基础上加“-ed”构成形容词, 表示“有限的” |
| sublime<br><br>adj. 崇高的 | sub-(在下, 向下), **lim(界限)**, e(连接字母)<br>到顶的 |


### lingu(i), lingu(o)

舌, 语言

| 单词 | 拆解 |
| --- | --- |
| bilingualism<br><br>n. 通晓两种语言; 用两种语言 | bi-(两, 双), **lingu(i), lingu(o)(舌, 语言)**, -al(…的), -ism(主义)<br>由表示“两、双”的前缀、“语言”词根与名词后缀结合, 指能熟练使用两种语言的能力或两种语言并用的社会现象, 即“通晓两种语言, 双语现象” |
| Linguaphone<br><br>n. 灵格风 | **lingu(i), lingu(o)(舌, 语言)**, a(连接字母), **phon(o)(声音)**, e(连接字母)<br>结合“语言”与“声音”概念构成的品牌名, 指借助唱片/录音进行语言发音与听力训练的教学系统, 即“灵格风” |
| linguist<br><br>n. 语言学家 | **lingu(i), lingu(o)(舌, 语言)**, -ist(人)<br>由表示“语言”的词根与专职人员后缀结合, 指熟练掌握多种语言或专门从事语言科学研究的专家, 即“语言学家” |
| linguistics<br><br>n. 语言学 | **lingu(i), lingu(o)(舌, 语言)**, -ist(人), -ics(…学)<br>由表示“语言”的词根派生出专门研究者, 再加学科后缀“-ics”, 指系统研究人类语言结构、运用与演化的专门科学, 即“语言学” |
| bilingual<br><br>adj. 流利地讲两种语言的; (文本或活动)双语的; 用两种语言进行的; (国家/城市/社区)使用两种语言的(尤指正式地)<br>n. 能讲两国话的人 | bi-(两, 双), **lingu(i), lingu(o)(舌, 语言)**, -al(…的)<br>由表示“两、双”的前缀与“语言”词根结合, 指能流利使用两种语言的, 或用两种语言表达的, 也指通晓两国语言的人 |
| linguistic<br><br>adj. 语言的; 语言学的 | **lingu(i), lingu(o)(舌, 语言)**, -istic(…的)<br>由表示“语言”的词根与形容词后缀结合, 表示与语言本身或其研究相关的特征, 引申为“语言的; 语言学的” |
| multilingual<br><br>adj. 多种语言的; 懂 (或用) 多种语言的 | multi-(多), **lingu(i), lingu(o)(舌, 语言)**, -al(…的)<br>由表示“多”的前缀、“语言”词根与形容词后缀结合, 指涉及、使用或掌握多种不同语言的, 即“多种语言的; 懂 (或用) 多种语言的” |
| sublingual<br><br>adj. 舌下的 | sub-(在下, 向下), **lingu(i), lingu(o)(舌, 语言)**, -al(…的)<br>由表示“在下”的前缀、“舌”词根与形容词后缀结合, 指位于舌头下方的解剖生理位置, 即“舌下的” |


### linqu, liqu

离开

| 单词 | 拆解 |
| --- | --- |
| relinquish<br><br>v. 放弃; 交出(控制权) | re-(回, 向后, 再次), **linqu(离开)**, -ish(…的)<br>放开并让某物离去, 因此表示放弃、交出 |
| delinquency<br><br>n. 懈怠; 失职; 过失; 少年犯罪 | de-(一再等加强意义), **linqu(离开)**, -ency(性质, 状态)<br>离开应尽的责任或合法轨道, 因此表示失职、违法行为 |
| delinquent<br><br>adj. 怠忽的; 有过失的<br>n. 行为不良的人; 违法者 | 源自拉丁语 delinquere“失职、犯罪”, 由 de“离开”与 linquere“留下”构成<br>离开职责轨道的人 |
| relic<br><br>n. 文物; 遗迹; 历史遗存 | re-(回, 向后, 再次), **lic(离开)**<br>从过去留下来的东西, 即遗物、遗迹 |
| reliquary<br><br>n. 遗物箱 | 源自拉丁语 reliquiae“遗物、遗骸”并加 -ary<br>存放圣人遗物或遗骸的容器 |


### liqu

液体

| 单词 | 拆解 |
| --- | --- |
| liquefy<br><br>v. (使)液化 | **liqu(液体)**, e(连接字母), -fy(…化, 做…)<br>使变成液体, 即液化 |
| liquefaction<br><br>n. 液化(作用) | **liqu(液体)**, e(连接字母), -faction(制作, 形成)<br>形成液体的过程, 即液化 |
| liquid<br><br>n. 液体; 流体; 流音<br>adj. 液体的; 透明的; 明亮的 | **liqu(液体)**, -id(…的)<br>具有流动性质的物质, 即液体或液态的 |
| liquidation<br><br>n. 了结; 清算; 肃清; 消灭 | liquidate→liquidat(词: 偿付), -ion(行为, 结果)<br>由“偿付”派生为当前词义 |
| liquidity<br><br>n. 流动性; 流畅 | liquid(词: 流动的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“流动性” |
| liquor<br><br>n. 液; 液体; 汁; 溶液; 烈性酒 | 源自拉丁语 liquor“液体”<br>后来专指含酒精的饮料 |


### liter

文字, 字母

| 单词 | 拆解 |
| --- | --- |
| obliterate<br><br>v. 涂抹; 删除; 擦掉 | ob-(对着, 朝向, 在前), **liter(文字, 字母)**, -ate(做, 使)<br>在文字或痕迹上反复涂抹使其消失, 因此表示擦除、毁灭 |
| illiterate<br><br>n. 文盲<br>adj. 文盲的; 不识字的 | 构词锚点：il 表示“无, 不, 非”; liter 表示“文字, 字母”; -ate 在此为名词或形容词词尾, 不取动词义<br>否定或缺少“文字”所指的性质, 因此表示“不识字的 (人), 文盲 (的), 无文化的 (人)” |
| literalism<br><br>n. 拘泥于字面意义的倾向; 对字面的忠实 | 由 literal“字面的”形成 literalism<br>拘泥于字面意义的倾向 |
| literate<br><br>n. 识字的人<br>adj. 识字的; 有文化的 | 构词锚点：liter 表示“文字, 字母”; -ate 在此为名词或形容词词尾, 不取动词义<br>围绕“文字”这一核心含义构成, 表示“有文化的 (人), 识字的 (人)” |
| literature<br><br>n. 文学 (作品) | **liter(文字, 字母)**, -at(做, 使), -ure(行为, 结果)<br>围绕“文字”这一核心含义构成, 表示“文学 (作品)” |
| transliteration<br><br>n. 按字母直译; 音译 | trans-(横过, 越过), **liter(文字, 字母)**, -ation(行为, 结果)<br>由一种字母转换成另一种字母 |
| literal<br><br>adj. 文字 (上) 的; 字面的; 逐字的; 字母的 | **liter(文字, 字母)**, -al(…的)<br>表示与“文字”有关或具有该特征, 即“文字 (上) 的” |
| literary<br><br>adj. 文学 (上) 的; 书本的 | **liter(文字, 字母)**, -ary(…的)<br>围绕“文字”这一核心含义构成, 表示“文学 (上) 的” |


### lith(o), li

石

| 单词 | 拆解 |
| --- | --- |
| cryolite<br><br>n. 冰晶石 | 由希腊语 kryos“冰冷”与 lithos“石”构成<br>因外观似冰而得名的冰晶石 |
| lithograph<br><br>n. 平版 (指石版或金属版) 画; 平版印刷品 | **litho(石)**, **graph(写, 画)**<br>记录或描绘“石”的方法, 即“平版 (指石版或金属版) 画” |
| lithology<br><br>n. 岩性学; 岩性 | **litho(石)**, -logy(…学, …研究)<br>以“石”为研究对象的学科, 即“岩性学” |
| lithosphere<br><br>n. 陆界; 岩石圈 | **litho(石)**, sphere(词: 球)<br>由“石”与“球”共同限定词义, 表示“岩石圈” |
| microlite<br><br>n. 微晶; 细晶石 | 由 micro“小”与 lithos“石”构成<br>极小晶体或微小矿物 |
| megalithic<br><br>adj. 巨石 (制) 的 | **mega(大, 百万)**, **lith(石)**, -ic(…的)<br>由“大”与“石”共同限定词义, 表示“巨石 (制) 的” |


### loc(o)

地方, 位置

| 单词 | 拆解 |
| --- | --- |
| allocate<br><br>v. 分配…(给); 拨…(给); 划…(归) | al-(到, 朝, 向), **loc(地方, 位置)**, -ate(做, 使)<br>分派到某个地方, 即"分配" |
| locate<br><br>v. 位于; 确定…的位置; 找到; 设置; 建立 | **loc(地方, 位置)**, -ate(做, 使)<br>围绕“位置”这一核心含义构成, 表示“位于” |
| translocate<br><br>v. 改变位置; 易位 | trans-(横过, 越过), **loc(地方, 位置)**, -ate(做, 使)<br>由“横过”与“位置”共同限定词义, 表示“改变位置, 易位” |
| collocation<br><br>n. 并置; 并列 | col-(与, 共同), **loc(地方, 位置)**, -ation(行为, 结果)<br>使“位置”共同结合或发挥作用, 因此表示“并置, 并列” |
| dislocation<br><br>n. 离开原位; 脱位; 脱臼 | dis-(否定, 相反), **loc(地方, 位置)**, -ation(行为, 结果)<br>使不在原来的位置 |
| localism<br><br>n. 地方主义; 方言; 土语 | local(词: 地方性的), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“地方主义” |
| localization<br><br>n. 地方化; 局限 | local(词: 地方性的), -ization(行为, …化)<br>在前词基础上加“-ization”构成名词, 表示“地方化” |
| locator<br><br>n. 定位器 | **loc(地方, 位置)**, -ator(物)<br>用于确定位置的装置, 即定位器 |
| locomotive<br><br>adj. 移动的; 运动的<br>n. 火车头; 机车 | **loco(地方, 位置)**, **mot(动, 移动)**, -ive(人; 物)<br>使列车从一处移动到另一处的机器, 即机车 |
| relocation<br><br>n. 重新定位; 重新安置 | re-(回, 向后, 再次), **loc(地方, 位置)**, -ation(行为, 结果)<br>由“重新”与“位置”共同限定词义, 表示“重新定位” |
| local<br><br>adj. 当地的<br>n. 当地人 | **loc(地方, 位置)**, -al(…的)<br>表示与“地方”有关或具有该特征, 即“地方的, 当地的, 本地的” |


### log(u)

说, 言

| 单词 | 拆解 |
| --- | --- |
| neologism<br><br>n. 新语; 新词 | 由 neo“新的”与希腊语 logos“词语”形成<br>新创造或新使用的词语, 即新词 |
| philologist<br><br>n. 语文学家; 语言学家 | **philo(爱)**, **log(说, 言)**, -ist(人)<br>爱好并研究语言文字的人, 即语言学者或文献学者 |
| philology<br><br>n. 语文(文献)学; 语言学 | 由希腊语 philos“爱”与 logos“语言、学问”构成<br>对语言和文献的研究 |
| prologue<br><br>n. 前言; 序言 | pro-(向前, 前进), **logu(说, 言)**, e(连接字母)<br>由“向前”与“言”共同限定词义, 表示“前言, 序言” |
| illogical<br><br>adj. 不合逻辑的 | il-(无, 不, 非), **log(说, 言)**, -ical(…的)<br>否定或缺少“说”所指的性质, 因此表示“不合逻辑的” |


### long, leng, ling

长; 归属

| 单词 | 拆解 |
| --- | --- |
| lengthen<br><br>v. 延长; 使变长 | length(词: 长), -en(做, 使)<br>在前词基础上加“-en”构成动词, 表示“延长” |
| linger<br><br>v. 逗留; 徘徊; 磨蹭; 苟延残喘; 缓慢消退 | 日耳曼语源, 可能受古诺尔斯语同源形式影响<br>表示迟迟停留或持续不散 |
| prolong<br><br>v. 延长 | pro-(向前, 前进), **long(长)**<br>由“向前”与“长”共同限定词义, 表示“延长” |
| length<br><br>n. 长; 长度 | **leng(长)**, -th(性质, 状态)<br>围绕“长”这一核心含义构成, 表示“长度” |
| longevity<br><br>n. 长寿; 长命; 长期供职; 资历 | **long(长)**, **ev(年龄, 时代)**, -ity(性质, 状态)<br>由“长”与“寿命”共同限定词义, 表示“长寿, 长命” |
| longitude<br><br>n. 经度; 长; 长度 | **long(长)**, -itude(性质, 状态)<br>围绕“长”这一核心含义构成, 表示“经度” |
| oblong<br><br>n. 长方形; 长椭圆形<br>adj. 长方形的; 长椭圆形的 | ob-(对着, 朝向, 在前), **long(长)**<br>由“对着”与“长”共同限定词义, 表示“长方形 (的)” |
| prolongation<br><br>n. 延长; 拉长; 拖延; 延长的部分 | prolong(词: 延长), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“延长” |
| lingering<br><br>adj. 拖延的; 逗留不去的 | linger(词: 逗留), -ing(…的)<br>长时间逗留不去的 |
| longish<br><br>adj. 稍长的 | **long(长)**, -ish(…的)<br>围绕“长”这一核心含义构成, 表示“稍长的” |


### loqu, locu

说, 言

| 单词 | 拆解 |
| --- | --- |
| colloquialism<br><br>n. 俗语; 口语; 口语词 | 由 colloquial“口语的”形成 colloquialism<br>日常谈话中使用的口语表达 |
| elocution<br><br>n. 演说术; 雄辩术 | e-(出, 向外), **locu(说, 言)**, -tion(行为, 结果)<br>把话清楚说出的技巧, 即演说术、朗诵法 |
| eloquent<br><br>adj. 有口才的; 雄辩的; 善辩的; 有说服力的 | e-(出, 向外), **loqu(说, 言)**, -ent(…的)<br>能把话语有力地说出来, 因此表示有口才的、雄辩的 |
| loquacious<br><br>adj. 多言的; 饶舌的 | **loqu(说, 言)**, -acious(…的)<br>围绕“言”这一核心含义构成, 表示“多言的, 饶舌的” |


### luc, lux, lust(r), lumin

光, 照

| 单词 | 拆解 |
| --- | --- |
| illuminate<br><br>v. 照亮; 照明; 阐释; 说明 | il-(无, 不, 非; 向内, 进入), **lumin(光, 照)**, -ate(做, 使)<br>将光线带入暗处, 引申指照明、照亮以及使道理清楚明晰 |
| illustrate<br><br>v. (用图等)说明; 给 (书)加插图 (或图表); （用图等）说明; 给（书）加插图（或图表） | il-(无, 不, 非), **lustr(光, 照)**, -ate(做, 使)<br>使发出光亮照亮清楚, 即"说明" |
| illuminator<br><br>n. 发光器; 照明装置; 启发者 | illuminate→illuminat(词: 照明), -or(物)<br>提供光亮的装置, 也可引申指带来启发的人 |
| illustration<br><br>n. 例证; 说明; 图解; 图示; 插图 | illustrate→illustrat(词: 说明; 图解), -ion(行为, 结果)<br>用图像或例子说明的过程或结果 |
| luminary<br><br>n. 发光体; 杰出人物 | 源自 lumin（光、照）, 本义为发光体; 转喻为在某一领域照亮他人的杰出人物 |
| luminosity<br><br>n. 光明; 光辉 | **lumin(光, 照)**, -osity(性质, 状态)<br>围绕“光”这一核心含义构成, 表示“光明, 光辉” |
| luster<br><br>n. 光泽 | 经法语和拉丁语进入英语, 核心意象是光亮<br>表示物体表面的光泽 |
| luxury<br><br>n. 奢侈; 奢侈品<br>adj. 奢侈的 | 源自拉丁语 luxuria（过度、奢华）, 经法语进入英语 |
| lucid<br><br>adj. 透明的; 照亮的; 光辉的 | **luc(光, 照)**, -id(…的)<br>围绕“光”这一核心含义构成, 表示“透明的” |
| luminescent<br><br>adj. 发光的 | **lumin(光, 照)**, -escent(开始或正在形成…的)<br>开始发出光亮的, 即"发光的" |
| luminous<br><br>adj. 发光的; 明白的 | **lumin(光, 照)**, -ous(…的)<br>表示与“光”有关或具有该特征, 即“发光的” |
| lustrous<br><br>adj. 有光泽的 | **lustr(光, 照)**, -ous(…的)<br>表示与“光”有关或具有该特征, 即“有光泽的” |
| luxurious<br><br>adj. 奢侈的; 豪华的 | 由 luxury“奢华”派生, 最终源自拉丁语 luxuria“过度”<br>奢侈的; 丰盛舒适的 |
| translucent<br><br>adj. 半透明的 | trans-(横过, 越过), **luc(光, 照)**, -ent(…的)<br>光线能透过的 |


### lud, lus

玩, 奏

| 单词 | 拆解 |
| --- | --- |
| allude<br><br>v. 间接提及; 暗示 | al-(到, 朝, 向), **lud(玩, 奏)**, e(连接字母)<br>像借游戏暗示规则一样不直说, 因此表示间接提及、暗示 |
| elude<br><br>v. (巧妙地) 逃避; 躲避 (责任; 困难; 危险等); 使困惑 | e-(出, 向外), **lud(玩, 奏)**, e(连接字母)<br>强化“玩”这一动作或状态, 因此表示“(巧妙地) 逃避, 躲避 (责任、困难、危险等)” |
| prelude<br><br>n. 序曲; 前奏 | pre-(先于, 预先), **lud(玩, 奏)**, e(连接字母)<br>由“前”与“奏”共同限定词义, 表示“序曲, 前奏” |
| elusive<br><br>adj. 难以捉摸的; 难以找到的 | 与 elude“逃避”同源, 源自拉丁语 eludere“逃出游戏”<br>总能避开抓取或理解的 |
| ludicrous<br><br>adj. 滑稽的 | 源自拉丁语 ludicrus（游戏的、玩笑的）, 后来发展为荒唐可笑的 |


### lun

月亮

| 单词 | 拆解 |
| --- | --- |
| lunacy<br><br>n. 疯狂; 精神错乱 | **lun(月亮)**, -acy(性质, 状态)<br>迷惑于月亮盈亏现象的变化 |
| lunation<br><br>n. 太阴月 | **lun(月亮)**, -ation(行为, 结果)<br>围绕“月亮”这一核心含义构成, 表示“太阴月” |
| lunar<br><br>adj. 月亮的; 月球的 | **lun(月亮)**, -ar(…的)<br>围绕“月亮”这一核心含义构成, 表示“月亮的, 月球的” |
