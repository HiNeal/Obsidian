## oyword-root-k


### kin(e), kines, kinemat(o)

运动

| 单词 | 拆解 |
| --- | --- |
| kinematics<br><br>n. 运动学 | **kinemat(运动)**, -ics(…学)<br>在前词基础上加“-ics”构成名词, 表示“运动学” |
| kinesiology<br><br>n. 运动学; 运动疗法 | 由希腊语 kinesis“运动”与 logy“研究”构成<br>研究人体运动的学科 |
| kinematic (al)<br><br>adj. 运动学的 | **kinemat(运动)**, -ical(…的)<br>表示与“运动”有关或具有该特征, 即“运动学的” |
| kinetic<br><br>adj. 动力(学)的; (运)动的; 活动的 | 源自希腊语 kinetikos“运动的”<br>与运动有关的 |
