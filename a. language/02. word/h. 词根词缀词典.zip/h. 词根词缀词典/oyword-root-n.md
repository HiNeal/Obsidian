## oyword-root-n


### nas(o)

鼻

| 单词 | 拆解 |
| --- | --- |
| nasal<br><br>adj. 鼻的; 鼻声的; 尖锐的<br>n. 鼻音; 鼻音字 | **nas(鼻)**, -al(…的)<br>围绕“鼻”这一核心含义构成, 表示“鼻的” |
| nasopharynx<br><br>n. 鼻咽 | **naso(鼻)**, pharynx(词: 咽)<br>鼻腔后方与咽相接的部分, 即鼻咽 |


### nat

出生; 漂, 游

| 单词 | 拆解 |
| --- | --- |
| natality<br><br>n. 出生率 | natal(词: 出生的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“出生率” |
| nation<br><br>n. 国家; 民族; 国民 | **nat(出生)**, -ion(行为, 结果)<br>围绕“出生”这一核心含义构成, 表示“民族” |
| nationality<br><br>n. 国籍 | national(词: 国家的), -ity(性质, 状态)<br>由“国家的”派生为当前词义 |
| native<br><br>adj. 本国的; 与生俱来的; 自然的<br>n. 本地人; 土产; 当地人 | **nat(出生)**, -ive(…的)<br>出生于此的, 即"原产于" |
| nativity<br><br>n. 出生; 诞生; 出生的情况; 出生地 | **nat(出生)**, -ivity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“出生” |
| nature<br><br>n. 大自然; 本质; 本性; 性质 | **nat(出生)**, -ure(行为, 结果)<br>事物与生俱来的性质, 也指自然界 |
| naturism<br><br>n. 对自然现象的崇拜 | 由 nature“自然”派生<br>崇尚自然生活、常特指裸体主义的观念 |
| neonate<br><br>n. 出生不满一个月的婴儿 | neo-(新), **nat(出生)**, e(连接字母)<br>刚刚出生的新生儿, 通常指未满一个月的婴儿; nat 在此指‘出生’ |
| natation<br><br>n. 游泳 (术) | **nat(漂, 游)**, -ation(行为, 结果)<br>围绕“游”这一核心含义构成, 表示“游泳 (术)” |
| natatorium<br><br>n. (室内) 游泳池 | 源自晚期拉丁语 natatorium“游泳场所”, 来自 natare“游泳”<br>室内游泳馆 |
| antenatal<br><br>adj. 出生以前的; 产前的 | ante-(先于, 早于), **nat(出生)**, -al(…的)<br>由“前”与“出生”共同限定词义, 表示“出生以前的, 产前的” |
| cognate<br><br>adj. 同族的; 同种的 | co-(与, 共同), g(连接字母), **nat(出生)**, e(连接字母)<br>使“出生”共同结合或发挥作用, 因此表示“同族的, 同种的” |
| connate<br><br>adj. 同生的; 同族的 | con-(与, 共同), **nat(出生)**, e(连接字母)<br>使“出生”共同结合或发挥作用, 因此表示“同生的, 同族的” |
| natal<br><br>adj. 出生的; 诞生时的 | **nat(出生)**, -al(…的)<br>表示与“出生”有关或具有该特征, 即“出生的, 诞生时的” |
| natural<br><br>adj. 天然的; 自然的; 生来的; 自然界的 | **nat(出生)**, **ur(行为, 结果)**, -al(…的)<br>由出生和本性形成的, 即自然的 |
| postnatal<br><br>adj. 出生以后的 | post-(在后, 之后), **nat(出生)**, -al(…的)<br>由“在后”与“出生”共同限定词义, 表示“出生以后的” |
| prenatal<br><br>adj. 出生以前的 | pre-(先于, 预先), **nat(出生)**, -al(…的)<br>由“前”与“出生”共同限定词义, 表示“出生以前的” |
| unnatural<br><br>adj. 不自然的; 做作的 | un-(无, 不, 非), natural(词: 自然的)<br>否定或缺少“自然的”所指的性质, 因此表示“不自然的” |


### nav, naut

船

| 单词 | 拆解 |
| --- | --- |
| circumnavigate<br><br>v. 环球航行 | circum-(四周, 周围), **nav(船)**, **ig(做, 行动)**, -ate(做, 使)<br>由“四周”与“船”与“行动”共同限定词义, 表示“环球航行” |
| navigate<br><br>v. 航行; 横渡 | **nav(船)**, **ig(做, 行动)**, -ate(做, 使)<br>驱动船只寻找航路, 后引申为在复杂环境中导航、找方向 |
| aeronaut<br><br>n. 飞艇 (或气球) 的驾驶员 (或乘客) | **aero(空中, 空气)**, **naut(船)**<br>由“空气”与“船”共同限定词义, 表示“飞艇 (或气球) 的驾驶员 (或乘客)” |
| aeronautics<br><br>n. 航空学; 航空术 | **aero(空中, 空气)**, **naut(船)**, -ics(…学)<br>以“航空、船”为研究对象的学科, 即“航空学” |
| aquanaut<br><br>n. 潜航员; 海底作业员 | **aqua(水)**, **naut(船)**<br>像航海者一样在水下活动和观察的人, 即海底观察员 |
| circumnavigation<br><br>n. 环球航行 | circum-(四周, 周围), **nav(船)**, **ig(做, 行动)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“环球航行” |
| cosmonaut<br><br>n. 宇宙航行员 | **cosmo(世界, 宇宙)**, **naut(船)**<br>由“宇宙”与“船”共同限定词义, 表示“宇宙航行员” |
| navaid<br><br>n. 助航装置 (如雷达信标); 助航系统 | **nav(船)**, aid(词: 帮助)<br>由“船”与“帮助”共同限定词义, 表示“助航装置 (如雷达信标)” |
| navigability<br><br>n. 适航性 | **nav(船)**, **ig(做, 行动)**, -ability(可…性)<br>船只能够安全航行通过的性质, 即适航性 |
| navy<br><br>n. 海军 | **nav(船)**, -y(群体)<br>围绕“船”这一核心含义构成, 表示“海军” |
| astronautic(al)<br><br>adj. 宇宙航行 (员) 的 | **astro(星, 天体)**, **naut(船)**, -ical(…的)<br>与驾驶航天器在太空航行有关, 因此表示宇航的、航天的 |
| nautical<br><br>adj. 航海的; 海员的; 船舶的 | **naut(船)**, -ical(…的)<br>表示与“船”有关或具有该特征, 即“航海的” |
| naval<br><br>adj. 海军的; 军舰的; 船的 | **nav(船)**, -al(…的)<br>与船只相关的, 即"海军的" |
| navicular<br><br>adj. 船形的; 舟状的 | **nav(船)**, -icular(…的)<br>围绕“船”这一核心含义构成, 表示“船形的, 舟状的” |
| navigable<br><br>adj. 可航行的; 可通航的 | navigate→navig(词: 航行), -able(可…的)<br>可供船只航行的 |


### necr(o)

死, 死尸

| 单词 | 拆解 |
| --- | --- |
| necrology<br><br>n. 死亡者名单; 死亡通知; 讣告 | **necro(死, 死尸)**, **log(说, 言)**, -y(活动)<br>汇集逝者姓名或生平记录的名单 |
| necromancer<br><br>n. 向亡魂问卜的巫术者; 巫术师; 行妖术者 | **necr(o)(死, 死尸)**, o(连接元音), **mancer(占卜者)**<br>声称能通灵招魂、向亡魂问卜未来的巫术师, 即死灵法师 |
| necromancy<br><br>n. 向亡魂问卜的巫术; 巫术; 妖术 | **necro(死, 死尸)**, **mancy(占卜)**<br>由“死”与“占卜”共同限定词义, 表示“向亡魂问卜的巫术” |
| necropolis<br><br>n. 坟地 | **necro(死, 死尸)**, **polis(城市)**<br>死者之城 |
| necropsy<br><br>n. 尸体剖检; 验尸 | 由 necro“尸体”与 opsy“观看、检查”构成<br>尸体剖检 |
| necrosis<br><br>n. 坏死; 枯斑 | **necr(o)(死, 死尸)**, -osis(病症)<br>机体局部活组织或细胞因严重缺血等不可逆损伤导致的病理死亡, 即坏死 |
| necrotic<br><br>adj. 坏死的 | **necr(死, 死尸)**, -otic(…的)<br>围绕“死”这一核心含义构成, 表示“坏死的” |


### nect, nex

连接, 绑缚

| 单词 | 拆解 |
| --- | --- |
| connect<br><br>v. 连结; 连接; 把…联系起来; （使）接通（电源等） | con-(与, 共同), nect(连接, 绑缚)<br>使“联”共同结合或发挥作用, 因此表示“连结, 连接, 把…联系起来” |
| disconnect<br><br>v. 拆开; 分离 | dis-(否定, 相反), con-(与, 共同), nect(连接, 绑缚)<br>解除原有连接, 使各部分分开, 因此表示断开、分离 |
| annex<br><br>n. 附属建筑; 附加物<br>v. 吞并; 兼并; 附加 | an-(到, 朝, 向), nex(连接, 绑缚)<br>把一部分连接到主体上, 因此表示附加、吞并 |
| annexation<br><br>n. 合并; 兼并; 吞并; 附加(物) | annex(词: 兼并), -ation(行为, 结果)<br>把领土等并入的行为 |
| connection<br><br>n. 连接; 联系 | connect(词: 连接), -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“连接” |
| connective<br><br>adj. 连接的; 有联系的 | connect(词: 连接), -ive(…的)<br>在前词基础上加“-ive”构成形容词, 表示“连接的” |
| unconnected<br><br>adj. 不连结的 | un-(无, 不, 非), con-(与, 共同), nect(连接, 绑缚), -ed(…的)<br>否定或缺少“结”所指的性质, 因此表示“不连结的” |


### neg

否定

| 单词 | 拆解 |
| --- | --- |
| neglect<br><br>n. 疏忽; 忽视<br>v. 疏忽; 忽视; 漏掉 | **neg(否定)**, **lect(收, 选择)**<br>没有把本应关注的事选入注意范围, 即忽视 |
| abnegation<br><br>n. 克制(私心; 欲望等); 放弃(权利等) | ab-(脱离, 离去), **neg(否定)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“克制” |
| negative<br><br>adj. 否定的; 消极的; 负的<br>n. 否定; 否定语; 负数 | **neg(否定)**, -ative(…的)<br>围绕“否定”这一核心含义构成, 表示“否定的, 反面的, 消极的, 负的, 阴性的” |
| negativism<br><br>n. 否定态度; 怀疑主义 | negative→negativ(词: 否定的), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“否定态度” |
| negativity<br><br>n. 否定性; 消极性 | negative→negativ(词: 否定的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“否定性” |
| negligence<br><br>n. 疏忽(行为); 粗心大意; 玩忽 | **neg(否定)**, **lig(收, 选择)**, -ence(性质, 状态)<br>未把应注意之事纳入考虑的状态, 即疏忽 |
| negotiation<br><br>n. 谈判; 协商; 磋商 | **neg(否定)**, **oti(闲暇)**, -ation(行为, 结果)<br>从闲暇转入办理事务, 通过商谈达成安排, 即谈判 |
| neglectful<br><br>adj. 疏忽的; 不注意的 | neglect(词: 疏忽), -ful(充满…的)<br>在前词基础上加“-ful”构成形容词, 表示“疏忽的, 不注意的” |
| negligent<br><br>adj. 玩忽的; 疏忽的; 粗心大意的 | **neg(否定)**, **lig(收, 选择)**, -ent(…的)<br>没有认真选择、收拢注意力的, 即疏忽的 |
| negligible<br><br>adj. 可以忽略的; 微不足道的 | **neg(否定)**, **lig(收, 选择)**, -ible(可…的)<br>小到可以不纳入考虑的 |
| negotiable<br><br>adj. 可谈判的; 协商的 | negotiate→negoti(词: 谈判), -able(可…的)<br>可以谈判、转让或兑现的 |


### negr(o), nigr

黑

| 单词 | 拆解 |
| --- | --- |
| denigrate<br><br>v. 使黑; 抹黑; 贬低; 诋毁 | de-(下降, 降低; 否定, 相反; 脱离, 离去; 取消, 除去; 一再等加强意义), **nigr(黑)**, -ate(做, 使)<br>使名誉变黑, 即抹黑、诋毁 |
| denigration<br><br>n. 弄黑; 贬低; 诋毁 | 与 denigrate“抹黑、贬低”同源, 核心拉丁语 niger 表示黑<br>把某人描黑, 即贬损 |
| Negress<br><br>n. [贬] 女黑人 | **negr(黑)**, -ess(女性, 雌性)<br>围绕“黑人”这一核心含义构成, 表示“女黑人” |
| Negro<br><br>n. 黑人 | 源自西班牙语和葡萄牙语 negro（黑色的）; 该称呼现代多被视为过时或冒犯性用语 |
| negroid<br><br>n. 黑种人<br>adj. 黑色人种的 | **negr(黑)**, -oid(似…的（物）)<br>形状像“黑人”, 即“黑人(似)的” |
| negrophile<br><br>n. [常作 N-] 同黑人友好的人; 关心黑人利益的人 | **negro(黑)**, **phil(爱)**, e(连接字母)<br>由“黑”与“爱”共同限定词义, 表示“同黑人友好的人, 关心黑人利益的人” |
| nigritude<br><br>n. 黑(色); 黑色物; [喻] 邪恶 | **nigr(黑)**, -itude(性质, 状态)<br>围绕“黑”这一核心含义构成, 表示“黑(色)” |


### nephr(o)

肾

| 单词 | 拆解 |
| --- | --- |
| nephrectomy<br><br>n. 肾切除术 | 由 nephro“肾”与 ectomy“切除术”构成<br>肾切除术 |
| nephritis<br><br>n. 肾炎 | **nephr(肾)**, -itis(…炎)<br>“肾”发生炎症, 即“肾炎” |
| nephrosis<br><br>n. 肾变病 | **nephr(肾)**, -osis(状态, 过程)<br>围绕“肾”这一核心含义构成, 表示“肾变病” |


### neur(o), nerv

神经

| 单词 | 拆解 |
| --- | --- |
| nervine<br><br>n. 健神经剂<br>adj. 神经的; 有镇定作用的 | **nerv(神经)**, -ine(…的)<br>围绕“神经”这一核心含义构成, 表示“(镇定) 神经的” |
| neuralgia<br><br>n. 神经痛 | **neur(神经)**, **alg(痛)**, -ia(性质, 状态)<br>由“神经”与“痛”共同限定词义, 表示“神经痛” |
| neurasthenia<br><br>n. 神经衰弱 | 由 neuro“神经”与 astheneia“无力”构成<br>旧称神经衰弱 |
| neuritis<br><br>n. 神经炎 | **neur(神经)**, -itis(…炎)<br>“神经”发生炎症, 即“神经炎” |
| neurologist<br><br>n. 神经病学家 | **neuro(神经)**, -logist(…学家)<br>围绕“神经”这一核心含义构成, 表示“神经病学家” |
| neurology<br><br>n. 神经病学 | **neuro(神经)**, -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“神经病学” |
| neuroma<br><br>n. 神经瘤 | **neur(神经)**, -oma(肿瘤, 肿块)<br>围绕“神经”这一核心含义构成, 表示“神经瘤” |
| neuropathology<br><br>n. 神经病理学 | **neuro(神经)**, **patho(感情)**, -logy(…学, …研究)<br>以“神经、疾病”为研究对象的学科, 即“神经病理学” |
| neuropathy<br><br>n. 神经病 | **neuro(神经)**, **pathy(疾病, 疗法)**<br>由“神经”与“疾病”共同限定词义, 表示“神经病” |
| nerval<br><br>adj. 神经 (组织) 的 | **nerv(神经)**, -al(…的)<br>表示与“神经”有关或具有该特征, 即“神经 (组织) 的” |
| nervous<br><br>adj. 神经 (方面) 的; 易激动的; 神经质的 | **nerv(神经)**, -ous(…的)<br>表示与“神经”有关或具有该特征, 即“神经 (方面) 的” |
| neurogenic<br><br>adj. 起源于神经组织的; 神经性的 | **neuro(神经)**, **gen(出生, 产生)**, -ic(…的)<br>由“神经”与“出生”共同限定词义, 表示“起源于神经组织的” |
| neurotoxic<br><br>adj. 毒害神经的 | **neuro(神经)**, **tox(毒)**, -ic(…的)<br>由“神经”与“毒”共同限定词义, 表示“毒害神经的” |


### neutr(o)

中性

| 单词 | 拆解 |
| --- | --- |
| neutralize<br><br>v. (使)中立化; (使)成为无效; 中和 | 由 neutral“中性的”派生<br>使失去效力或变为中性 |
| neutral<br><br>adj. 中立的; 中性的<br>n. 中立者; 空挡 | **neutr(中性)**, -al(…的)<br>表示与“中”有关或具有该特征, 即“中立的” |
| neutrality<br><br>n. 中立(地位); 中性 | neutral(词: 中立者), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“中立” |
| neutron<br><br>n. 中子 | **neutr(中性)**, -on(粒子)<br>围绕“中”这一核心含义构成, 表示“中子” |
| neutropenia<br><br>n. 嗜中性白血球减少症 | 由 neutro“中性粒细胞”与 penia“缺乏”构成<br>中性粒细胞减少 |


### nihil

无, 不存在

| 单词 | 拆解 |
| --- | --- |
| annihilate<br><br>v. 歼灭; 消灭 | an-(到, 朝, 向), **nihil(无, 不存在)**, -ate(做, 使)<br>使事物归于不存在、化为虚无, 因此表示歼灭、消灭 |
| annihilation<br><br>n. 歼灭; 消灭 | an-(到, 朝, 向), **nihil(无, 不存在)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“歼灭” |
| annihilator<br><br>n. 歼灭者 | an-(到, 朝, 向), **nihil(无, 不存在)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“歼灭者” |
| nihilism<br><br>n. 虚无主义 | **nihil(无, 不存在)**, -ism(主义)<br>表示与“无”有关的性质或状态, 即“虚无主义” |
| nihilist<br><br>n. 虚无主义者 | **nihil(无, 不存在)**, -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“虚无主义者” |
| nihilistic<br><br>adj. 虚无主义的 | nihilist(词: 虚无主义者), -ic(…的)<br>在前词基础上加“-ic”构成形容词, 表示“虚无主义的” |


### noc, nox

伤害

| 单词 | 拆解 |
| --- | --- |
| innocence<br><br>n. 无罪, 清白, 无害; 天真 | in-(无, 不, 非), **noc(伤害)**, -ence(性质, 状态)<br>否定或缺少“伤害”所指的性质, 因此表示“无罪, 清白, 无害” |
| innocent<br><br>adj. 无罪的, 清白的; 无害的; 天真的 | in-(无, 不, 非), **noc(伤害)**, -ent(…的)<br>不造成伤害或罪过, 因此表示无辜的、无害的 |
| innocuous<br><br>adj. 无害的; 无毒的 | in-(无, 不, 非), **noc(伤害)**, -uous(…的)<br>否定或缺少“伤害”所指的性质, 因此表示“无害的” |
| noxious<br><br>adj. 有害的; 有毒的 | **nox(伤害)**, -ious(…的)<br>表示与“伤害”有关或具有该特征, 即“有害的, 有毒的” |
| obnoxious<br><br>adj. 可憎的, 讨厌的 | ob-(对着, 朝向, 在前), **nox(伤害)**, -ious(…的)<br>对…有伤害 |


### noct(i), noct(o)

夜

| 单词 | 拆解 |
| --- | --- |
| nocturne<br><br>n. 夜曲; 夜景画 | 英语内部没有可靠的同步切分<br>核心意象是夜晚, 指表现夜色氛围的乐曲或绘画 |
| noctilucent<br><br>adj. 生物(性)发光的; 夜间发生的; 夜间可见的 | **nocti(夜)**, **luc(光, 照)**, -ent(…的)<br>在前词基础上加“-ent”构成形容词, 表示“生物” |
| nocturnal<br><br>adj. 夜的; 夜间发生的; 夜出的; 夜间活动的 | 源自拉丁语 nocturnus（夜间的）, 核心 nox、noct- 意为夜 |


### nom(y)

法则, 管理; …学

| 单词 | 拆解 |
| --- | --- |
| agronomist<br><br>n. 农(艺)学家 | agronomy→agronom(词: 农学), -ist(人)<br>研究农学及作物土地管理的人 |
| astronomer<br><br>n. 天文学家; 宇航员 | **astro(星, 天体)**, **nom(…学)**, -er(人)<br>研究星辰和天体规律的人, 即天文学家 |
| autonomist<br><br>n. 自治论者 | auto-(自己, 自动), **nom(法则, 管理)**, -ist(人)<br>由“自己”与“学”共同限定词义, 表示“自治论者” |
| autonomy<br><br>n. 自治 (权); 自主 | auto-(自己, 自动), **nomy(法则, 管理)**<br>围绕“自己”这一核心含义构成, 表示“自治 (权)” |
| bionomy<br><br>n. 生态学; 生理学 | **bio(生命, 生物)**, **nomy(法则, 管理)**<br>围绕“生命”这一核心含义构成, 表示“生态学” |
| gastronomy<br><br>n. 美食法; 烹调法 | **gastro(胃, 腹)**, **nomy(法则, 管理)**<br>研究吃的方法 |
| agronomic<br><br>adj. 农(艺)学的 | **agro(田地, 土地)**, **nom(…学)**, -ic(…的)<br>由“田地”与“学”共同限定词义, 表示“农(艺)学的” |
| gastronomic<br><br>adj. 烹调法的; 美食法的 | **gastro(胃, 腹)**, **nom(法则, 管理)**, -ic(…的)<br>由“胃”与“法”共同限定词义, 表示“烹调法的, 美食法的” |


### nomin

名

| 单词 | 拆解 |
| --- | --- |
| denominate<br><br>v. 给……命名 | de-(一再等加强意义), **nomin(名)**, -ate(做, 使)<br>给人或事物明确指定名称, 即命名 |
| nominate<br><br>v. 提名; 指派; 指定; 任命 | **nomin(名)**, -ate(做, 使)<br>围绕“名”这一核心含义构成, 表示“提名” |
| denomination<br><br>n. 命名; 名称 | 与 denominate“命名”同源, 由 de“完全”与 nomen“名称”构成<br>命名所得的类别、名称或面额 |
| denominator<br><br>n. 命名者 | 由 denominate（命名、标明数值）形成的施事名词; 数学中指分母 |
| ignominy<br><br>n. 不名誉; 耻辱; 无耻行为; 丑行 | 源自拉丁语 ignominia, 由 in“无”与 nomen“名誉、名称”构成<br>失去好名声, 即耻辱 |
| nomination<br><br>n. 提名 (权); 任命 (权) | **nomin(名)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“提名” |
| nominator<br><br>n. 提名者; 任命者 | **nomin(名)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“提名者” |
| nominee<br><br>n. 被提名者; 被任命者 | **nomin(名)**, -ee(接受动作的人)<br>在前词基础上加“-ee”构成名词, 表示“被提名者” |
| ignominious<br><br>adj. 不名誉的; 不光彩的; 耻辱的 | ig-(无, 不, 非), **nomin(名)**, -ious(…的)<br>没有好名声的, 即不名誉、可耻的 |
| innominate<br><br>adj. 无名的; 匿名的 | 构词锚点：in 表示“无, 不, 非”; nomin 表示“名”; -ate 在此为形容词词尾, 不取动词义<br>否定或缺少“名”所指的性质, 因此表示“无名的, 匿名的” |
| nominal<br><br>adj. 名义上的; 有名无实的; 名字的; 列名的 | **nomin(名)**, -al(…的)<br>表示与“名”有关或具有该特征, 即“名义上的, 有名无实的” |
| nominative<br><br>adj. 主格的; 被提名的; 被任命的; 具有姓名的 | **nomin(名)**, -ative(…的)<br>在前词基础上加“-ative”构成形容词, 表示“主格的” |


### norm

正规, 规范

| 单词 | 拆解 |
| --- | --- |
| abnormality<br><br>n. 反常; 变态; 不规则 | abnormal(词: 反常的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“反常” |
| enormity<br><br>n. 巨大; 庞大; 穷凶极恶; 滔天大罪 | e-(出, 向外), **norm(正规, 规范)**, -ity(性质, 状态)<br>超过正常范围 |
| normality<br><br>n. 正规状态; 正常状态 | normal(词: 正规的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“正规状态” |
| normalization<br><br>n. 正常化; 正规化; 规范化 | normal(词: 正常), -ization(行为, …化)<br>在前词基础上加“-ization”构成名词, 表示“正常化” |
| abnormal<br><br>adj. 反常的; 变态的; 不规则的; 不正常的 | ab-(异常), **norm(正规, 规范)**, -al(…的)<br>偏离正常规范, 因此表示反常的、异常的 |
| enormous<br><br>adj. 巨大的; 极大的 | e-(出, 向外), **norm(正规, 规范)**, -ous(…的)<br>超出正常尺度, 因此表示巨大的、庞大的 |
| normal<br><br>adj. 正常的; 正规的; 规范的 | **norm(正规, 规范)**, -al(…的)<br>表示与“正规”有关或具有该特征, 即“正规的, 正常的” |
| subnormal<br><br>adj. 低于正常的 | sub-(在下, 向下), **norm(正规, 规范)**, -al(…的)<br>由“在下”与“正规”共同限定词义, 表示“低于正常的” |
| supernormal<br><br>adj. 超常态的; 在一般之上的 | super-(超), **norm(正规, 规范)**, -al(…的)<br>由“超”与“正规”共同限定词义, 表示“超常态的” |


### not

认知; 标记

| 单词 | 拆解 |
| --- | --- |
| annotate<br><br>v. 注解; 注释 | an-(到, 朝, 向), **not(标记)**, -ate(做, 使)<br>朝正文添加使人理解的标记或说明, 即注解 |
| denote<br><br>v. 表示; 意味着 | de-(一再等加强意义), **not(标记)**, e(连接字母)<br>作出明确标记使人知道, 即表示、意味着 |
| notify<br><br>v. 通知; 警告; 报告; 告知 | **not(认知)**, -ify(…化, 做…)<br>使他人知道某项信息, 即通知 |
| annotation<br><br>n. 注解; 注释 | an-(到, 朝, 向), **not(标记)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“注解” |
| annotator<br><br>n. 注解者; 注释者 | an-(到, 朝, 向), **not(标记)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“注解者” |
| notability<br><br>n. 名人; 显要人物; 值得注意(指性质或状况) | **not(认知)**, -ability(可…性)<br>围绕“知道”这一核心含义构成, 表示“名人, 显要人物” |
| notation<br><br>n. 记号; 注释; 标志(法) | **not(标记)**, -ation(行为, 结果)<br>围绕“标记”这一核心含义构成, 表示“标志(法)” |
| notice<br><br>n. 注意; 通知; 公告<br>v. 注意到; 意识到 | **not(认知)**, -ice(性质, 状态)<br>围绕“知道”这一核心含义构成, 表示“注意到, 觉察到” |
| notification<br><br>n. 通知(书) | **not(认知)**, i(连接字母), -fication(…化, 做…)<br>围绕“知道”这一核心含义构成, 表示“通知(书)” |
| notion<br><br>n. 观念; 意见 | **not(认知)**, -ion(行为, 结果)<br>在头脑中形成的认识或想法 |
| notoriety<br><br>n. 臭名昭著; 声名狼藉的人 | **not(认知)**, **ori(升起, 开始)**, -ety(性质, 状态)<br>围绕“知道”这一核心含义构成, 表示“臭名昭著” |
| notable<br><br>adj. 显著的; 著名的 | **not(认知)**, -able(可…的)<br>围绕“知道”这一核心含义构成, 表示“显著的, 著名的” |
| noted<br><br>adj. 著名的; 知名的 | **not(认知)**, -ed(…的)<br>围绕“知道”这一核心含义构成, 表示“著名的, 知名的” |
| noticeable<br><br>adj. 显而易见的; 显著的; 值得注意的; 重要的 | notice(词: 注意), -able(可…的)<br>由“注意”派生为当前词义 |
| notorious<br><br>adj. 臭名昭著的; 声名狼藉的 | 源自拉丁语 notorius“众所周知的”<br>后来多指因坏事而出名的 |


### nounc, nuncil

说

| 单词 | 拆解 |
| --- | --- |
| announce<br><br>v. 宣布; 预示; 显示; 通知 | an-(到, 朝, 向), **nounc(说)**, e(连接字母)<br>向公众说出来, 即宣布 |
| denounce<br><br>v. 公开指责; 抨击 | de-(一再等加强意义), **nounc(说)**, e(连接字母)<br>公开而强烈地说出指责, 即谴责 |
| pronounce<br><br>v. 发音; 宣布; 宣判; 发……的音 | pro-(向前, 前进), **nounc(说)**, e(连接字母)<br>把声音向前清楚说出, 因此表示发音、宣布 |
| renounce<br><br>v. 放弃 | re-(回, 向后, 再次), **nounc(说)**, e(连接字母)<br>收回所说的 |
| announcement<br><br>n. 宣布; 宣告; 通告; 预告 | announce(词: 宣布), -ment(行为, 过程)<br>在前词基础上加“-ment”构成名词, 表示“宣布” |
| pronunciation<br><br>n. 发音(方法) | pro-(向前, 前进), **nunci(说)**, -ation(行为, 结果)<br>把词语向外说出的方式, 即发音、读法 |


### nour, nurs, nutr(i)

喂养, 营养

| 单词 | 拆解 |
| --- | --- |
| nourish<br><br>v. 抚养; 滋养; 培养; 助长 | 经古法语 nourrir 进入英语, 源头与哺育、喂养有关<br>表示提供营养并促进成长 |
| innovate<br><br>v. 革新; 创新; 改革 | in-(向内, 进入), **nov(新)**, -ate(做, 使)<br>把新事物引入原有做法, 即革新、创新 |
| renovate<br><br>v. 翻新; 修复; 整修; 革新 | re-(回, 向后, 再次), **nov(新)**, -ate(做, 使)<br>由“重新”与“新”共同限定词义, 表示“更新, 刷新” |
| malnutrition<br><br>n. 营养不良 | mal-(坏, 恶, 不良), **nutr(喂养, 营养)**, -ition(行为, 结果)<br>由“坏恶, 不良”与“营养”共同限定词义, 表示“营养不良” |
| nourishment<br><br>n. 营养; 培养; 营养情况 | nourish(词: 滋养), -ment(结果)<br>由“滋养”派生为当前词义 |
| nurse<br><br>n. 护士; 保姆<br>v. 护理; 调养; 怀抱 | **nurs(喂养, 营养)**, e(连接字母)<br>照料和滋养病人或幼儿的人, 也可作动词 |
| nursery<br><br>n. 托儿所; 保育室; 苗圃; 养鱼池<br>adj. 托儿所的 | **nurs(喂养, 营养)**, -ery(场所)<br>围绕“喂”这一核心含义构成, 表示“托儿所” |
| nursing<br><br>n. 保育; 护理 | **nurs(喂养, 营养)**, -ing(行为, 过程)<br>在前词基础上加“-ing”构成名词, 表示“保育” |
| nurture<br><br>n. 养育; 培育<br>v. 养育; 培养 | **nur(喂养, 营养)**, -ture(行为)<br>围绕“营养”这一核心含义构成, 表示“营养物, 食物, 养育” |
| nutrient<br><br>n. 营养物; 滋养物<br>adj. 营养的; 滋养的 | **nutr(喂养, 营养)**, -ient(人; 物)<br>用于喂养、滋补生命的物质, 即营养物 |
| nutriment<br><br>n. 营养品; 食物; 促进生长的东西 | **nutri(喂养, 营养)**, -ment(物)<br>提供营养、促进生长的东西, 即营养品或食物 |
| nutrition<br><br>n. 营养; 滋养; 营养物; 滋养物; 食物 | **nutri(喂养, 营养)**, -tion(行为, 结果)<br>摄取和利用营养物质的过程 |
| nutritive<br><br>adj. 有营养的; 滋养的; 与营养有关的<br>n. 富有营养的食物 | **nutr(喂养, 营养)**, -itive(…的)<br>围绕“营养”这一核心含义构成, 表示“有关营养的, 有营养的, 滋养的” |
| innovation<br><br>n. 革新; 创新; 改革; 新方法; 新事物 | in-(向内, 进入), **nov(新)**, -ation(行为, 结果)<br>把新事物引入现有体系的过程或成果 |
| innovator<br><br>n. 革新者; 创新者 | in-(向内, 进入), **nov(新)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“革新者, 创新者” |
| novation<br><br>n. 更新 | **nov(新)**, -ation(行为, 结果)<br>围绕“新”这一核心含义构成, 表示“更新” |
| novel<br><br>adj. 新奇的; 异常的<br>n. 小说; 长篇故事 | **nov(新)**, -el(小)<br>故事 |
| novelette<br><br>n. 中篇小说 | novel(词: 小说), -ette(小)<br>篇幅比长篇小说短小, 因此指中篇小说 |
| novelty<br><br>n. 新奇; 新颖; 新奇的事物 | novel(词: 新奇的), -ty(性质, 状态)<br>表示与“新奇的”有关的性质或状态, 即“新奇, 新颖” |
| novice<br><br>n. 新手; 初学者 | **nov(新)**, -ice(性质, 状态)<br>新入行的人, 即"新手" |
| novitiate<br><br>n. (新手的)见习(期) | 源自拉丁语 noviciatus, 与 novice“新手”同源<br>见习期或初学者身份 |
| novobiocin<br><br>n. 新生霉素 | **novo(新)**, **bio(生命, 生物)**, c(连接字母), -in(…素)<br>由“新”与“生命”共同限定词义, 表示“新生霉素” |
| renovation<br><br>n. 更新; 翻新; 革新 | re-(回, 向后, 再次), **nov(新)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“更新” |
| renovator<br><br>n. 更新者; 革新者; 刷新者; 修复者 | re-(回, 向后, 再次), **nov(新)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“更新者” |
| nourishing<br><br>adj. 滋养的; 富于营养的 | nourish(词: 滋养), -ing(…的)<br>能够提供营养、使人得到滋养的 |
| nutritious<br><br>adj. 有营养的; 滋养的 | **nutr(喂养, 营养)**, -itious(…的)<br>能够提供丰富营养的 |
| innovative<br><br>adj. 革新的; 创新的 | in-(向内, 进入), **nov(新)**, -ative(…的)<br>能够引入新思想或新方法的 |


### nov(o)

新

| 单词 | 拆解 |
| --- | --- |
| innovate<br><br>v. 革新; 创新; 改革 | in-(向内, 进入), **nov(新)**, -ate(做, 使)<br>把新事物引入原有做法, 即革新、创新 |
| innovation<br><br>n. 革新, 创新, 改革; 新方法, 新事物 | in-(向内, 进入), **nov(新)**, -ation(行为, 结果)<br>把新事物引入现有体系的过程或成果 |
| innovative<br><br>adj. 革新的, 创新的 | in-(向内, 进入), **nov(新)**, -ative(…的)<br>能够引入新思想或新方法的 |
| innovator<br><br>n. 革新者, 创新者 | in-(向内, 进入), **nov(新)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“革新者, 创新者” |
| novation<br><br>n. 更新 | **nov(新)**, -ation(行为, 结果)<br>围绕“新”这一核心含义构成, 表示“更新” |
| novel<br><br>adj. 新奇的; 异常的<br>n. 小说; 长篇故事 | **nov(新)**, -el(小)<br>故事 |
| novelette<br><br>n. 中篇小说 | novel(词: 小说), -ette(小)<br>篇幅比长篇小说短小, 因此指中篇小说 |
| novelty<br><br>n. 新奇, 新颖; 新奇的事物 | novel(词: 新奇的), -ty(性质, 状态)<br>表示与“新奇的”有关的性质或状态, 即“新奇, 新颖” |
| novice<br><br>n. 新手; 初学者 | **nov(新)**, -ice(性质, 状态)<br>新入行的人, 即"新手" |
| novitiate<br><br>n. (新手的)见习(期) | 源自拉丁语 noviciatus, 与 novice“新手”同源<br>见习期或初学者身份 |
| novobiocin<br><br>n. 新生霉素 | **novo(新)**, **bio(生命, 生物)**, c(连接字母), -in(…素)<br>由“新”与“生命”共同限定词义, 表示“新生霉素” |
| renovate<br><br>v. 翻新; 修复; 整修; 革新 | re-(回, 向后, 再次), **nov(新)**, -ate(做, 使)<br>由“重新”与“新”共同限定词义, 表示“更新, 刷新” |
| renovation<br><br>n. 更新; 翻新; 革新 | re-(回, 向后, 再次), **nov(新)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“更新” |
| renovator<br><br>n. 更新者; 翻新者; 刷新者; 修复者 | re-(回, 向后, 再次), **nov(新)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“更新者” |


### nul, null

毫无, 没有

| 单词 | 拆解 |
| --- | --- |
| annul<br><br>v. 废除; 取消 | an-(到, 朝, 向), **nul(毫无, 没有)**<br>使原有法律或效力归于无, 因此表示废除、取消 |
| nullify<br><br>v. 使无效; 取消 | **null(毫无, 没有)**, i(连接字母), -fy(…化, 做…)<br>使事物呈现“毫无”与“…化, 做…”所表达的状态, 即“使无效, 取消” |
| nullification<br><br>n. 无效; 废弃; 取消 | **null(毫无, 没有)**, i(连接字母), -fication(…化, 做…)<br>围绕“毫无”这一核心含义构成, 表示“无效, 废弃, 取消” |
| nullity<br><br>n. 无效; 无效的东西; 无价值的东西; 不存在 | **null(毫无, 没有)**, -ity(性质, 状态)<br>表示与“毫无”有关的性质或状态, 即“无效” |
| annulled<br><br>adj. 废除的; 取消的 | annul(词: 废除), l(连接字母), -ed(…的)<br>在前词基础上加“-l-”、“-ed”构成形容词, 表示“废除的, 取消的” |


### numer(o)

数

| 单词 | 拆解 |
| --- | --- |
| enumerate<br><br>v. 数; 点数; 列举 | 源自拉丁语 enumerare, 由 e“完全”与 numerus“数”构成<br>逐一数出、列举 |
| numerate<br><br>v. 数; 计算; 读(数)<br>adj. 识数的; 有计算能力的 | 构词锚点：numer 表示“数”; -ate 在此为形容词词尾, 不取动词义<br>围绕“数”这一核心含义构成, 表示“有计算能力的” |
| enumeration<br><br>n. 计数; 列举; 细目 | 与 enumerate“列举”同源<br>逐项列出的行为或结果 |
| numeral<br><br>adj. 数字的; 表示数字的<br>n. 数字; 数 | **numer(数)**, -al(…的)<br>围绕“数”这一核心含义构成, 表示“数的” |
| numerator<br><br>n. 计算者; 计数器; 计数管 | **numer(数)**, -ator(物)<br>分数中位于横线上方、表示被分份数目的部分, 即分子 |
| numeric<br><br>adj. 数值的; 数字的<br>n. 数; 数字 | **numer(数)**, -ic(…的)<br>围绕“数”这一核心含义构成, 表示“数字的, 数值的” |
| supernumerary<br><br>adj. 额外的; 多余的<br>n. 跑龙套的角色; 杂工; 临时演员 | super-(超), **numer(数)**, -ary(…的)<br>超过规定数额而额外增加的人或物, 即额外的、多余的 |
| enumerable<br><br>adj. 可点数的; 可列举的 | e-(出, 向外), **numer(数)**, -able(可…的)<br>能够把各项列出并计数, 因此表示可枚举、可点数的 |
| innumerable<br><br>adj. 无数的; 数不清的 | in-(无, 不, 非), **numer(数)**, -able(可…的)<br>否定或缺少“数”所指的性质, 因此表示“数不清的, 无数的” |
| numerical<br><br>adj. 数字的; 用数字表示的; 数值的 | numeric(词: 数字的), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“数字的” |
| numerous<br><br>adj. 为数众多的; 许多 | **numer(数)**, -ous(…的)<br>数量众多的, 即"大量的" |
