## oyword-root-e


### eas

舒适, 易

| 单词 | 拆解 |
| --- | --- |
| ease<br><br>n. 安乐; 安逸; 悠闲<br>v. 使安乐; 使安心; 减轻 | **eas(易, 舒适)**, e(连接字母)<br>由舒适、无困难引申为缓和、减轻 |
| disease<br><br>n. 疾病 | dis-(否定, 相反), **eas(易, 舒适)**, e(连接字母)<br>失去舒适、安宁的身体状态, 因此表示疾病 |
| easy<br><br>adj. 容易的; 舒适的 | **eas(易, 舒适)**, -y(充满…的, 有…特征的, 像…的)<br>在前词基础上加“-y”构成形容词, 表示“容易的” |
| uneasy<br><br>adj. 心神不定的; 担心的; 忧虑的; 心神不安的 | un-(无, 不, 非), easy(词: 舒适的)<br>不舒适、不安或不容易的 |


### eco

家, 环境

| 单词 | 拆解 |
| --- | --- |
| ecologist<br><br>n. 生态学家 | **eco(家, 环境)**, -logist(…学家)<br>围绕“家”这一核心含义构成, 表示“生态学家” |
| ecology<br><br>n. 生态; 生态学 | **eco(家, 环境)**, -logy(…学, …研究)<br>以“家”为研究对象的学科, 即“生态学” |
| economics<br><br>n. 经济学; 经济状况 | **eco(家, 环境)**, **nom(…学)**, -ics(…学)<br>原指管理家庭的规则, 后来发展为研究经济运行的学科 |
| economy<br><br>n. 经济; 节约; 经济制度; 节省 | **eco(家, 环境)**, **nom(法则, 管理)**, -y(性质, 状态)<br>原指管理家庭的规则, 后来扩展为经济体系, 也可表示节约 |
| economic<br><br>adj. 经济 (学) 的 | **eco(家, 环境)**, **nom(…学)**, -ic(…的)<br>由“家”与“学”共同限定词义, 表示“经济 (学) 的” |
| economical<br><br>adj. 经济的; 节约的 | **eco(家, 环境)**, **nom(法则, 管理)**, -ical(…的)<br>善于管理家庭或资源、避免浪费, 因此表示节约的 |


### ed

吃

| 单词 | 拆解 |
| --- | --- |
| edibility<br><br>n. 可食性 | edible→edibil(词: 可食用的), -ity(性质, 状态)<br>可以食用的性质 |
| edible<br><br>adj. 可食的; 食用的; 可以吃的 | 源自拉丁语 edibilis（可吃的）, 核心 edere 意为吃 |
| inedible<br><br>adj. 不可吃的; 不适合食用的 | in-(无, 不, 非), **ed(吃)**, -ible(可…的)<br>在前词基础上加“-ible”构成形容词, 表示“不可吃的” |


### ego

我

| 单词 | 拆解 |
| --- | --- |
| ego<br><br>n. 自我; 自尊; 自负 | **ego(我)**<br>直接表示“我、自我” |
| egocentric<br><br>adj. 以自我为中心的<br>n. 自我中心者 | **ego(我)**, **centr(中心)**, -ic(…的)<br>以自我为中心的, 即"自我中心的" |
| egoism<br><br>n. 自我主义; 利己主义 | **ego(我)**, -ism(主义)<br>表示与“我”有关的性质或状态, 即“自我主义, 利己主义” |


### electr

电

| 单词 | 拆解 |
| --- | --- |
| electrician<br><br>n. 电学家; 电工 | **electr(电)**, -ician(人)<br>在前词基础上加“-ician”构成名词, 表示“电学家” |
| electricity<br><br>n. 电力 | **electr(电)**, -icity(性质, 状态)<br>在前词基础上加“-icity”构成名词, 表示“电” |
| electron<br><br>n. 电子 | **electr(电)**, -on(粒子)<br>围绕“电”这一核心含义构成, 表示“电子” |
| electric<br><br>adj. 电动的; 电的 | **electr(电)**, -ic(…的)<br>表示与“电”有关或具有该特征, 即“电动的, 电的” |
| electrical<br><br>adj. 电的; 用电的; 发电的 | **electr(电)**, -ical(…的)<br>表示与“电”有关或具有该特征, 即“电的, 用电的, 发电的” |
| electronic<br><br>adj. 电子的; 使用电子装置的 | electron(词: 电子), -ic(…的)<br>与电子或电子设备有关的 |


### em, empt

拿, 买

| 单词 | 拆解 |
| --- | --- |
| exemplify<br><br>v. 举例说明 | ex-(出, 向外), em-(进入, 包围), **pli(满, 全)**, -fy(…化, 做…)<br>把抽象内容做成可见实例, 因此表示举例说明、体现 |
| exempt<br><br>v. 免除; 豁免 | ex-(出, 向外), **empt(拿, 买)**<br>由“除去”与“拿”共同限定词义, 表示“免除, 豁免” |
| prompt<br><br>v. 促使; 激励<br>adj. 迅速的; 准时的<br>n. 提示; 提示符 | 源自拉丁语 promptus（拿出来、准备好的）, 表示迅速的或提示 |
| redeem<br><br>v. 弥补; 赎回; 挽回; 补偿; 兑现 | 源自拉丁语 redimere（买回来）, 表示赎回、补偿 |
| exemplar<br><br>n. 典型; 模范; 模型; 样品; 范例 | 源自拉丁语 exemplar“样本、范例”, 与 example 同源<br>可供仿效的典范 |
| premium<br><br>n. 保险费; 额外费用; 奖金; 津贴<br>adj. 优质的; 昂贵的; 价格更高的 | 源自拉丁语 praemium“奖赏、利益”<br>表示额外支付的费用, 也可引申为优质等级 |
| redemption<br><br>n. 赎回; 买回 | red-(回, 向后), **empt(拿, 买)**, -ion(行为, 结果)<br>把原先失去或抵押之物买回, 因此表示赎回、救赎 |
| sample<br><br>n. (抽查的)样本; 样品; 取样; 抽样调查 | 由 example 截去开头形成<br>表示能够代表整体的一小部分, 属于截短构词 |
| impromptu<br><br>adj. 临时的; 即席的 | 直接借自拉丁语 in promptu“处于准备好的状态”<br>无需预先准备、即兴的 |
| redeemable<br><br>adj. 可赎回的 | redeem(词: 赎回), -able(可…的)<br>在前词基础上加“-able”构成形容词, 表示“可赎回的” |


### emper, imper

统治, 命令

| 单词 | 拆解 |
| --- | --- |
| emperor<br><br>n. 皇帝; 帝王 | **emper(统治, 命令)**, -or(人)<br>围绕“统治”这一核心含义构成, 表示“皇帝, 帝王” |
| empire<br><br>n. 帝国; 帝权 | 经法语 empire 进入英语, 源自拉丁语 imperium（命令权、统治权） |
| empress<br><br>n. 女皇; 皇后 | emperor→empr(词: 皇帝), -ess(女性, 雌性)<br>女性君主或皇帝之妻 |
| imperative<br><br>adj. 必须的; 紧急的; 命令的; 强制的; 专横的<br>n. 当务之急 | **imper(统治, 命令)**, -ative(…的)<br>围绕“统治”这一核心含义构成, 表示“必须的” |
| imperialism<br><br>n. 帝国主义 | imperial(词: 帝王的), -ism(主义)<br>由“帝王的”派生为当前词义 |
| imperialist<br><br>n. 帝国主义者 | imperial(词: 帝王的), -ist(人)<br>由“帝王的”派生为当前词义 |
| imperial<br><br>adj. 帝国的; 帝制的 | **imper(统治, 命令)**, -ial(…的)<br>与帝国统治或皇权有关的 |


### enter(o)

肠

| 单词 | 拆解 |
| --- | --- |
| dysentery<br><br>n. 痢疾 | dys-(不良, 坏的), **enter(肠)**, -y(活动)<br>肠道功能异常并引起严重腹泻的疾病, 即痢疾 |
| enteritis<br><br>n. 肠炎 | **enter(肠)**, -itis(…炎)<br>“肠”发生炎症, 即“肠炎” |


### entom(o)

昆虫

| 单词 | 拆解 |
| --- | --- |
| entomologist<br><br>n. 昆虫学家 | **entomo(昆虫)**, -logist(…学家)<br>在前词基础上加“-logist”构成名词, 表示“昆虫学家” |
| entomology<br><br>n. 昆虫学 | **entomo(昆虫)**, -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“昆虫学” |
| entomological<br><br>adj. 昆虫学的 | **entomo(昆虫)**, -logical(…学的)<br>围绕“昆虫”这一核心含义构成, 表示“昆虫学的” |


### equ(i)

相等

| 单词 | 拆解 |
| --- | --- |
| equate<br><br>v. 使相等; 使等同 | **equ(相等)**, -ate(做, 使)<br>词根本身即表示“使相等”, 整词沿用该义 |
| adequacy<br><br>n. 足够; 充分; 适合 | adequate→adequa(词: 足够的), -cy(性质, 状态)<br>足够、胜任的状态 |
| equality<br><br>n. 平等 | equal(词: 平等的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“平等” |
| equanimity<br><br>n. 沉着; 镇定; 平静 | **equ(相等)**, **anim(生命; 心意; 精神; 气息)**, -ity(性质, 状态)<br>内心保持平衡、不偏不摇, 因此表示沉着、镇定 |
| equator<br><br>n. 赤道 | **equ(相等)**, -ator(物)<br>把地球等分为南北半球的纬线, 即赤道 |
| equity<br><br>n. 公平; 公道; 公平的事物 | **equ(相等)**, -ity(性质, 状态)<br>表示与“平”有关的性质或状态, 即“公平, 公道” |
| equivalent<br><br>adj. 等同的; 等价的<br>n. 对等物; 等价物 | **equi(相等)**, **val(值, 价值)**, -ent(…的)<br>由“相等”与“值”共同限定词义, 表示“相等的, 相当的, 等量的, 等(值)的” |
| equivalence<br><br>n. 均等; 等价; 等值 | 与 equivalent“等值的”同源<br>价值、意义或效果相等的状态 |
| iniquity<br><br>n. 邪恶; 不法 | 源自拉丁语 iniquitas, 由 in“不”与 aequus“公平”构成<br>不公平、邪恶 |
| adequate<br><br>adj. 足够的; 充足的; 适当的; 能胜任的; 合格的 | 构词锚点：ad 表示“到, 朝, 向”; equ 表示“相等”; -ate 在此为形容词词尾, 不取动词义<br>达到与要求相等的程度, 因此表示足够的、合格的 |
| equal<br><br>adj. 相等的; 平等的; 相同的 | **equ(相等)**, -al(…的)<br>表示与“相等”有关或具有该特征, 即“相等的” |
| equivocal<br><br>adj. 模棱两可的; 含糊其辞的; 意义不明确的; 令人怀疑的 | **equi(相等)**, **voc(声音, 叫喊)**, -al(…的)<br>一语作两种解释均可的 |
| unequivocal<br><br>adj. 不含糊的; 明确的 | un-(无, 不, 非), equivocal(词: 意义不明确的)<br>否定或缺少“歧义的”所指的性质, 因此表示“不含糊的, 明确的” |


### erg(o)

工作

| 单词 | 拆解 |
| --- | --- |
| energetics<br><br>n. 力能学; [复] 功能学 | 由 energetic“能量的”加学科复数形式 -s 构成<br>研究能量转换与平衡的学科 |
| energy<br><br>n. 能量; 精力 | en-(进入, 包围), **erg(工作)**, -y(性质, 状态)<br>原指内在运作、活动的力量, 后来表示能量或精力 |
| erg<br><br>n. [物] 尔格 (功的单位) | **erg(工作)**<br>围绕“工作”这一核心含义构成, 表示“尔格 (功的单位)” |
| ergometer<br><br>n. 测功计; 测力计 | **ergo(工作)**, **meter(测量器, 仪表)**<br>围绕“工作”这一核心含义构成, 表示“测功计, 测力计” |
| synergism<br><br>n. 协同; (尤指药物的) 协助作用 | syn-(共同), **erg(工作)**, -ism(行为)<br>共同作用产生的协同现象 |
| energetic<br><br>adj. 精力充沛的; 充满活力的; 积极的 | en-(进入, 包围), **erg(工作)**, -etic(…的)<br>具有持续做功、行动的能力, 因此表示精力充沛的 |
| lethargic<br><br>adj. 昏睡的; 无生气的 | 与 lethargy“昏睡、无精打采”同源, 源自希腊语 lethargos<br>昏昏欲睡、缺乏活力的 |
| synergic<br><br>adj. 协作的; 合作的 | syn-(共同), **erg(工作)**, -ic(…的)<br>使“工作”共同结合或发挥作用, 因此表示“协作的, 合作的” |


### err

走, 漫游

| 单词 | 拆解 |
| --- | --- |
| aberration<br><br>n. 离开正道; 脱离常轨 | ab-(脱离, 离去), **err(走, 漫游)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“离开正道” |
| error<br><br>n. 错误; 谬误; 过失 | 源自拉丁语 error“漫游、偏离”<br>由偏离正确路线发展为错误 |
| inerrancy<br><br>n. 无错误; 绝对正确 | in-(无, 不, 非), **err(走, 漫游)**, -ancy(性质, 状态)<br>否定或缺少“漫游”所指的性质, 因此表示“无错误” |
| aberrant<br><br>adj. 离开正道的; 脱离常轨的 | ab-(脱离, 离去), **err(走, 漫游)**, -ant(…的)<br>在前词基础上加“-ant”构成形容词, 表示“离开正道的” |
| errant<br><br>adj. 周游的; 漂泊的 | **err(走, 漫游)**, -ant(…的)<br>围绕“漫游”这一核心含义构成, 表示“周游的” |
| erratic<br><br>adj. 不规则的; 忽强忽弱的 | **err(走, 漫游)**, -atic(…的)<br>表示与“漫游”有关或具有该特征, 即“飘忽不定的” |
| erring<br><br>adj. 做错了事的; 走入歧途的 | **err(走, 漫游)**, -ing(…的)<br>偏离正确道路而犯错的 |


### ethn(o)

民族, 人民

| 单词 | 拆解 |
| --- | --- |
| ethnographer<br><br>n. 人种史研究者; 人种史学者 | **ethno(民族, 人民)**, **graph(写, 画)**, -er(人)<br>记录或描绘“人民”的方法, 即“人种史研究者” |
| ethnography<br><br>n. 人种史; 人种论 | 由希腊语 ethnos“民族”与 graphia“描写”构成<br>对特定民族文化的系统描述 |
| ethnologist<br><br>n. 人种学者; 民族学者 | **ethno(民族, 人民)**, -logist(…学家)<br>围绕“人民”这一核心含义构成, 表示“人种学者” |
| ethnology<br><br>n. 人种学; 民族学 | **ethno(民族, 人民)**, -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“人种学” |
| ethnical<br><br>adj. 种族的; 人种学的 | **ethn(民族, 人民)**, -ical(…的)<br>围绕“人种”这一核心含义构成, 表示“种族的” |
| ethnocentric<br><br>adj. 种族(或民族)中心主义的 | **ethno(民族, 人民)**, **centr(中心)**, -ic(…的)<br>由“民族”与“中心”共同限定词义, 表示“种族(或民族)中心主义的” |


### ev

年龄, 时代

| 单词 | 拆解 |
| --- | --- |
| coeval<br><br>adj. 同时代的<br>n. 同时代的人 | co-(与, 共同), **ev(年龄, 时代)**, -al(…的)<br>使“时代”共同结合或发挥作用, 因此表示“同时代的(人或物)” |
| longevity<br><br>n. 长寿; 长命; 长期供职; 资历 | **long(长)**, **ev(年龄, 时代)**, -ity(性质, 状态)<br>由“长”与“寿命”共同限定词义, 表示“长寿, 长命” |
| medievalism<br><br>n. 中世纪精神 (或特征; 状态; 风俗; 信仰等); 对中世纪风味的爱好; 中世纪残存的思想 (或风俗等) | 由 medieval“中世纪的”形成<br>中世纪式的思想、风俗、特征或对其的偏爱 |
| medievalist<br><br>n. 中世纪史专家 (或研究者); 中世纪艺术 (或文化) 的鉴赏者 (或爱好者) | medieval(词: 中世纪的), -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“中世纪史专家” |
| medieval<br><br>adj. 中古时代的; 中世纪的; 守旧的 | **medi(中间)**, **ev(年龄, 时代)**, -al(…的)<br>处在古代与近代之间时期的, 即中世纪的 |
| primeval<br><br>adj. 原始的; 远古的 | **prim(第一, 首要)**, **ev(年龄, 时代)**, -al(…的)<br>属于最初时代的, 因此表示原始的、远古的 |
