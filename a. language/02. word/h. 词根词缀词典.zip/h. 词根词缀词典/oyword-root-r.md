## oyword-root-r


### radi(o)

光线, 辐射

| 单词 | 拆解 |
| --- | --- |
| radiate<br><br>v. 辐射; 放射; 散发<br>adj. 辐射状的 | **radi(光线, 辐射)**, -ate(做, 使)<br>围绕“辐射”这一核心含义构成, 表示“放射, 辐射, 散布, 传播” |
| radial<br><br>adj. 光线的; 光线状的; 放射状的<br>n. 光线; 射线 | **radi(光线, 辐射)**, -al(…的)<br>围绕“光线”这一核心含义构成, 表示“光线的, 射线的, 辐射状的, 放射的” |
| radiance<br><br>n. 光辉; 容光焕发; 辐射性能 | **radi(光线, 辐射)**, -ance(性质, 状态)<br>表示与“光线”有关的性质或状态, 即“光辉” |
| radiation<br><br>n. 发光; 辐射(线); 放射(物) | **radi(光线, 辐射)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“放射” |
| radiator<br><br>n. 辐射体; 辐射器; 辐射源; 暖气设备 | **radi(光线, 辐射)**, -ator(物)<br>把热量向外辐射的装置, 即散热器、暖气设备 |
| radiology<br><br>n. 辐射学; 放射学 | **radio(光线, 辐射)**, -logy(…学, …研究)<br>以“辐射”为研究对象的学科, 即“辐射学, 放射学” |
| radiosensitivity<br><br>n. 放射敏感度 | 由 radio“辐射”与 sensitivity“敏感性”构成<br>组织或生物对辐射的敏感程度 |


### radic

根

| 单词 | 拆解 |
| --- | --- |
| eradicate<br><br>v. 根除 | e-(出, 向外), **radic(根)**, -ate(做, 使)<br>由“除去”与“根”共同限定词义, 表示“根除” |
| eradication<br><br>n. 根除 | eradicate→eradicat(词: 根除), -ion(行为, 结果)<br>由“根除”派生为当前词义 |
| radical<br><br>adj. 根本的; 激进的; 全新的<br>n. 激进分子; 根基; 自由基 | **radic(根)**, -al(…的)<br>触及根本的, 引申指根本的、激进的; 名词指激进分子或根基 |
| radicle<br><br>n. 胚根; 小根; 基; 根 | **radic(根)**, -le(小, 物)<br>围绕“根”这一核心含义构成, 表示“胚根, 小根” |
| radix<br><br>n. 根; 根本; 根源 | 直接借自拉丁语 radix“根”<br>数学中的基数或词形学中的词根 |


### rag

疯狂

| 单词 | 拆解 |
| --- | --- |
| enrage<br><br>v. 使发怒; 激怒 | en-(进入, 包围), **rag(疯狂)**, e(连接字母)<br>由“致使”与“疯狂”共同限定词义, 表示“使发怒, 激怒” |
| outrage<br><br>n. 暴行; 侮辱; 愤怒<br>v. 凌辱; 虐待; 触犯 | 经古法语 outrage 进入英语, 核心意象是越过合理限度<br>表示严重冒犯、暴行或强烈愤怒 |
| outrageous<br><br>adj. 骇人的; 无法容忍的; 反常的; 令人惊讶的 | out-(出, 外, 远), rage(词: 愤怒), -ous(…的)<br>超出可容忍范围并激起愤怒, 因此表示骇人的、无法容忍的 |
| raging<br><br>adj. 狂怒的; 狂烈的; 狂野的 | rage→rag(词: 狂怒), -ing(…的)<br>处于强烈愤怒或猛烈发展状态的 |


### range

行, 列

| 单词 | 拆解 |
| --- | --- |
| arrange<br><br>v. 安排; 准备; 整理; 使有条理 | 经古法语进入英语, 核心意象是把事物排成一列或次序<br>由排列发展为安排、筹备 |
| arrangement<br><br>n. 安排; 布置 | arrange(词: 安排), -ment(行为, 过程)<br>在前词基础上加“-ment”构成名词, 表示“安排” |
| ranger<br><br>n. 徘徊者, 漫游者; 巡逻骑兵 | range→rang(词: 漫游), -er(人)<br>在路上行走的人 |
| rang(e)y<br><br>adj. 瘦长适于奔跑的; 喜欢漫游的 | **range(行, 列)**, -y(充满…的, 有…特征的, 像…的)<br>在前词基础上加“-y”构成形容词, 表示“徘徊的, 喜欢漫游的” |
| ranging<br><br>n. 距离修正; 广泛搜索 | 词形来源：range + ing-form |


### rap, rapt, rav

抓, 夺

| 单词 | 拆解 |
| --- | --- |
| rapacity<br><br>n. 掠夺; 强取 | **rap(抓, 夺)**, -acity(性质, 状态)<br>在前词基础上加“-acity”构成名词, 表示“掠夺” |
| rape<br><br>n. 强奸; 蹂躏<br>v. 强暴; 蹂躏; 肆意破坏 | **rap(抓, 夺)**, e(连接字母)<br>围绕“抓”这一核心含义构成, 表示“强奸” |
| rapine<br><br>n. 强夺; 抢劫; 劫掠 | **rap(抓, 夺)**, -ine(…的)<br>围绕“夺”这一核心含义构成, 表示“强夺, 抢劫, 劫掠” |
| rapist<br><br>n. 强奸犯 | **rap(抓, 夺)**, -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“强奸犯” |
| raptor<br><br>n. 猛禽 | **rapt(抓, 夺)**, -or(物)<br>以抓捕猎物为特征的猛禽 |
| rapture<br><br>n. 兴高采烈; 着迷; 欢天喜地<br>v. 使狂喜 | **rapt(抓, 夺)**, -ure(行为, 结果)<br>围绕“抓”这一核心含义构成, 表示“(使)着迷, (使)销魂” |
| rapacious<br><br>adj. 掠夺的; 强取的 | **rap(抓, 夺)**, -acious(…的)<br>围绕“夺”这一核心含义构成, 表示“掠夺的, 强取的” |
| rapt<br><br>adj. 着迷的; 销魂的; 全神贯注的 | **rapt(抓, 夺)**<br>围绕“抓”这一核心含义构成, 表示“着迷的, 销魂的” |
| rapturous<br><br>adj. 狂喜的; 引起狂喜的 | rapture→raptur(词: 兴高采烈), -ous(…的)<br>由“兴高采烈”派生为当前词义 |
| ravenous<br><br>adj. 贪婪的; 饥饿的 | **rav(抓, 夺)**, -en(做, 使), -ous(…的)<br>表示与“抓”有关或具有该特征, 即“贪婪的, 饥饿的” |


### rad, ras

擦, 刮

| 单词 | 拆解 |
| --- | --- |
| abrade<br><br>v. 磨(掉); 擦(掉) | ab-(脱离, 离去), **rad(擦, 刮)**, e(连接字母)<br>由“脱离”与“擦”共同限定词义, 表示“磨(掉), 擦(掉)” |
| erase<br><br>v. 擦去; 抹掉; 除去; 清除; 抹去 | e-(出, 向外), **ras(擦, 刮)**, e(连接字母)<br>由“除去”与“擦”共同限定词义, 表示“擦去, 抹掉” |
| raze<br><br>v. 刮去; 削去; 铲掉; 铲平 | razras 刮<br>引申为刮去 |
| abrasion<br><br>n. 擦掉; 磨损; 擦伤处 | ab-(脱离, 离去), **ras(擦, 刮)**, -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“擦掉” |
| abrasive<br><br>adj. 有研磨作用的<br>n. 研磨料 | ab-(脱离, 离去), **ras(擦, 刮)**, -ive(…的)<br>在前词基础上加“-ive”构成名词或形容词, 表示“有研磨作用的” |
| eraser<br><br>n. 擦除器(如黑板擦; 橡皮等) | erase→eras(词: 抹去), -er(物)<br>由“抹去”派生为当前词义 |
| erasure<br><br>n. 擦掉; 删去; 擦掉处 | erase→eras(词: 抹去), -ure(行为, 结果)<br>由“抹去”派生为当前词义 |
| razor<br><br>n. 剃须刀; 刮脸刀; 剃刀<br>v. (用剃刀)剃; （用剃刀）剃 | 经古法语 rasor 进入英语, 核心动词 raser 表示刮剃<br>指用于刮除毛发的剃刀 |
| erasable<br><br>adj. 可擦掉的; 可抹掉的 | e-(出, 向外), **ras(擦, 刮)**, -able(可…的)<br>能够被擦去、刮除, 因此表示可擦除的 |


### real

现实

| 单词 | 拆解 |
| --- | --- |
| realia<br><br>n. 实际事物; 实在 | **real(现实)**, -ia(性质, 状态)<br>围绕“现实”这一核心含义构成, 表示“实际事物” |
| realism<br><br>n. 现实主义, 写实主义 | **real(现实)**, -ism(主义)<br>表示与“现实”有关的性质或状态, 即“现实主义, 写实主义” |
| realist<br><br>n. 现实主义者, 现实主义作家, 唯实论者; 采取现实主义态度的人 | **real(现实)**, -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“现实主义者, 现实主义作家, 唯实论者” |
| reality<br><br>n. 现实, 实际存在的事物, 真实; 逼真 | **real(现实)**, -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“现实, 实际存在的事物, 真实” |
| realization<br><br>n. 实现 | **real(现实)**, -ization(行为, …化)<br>在前词基础上加“-ization”构成名词, 表示“实现” |
| realize<br><br>v. 实现 | **real(现实)**, -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“实现” |
| really<br><br>adv. 真正地 | **real(现实)**, -ly(…地)<br>在前词基础上加“-ly”构成副词, 表示“真正地” |
| realty<br><br>n. 不动产, 房地产 | **real(现实)**, -ty(性质, 状态)<br>表示与“现实”有关的性质或状态, 即“不动产, 房地产” |
| unreal<br><br>adj. 不真实的, 不现实的, 虚构的 | un-(无, 不, 非), **real(现实)**<br>否定或缺少“现实”所指的性质, 因此表示“不真实的, 不现实的, 虚构的” |


### rect(i)

正, 直

| 单词 | 拆解 |
| --- | --- |
| direct<br><br>adj. 直接的; 直率的<br>v. 指导; 导演; 指引<br>adv. 径直地; 直接地 | 源自拉丁语 dirigere“使成直线、引导”<br>由朝直线方向引导发展为直接的或指导 |
| erect<br><br>v. 建立; 竖立<br>adj. 竖直的; 直立的 | e-(出, 向外), **rect(正, 直)**<br>把事物向外、向上拉直, 因此表示竖立、直立的 |
| corrector<br><br>n. 改正者; 矫正者; 纠正者 | correct(词: 改正), -or(人)<br>在前词基础上加“-or”构成名词, 表示“改正者” |
| erector<br><br>n. 树立者; 建立者 | erect(词: 树立), -or(人)<br>在前词基础上加“-or”构成名词, 表示“树立者” |
| rectangle<br><br>n. 矩形; 长方形 | **rect(正, 直)**, angle(词: 角)<br>直角的图形 |
| rectification<br><br>n. 纠正; 整顿 | **recti(正, 直)**, -fication(…化, 做…)<br>围绕“正”这一核心含义构成, 表示“纠正, 整顿” |
| rectifier<br><br>n. 纠正者; 整顿者; 矫正器 | **recti(正, 直)**, -fier(做…的人或物)<br>在前词基础上加“-fier”构成名词, 表示“纠正者” |
| rectitude<br><br>n. 正直; 正确; 笔直 | **rect(正, 直)**, -itude(性质, 状态)<br>围绕“正”这一核心含义构成, 表示“正直, 正确, 笔直” |
| rectum<br><br>n. 直肠 | **rect(正, 直)**, -um(名词词尾)<br>被认为较直的一段肠道, 即直肠 |
| corrective<br><br>adj. 改正的; 纠正的; 矫正的 | correct(词: 改正), -ive(…的)<br>在前词基础上加“-ive”构成形容词, 表示“改正的” |
| erectile<br><br>adj. 可竖直的 | erect(词: 笔直的), -ile(…的)<br>在前词基础上加“-ile”构成形容词, 表示“可竖直的” |
| incorrect<br><br>adj. 不正确的 | in-(无, 不, 非), cor-(与, 共同), **rect(正, 直)**<br>否定或缺少“正”所指的性质, 因此表示“不正确的” |


### reg(i), regn

统治, 规则

| 单词 | 拆解 |
| --- | --- |
| regulate<br><br>v. 管理; 控制; 调整 | **reg(统治, 规则)**, -ulate(做, 使)<br>使事物按规则运行, 即管理或调节 |
| regalia<br><br>n. 王室的特权; 王权; 王位(或王权)的标志 | 源自中世纪拉丁语 regalia“王室之物”, 来自 rex“国王”<br>王权标志、礼服或盛装 |
| regency<br><br>n. 摄政; 政权; 统治 | **reg(统治, 规则)**, -ency(性质, 状态)<br>围绕“统治”这一核心含义构成, 表示“摄政” |
| regent<br><br>adj. 摄政的<br>n. 摄政者; 摄政王 | **reg(统治, 规则)**, -ent(…的)<br>代替君主行使统治权的人, 即摄政者 |
| regicide<br><br>n. 弑君(者) | **regi(统治, 规则)**, **cid(切, 杀)**, e(连接字母)<br>杀死君主的行为或实施者, 即弑君、弑君者 |
| regime<br><br>n. 政体; 政权; 统治 | 直接借自法语 régime（统治、制度）, 表示政权或管理体制 |
| regiment<br><br>n. （军队）团; 大量（人或物）<br>v. 组编成团; 组织; 严格管制 | 源自拉丁语 regimen（统治、管理）及其法语形式, 后专指受统一管辖编制的军团, 也可转化作动词表示严格管辖 |
| region<br><br>n. 地区; 区域; 范围 | 源自拉丁语 regio“方向、区域”<br>表示划定或管理的一片地区 |
| regularity<br><br>n. 规则性; 规律性; 整齐; 匀称 | regular(词: 规则的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“规则性” |
| regulator<br><br>n. 管理者; 调整者; 调节器; 调节剂 | **reg(统治, 规则)**, -ulator(人)<br>负责管理、调节的人或机构 |
| regal<br><br>adj. 国王的; 王室的; 庄严的 | **reg(统治, 规则)**, -al(…的)<br>表示与“统治”有关或具有该特征, 即“国王的, 王室的” |
| regius<br><br>adj. 皇家的; 钦定的 | 源自拉丁语 regius（国王的、皇家的）, 记忆锚点为与统治者或王权相关 |
| regular<br><br>adj. 规则的; 有规律的; 匀称的 | **reg(统治, 规则)**, -ular(…的)<br>围绕“规则”这一核心含义构成, 表示“规则的, 有规律的” |
| regulatory<br><br>adj. 规章的; 受规章限制的 | **reg(统治, 规则)**, -ulatory(…的)<br>与管理规则或监管活动有关的 |


### reti, reticul

网

| 单词 | 拆解 |
| --- | --- |
| reticulate<br><br>v. 成网状<br>adj. 网状的 | **reticul(网)**, -ate(做, 使)<br>在前词基础上加“-ate”构成形容词或动词, 表示“网状的” |
| reticle<br><br>n. 光网 | **reti(网)**, -cle(小)<br>围绕“网”这一核心含义构成, 表示“光网” |
| reticulation<br><br>n. 网状组织(如交通运输网); 网状(物) | **reticul(网)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“网状” |
| reticule<br><br>n. 光网; 可收口的女用网格拎包 | **reti(网)**, -cule(小)<br>围绕“网”这一核心含义构成, 表示“光网” |
| reticulocyte<br><br>n. 网织红血球; 网状细胞 | **reticul(网)**, o(连接字母), **cyt(细胞)**, e(连接字母)<br>由“网”与“细胞”共同限定词义, 表示“网织红血球, 网状细胞” |
| reticulum<br><br>n. (细胞原生质的)网状结构; (反刍动物的)蜂窝胃 | **reticul(网)**, -um(名词词尾)<br>网状结构, 也指反刍动物的蜂窝胃 |
| retina<br><br>n. 视网膜 | 源自中世纪拉丁语 retina“网状膜”, 原为 tunica retina 的省略<br>眼底感光的网膜 |
| retinitis<br><br>n. 视网膜炎 | retina→retin(词: 视网膜), -itis(…炎)<br>在前词基础上加“-itis”构成名词, 表示“视网膜炎” |
| reticular<br><br>adj. 网状的; 网状结缔的; 网状组织的; 错综复杂的 | **reticul(网)**, -ar(…的)<br>围绕“网”这一核心含义构成, 表示“网状的” |


### rhin(o)

鼻

| 单词 | 拆解 |
| --- | --- |
| otorhinolaryngology<br><br>n. 耳鼻喉科学 | **oto(耳)**, **rhino(鼻)**, **laryngo(喉)**, -logy(…学, …研究)<br>以“耳、鼻、喉”为研究对象的学科, 即“耳鼻喉科学” |
| rhinitis<br><br>n. 鼻炎 | **rhin(鼻)**, -itis(…炎)<br>“鼻”发生炎症, 即“鼻炎” |


### rhiz(o)

根

| 单词 | 拆解 |
| --- | --- |
| rhizosphere<br><br>n. 根际; 根际圈 | **rhiz(o)(根)**, **spher(o)(球)**<br>紧邻植物根系受根部分泌物直接影响的土壤微域环境 |
| rhizoid<br><br>n. 假根; 假根状的 | **rhiz(o)(根)**, -oid(似…的（物）)<br>苔藓或低等植物形似根部起固着与吸水作用的器官 |


### rid, ris

笑

| 单词 | 拆解 |
| --- | --- |
| deride<br><br>v. 讥笑; 愚弄 | de-(一再等加强意义), **rid(笑)**, e(连接字母)<br>强烈地嘲笑, 即嘲弄 |
| derision<br><br>n. 嘲笑; 讥笑; 嘲弄; 笑柄 | de-(一再等加强意义), **ris(笑)**, -ion(行为, 结果)<br>嘲笑的行为或结果, 即嘲弄、嘲笑 |
| ridicule<br><br>n. 嘲笑; 戏弄<br>v. 嘲笑; 奚落 | **rid(笑)**, i(连接字母), -cule(小)<br>围绕“笑”这一核心含义构成, 表示“嘲笑, 讥笑” |
| derisive<br><br>adj. 嘲笑的; 嘲弄的; 幼稚可笑的 | 与 deride“嘲笑”同源, 源自拉丁语 deridere<br>带有嘲弄、讥讽意味的 |
| ridiculous<br><br>adj. 荒谬的; 可笑的 | 源自拉丁语 ridiculosus（可笑的）, 核心 ridere 意为笑 |
| risible<br><br>adj. 爱笑的; 能笑的; 可笑的; 笑的 | **ris(笑)**, -ible(可…的)<br>在前词基础上加“-ible”构成形容词, 表示“爱笑的” |


### rig

刚, 硬

| 单词 | 拆解 |
| --- | --- |
| rigidity<br><br>n. 刚硬; 坚硬; 僵硬 | rigid(词: 坚硬的), -ity(性质, 状态)<br>由“坚硬的”派生为当前词义 |
| rigor<br><br>n. (发烧前突然的)寒战; 发冷; 僵直 | 源自拉丁语 rigor“僵硬、寒战”<br>表示身体僵直或发冷, 也可表示严格 |
| rigo(u)r<br><br>n. 严峻; 严厉; 苛刻; 严格 | 源自拉丁语 rigor“僵硬、严格”<br>表示严格或严谨; 英式可拼 rigour |
| rigid<br><br>adj. 坚硬刚硬的; 严格死板的; 固执僵化的 | **rig(刚, 硬)**, -id(…的)<br>围绕“硬”这一核心含义构成, 表示“刚硬的, 坚硬的” |
| rigorous<br><br>adj. 谨慎的; 细致的; 严格的; 严厉的; 一丝不苟的 | 源自拉丁语 rigor“僵硬、严格”<br>表示要求严密精确、毫不放松的 |


### riv

河流

| 单词 | 拆解 |
| --- | --- |
| arrive<br><br>v. 到达; 来临; 达成; 取得成功 | 经古法语 ariver“靠岸”传入, 原指船到达岸边<br>由靠岸泛化为到达 |
| arrival<br><br>n. 到达; 抵达的人或事物 | ar-(到, 朝, 向), **riv(河流)**, -al(行为, 过程)<br>本义抵达河岸, 引申为到达; 也可指到达的人或物 |


### robor, robust

力量; 橡木

| 单词 | 拆解 |
| --- | --- |
| corroborative<br><br>adj. 确证的 | corroborate→corroborat(词: 巩固), -ive(…的)<br>由“巩固”派生为当前词义 |
| robust<br><br>adj. 强健的; 健壮的; 强壮的 | 源自拉丁语 robustus“橡木般坚固的”<br>表示强健、结实或系统可靠的 |


### rod, ros

啃, 咬

| 单词 | 拆解 |
| --- | --- |
| corrode<br><br>v. 侵蚀; 腐蚀 | cor-(与, 共同), **rod(啃, 咬)**, e(连接字母)<br>像被不断啃咬一样逐渐损坏, 因此表示腐蚀、侵蚀 |
| erode<br><br>v. 腐蚀; 侵蚀 | e-(出, 向外), **rod(啃, 咬)**, e(连接字母)<br>侵蚀如被啃噬 |
| anticorrosion<br><br>n. 防腐蚀 | anti-(反对, 相反), cor-(与, 共同), **ros(啃, 咬)**, -ion(行为, 结果)<br>对抗材料被逐渐啃蚀的过程, 因此表示防腐蚀 |
| corrosion<br><br>n. 侵蚀; 腐蚀 | cor-(与, 共同), **ros(啃, 咬)**, -ion(行为, 结果)<br>材料像被啃咬般逐渐损坏的过程, 即腐蚀、侵蚀 |
| rodent<br><br>adj. 咬的; 啮齿类的<br>n. 啮齿动物 | **rod(啃, 咬)**, -ent(…的)<br>围绕“咬”这一核心含义构成, 表示“咬的, 嚼的” |
| rodenticide<br><br>n. 杀鼠药 | 由 rodent“啮齿动物”与 cide“杀灭物”构成<br>灭鼠剂 |
| erosive<br><br>adj. 腐蚀性的 | e-(出, 向外), **ros(啃, 咬)**, -ive(…的)<br>能够像啃咬一样逐渐磨损材料, 因此表示侵蚀性的 |


### rog

问, 要求

| 单词 | 拆解 |
| --- | --- |
| abrogate<br><br>v. 取消; 废除 | ab-(脱离, 离去), **rog(问, 要求)**, -ate(做, 使)<br>把原有要求或法令撤去, 因此表示取消、废除 |
| interrogate<br><br>v. 审问; 讯问; 质问 | inter-(在...之间), **rog(问, 要求)**, -ate(做, 使)<br>由“在…之间”与“问”共同限定词义, 表示“审问” |
| abrogation<br><br>n. 取消; 废除 | 源自拉丁语 abrogatio“废除”, 由 ab“离开”与 rogare“提出、询问”构成<br>记忆为正式撤回一项法令 |
| rogue<br><br>n. 恶棍; 无赖<br>adj. 叛变的; 擅自行动的 | 16世纪出现, 可能与早期英语 roger 或法语、北欧词有关, 确切来源未定<br>本土化后表示流氓、无赖 |
| prerogative<br><br>adj. 特权的; 行使特权的<br>n. 特权; 君权; 职权 | pre-(先于, 预先), **rog(问, 要求)**, -ative(…的)<br>有先要求权的 |
| arrogant<br><br>adj. 骄傲自大的; 傲慢的 | ar-(到, 朝, 向), **rog(问, 要求)**, -ant(…的)<br>强求别人 |
| interrogative<br><br>adj. 疑问的; 讯问的; 质问的 | interrogate→interrogat(词: 质问), -ive(…的)<br>由“质问”派生为当前词义 |
| roguish<br><br>adj. 流氓的; 无赖的 | rogue→rogu(词: 恶棍), -ish(…的)<br>由“恶棍”派生为当前词义 |


### rot

转, 轮

| 单词 | 拆解 |
| --- | --- |
| Rotarian<br><br>n. 扶轮社成员<br>adj. 扶轮社的 | **rot(转, 轮)**, -arian(人)<br>与轮流主持的传统有关, 指扶轮国际成员或与其有关的 |
| rotary<br><br>adj. 旋转的; 轮流的<br>n. 旋转式机器 | **rot(转, 轮)**, -ary(…的)<br>围绕“转”这一核心含义构成, 表示“旋转的, 转动的” |
| rote<br><br>n. 死记硬背; 机械的方法; 生搬硬套 | **rot(转, 轮)**, e(连接字母)<br>围绕“转”这一核心含义构成, 表示“死记硬背” |
| rotorcraft<br><br>n. 旋翼飞机 | rotor(词: 旋翼), craft(词: 飞行器)<br>以旋翼产生升力的飞行器 |
| rotunda<br><br>n. 圆形建筑物; 圆形大厅; (旅馆等的) 中央大厅 | 核心意象是圆形<br>指圆形建筑或带圆顶的中央大厅 |
| levorotatory<br><br>adj. 左旋的; 逆时针方向旋转的 | **levo(左)**, **rot(转, 轮)**, -ate(…的), -ory(…的)<br>化学中使偏振光的偏振平面沿逆时针向左旋转的旋光性质, 即左旋的 |
| rotund<br><br>adj. 圆胖的 | **rot(转, 轮)**, **und(波浪)**<br>整体轮廓圆转、丰满, 因此表示圆胖的; 与 und‘波浪’无直接关系 |


### rrhag, rrhea

流出

| 单词 | 拆解 |
| --- | --- |
| diarrhea<br><br>n. 腹泻; 痢疾 | dia-(通过, 穿过), **rrhea(流出)**<br>液体不断流过身体, 即腹泻 |
| hemorrhage<br><br>n. 出血 | **hemo(血)**, **rrhag(流出)**, e(连接字母)<br>由“血”与“流出”共同限定词义, 表示“出血” |
| menorrhagia<br><br>n. 月经过多 | 由希腊语 meno“月经”与 rrhagia“大量流出”构成<br>月经过多 |
| seborrhea<br><br>n. 皮脂溢 | 由 sebum“皮脂”与 rrhea“流出”构成<br>皮脂分泌过多 |


### rud

原始, 粗野

| 单词 | 拆解 |
| --- | --- |
| erudite<br><br>n. 博学者<br>adj. 博学的 | e-(出, 向外), **rud(原始, 粗野)**, -ite(…的)<br>脱离粗野无知状态、学识丰富的 |
| rudiment<br><br>n. 基本原理; 基础知识; 雏形 | **rud(原始, 粗野)**, i(连接元音), -ment(物)<br>事物处于最原始起点处的根本法则或入门雏形 |
| rudimentary<br><br>adj. 基本的; 初步的; 未充分发展的 | **rud(原始, 粗野)**, i(连接元音), -ment(行为, 过程), -ary(…的)<br>处于原始初生阶段的基础状态 |


### rupt

裂

| 单词 | 拆解 |
| --- | --- |
| interrupter<br><br>n. 中断者; 折断者; 断流器 | inter-(在...之间), **rupt(裂)**, -er(人)<br>造成中断的人; 也可引申指断流装置 |
| rupture<br><br>n. 破裂; 裂开; 决裂 | **rupt(裂)**, -ure(行为, 结果)<br>围绕“裂”这一核心含义构成, 表示“破裂, 裂开” |
| incorruptible<br><br>adj. 不易败坏的; 不易腐蚀的 | in-(无, 不, 非), cor-(与, 共同; 彻底, 完全, 加强), **rupt(裂)**, -ible(可…的)<br>否定或缺少“裂”所指的性质, 因此表示“不易败坏的, 不易腐蚀的” |


### rur, rus

农村, 乡村

| 单词 | 拆解 |
| --- | --- |
| rurality<br><br>n. 农村景色; 田园风味 | rural(词: 农村的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“农村景色” |
| rural<br><br>adj. 乡村的; 农村的; 田园风光的 | **rur(农村, 乡村)**, -al(…的)<br>表示与“农村的”有关或具有该特征, 即“农村的, 田园的” |
| rustic<br><br>adj. 乡村的; 农村的; 庄稼人样子的 | **rus(农村, 乡村)**, -tic(…的)<br>围绕“农村的”这一核心含义构成, 表示“乡村的, 农村的” |
