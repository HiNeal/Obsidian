## oyword-root-y


### yl

基

| 单词 | 拆解 |
| --- | --- |
| ethyl<br><br>n. [化]乙基, 乙烷基 | 由 ether“乙醚”词干与化学后缀 -yl 构成<br>表示乙基 |
| ethylene<br><br>n. 乙烯; 乙撑; 次乙基 | 由 ethyl“乙基”加化学命名后缀形成<br>指乙烯这种碳氢化合物 |
| methyl<br><br>n. 甲基 | methy→meth(词: 木精; 酒), **yl(基)**<br>源自希腊语 methy(酒/木精)与 hyle(木材), 构词形成有机化学中最基础的一价碳氢烷基, 即甲基 |
| methylamine<br><br>n. 甲胺 | methyl(词: 甲基), amine(词: 胺)<br>由甲基与胺构成的化合物甲胺 |
| methylated<br><br>adj. 甲基化了的; 加入甲醇的 | 词形来源：methylate + ed-form |
| methylene<br><br>n. 甲叉; 亚撑; 亚甲基 | 19世纪由希腊语 methy“酒”与 hyle“木材”构成, 因早期与木醇相关<br>化学中的亚甲基或二氯甲烷旧称 |
