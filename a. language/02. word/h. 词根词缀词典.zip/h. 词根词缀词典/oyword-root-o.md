## oyword-root-o


### ocul(i), ocul(o)

眼

| 单词 | 拆解 |
| --- | --- |
| binocular<br><br>adj. 同时用两眼的; 两眼并用的 | 由拉丁语 bini“两个一组”与 oculus“眼睛”构成<br>供双眼共同观看的 |
| ocular<br><br>n. 目镜<br>adj. 眼睛的; 用眼的; 凭视觉的 | **ocul(眼)**, -ar(…的)<br>围绕“眼”这一核心含义构成, 表示“眼睛的, 视觉 (上) 的” |
| monocular<br><br>adj. 单眼的 | mon-(单一, 独), **ocul(眼)**, -ar(…的)<br>只使用一只眼睛的, 即单眼的 |
| oculomotor<br><br>adj. 眼球运动的; 动眼 (神经) 的 | **oculo(眼)**, motor(词: 发动的)<br>围绕“眼”这一核心含义构成, 表示“眼球运动的” |


### odont(o)

牙

| 单词 | 拆解 |
| --- | --- |
| odontology<br><br>n. 牙科学; 齿科学 | **odonto(牙)**, -logy(…学, …研究)<br>以“牙”为研究对象的学科, 即“牙科学, 齿科学” |
| orthodontia<br><br>n. 正齿学; 畸齿矫正术; 矫形齿科学 | orth-(正确, 直), **odont(牙)**, -ia(性质, 状态)<br>围绕“齿”这一核心含义构成, 表示“正齿学” |
| orthodontist<br><br>n. 畸齿矫正医生; 矫形齿科医生 | 由 ortho“正直、矫正”、odont“牙”与 ist“从业者”构成<br>牙齿矫正专科医生 |


### ole(o)

油

| 单词 | 拆解 |
| --- | --- |
| olea<br><br>n. [复] 油 | 直接采用拉丁语 olea（橄榄树）, 也是木犀科木犀榄属的学名 |
| oleate<br><br>n. 油酸盐 | 构词锚点：ole 表示“油”; -ate 在此为化学命名词尾, 不取动词义<br>围绕“油”这一核心含义构成, 表示“油酸盐” |
| oleoresin<br><br>n. 含油树脂 | **oleo(油)**, resin(词: 树脂)<br>由“油”与“树脂”共同限定词义, 表示“含油树脂” |
| petroleum<br><br>n. 石油 | **petr(石, 岩石)**, **ole(油)**, -um(化学元素或物质)<br>石中之油 |
| oleic<br><br>adj. 油 (酸) 的 | **ole(油)**, -ic(…的)<br>表示与“油”有关或具有该特征, 即“油 (酸) 的” |


### olig(o)

少

| 单词 | 拆解 |
| --- | --- |
| oligarch<br><br>n. 寡头政治的执政者 (或支持者) | **olig(少)**, **arch(统治)**<br>围绕“少”这一核心含义构成, 表示“寡头政治的执政者 (或支持者)” |
| oligarchy<br><br>n. 寡头政治; 寡头统治; 少数人垄断的组织 | **olig(少)**, **archy(为首)**<br>围绕“统治”这一核心含义构成, 表示“寡头政治, 寡头统治” |
| oligarchic(al)<br><br>adj. (鼓吹) 寡头政治的 | **olig(少)**, **arch(统治)**, -ical(…的)<br>由少数人统治的, 即寡头政治的 |


### ombro

雨

| 单词 | 拆解 |
| --- | --- |
| ombrometer<br><br>n. 雨量计 | **ombro(雨)**, **meter(测量; 测量器, 仪表)**<br>用于精确测定一定时间内地面降雨量的仪器 |
| ombrophile<br><br>n. 喜雨植物; 适雨生物<br>adj. 喜雨的 | **ombro(雨)**, **phil(o)(爱)**<br>极度喜好充沛雨水并在多雨环境中茂盛生长的植物 |


### omphal(o)

脐

| 单词 | 拆解 |
| --- | --- |
| omphalos<br><br>n. (古希腊) 盾中央的浮凸物; 中心; 中枢; 脐 | **omphal(o)(脐)**, s(连接字母)<br>原指人体肚脐, 古希腊特指德尔斐世界神圣中心石, 引申为枢纽、中心 |
| omphalitis<br><br>n. 脐炎 | **omphal(o)(脐)**, -itis(…炎)<br>新生儿或人体的肚脐部位发炎 |


### oneir(o)

梦

| 单词 | 拆解 |
| --- | --- |
| oneiric<br><br>adj. 梦的; 关于梦的 | **oneir(o)(梦)**, -ic(…的)<br>电影与艺术批评中形容氛围如梦境般虚幻迷离、超现实的特质, 即梦境般的 |
| oneirology<br><br>n. 梦学; 释梦学 | **oneir(o)(梦)**, -logy(…学, …研究)<br>科学研究梦境产生机制及其象征意义的学科 |


### oner, on

负担

| 单词 | 拆解 |
| --- | --- |
| exonerate<br><br>v. 证明无罪; 免除 | ex-(出, 向外), **oner(负担)**, -ate(做, 使)<br>否定或缺少“负担”所指的性质, 因此表示“证明无罪” |
| exoneration<br><br>n. 免罪; 免除 | 与 exonerate“卸下负担、免罪”同源, 由 ex“去除”与 onus“负担”构成<br>去除罪责或责任 |
| onus<br><br>n. 重担; 责任; 过失; 耻辱 | 直接借自拉丁语 onus“负担”<br>责任或举证负担 |
| onerous<br><br>adj. 繁重的; 费力的 | **oner(负担)**, -ous(…的)<br>表示与“负担”有关或具有该特征, 即“繁重的” |


### onto

存在, 个体

| 单词 | 拆解 |
| --- | --- |
| ontogenesis<br><br>n. 个体发生; 个体发育 | **onto(存在, 个体)**, **gen(出生, 产生)**, -esis(行为, 过程)<br>由“个体”与“出生”共同限定词义, 表示“个体发生” |
| ontology<br><br>n. 本体论 | **onto(存在, 个体)**, -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“本体论” |
| ontogenetic<br><br>adj. 个体发生的; 个体发育的 | 由希腊语 ōn、ont-（存在者）与 genesis（发生、起源）构成, 表示个体发生的 |
| ontological<br><br>adj. 本体论的 | **onto(存在, 个体)**, -logical(…学的)<br>围绕“个体”这一核心含义构成, 表示“本体论的” |


### onym

名

| 单词 | 拆解 |
| --- | --- |
| operate<br><br>v. 操作; 运转; 运营; 动手术; 起作用 | **oper(工作)**, -ate(做, 使)<br>使运转工作起来, 即"运行" |
| anonym<br><br>n. 匿名者; 无名氏 | an-(无, 不, 非), **onym(名)**<br>否定或缺少“名”所指的性质, 因此表示“匿名者, 无名氏” |
| anonymity<br><br>n. 匿名状态; 身份隐匿 | anonymous→anonym(词: 匿名的), -ity(性质, 状态)<br>姓名不被公开的状态 |
| antonym<br><br>n. 短语; 习语; n-反义词 | ant-(反对, 相反), **onym(名)**<br>由“反对”与“名”共同限定词义, 表示“反义词” |
| patronymic<br><br>adj. 源于父名的<br>n. 父系的姓; 源于父名的姓 | **patr(父祖)**, **onym(名)**, -ic(…的)<br>由“父”与“名”共同限定词义, 表示“源于父名(或祖先名)的(姓)” |
| pseudonym<br><br>n. 假名 | pseud-(假的), **onym(名)**<br>由“假的”与“名”共同限定词义, 表示“假名” |
| synonym<br><br>n. 同义词 | syn-(共同), **onym(名)**<br>名称或表达不同而意义相同的词, 即同义词 |
| operative<br><br>adj. 动作的; 运转的; 有效的<br>n. 技工; 侦探 | **oper(工作)**, -ative(…的)<br>围绕“工作”这一核心含义构成, 表示“操作的, 工作着的, 起作用的, 有效的, 施行的, 手术的” |
| operator<br><br>n. 操作人员; (外科) 手术员; 经营者; 经纪人 | **oper(工作)**, -ator(人)<br>围绕“工作”这一核心含义构成, 表示“操作人员” |
| operon<br><br>n. [生] 操纵子 | 源自法语 opérer“工作、运作”形成的生物学术语<br>表示共同受控并一起运作的一组基因, 即操纵子 |
| anonymous<br><br>adj. 无名的; 匿名的 | an-(无, 不, 非), **onym(名)**, -ous(…的)<br>以“名”为语义核心构成, 表示“匿名的” |
| homonymous<br><br>adj. 同名的 | 由 homonym“同形同音异义词”派生<br>同名、同形或同音的 |
| onymous<br><br>adj. 有名字的; 署名的 | **onym(名)**, -ous(…的)<br>表示与“名”有关或具有该特征, 即“有名字的” |
| pseudonymous<br><br>adj. (用) 假名的 | 由 pseudo“假的”与 onym“名称”构成<br>使用假名的 |
| operatic<br><br>adj. 歌剧 (式) 的; 适合于歌剧的 | opera(词: 歌剧), -tic(…的)<br>围绕“歌剧”这一核心含义构成, 表示“歌剧 (式) 的” |
| operational<br><br>adj. 操作上的; 用手操作的; 业务上的; 运算上的 | **oper(工作)**, -ation(行为, 结果), -al(…的)<br>表示与“工作”有关或具有该特征, 即“操作上的, 用手操作的” |


### oo

卵

| 单词 | 拆解 |
| --- | --- |
| oocyte<br><br>n. 卵母细胞 | **oo(卵)**, **cyt(o)(细胞)**, e(连接字母)<br>雌性卵巢内未成熟或成熟的原始生殖细胞, 即卵母细胞 |
| oolite<br><br>n. 卵石, 鲕状岩 | 由希腊语 oon“卵”与 lithos“石”构成<br>由鱼卵状颗粒组成的岩石 |
| oolitic<br><br>adj. 鲕状的 | oolite→oolit(词: 鱼卵石), -ic(…的)<br>由“鱼卵石”派生为当前词义 |


### oper

工作

| 单词 | 拆解 |
| --- | --- |
| cooperate<br><br>v. 合作; 协助; 协作 | co-(与, 共同), **oper(工作)**, -ate(做, 使)<br>使“工作”共同结合或发挥作用, 因此表示“合作, 协作” |
| cooperation<br><br>n. 合作, 协作 | co-(与, 共同), **oper(工作)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“合作, 协作” |
| cooperative<br><br>adj. 合作的; 协作的; 合作社<br>n. 合作的, 协作的; 合作社 | co-(与, 共同), **oper(工作)**, -ative(…的)<br>在前词基础上加“-ative”构成名词或形容词, 表示“合作的, 协作的” |
| cooperator<br><br>n. 合作者, 合作社社员 | co-(与, 共同), **oper(工作)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“合作者, 合作社社员” |
| inoperable<br><br>adj. 不能实行手术的, 不宜动手术的 | in-(无, 不, 非), **oper(工作)**, -able(可…的)<br>否定或缺少“工作”所指的性质, 因此表示“不能实行手术的, 不宜动手术的” |
| opera<br><br>n. 歌剧 | **oper(工作)**, a(连接字母)<br>围绕“工作”这一核心含义构成, 表示“歌剧” |
| operability<br><br>n. 可操作性, 合用性; 能实行手术治疗 | **oper(工作)**, -ability(可…性)<br>围绕“工作”这一核心含义构成, 表示“可操作性, 合用性” |
| operand<br><br>n. 运算域; 运算数, 操作数 | 源自拉丁语 operandum“将被操作之物”<br>数学或计算中接受运算的对象 |
| operate<br><br>v. 操作; 运转; 运营; 动手术; 起作用 | **oper(工作)**, -ate(做, 使)<br>使运转工作起来, 即"运行" |
| operatic<br><br>adj. 歌剧(式)的; 适合于歌剧的 | opera(词: 歌剧), -tic(…的)<br>围绕“歌剧”这一核心含义构成, 表示“歌剧 (式) 的” |
| operational<br><br>adj. 操作上的, 用手操作的; 业务上的; 运算上的 | **oper(工作)**, -ation(行为, 结果), -al(…的)<br>表示与“工作”有关或具有该特征, 即“操作上的, 用手操作的” |
| operative<br><br>adj. 动作的; 运转的; 有效的<br>n. 技工; 侦探 | **oper(工作)**, -ative(…的)<br>围绕“工作”这一核心含义构成, 表示“操作的, 工作着的, 起作用的, 有效的, 施行的, 手术的” |
| operator<br><br>n. 操作人员; (外科)手术员; 经营者; 经纪人 | **oper(工作)**, -ator(人)<br>围绕“工作”这一核心含义构成, 表示“操作人员” |
| operon<br><br>n. [生]操纵子 | 源自法语 opérer“工作、运作”形成的生物学术语<br>表示共同受控并一起运作的一组基因, 即操纵子 |


### ophi(o)

蛇

| 单词 | 拆解 |
| --- | --- |
| ophidian<br><br>n. 蛇<br>adj. 蛇类的; 蛇样的 | **ophi(蛇)**, d(连接字母), -ian(…的)<br>围绕“蛇”这一核心含义构成, 表示“蛇类的, 像蛇的” |
| ophiology<br><br>n. 蛇类学 | **ophi(o)(蛇)**, -logy(…学, …研究)<br>专门研究蛇类生物特征与分类的学科 |


### ophthalm(o)

眼

| 单词 | 拆解 |
| --- | --- |
| ophthalmic<br><br>adj. 眼睛的; 眼科的; 眼炎的 | **ophthalm(眼)**, -ic(…的)<br>在前词基础上加“-ic”构成名词或形容词, 表示“眼的” |
| ophthalmologist<br><br>n. 眼科学者; 眼科医生 | 由 ophthalmo“眼”与 logist“研究、诊治者”构成<br>眼科医生 |
| ophthalmology<br><br>n. 眼科学 | **ophthalmo(眼)**, -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“眼科学” |
| ophthalmoscope<br><br>n. 检眼镜 | **ophthalmo(眼)**, **scop(镜, 观察)**, e(连接字母)<br>由“眼”与“镜”共同限定词义, 表示“检眼镜” |
| ophthalmoscopy<br><br>n. 用检眼镜检查(法) | **ophthalmo(眼)**, **scop(镜, 观察)**, y(连接字母)<br>在前词基础上加“-y”构成名词, 表示“用检眼镜检查” |


### opt

选择

| 单词 | 拆解 |
| --- | --- |
| adopt<br><br>v. 收集; 采取; 采用; 选用; 收养 | ad-(到, 朝, 向), **opt(选择)**<br>朝向所选之物靠拢, 即"采取" |
| adoption<br><br>n. 采用; 采取; 选用 | ad-(到, 朝, 向), **opt(选择)**, -ion(行为, 结果)<br>选择并接纳为己用的行为 |
| option<br><br>n. 选择 (optional; 可选择的) | **opt(选择)**, -ion(行为, 结果)<br>围绕“选择”这一核心含义构成, 表示“选择(权)” |
| adoptable<br><br>adj. 可选用的; 可采用的 | adopt(词: 采用), -able(可…的)<br>由“采用”派生为当前词义 |
| adoptive<br><br>adj. 采用的; 选取的 | adopt(词: 采用), -ive(…的)<br>在前词基础上加“-ive”构成形容词, 表示“采用的” |
| optional<br><br>adj. 可任意选择的; 非强制的 | option(词: 选择权), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“可任意选择的” |


### opt(o), ops, opi

眼, 视觉

| 单词 | 拆解 |
| --- | --- |
| autopsy<br><br>n. 亲自视察 | 源自希腊语 autopsia, 由 autos“自己”与 opsis“看见”构成<br>本义为亲眼观察, 后专指尸体解剖检查 |
| hyperopia<br><br>n. 远视 | 由希腊语 hyper“超过、在远处”与 opia“视觉”构成<br>近处聚焦不足的远视 |
| opinion<br><br>n. 意见; 看法; 见解; 评价 | 源自拉丁语 opinio“看法、信念”, 核心 opinari 表示认为<br>指个人形成的观点 |
| optician<br><br>n. 光学仪器商; 眼镜商 | **opt(眼, 视觉)**, -ician(人)<br>配制眼镜或经营光学仪器的人, 即验光配镜师 |
| optics<br><br>n. 光学 | **opt(眼, 视觉)**, -ics(…学)<br>研究光和视觉现象的学科, 即光学 |
| optometrist<br><br>n. 配镜师; 验光专家 | 由 optometry“视力测量”派生为人员名词<br>指验光和基础视力保健专业人员 |
| optometry<br><br>n. 视力测定法; 验光法 | 由希腊语 optos“视觉”与 metry“测量”构成<br>测量视力并验配镜片的专业 |
| synopsis<br><br>n. (书; 剧本等的) 提要; 概要; 梗概 | syn-(共同), **ops(眼, 视觉)**, -is(性质, 状态)<br>把各部分放在一起一次看清, 因此表示概要、梗概 |
| opinionated<br><br>adj. 固执己见的 | 词形来源：opinionate + ed-form |
| optic<br><br>adj. 视力的; 光学的 | **opt(眼, 视觉)**, -ic(…的)<br>眼睛、视觉或光学的 |
| panoptic<br><br>adj. 显示全貌的 | pan-(全, 总, 泛), **opt(眼, 视觉)**, -ic(…的)<br>能够看见整体全貌的, 即全景的 |


### optim

最佳

| 单词 | 拆解 |
| --- | --- |
| optimize<br><br>v. 优选; 最佳化; 使尽可能完善 | **optim(最佳)**, -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“优选” |
| optimism<br><br>n. 乐观(主义) | **optim(最佳)**, -ism(主义)<br>表示与“最好”有关的性质或状态, 即“乐观(主义)” |
| optimist<br><br>n. 乐观(主义)者 | **optim(最佳)**, -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“乐观” |
| optimization<br><br>n. 最佳化; 最优化 | **optim(最佳)**, -ization(行为, …化)<br>围绕“最佳”这一核心含义构成, 表示“最佳化, 最优化” |
| optimum<br><br>n. 最适条件; 最佳效果<br>adj. 最优的; 最适宜的 | **optim(最佳)**, -um(名词词尾)<br>最好的条件或状态, 即最适值; 也可转化作形容词 |
| optimal<br><br>adj. 最适宜的; 最理想的; 最令人满意的; 最佳的 | **optim(最佳)**, -al(…的)<br>表示与“最佳”有关或具有该特征, 即“最佳的, 最理想的” |
| optimistic(al)<br><br>adj. 乐观(主义)的 | optimist(词: 乐观主义者), -ical(…的)<br>在前词基础上加“-ic”构成形容词, 表示“乐观” |


### or(a)

说

| 单词 | 拆解 |
| --- | --- |
| orate<br><br>v. 演说; 装演说腔 | 由 oration“演说”逆构而来<br>正式演说, 常含夸张意味 |
| oracle<br><br>n. 预言; 先知 | 经古法语借自拉丁语 oraculum“神谕”, 与 orare“说、祈祷”相关<br>神的答复; 引申为权威意见 |
| oral<br><br>adj. 口头的; 口腔的<br>n. 口试 | 源自拉丁语 os、or-“嘴”<br>表示口头的或与口腔有关的 |
| oration<br><br>n. 演说; 讲演 | 源自拉丁语 oratio“讲话、演说”, 来自 orare“说”<br>正式演讲 |
| orator<br><br>n. 演说者; 雄辩家 | 源自拉丁语 orator“说话者、演说者”<br>擅长公开演讲的人 |
| oratorio<br><br>n. (以圣经故事为主题的) 清唱剧; 圣乐 | 借自意大利语 oratorio, 原指在祈祷室演出的宗教音乐<br>大型声乐与管弦乐作品 |
| oratory<br><br>n. 演讲 (术); 雄辩 (术); 修辞; 祈祷室 | orator(词: 演讲者), -y(场所)<br>在前词基础上加“-y”构成名词, 表示“演讲” |
| oracular<br><br>adj. 预言的; 圣言的 | 由 oracle“神谕”派生<br>像神谕般权威或晦涩的 |


### oram

观看, 景象

| 单词 | 拆解 |
| --- | --- |
| cyclorama<br><br>n. 圆形画景 | **cycl(圆, 环)**, **orama(观看, 景象)**<br>由“圆”与“景”共同限定词义, 表示“圆形画景” |
| diorama<br><br>n. 透景画; 西洋景; 洋片 | 源自希腊语 dia“穿过” + horama“景象”<br>原指透过开口观看的景象, 后来指立体模型或西洋镜 |
| panorama<br><br>n. 全景 (画); 全景照片 | pan-(全, 总, 泛), **orama(观看, 景象)**<br>把四周全部景象纳入一次观看, 即全景; pan- 是‘全部’ |
| panoramic<br><br>adj. 全景的; 全貌的 | 由 panorama“全景”派生, panorama 本由希腊语 pan“全部”与 horama“景象”构成<br>呈现广阔全景的 |


### orbit

圆周, 轨道

| 单词 | 拆解 |
| --- | --- |
| orbit<br><br>n. (环绕地球; 太阳等运行的)轨道<br>v. 绕轨道而行 | **orbit(圆周, 轨道)**<br>围绕中心运行的轨道, 也可转化作动词 |
| orbiter<br><br>n. 沿轨道运行的东西(尤指绕天体做轨道运行的宇宙飞船) | **orbit(圆周, 轨道)**, -er(物)<br>沿轨道运行的航天器或天体 |
| exorbitant<br><br>adj. 过度的; 过高的; 昂贵的 | 源自拉丁语 exorbitare“离开轨道”, 由 ex“离开”与 orbita“轨道”构成<br>偏离正常范围, 即过高的 |
| orbital<br><br>adj. 轨道的; 轨迹的 | **orbit(圆周, 轨道)**, -al(…的)<br>表示与“轨道”有关或具有该特征, 即“轨道的, 轨迹的” |


### order, ordin

秩序, 顺序

| 单词 | 拆解 |
| --- | --- |
| coordinate<br><br>n. 坐标; (衣服; 家具等)搭配; 协调<br>v. (使)协调; (使)相配合; 使(身体各部位)动作协调<br>adj. 同等的; 并列的; 坐标的 | co-(与, 共同), **ordin(秩序, 顺序)**, -ate(做, 使)<br>使各部分遵循共同次序, 因此表示协调、配合 |
| disorder<br><br>n. 杂乱; 混乱; (身心; 机能的)失调; 病 | dis-(否定, 相反), **order(秩序, 顺序)**<br>失去正常秩序, 因此表示混乱、失调或疾病 |
| ordinance<br><br>n. 法令; 条例; 条令 | **ordin(秩序, 顺序)**, -ance(性质, 状态)<br>使秩序得以确立的状态, 即"法规, 法令" |
| ordination<br><br>n. 排成等级; 分类 | **ordin(秩序, 顺序)**, -ation(行为, 结果)<br>围绕“秩序”这一核心含义构成, 表示“排成等级” |
| extraordinary<br><br>adj. 非凡的; 特别的 | extra-(在外, 向外), **ordin(秩序, 顺序)**, -ary(…的)<br>超出通常秩序和常规, 因此表示非凡的、特别的 |
| inordinate<br><br>adj. 过分的; 不节制的 | 构词锚点：in 表示“无, 不, 非”; ordin 表示“秩序, 顺序”; -ate 在此为形容词词尾, 不取动词义<br>不按顺序的 |
| orderly<br><br>adj. 整齐的; 有秩序的 | **order(秩序, 顺序)**, -ly(…的)<br>围绕“秩序”这一核心含义构成, 表示“整齐的, 有秩序的” |
| ordinal<br><br>adj. 依次的; 顺序的 | **ordin(秩序, 顺序)**, -al(…的)<br>表示与“顺序”有关或具有该特征, 即“依次的, 顺序的” |
| ordinary<br><br>adj. 通常的; 普通的; 平庸的; 平淡的 | **ordin(秩序, 顺序)**, -ary(…的)<br>按秩序的 |
| subordinate<br><br>n. 部属; 下级<br>adj. 次要的; 从属的; 下级的 | 构词锚点：sub 表示“在下, 向下”; ordin 表示“秩序, 顺序”; -ate 在此为名词或形容词词尾, 不取动词义<br>位于下级 |


### ori(g)

升起, 开始

| 单词 | 拆解 |
| --- | --- |
| disorient<br><br>v. 使迷失方向(或方位) | dis-(否定, 相反), orient(词: 东方)<br>由“否定”与“东方”共同限定词义, 表示“使迷失方向(或方位)” |
| orientate<br><br>v. 指向东方; 定方位; 指示方向 | orient(词: 向东), -ate(做, 使)<br>在前词基础上加“-ate”构成动词, 表示“指向东方” |
| originate<br><br>n. 起源 original<br>v. 引起; 起源 (origin; 发源<br>adj. 最初的) | origin(词: 起源), -ate(做, 使)<br>围绕“升起”这一核心含义构成, 表示“起源, 发源” |
| aboriginal<br><br>adj. 原来的; 土著的<br>n. 原住民 | ab-(脱离, 离去), origin(词: 起源), -al(…的)<br>从最初起源之时便存在的, 即土著的或原始的 |
| disorientation<br><br>n. 不辨方向 | disorient(词: 使失去方向), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“不辨方向” |
| orient<br><br>adj. 东方的<br>n. 东方; 东方诸国<br>v. 向东; 使朝东; 使适应 | **ori(升起, 开始)**, -ent(…的)<br>太阳升起的地方(的) |
| orientation<br><br>n. 方向; 定向; 目标; 适应培训; 迎新会 | orient(词: 向东), -ation(行为, 结果)<br>原指面向东方 |
| origin<br><br>n. 根源; 源头; (信息)来源 | 源自拉丁语 oriri（升起、开始）, 记忆锚点是某事最初升起之处, 即起源 |
| reorientation<br><br>n. 再定方向; 重新定位 | re-(回, 向后, 再次), orient(词: 东方), -ation(行为, 结果)<br>由“重新”与“东方”共同限定词义, 表示“再定方向, 重新定位” |
| original<br><br>adj. 最初的; 原创的 | origin(词: 起源), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“最初的” |


### orn

装饰, 装备

| 单词 | 拆解 |
| --- | --- |
| adorn<br><br>v. 装饰; 打扮; 装扮 | ad-(到, 朝, 向), **orn(装饰, 装备)**<br>给某物加上装饰, 使其更美观, 因此表示装饰 |
| adornment<br><br>n. 装饰; 打扮 | adorn(词: 装饰), -ment(行为, 过程)<br>在前词基础上加“-ment”构成名词, 表示“装饰” |
| ornament<br><br>n. 装饰 (物)<br>v. 装饰 | **orn(装饰, 装备)**, a(连接字母), -ment(物)<br>用于装饰的物品; 也可转化作动词表示装饰 |
| ornamentation<br><br>n. 装饰; 修饰; 装饰品 | ornament(词: 装饰), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“装饰” |
| ornamental<br><br>adj. 装饰的 | ornament(词: 装饰), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“装饰的” |
| ornate<br><br>adj. 装饰华丽的; 过分装饰的; 华美的; 矫揉造作的 | 构词锚点：orn 表示“装饰, 装备”; -ate 在此为形容词词尾, 不取动词义<br>围绕“装饰”这一核心含义构成, 表示“装饰华丽的, 过分装饰的” |


### ornith(o)

鸟

| 单词 | 拆解 |
| --- | --- |
| ornithine<br><br>n. 鸟氨酸 | **ornith(鸟)**, -ine(…的)<br>围绕“鸟”这一核心含义构成, 表示“鸟氨酸” |
| ornithologist<br><br>n. 鸟学家 | **ornitho(鸟)**, -logist(…学家)<br>围绕“鸟”这一核心含义构成, 表示“鸟学家” |
| ornithology<br><br>n. 鸟学; 禽学 | **ornitho(鸟)**, -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“鸟学” |


### oro

山

| 单词 | 拆解 |
| --- | --- |
| orogeny<br><br>n. 造山运动; 造山作用 | orogen(词: 造山带), -y(活动)<br>在前词基础上加“-y”构成名词, 表示“造山运动” |
| orography<br><br>n. 山志学; 山岳形态学 | **oro(山)**, **graph(写, 画)**, -y(活动)<br>记录或描绘“山”的方法, 即“山志学, 山岳形态学” |


### oscill(o)

摇动

| 单词 | 拆解 |
| --- | --- |
| oscillate<br><br>v. (使)摆动; (使)动摇; 振动 | **oscill(摇动)**, -ate(做, 使)<br>围绕“摇动”这一核心含义构成, 表示“(使)摆动” |
| oscillation<br><br>n. 摆动; 动摇; 振动 | **oscill(摇动)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“摆动” |
| oscillator<br><br>n. 摇摆的人(或物); 振荡器 | **oscill(摇动)**, -ator(物)<br>产生周期性振荡的装置或系统 |
| oscilloscope<br><br>n. 示波器; 示波管 | **oscillo(摇动)**, **scop(镜, 观察)**, e(连接字母)<br>围绕“观察”这一核心含义构成, 表示“示波器” |
| oscillatory<br><br>adj. 摆动的; 振动的; 动摇不定的 | **oscill(摇动)**, -atory(…的)<br>在前词基础上加“-atory”构成形容词, 表示“摆动的” |


### oss(e), oss(i)

骨

| 单词 | 拆解 |
| --- | --- |
| ossify<br><br>v. (使) 骨化; 使硬化 | **ossi(骨)**, -fy(…化, 做…)<br>围绕“骨”这一核心含义构成, 表示“(使) 骨化” |
| ossification<br><br>n. 骨化; 成骨 | **ossi(骨)**, -fication(…化, 做…)<br>使事物呈现“骨”与“…化”所表达的状态, 即“骨化” |
| ossuary<br><br>n. 藏尸骨处 | **oss(骨)**, u(连接字母), -ary(场所)<br>存放尸骨的场所 |
| osseous<br><br>adj. 骨(状)的 | **osse(骨)**, -ous(…的)<br>表示与“骨”有关或具有该特征, 即“骨(状)的” |


### oste(o)

骨

| 单词 | 拆解 |
| --- | --- |
| osteitis<br><br>n. 骨炎 | **oste(骨)**, -itis(…炎)<br>“骨”发生炎症, 即“骨炎” |
| osteoarthritis<br><br>n. 骨关节炎 | **osteo(骨)**, **arthr(关节)**, -itis(…炎)<br>“骨、关节”发生炎症, 即“骨关节炎” |
| osteogenesis<br><br>n. 骨生成; 成骨; 骨发生 | **osteo(骨)**, **gen(出生, 产生)**, -esis(行为, 过程)<br>由“骨”与“出生”共同限定词义, 表示“骨生成” |
| osteology<br><br>n. 骨学 | **osteo(骨)**, -logy(…学, …研究)<br>以“骨”为研究对象的学科, 即“骨学” |
| osteoma<br><br>n. 骨瘤 | **oste(骨)**, -oma(肿瘤, 肿块)<br>围绕“骨”这一核心含义构成, 表示“骨瘤” |
| osteopathy<br><br>n. 疗骨术 | **osteo(骨)**, **pathy(疾病, 疗法)**<br>由“骨”与“疗法”共同限定词义, 表示“疗骨术” |
| osteotomy<br><br>n. 骨切开术; 截骨术 | **osteo(骨)**, **tomy(切, 割)**<br>切开“骨”的术式, 即“骨切开术” |
| periosteum<br><br>n. 骨膜 | peri-(四周, 近), **oste(骨)**, -um(名词词尾)<br>包围并覆盖骨表面的膜, 即骨膜 |
| osteoid<br><br>adj. 似骨的; 骨样的 | **oste(骨)**, -oid(似…的（物）)<br>形状像“骨”, 即“似骨的” |


### ot(o)

耳

| 单词 | 拆解 |
| --- | --- |
| otitis<br><br>n. 耳炎 | **ot(o)(耳)**, -itis(…炎)<br>耳道内部或中耳黏膜受到病菌感染引起的炎性病症, 即耳炎 |
| otolith<br><br>n. 耳石; 听石 | **oto(耳)**, **lith(石)**<br>围绕“耳”这一核心含义构成, 表示“耳石, 听石” |
| otology<br><br>n. 耳科学 | **oto(耳)**, -logy(…学, …研究)<br>以“耳”为研究对象的学科, 即“耳科学” |
| otorhinolaryngology<br><br>n. 耳鼻喉科学 | **oto(耳)**, **rhino(鼻)**, **laryngo(喉)**, -logy(…学, …研究)<br>以“耳、鼻、喉”为研究对象的学科, 即“耳鼻喉科学” |
| otoscope<br><br>n. 耳镜 | **oto(耳)**, **scop(镜, 观察)**, e(连接字母)<br>由“耳”与“镜”共同限定词义, 表示“耳镜” |
| parotid<br><br>n. 耳下腺; 腮腺 | par-(旁边), **ot(耳)**, -id(…的)<br>位于耳旁的腺体, 即腮腺 |
| otic<br><br>adj. 耳(部)的 | 源自希腊语 ous, ot“耳”<br>与耳有关的 |


### ov(i), ov(o)

卵, 蛋

| 单词 | 拆解 |
| --- | --- |
| ovariectomy<br><br>n. 卵巢切除术 | 由 ovari“卵巢”与 ectomy“切除术”构成<br>卵巢切除术 |
| oviduct<br><br>n. 输卵管 | **ovi(卵, 蛋)**, **duct(引, 导)**<br>由“卵”与“引”共同限定词义, 表示“输卵管” |
| ovoid<br><br>n. 卵形体<br>adj. 卵形的; 梨形的 | **ov(卵, 蛋)**, -oid(似…的（物）)<br>似...形的 |
| ovulation<br><br>n. 排卵 | ovulate→ovulat(词: 排卵), -ion(行为, 结果)<br>由“排卵”派生为当前词义 |
| ovule<br><br>n. 小卵 | **ov(卵, 蛋)**, -ule(小)<br>围绕“卵”这一核心含义构成, 表示“小卵” |
| ovum<br><br>n. 卵 (细胞) | **ov(卵, 蛋)**, -um(名词词尾)<br>卵细胞 |
| oval<br><br>adj. 椭圆状的 | **ov(卵, 蛋)**, -al(…的)<br>如卵形状的, 即"椭圆的" |
| ovarian<br><br>adj. 卵巢的 | **ovari(卵巢)**, -an(…的)<br>围绕“卵巢”这一核心含义构成, 表示“卵巢的” |
| ovate<br><br>adj. 卵 (体) 形的 | 构词锚点：ov 表示“卵, 蛋”; -ate 在此为形容词词尾, 不取动词义<br>围绕“卵”这一核心含义构成, 表示“卵 (体) 形的” |


### ovari, avario

卵巢

| 单词 | 拆解 |
| --- | --- |
| oval<br><br>adj. 卵形的 | **ov(卵, 蛋)**, -al(…的)<br>如卵形状的, 即"椭圆的" |
| ovarian<br><br>adj. 卵巢的 | **ovari(卵巢)**, -an(…的)<br>围绕“卵巢”这一核心含义构成, 表示“卵巢的” |
| ovariectomy<br><br>n. 卵巢切除术 | 由 ovari“卵巢”与 ectomy“切除术”构成<br>卵巢切除术 |
| ovate<br><br>adj. 卵(体)形的 | 构词锚点：ov 表示“卵, 蛋”; -ate 在此为形容词词尾, 不取动词义<br>围绕“卵”这一核心含义构成, 表示“卵 (体) 形的” |
| oviduct<br><br>n. 输卵管 | **ovi(卵, 蛋)**, **duct(引, 导)**<br>由“卵”与“引”共同限定词义, 表示“输卵管” |
| ovoid<br><br>n. 卵形体<br>adj. 卵形的; 梨形的 | **ov(卵, 蛋)**, -oid(似…的（物）)<br>似...形的 |
| ovulation<br><br>n. 排卵 | ovulate→ovulat(词: 排卵), -ion(行为, 结果)<br>由“排卵”派生为当前词义 |
| ovule<br><br>n. 小卵 | **ov(卵, 蛋)**, -ule(小)<br>围绕“卵”这一核心含义构成, 表示“小卵” |
| ovum<br><br>n. 卵(细胞) | **ov(卵, 蛋)**, -um(名词词尾)<br>卵细胞 |


### oxy

尖锐, 敏锐; 酸; 含氧; 快

| 单词 | 拆解 |
| --- | --- |
| oxygenate<br><br>v. 充氧于; 氧化 | oxygen(词: 氧), -ate(做, 使)<br>在前词基础上加“-ate”构成动词, 表示“充氧于” |
| oxychloride<br><br>n. 氯氧化物 | **oxy(含氧)**, **chlor(绿, 氯)**, -ide(化合物)<br>同时含氧和氯的化合物, 即氯氧化物 |
| oxygen<br><br>n. 氧 (气); 氧气 | **oxy(酸)**, **gen(出生, 产生)**<br>名称原意为“产生酸的物质”, 源于早期化学理论; 现代指氧 |
| oxytetracycline<br><br>n. 氧四环素; 土霉素 | 由 oxy“含氧”、tetracycline“四环素”构成<br>含额外羟基的四环素类抗生素 |
