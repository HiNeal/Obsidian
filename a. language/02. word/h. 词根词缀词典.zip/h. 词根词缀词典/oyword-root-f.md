## oyword-root-f


### fabl, fabul

说; 故事

| 单词 | 拆解 |
| --- | --- |
| confabulation<br><br>n. 闲谈; 讨论 | con-(与, 共同), **fabul(说)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“闲谈” |
| fable<br><br>n. 寓言; 传说 | **fabl(故事)**, e(连接字母)<br>以虚构故事寄托寓意, 即寓言 |
| fabled<br><br>adj. 寓言中的; 虚构的 | **fabl(故事)**, -ed(…的)<br>在故事中广为传说的, 即传奇的 |
| fabulous<br><br>adj. 寓言般的; 传说的; 编写寓言的 | **fabul(故事)**, -ous(…的)<br>原指只存在于故事中的, 后来表示难以置信或极好的 |


### fabr

制作

| 单词 | 拆解 |
| --- | --- |
| fabricate<br><br>v. 制作; 装配; 捏造; 伪造 | 源自拉丁语 fabricare“制作、建造”<br>表示制造物品, 也引申为编造虚假内容 |
| fabric<br><br>n. 织物; 结构; 组织; 布料 | 源自拉丁语 fabrica“制作、作坊、构造”<br>表示制作出的织物, 也引申为结构或组织 |
| fabricant<br><br>n. 制造者; 制作者 | 源自法语 fabricant“制造者”, 与 fabricate“制造”同族<br>表示从事制造的人 |
| fabrication<br><br>n. 制造; 装配; 捏造; 编造 | fabricate→fabricat(词: 制造; 编造), -ion(行为, 结果)<br>制造、装配或编造的行为及结果 |
| fabricator<br><br>n. 装配工; 捏造者; 金属加工厂 | fabricate→fabricat(词: 制造; 编造), -or(人)<br>从事制造的人, 也可指捏造事实的人 |


### fac, fic

面, 外形

| 单词 | 拆解 |
| --- | --- |
| efface<br><br>v. 消除; 抹掉 | ef-(出, 向外), **fac(面, 外形)**, e(连接字母)<br>把表面上的痕迹去掉, 即抹去 |
| facade<br><br>n. 正面; 表面; 外观; 门面 | **fac(面, 外形)**, -ade(行为, 结果)<br>建筑朝外的一面, 即正面; 也引申为掩饰真实情况的外表 |
| face<br><br>n. 脸; 面容; 正面<br>v. 面对; 朝; 正视 | 经古法语 face 借自拉丁语 facies“外形、面貌”<br>由人的面貌引申为表面, 并转化作动词表示面对 |
| facer<br><br>n. (拳击等)面部所受的打击 | 由 face“正面”派生出的事物名词<br>指迎面而来的打击或必须正视的困难 |
| facet<br><br>n. 小(平)面 | **fac(面, 外形)**, -et(小)<br>宝石上的一个小平面, 引申为事物的一个方面 |
| facing<br><br>n. 面层; 覆盖层; 饰面 | **fac(面, 外形)**, -ing(物)<br>覆盖或装饰表面的材料, 即面层 |
| surface<br><br>n. 表面; 地面; 水面<br>v. 出现在XX表面 | sur-(上), **fac(面, 外形)**, e(连接字母)<br>位于最上方的一面, 即表面; 也可转化作动词表示浮现 |
| deficiency<br><br>n. 缺乏; 不足 (deficit; 赤字; 亏损) | de-(脱离, 取消, 除去), **fic(做)**, i(连接字母), -ency(性质, 状态)<br>偏离完整、充分状态而有所缺少, 即不足 |
| deficit<br><br>n. 赤字; 逆差; 亏损; 不定额 | 直接借自拉丁语 deficit（缺少）, 原为 deficere 的第三人称形式 |
| efficiency<br><br>n. 效率; 功率 | ef-(出, 向外), **fic(做)**, i(连接字母), -ency(性质, 状态)<br>做出的结果 |
| facial<br><br>adj. 面部的<br>n. 美容; 面部护理 | **faci(面, 外形)**, -al(…的)<br>与面部或外观有关的 |
| superficial<br><br>adj. 表面的; 肤浅的; 表皮的; 表层的 | 源自拉丁语 superficies（表面）, 记忆锚点是只停留在事物表层, 因此表示表面的或肤浅的 |
| deficient<br><br>adj. 缺乏的; 欠缺的; 有缺陷的 | 源自拉丁语 deficiens“缺少的”, 与 defect 同源<br>数量或能力不足的 |
| efficient<br><br>adj. 有效率的; 有能力的; 效率高的 | ef-(出, 向外), **fic(做)**, -ient(…的)<br>围绕“出”这一核心含义构成, 表示“高效的” |
| inefficient<br><br>adj. 无效率的; 效率低的 | 由 in“无、不”与 efficient“有效率的”构成<br>不能有效产生结果的 |
| proficient<br><br>adj. 熟练的 | pro-(向前, 前进), **fic(做)**, -ient(…的)<br>做在前面的 |
| sufficient<br><br>adj. 充足的; 足够的 | suf-(在下, 向下), **fic(做)**, -ient(…的)<br>围绕“在下”这一核心含义构成, 表示“充分的, 足够的” |


### fac, fact,fic

做

| 单词 | 拆解 |
| --- | --- |
| facility<br><br>n. 设施; 设备; 附加功能; 天赋; 便利 | **fac(做)**, -ility(性质, 状态)<br>表示与“做”有关的性质或状态, 即“设备, 设施” |
| facsimile<br><br>n. 摹写; 摹真本; 传真 | **fac(做)**, **simil(相同, 相似)**, e(连接字母)<br>做出相似的东西 |
| fact<br><br>n. 事实 | **fact(做)**<br>已经做出来的事 |
| faction<br><br>n. 派别; 宗派; 派系斗争; 内讧 | **fact(做)**, -ion(行为, 结果)<br>做同样事情的人 |
| factionalism<br><br>n. 派别活动; 派性 | 由 factional“派系的”形成 factionalism<br>以派系利益行动的倾向或活动 |
| factory<br><br>n. 制造厂; 工厂 | **fact(做)**, -ory(场所)<br>进行制造生产的场所, 即工厂 |
| factum<br><br>n. 自己的行为; 遗嘱的正式订立; 事实陈述书; 呈文 | **fact(做)**, -um(名词词尾)<br>已经做成或正式陈述的事项, 即行为或事实陈述书 |
| facture<br><br>n. 制作 (法) | **fact(做)**, -ure(行为, 结果)<br>围绕“作”这一核心含义构成, 表示“制作 (法)” |
| malefactor<br><br>n. 作恶者; 犯罪分子; 坏分子 | male-(坏, 恶, 不良), **fact(做)**, -or(人)<br>由“恶”与“作”共同限定词义, 表示“作恶者” |
| manufacturer<br><br>n. 制造者; 制造商; 工厂主 | manufacture→manufactur(词: 制造), -er(人)<br>从事产品制造的企业或人员 |
| facile<br><br>adj. 容易做到的; 易得到的; 灵巧的 | **fac(做)**, -ile(…的)<br>围绕“做”这一核心含义构成, 表示“容易做到的” |
| factitious<br><br>adj. 人为的; 做作的; 不自然的 | **fact(做)**, -itious(…的)<br>围绕“做”这一核心含义构成, 表示“人为的” |


### faith, fid

信任, 信心

| 单词 | 拆解 |
| --- | --- |
| confidence<br><br>n. 自信; 信任 | con-(与, 共同), **fid(信任, 信心)**, -ence(性质, 状态)<br>对某人或某事怀有充分信任的状态, 即信心 |
| diffidence<br><br>n. 不自信; 羞怯 | dif-(分开, 分离), **fid(信任, 信心)**, -ence(性质, 状态)<br>与信心分离、缺少自信的状态, 即羞怯 |
| faith<br><br>n. 信任; 信仰; 忠诚; 保证 | **faith(信任, 信心)**<br>核心义为信任, 由此发展为信仰、忠诚 |
| fidelity<br><br>n. 忠诚 | 源自拉丁语 fidelitas“忠诚、信实”<br>表示对人、原则或原件保持忠实的性质 |
| confident<br><br>adj. 确信的; 自信的 | 经法语借自拉丁语 confidens“充分信任的”<br>由信任发展为自信的、确信的 |
| confidential<br><br>adj. 秘密的; 机密的; 委以机密的; 获信任的 | con-(与, 共同), **fid(信任, 信心)**, -ent(…的), -ial(…的)<br>基于信任而不应公开的, 即机密的 |
| faithful<br><br>adj. 守信的; 忠实的; 如实的 | **faith(信任, 信心)**, -ful(充满…的)<br>围绕“信任”这一核心含义构成, 表示“守信的, 忠实的” |
| faithless<br><br>adj. 背信弃义的; 不忠的; 不可靠的; 不老实的; 无信仰的 | **faith(信任, 信心)**, -less(无…的, 不…的)<br>在前词基础上加“-less”构成形容词, 表示“背信弃义的” |
| perfidious<br><br>adj. 不忠的; 不义的; 奸诈的 | per-(完全, 十足), **fid(信任, 信心)**, -ious(…的)<br>彻底背弃信任的, 即不忠或奸诈的 |


### fall, fals, fault

欺骗; 错误

| 单词 | 拆解 |
| --- | --- |
| falsify<br><br>v. 伪造; 说谎 | **fals(欺骗)**, i(连接字母), -fy(…化, 做…)<br>围绕“欺骗”这一核心含义构成, 表示“伪造, 说谎” |
| fallacy<br><br>n. 谬误; 谬论; 谬见 | **fall(错误)**, -acy(性质, 状态)<br>具有欺骗性的错误推理, 即谬误 |
| fallibility<br><br>n. 易犯错误性; 难免有错误 | **fall(错误)**, -ibility(可…性)<br>围绕“错误”这一核心含义构成, 表示“易犯错误性” |
| fault<br><br>n. 过失; 过错; 缺点; 毛病; 故障<br>v. 找出缺点 | **fault(错误)**<br>核心义为错误, 由此表示过失、缺点或故障 |
| fallacious<br><br>adj. 谬误的; 欺骗的 | **fall(欺骗)**, -acious(…的)<br>围绕“错误”这一核心含义构成, 表示“谬误的” |
| fallible<br><br>adj. 易犯错误的 | **fall(错误)**, -ible(可…的)<br>在前词基础上加“-ible”构成形容词, 表示“易犯错误的” |
| false<br><br>adj. 错误的; 虚假的; 不正确的; 伪造的 | **fals(错误)**, e(连接字母)<br>与事实不符, 即错误的、假的 |
| faultless<br><br>adj. 无缺点的内容; 无可指责的 | fault(词: 缺点; 过错), -less(无…的, 不…的)<br>没有缺点或过错的, 即无可指责的 |
| faulty<br><br>adj. 有错误的; 有缺点的; 不完善的 | **fault(错误)**, -y(充满…的, 有…特征的, 像…的)<br>在前词基础上加“-y”构成形容词, 表示“有错误的” |
| infallible<br><br>adj. 无过失的; 一贯正确的 | in-(无, 不, 非), **fall(错误)**, -ible(可…的)<br>否定或缺少“错误”所指的性质, 因此表示“无过失的” |


### feat, feas

做

| 单词 | 拆解 |
| --- | --- |
| defeat<br><br>n. 失败; 战败<br>v. 击败; 战胜; 挫败 | de-(否定, 相反), **feat(做)**<br>使对方无法继续行动, 即击败 |
| feasibility<br><br>n. 可行性 | **feas(做)**, -ibility(可…性)<br>围绕“做”这一核心含义构成, 表示“可行性” |
| feat<br><br>n. 成就; 功绩 | **feat(做)**<br>引申为"技艺; 功绩" |
| feature<br><br>n. 特征; 特色; 特写; 特辑<br>v. 以…为特色 | **feat(做)**, -ure(状态)<br>围绕“做”这一核心含义构成, 表示“特征, 特色” |
| feasible<br><br>adj. 可行的; 行得通的; 可实行的; 适合的 | **feas(做)**, -ible(可…的)<br>在前词基础上加“-ible”构成形容词, 表示“可行的, 行得通的, 可实行的” |


### febr(i)

发热, 发烧

| 单词 | 拆解 |
| --- | --- |
| febrile<br><br>adj. 发热的; 热病的; 狂热的 | **febr(i)(发热, 发烧)**, -ile(…的)<br>体温异常升高呈现发烧状态, 引申为狂热的 |
| febrifuge<br><br>n. 退热药; 解热剂<br>adj. 解热的 | **febr(i)(发热, 发烧)**, i(连接字母), **fug(逃, 散)**<br>使身体发热症状驱散退去的药物 |


### fect

做

| 单词 | 拆解 |
| --- | --- |
| affect<br><br>v. 影响; (感情方面)打动; （感情上）打动; 使悲伤 | af-(到, 朝, 向), **fect(做)**<br>对某人某物施加作用, 即影响; 感情义由“作用于内心”发展 |
| perfect<br><br>v. 使完美; 改善<br>adj. 完美的; 完全的 | per-(通过, 贯穿), **fect(做)**<br>强化“做”这一动作或状态, 因此表示“完美的, 完全的” |
| affection<br><br>n. 喜爱; 感情; 喜欢; (复数)爱情 | af-(到, 朝, 向), **fect(做)**, -ion(行为, 结果)<br>内心所向 |
| defect<br><br>n. 缺点; 缺陷; 欠缺<br>v. 叛逃; 变节 | de-(脱离, 取消, 除去), **fect(做)**<br>偏离应有制作或状态之处, 即缺陷; 作动词时指脱离阵营 |
| effect<br><br>n. 效应; 影响 ”使发生; 实现 | ef-(出, 向外), **fect(做)**<br>做的外在效果 |
| perfection<br><br>n. 尽善尽美; 完美 | perfect(词: 完成时), -ion(行为, 结果)<br>由“完成时”派生为当前词义 |
| effective<br><br>adj. 有效的; 生效的 | ef-(出, 向外), **fect(做)**, -ive(…的)<br>能够把预期结果做出来的, 即有效的 |
| infectious<br><br>adj. 传染(性)的 | in-(向内, 进入), **fect(做)**, -ious(…的)<br>在内部起作用的 |


### feder

联盟, 联合

| 单词 | 拆解 |
| --- | --- |
| confederate<br><br>n. 同盟者; 同盟国<br>v. 联盟; 联合<br>adj. 同盟的; 联合的 | con-(与, 共同), **feder(联盟, 联合)**, -ate(做, 使)<br>在 federation(联盟)的基础上派生, 表示结盟的、同盟者或使结盟 |
| confederacy<br><br>n. 联盟; 邦联; 同盟 | con-(与, 共同), **feder(联盟, 联合)**, -acy(性质, 状态)<br>使“联盟”共同结合或发挥作用, 因此表示“联盟, 邦联, 同盟” |
| confederation<br><br>n. 联盟; 邦联 | con-(与, 共同), **feder(联盟, 联合)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“联盟” |
| federalism<br><br>n. 联邦制; 联邦主义 | **feder(联盟, 联合)**, -al(…的), -ism(主义)<br>表示与“联盟”有关的性质或状态, 即“联邦制” |
| federalist<br><br>n. 联邦制拥护者; 联邦主义者 | federal(词: 联邦制的), -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“联邦制拥护者” |
| federation<br><br>n. 联盟; 同盟; 联合会; 联邦(政府) | **feder(联盟, 联合)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“联盟” |
| federative<br><br>adj. 联合的; 联邦的 | **feder(联盟, 联合)**, -ative(…的)<br>在前词基础上加“-ative”构成形容词, 表示“联合的” |


### fer

带, 拿; 产生; 野生

| 单词 | 拆解 |
| --- | --- |
| confer<br><br>v. 协商; 商议; 授予 | con-(与, 共同), **fer(带, 拿)**<br>把意见带到一起来 |
| defer<br><br>v. 拖延; 推迟 | de-(脱离, 取消, 除去), **fer(带, 拿)**<br>把事情带离当前时间, 即推迟; 也可指把判断交给他人 |
| differ<br><br>v. 不同; 相异; 意见不同 | dif-(分开, 分离), **fer(带, 拿)**<br>携带或承载“分开”的事物, 即“不同, 相异” |
| differentiate<br><br>v. 区别; 区分 | 源自 different（不同的）形成的动词, 表示辨别或使产生差异 |
| infer<br><br>v. 推断; 暗示; 推理 | in-(向内, 进入), **fer(带, 拿)**<br>把信息带入心中得出结论 |
| conference<br><br>n. (常持续数日的大型正式)会议; 正式商谈; （常持续数日的大型正式）会议 | con-(与, 共同), **fer(带, 拿)**, -ence(性质, 状态)<br>把各方意见带到一起商议的会议 |
| efferent<br><br>adj. 传出的<br>n. 输出管 | ef-(出, 向外), **fer(带, 拿)**, -ent(…的)<br>携带或承载“出”的事物, 即“传出的” |
| offer<br><br>n. 提议; 出价; 录取通知<br>v. 提供; 提议; 出售 | of-(对着, 朝向, 在前), **fer(带, 拿)**<br>拿到前面来 |
| offering<br><br>n. 提供; 捐献物 | offer(词: 提供), -ing(物)<br>在前词基础上加“-ing”构成名词, 表示“提供” |
| transfer<br><br>n. 转移; 调动; 转车<br>v. 转移; 调动; 转让 | trans-(横过, 越过), **fer(带, 拿)**<br>携带或承载“横过”的事物, 即“转移” |
| transferee<br><br>n. 受让人 | transfer(词: 迁移), -ee(接受动作的人)<br>由“迁移”派生为当前词义 |
| carboniferous<br><br>adj. 含碳的 | carbon(词: 碳), i(连接字母), **fer(带, 拿)**, -ous(…的)<br>携带或承载“碳”的事物, 即“含碳的” |
| different<br><br>adj. 不同的; 相异的 | differ(词: 不同), -ent(…的)<br>在前词基础上加“-ent”构成形容词, 表示“不同的” |
| preferable<br><br>adj. 更可取的; 更好的 | pre-(先于, 预先), **fer(带, 拿)**, -able(可…的)<br>携带或承载“前”的事物, 即“更可取的” |
| preferential<br><br>adj. 优先的; 优惠的 | prefer(词: 更喜欢), -ent(…的), -ial(…的)<br>在前词基础上加“-ent”、“-ial”构成形容词, 表示“优先的” |


### fer, fur

野生; 狂怒

| 单词 | 拆解 |
| --- | --- |
| ferocity<br><br>n. 凶恶; 凶猛; 残忍; 暴行 | **feroc(凶猛)**, -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“凶恶” |
| furnace<br><br>n. 炉子; 熔炉; 极热的地方; 磨炼<br>v. 在炉中烧热(金属) | 源自拉丁语 fornax“炉、烤炉”, 经法语进入英语<br>指产生高温的炉子 |
| furor<br><br>n. 激怒; 狂怒; (宗教的)狂热 | 源自拉丁语 furor“狂怒、疯狂”<br>表示强烈愤怒或狂热 |
| fury<br><br>n. 暴怒; 狂怒; 泼妇 | **fur(狂怒)**, -y(性质, 状态)<br>围绕“狂怒”这一核心含义构成, 表示“暴怒, 狂怒” |
| feral<br><br>adj. 野的; 未驯服的; 凶残的 | **fer(野生)**, -al(…的)<br>处于野生、未驯服状态的 |
| ferocious<br><br>adj. 残忍的; 凶猛的 | **feroc(凶猛)**, -ious(…的)<br>携带或承载“对着”的事物, 即“残忍的” |
| furious<br><br>adj. 狂怒的; 狂暴的; 猛烈的; 喧闹的; 暴怒的 | **fur(狂怒)**, -ious(…的)<br>表示与“狂怒”有关或具有该特征, 即“狂怒的, 暴怒的” |


### ferr(i), ferr(o)

铁

| 单词 | 拆解 |
| --- | --- |
| ferrite<br><br>n. 铁酸盐 | **ferr(铁)**, -ite(矿物)<br>含铁的材料或铁酸盐类物质 |
| ferroalloy<br><br>n. 铁合金 | **ferro(铁)**, alloy(词: 合金)<br>由“铁”与“合金”共同限定词义, 表示“铁合金” |
| ferric<br><br>adj. 铁的; 含铁的 | **ferr(铁)**, -ic(…的)<br>表示与“铁”有关或具有该特征, 即“铁的” |
| ferrous<br><br>adj. 铁的; 含铁的; 亚铁的 | **ferr(铁)**, -ous(…的)<br>表示与“铁”有关或具有该特征, 即“铁的” |


### ferv

沸, 热

| 单词 | 拆解 |
| --- | --- |
| effervescence<br><br>n. 冒泡; 起泡沫; 泡腾 | 源自拉丁语 effervescere“沸腾起来”<br>冒泡起沫; 引申为活泼热情 |
| fervor<br><br>n. 炽热; 热情; 热烈 | 源自拉丁语 fervor“沸腾、炽热”<br>由热度发展为热情 |
| effervescent<br><br>adj. 冒泡的; 泡腾的; 沸腾的 | 与 effervesce“冒泡”同源<br>冒泡的; 充满活力的 |
| fervent<br><br>adj. 炽热的; 热情的; 热烈的 | **ferv(沸, 热)**, -ent(…的)<br>在前词基础上加“-ent”构成形容词, 表示“炽热的” |
| fervid<br><br>adj. 炽热的; 热情的; 热烈的 | **ferv(沸, 热)**, -id(…的)<br>围绕“热”这一核心含义构成, 表示“炽热的” |


### fibr(o)

纤维

| 单词 | 拆解 |
| --- | --- |
| fibre<br><br>n. 纤维<br>v. 编织; 针织 | **fibr(纤维)**, e(连接字母)<br>表示细长的纤维结构 |
| fibril<br><br>n. 小纤维; 原纤维; 根毛 | 源自拉丁语 fibra“纤维”的小称形式<br>极细小的纤维 |
| fibroblast<br><br>n. 成纤维细胞 | **fibro(纤维)**, **blast(细胞)**<br>围绕“纤维”这一核心含义构成, 表示“成纤维细胞” |
| fibroma<br><br>n. 纤维瘤 | **fibr(纤维)**, -oma(肿瘤, 肿块)<br>围绕“纤维”这一核心含义构成, 表示“纤维瘤” |
| fibrosis<br><br>n. 纤维变性; 纤维化 | **fibr(纤维)**, -osis(状态, 过程)<br>围绕“纤维”这一核心含义构成, 表示“纤维变性, 纤维化” |
| fibroid<br><br>adj. 纤维样的; 纤维性的; 由纤维组成的 | **fibr(纤维)**, -oid(似…的（物）)<br>形状像“纤维”, 即“纤维样的” |
| fibrous<br><br>adj. 含纤维的; 纤维状的; 纤维构成的 | **fibr(纤维)**, -ous(…的)<br>表示与“纤维”有关或具有该特征, 即“含纤维的” |


### fict, fig

塑造, 虚构

| 单词 | 拆解 |
| --- | --- |
| configure<br><br>v. 使成形; 使具形体 | con-(与, 共同), **fig(塑造, 虚构)**, -ure(行为, 结果)<br>把各部分共同塑造成特定形态, 因此表示配置、设定 |
| configuration<br><br>n. 构造; 结构; 形状; 外形 | configure→configur(词: 装配), -ation(行为, 结果)<br>由“装配”派生为当前词义 |
| disfigurement<br><br>n. 毁形; 毁容 | dis-(否定, 相反), figure(词: 外形), -ment(行为, 过程)<br>破坏原有外形的行为, 即毁形或毁容 |
| fiction<br><br>n. 虚构; 杜撰; 捏造; 小说 | **fict(塑造, 虚构)**, -ion(行为, 结果)<br>围绕“虚构”这一核心含义构成, 表示“虚构, 杜撰” |
| figment<br><br>n. 虚构的事; 臆造的事物 | **fig(塑造, 虚构)**, -ment(物)<br>由想象虚构出来的事物 |
| figure<br><br>n. 数字; 数值; 图像; 图形; 人物; 身材; 形象; 花样<br>v. 计算; 推断; 认为; 出现 | **fig(塑造, 虚构)**, -ure(行为, 结果)<br>塑造出的形状或形象, 也可表示数字、人物 |
| figurine<br><br>n. 小塑像 | figure→figur(词: 数字), -ine(…的)<br>由“数字”派生为当前词义 |
| nonfiction<br><br>n. 非小说类文学作品 | non-(无, 不, 非), **fict(塑造, 虚构)**, -ion(行为, 结果)<br>否定或缺少“制造”所指的性质, 因此表示“非小说类文学作品” |
| fictitious<br><br>adj. 虚构的; 杜撰的; 非真实的 | 源自拉丁语 ficticius“虚构的”, 与 fiction 同源<br>被塑造而非真实存在的 |


### fid, fiss(i)

裂

| 单词 | 拆解 |
| --- | --- |
| fission<br><br>n. 分裂; 裂变; 分裂生殖 | **fiss(裂)**, -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“分裂” |
| fissure<br><br>n. 裂缝; 裂纹; 分歧 | **fiss(裂)**, -ure(行为, 结果)<br>围绕“裂”这一核心含义构成, 表示“裂缝” |
| fissile<br><br>adj. 易裂的; 可分裂的 | **fiss(裂)**, -ile(…的)<br>围绕“裂”这一核心含义构成, 表示“易裂的” |
| fissionable<br><br>adj. 可分裂的; 可裂变的 | fission(词: 分裂), -able(可…的)<br>在前词基础上加“-able”构成形容词, 表示“可分裂的” |


### fil

线; 子女

| 单词 | 拆解 |
| --- | --- |
| defile<br><br>v. 纵列行军; 单列前进; 鱼贯而入 | de-(下降, 降低), **fil(线)**, e(连接字母)<br>沿着狭窄路线排成一列前进, 因此表示鱼贯行进; 另有‘玷污’的同形词 |
| filament<br><br>n. 细线; 丝; 线状物 | **fil(线)**, a(连接字母), -ment(物)<br>线状的细长物, 即细丝或线状物 |
| file<br><br>n. 文件; 档案<br>v. 归档 | **fil(线)**, e(连接字母)<br>原指用线串起的一组材料, 后来发展为文件或档案 |
| profile<br><br>n. 侧面; 轮廓; 传略<br>v. 描绘...轮廓; 写...的传略 | pro-(向前, 前进), **fil(线)**, e(连接字母)<br>原指从侧面线条勾出的轮廓, 后来表示人物简介、概述 |
| filiation<br><br>n. 父子关系 | 源自拉丁语 filiatio, 核心 filius 表示儿子、后代<br>表示亲子关系或传承关系 |
| filamentary<br><br>adj. 细线的; 细丝的; 纤维的 | filament(词: 细线), -ary(…的)<br>在前词基础上加“-ary”构成形容词, 表示“细线的” |
| filamentous<br><br>adj. 如丝的; 纤维的 | filament(词: 细丝), -ous(…的)<br>由“细丝”派生为当前词义 |
| filiform<br><br>adj. 线状的; 丝状的 | **fil(线)**, i(连接字母), -form(…形状的)<br>围绕“线”这一核心含义构成, 表示“线状的” |
| filial<br><br>adj. 子女的; 孝道的; 孝顺的 | **fil(子女)**, -ial(…的)<br>与子女身份或孝道有关的 |


### fin

终结, 界限

| 单词 | 拆解 |
| --- | --- |
| define<br><br>v. 限定; 给⋯⋯下定义 | de-(一再等加强意义), **fin(终结, 界限)**, e(连接字母)<br>四周加以界限 |
| finish<br><br>n. 结束; 终点; 抛光面<br>v. 完成; 结束 | **fin(终结, 界限)**, -ish(…的)<br>围绕“终结”这一核心含义构成, 表示“结束, 完毕” |
| affinity<br><br>n. 密切关系; 类似; 吸引力 | af-(到, 朝, 向), **fin(终结, 界限)**, -ity(性质, 状态)<br>全部朝终点靠拢 |
| confinement<br><br>n. 限制; 界限; 监禁; 拘留 | confine(词: 限制), -ment(行为, 过程)<br>在前词基础上加“-ment”构成名词, 表示“限制” |
| finality<br><br>n. 终结; 决定性; 定局 | final(词: 期末考试), -ity(性质, 状态)<br>由“期末考试”派生为当前词义 |
| finance<br><br>v. 为……提供资金 | **fin(终结, 界限)**, -ance(性质, 状态)<br>原指结清款项、结束债务, 后来发展为财政、金融 |
| financier<br><br>n. 财政家; 金融家 | finance→financ(词: 财政), -ier(人)<br>在前词基础上加“-ier”构成名词, 表示“财政家” |
| infinitive<br><br>adj. 不定式的<br>n. 不定式 | in-(无, 不, 非), **fin(终结, 界限)**, -itive(…的)<br>否定或缺少“终结”所指的性质, 因此表示“(动词)不定式” |
| infinity<br><br>n. 无限; 大量; 无穷大 | in-(无, 不, 非), **fin(终结, 界限)**, -ity(性质, 状态)<br>否定或缺少“限制”所指的性质, 因此表示“无限, 大量” |
| definite<br><br>adj. 限定的; 肯定的; 明确的; 确切的 | de-(一再等加强意义), **fin(终结, 界限)**, -ite(…的)<br>界限完全明确的, 即确定的 |
| final<br><br>adj. 末尾的; 最后的 | **fin(终结, 界限)**, -al(…的)<br>表示与“终结”有关或具有该特征, 即“末尾的” |
| finite<br><br>adj. 有限的; 有穷的; 限定的 | 源自拉丁语 finitus“有边界的、有限的”<br>与 fin“界限”同源, 记忆为有明确界限的 |
| infinite<br><br>adj. 无限的; 极大的 | in-(无, 不, 非), finite(词: 有限的)<br>没有边界或终点的, 即无限的 |
| unconfined<br><br>adj. 无限制的; 无拘束的; 自由自在的 | un-(无, 不, 非), con-(与, 共同), **fin(终结, 界限)**, -ed(…的)<br>否定或缺少“限制”所指的性质, 因此表示“无限制的” |


### firm

坚固, 结实

| 单词 | 拆解 |
| --- | --- |
| affirm<br><br>v. 断言; 肯定; 坚持声称; 证实 | af-(到, 朝, 向), **firm(坚固, 结实)**<br>把说法确立得坚固可靠, 因此表示断言、肯定 |
| confirm<br><br>v. 肯定; 证实; 确保; 巩固 | con-(与, 共同), **firm(坚固, 结实)**<br>使“结实”共同结合或发挥作用, 因此表示“确认, 证实” |
| affirmance<br><br>n. 断言; 证实 | affirm(词: 断言), -ance(性质, 状态)<br>在前词基础上加“-ance”构成名词, 表示“断言” |
| confirmation<br><br>n. 确认; 证实 | confirm(词: 确认), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“确认” |
| firm<br><br>n. 公司; 商行<br>adj. 坚固的; 稳固的; 坚定的; 坚决的<br>v. (使)坚实<br>adv. 稳固地 | **firm(坚固, 结实)**<br>表示坚实、稳定; “公司”义来自商业名称的历史转化 |
| firmness<br><br>n. 坚固; 稳固 | **firm(坚固, 结实)**, -ness(性质, 状态)<br>在前词基础上加“-ness”构成名词, 表示“坚固” |
| infirmity<br><br>n. 虚弱; 疾病; 懦弱; 弱点 | infirm(词: 虚弱的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“虚弱” |
| affirmative<br><br>adj. 肯定的 | 经古法语借自晚期拉丁语 affirmativus“肯定的”<br>与 affirm“断言、肯定”相连 |
| confirmatory<br><br>adj. 起确定作用的; 证实的 | confirm(词: 确定), -atory(…的)<br>在前词基础上加“-atory”构成形容词, 表示“起确定作用的” |
| infirm<br><br>adj. 虚弱的; (意志) 薄弱的 | in-(无, 不, 非), **firm(坚固, 结实)**<br>不坚固、缺少力量, 因此表示虚弱的、意志薄弱的 |


### fisc

国库

| 单词 | 拆解 |
| --- | --- |
| confiscate<br><br>v. 没收; 把...充公; 查抄<br>adj. 被没收的 | con-(与, 共同), **fisc(国库)**, -ate(做, 使)<br>收入国库 |
| fiscal<br><br>adj. 财政的; 国库的; 会计的 | **fisc(国库)**, -al(…的)<br>与国家财政或公共资金相关的 |


### flag, flam

燃烧, 火焰

| 单词 | 拆解 |
| --- | --- |
| inflame<br><br>v. 使激动; 使愤怒 | in-(向内, 进入), **flam(燃烧, 火焰)**, e(连接字母)<br>使内部像燃烧一样发炎, 也可引申为激怒 |
| flame<br><br>n. 火焰; 热情<br>v. 燃烧; 泛红 | **flam(燃烧, 火焰)**, e(连接字母)<br>表示燃烧产生的火焰, 并可转化作动词 |
| inflammable<br><br>adj. 易燃的; 易怒的 | in-(向内, 进入), **flamm(燃烧, 火焰)**, -able(可…的)<br>容易进入燃烧状态的, 即易燃的 |
| inflammation<br><br>n. 点火; 燃烧; 激动 | inflame→inflamm(词: 燃烧, 发炎), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“点火” |
| flagrant<br><br>adj. 罪恶昭彰的; 公然的 | 源自拉丁语 flagrans“燃烧的”<br>像火焰一样显眼, 引申为公然恶劣的 |
| flaming<br><br>adj. 燃烧的; 火焰般的; 火红的; 激情的 | **flam(燃烧, 火焰)**, -ing(…的)<br>正在燃烧或像火焰一样炽烈、鲜红的 |
| flammable<br><br>adj. 易燃的 | **flam(燃烧, 火焰)**, m(连接字母), -able(可…的)<br>由“燃烧”与“提醒”共同限定词义, 表示“易燃的” |
| inflammatory<br><br>adj. 使激怒的; 煽动性的 | inflame→inflamm(词: 燃烧, 发炎), -atory(…的)<br>会引起炎症或激化情绪的 |


### flat

吹

| 单词 | 拆解 |
| --- | --- |
| deflate<br><br>v. 使缩小; 使瘪下去; 紧缩(通货) | de-(脱离, 取消, 除去), **flat(吹)**, e(连接字母)<br>放气 |
| flatter<br><br>v. 奉承; 讨好; 向……谄媚 | 经古法语 flater 进入英语, 可能带有抚平、取悦的意象<br>表示用赞美讨好他人 |
| inflate<br><br>n. 膨胀; 充气 | in-(向内, 进入), **flat(吹)**, e(连接字母)<br>吹入气体 |
| conflation<br><br>n. 合并; 合成 | con-(与, 共同), **flat(吹)**, -ion(行为, 结果)<br>吹到一起 |
| deflation<br><br>n. 放气; 缩小; 紧缩通货; 通货紧缩 | de-(脱离, 取消, 除去), **flat(吹)**, -ion(行为, 结果)<br>把空气放出使体积缩小, 后也指物价水平下降 |
| flattery<br><br>n. 奉承; 捧场; 恭维话; 谄媚的举动 | flatter(词: 奉承), -y(活动)<br>在前词基础上加“-y”构成名词, 表示“奉承” |
| flatulence<br><br>n. 肠胃气胀; 浮夸; 夸大; 自负 | **flat(吹)**, -ulence(性质, 状态)<br>围绕“吹”这一核心含义构成, 表示“肠胃气胀” |
| flatus<br><br>n. 肠胃内的气体; 肠胃胀气; 气息; 一阵风 | **flat(吹)**, -us(名词词尾)<br>围绕“吹”这一核心含义构成, 表示“肠胃内的气体” |
| inflation<br><br>n. 充气; 膨胀; 通货膨胀 | in-(向内, 进入), **flat(吹)**, -ion(行为, 结果)<br>向内部吹气使体积膨胀, 引申为通货膨胀 |
| inflator<br><br>n. 充气者; 充气机; 打气筒 | 词形来源：inflater |
| deflationary<br><br>adj. 紧缩通货的 | deflation(词: 通货紧缩), -ary(…的)<br>在前词基础上加“-ary”构成形容词, 表示“紧缩通货的” |
| flatulent<br><br>adj. 肠胃气胀的; 浮夸的; 自负的 | **flat(吹)**, -ulent(多…的, 充满…的)<br>在前词基础上加“-ulent”构成形容词, 表示“肠胃气胀的” |
| inflatable<br><br>adj. 可充气的; 可膨胀的 | in-(向内, 进入), **flat(吹)**, -able(可…的)<br>能够吹入空气使其膨胀, 因此表示可充气的 |


### flect, flex

弯曲

| 单词 | 拆解 |
| --- | --- |
| deflect<br><br>v. 偏斜; 倒转; 使偏离; （使）偏转; 转移 | de-(下降, 降低), **flect(弯曲)**<br>由“使…变成”与“弯曲”共同限定词义, 表示“使偏斜” |
| inflect<br><br>v. 弯曲; 使向内变曲; 使屈折 | in-(向内, 进入), **flect(弯曲)**<br>以“弯曲”为语义核心构成, 表示“弯曲” |
| deflection<br><br>n. 偏斜; 偏转 | deflect(词: 偏斜), -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“偏斜” |
| deflector<br><br>n. 偏导器; 致偏板; 偏转仪 | deflect(词: 转移), -or(物)<br>由“转移”派生为当前词义 |
| flexor<br><br>n. [解] 肌 | **flex(弯曲)**, -or(物)<br>使关节弯曲的肌肉 |
| flexure<br><br>n. 弯曲; 挠曲; 折褶 | **flex(弯曲)**, -ure(行为, 结果)<br>围绕“弯曲”这一核心含义构成, 表示“弯曲, 挠曲” |
| flexible<br><br>adj. 可弯曲的; 灵活的; 易变通的 | **flex(弯曲)**, -ible(可…的)<br>可以弯曲的, 即"灵活的" |


### flict

打击

| 单词 | 拆解 |
| --- | --- |
| afflict<br><br>v. 折磨; 使痛苦 | af-(到, 朝, 向), **flict(打击)**<br>像遭到持续打击一样承受痛苦, 因此表示折磨、使痛苦 |
| inflict<br><br>v. 予以打击; 使遭受痛苦; 加刑; 处罚 | in-(向内, 进入), **flict(打击)**<br>给以打击 |
| affliction<br><br>n. 苦恼; 折磨; 苦事 | afflict(词: 使苦恼), -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“苦恼” |
| conflict<br><br>n. 冲突; 矛盾<br>v. 冲突; 抵触 | con-(与, 共同), **flict(打击)**<br>相互打击 |
| infliction<br><br>n. 使受痛苦; 处罚 | inflict(词: 加), -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“使受痛苦” |


### flor(i), flour

花

| 单词 | 拆解 |
| --- | --- |
| flourish<br><br>v. 茂盛; 繁荣; 兴旺; 茁壮成长; 挥舞<br>n. 挥舞; 炫耀性动作; 花饰 | **flour(花)**, -ish(做, 使)<br>像花朵盛开一样蓬勃发展, 即繁荣; 也引申为挥舞或装饰性花饰 |
| defloration<br><br>n. 摘花; 采花 | de-(脱离, 取消, 除去), **flor(花)**, -ation(行为, 结果)<br>把花摘下; 也可比喻夺去贞洁, 因此表示采花、破处 |
| efflorescence<br><br>n. 开花 (期) | 源自拉丁语 efflorescere“开花”<br>开花或晶体在表面析出的过程 |
| Flora<br><br>n. (某地区的)植物群; n （尤指某一地区的）植物群 | 直接采用拉丁语 Flora（罗马花神名）, 后来用作某地区全部植物的总称 |
| floret<br><br>n. 小花 | **flor(花)**, -et(小)<br>围绕“花”这一核心含义构成, 表示“小花” |
| floriculture<br><br>n. 养花; 花卉栽培; 花艺 | **flori(花)**, **cult(耕作, 培养)**, -ure(行为, 结果)<br>由“花”与“栽培”共同限定词义, 表示“养花, 花卉栽培, 花艺” |
| florilegium<br><br>n. 选集; 作品集锦; 花谱; 群芳谱 | 源自拉丁语 flos“花”与 legere“采集、选择”<br>原指采花集锦, 后引申为作品选集 |
| floral<br><br>adj. 花的; 如花的 | **flor(花)**, -al(…的)<br>表示与“花”有关或具有该特征, 即“花的” |
| florid<br><br>adj. 如花的; 鲜艳的; 华丽的 | **flor(花)**, -id(…的)<br>围绕“花”这一核心含义构成, 表示“如花的, 鲜艳的, 华丽的” |


### flu, flux

流

| 单词 | 拆解 |
| --- | --- |
| fluctuate<br><br>v. 波动, 起伏 | 源自拉丁语 fluctuare（像波浪般起伏）, 核心 fluctus 意为波浪 |
| flush<br><br>n. 脸红; 一阵强烈情感; 冲(马桶); 同花的一手牌<br>v. 冲洗; 冲走; 发红; 脸红<br>adj. 富有的; 有钱的; 完全齐平的 | 中古英语已有此词, 早期有“突然飞出、涌出”之义<br>后来发展出冲洗、泛红和齐平等义 |
| influence<br><br>n. 影响; 作用<br>v. 影响; 感动 | in-(向内, 进入), **flu(流)**, -ence(性质, 状态)<br>原指某种力量像液体流入并改变事物, 后来表示影响 |
| affluence<br><br>n. 富裕; 丰富 | af-(到, 朝, 向), **flu(流)**, -ence(性质, 状态)<br>财富不断流入并积聚, 由此表示富裕、丰富 |
| confluence<br><br>n. 合流; 汇合; 合流点; 汇合处; 汇流而成的河 | con-(与, 共同), **flu(流)**, -ence(性质, 状态)<br>使“流”共同结合或发挥作用, 因此表示“合流, 汇合” |
| conflux<br><br>n. 共流; 合流; 汇合; 汇合处 | con-(与, 共同), **flux(流)**<br>使“流”共同结合或发挥作用, 因此表示“共流, 合流, 汇合” |
| efflux<br><br>n. 流出; 散发; 流出物; (时间的)消逝; 满期 | ef-(出, 向外), **flux(流)**<br>液体、气体等向外流出的过程, 即流出、散发 |
| fluency<br><br>n. 流利; 流畅 | **flu(流)**, -ency(性质, 状态)<br>围绕“流”这一核心含义构成, 表示“流利, 流畅” |
| fluid<br><br>n. 流体; 液体<br>adj. 流动的; 不固定的; 流畅的 | **flu(流)**, -id(…的)<br>围绕“流”这一核心含义构成, 表示“流动的, 流体的, 液体的” |
| fluidity<br><br>n. 流动性; 流度 | fluid(词: 流动的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“流动性” |
| influx<br><br>n. 流入; 注入; 涌进 | in-(向内, 进入), **flux(流)**<br>由“进入”与“流”共同限定词义, 表示“流入, 注入” |
| reflux<br><br>n. 倒流; 逆流; 回流; 退潮 | re-(回, 向后, 再次), **flux(流)**<br>液体向后回流, 因此表示倒流、反流 |
| superfluity<br><br>n. 过剩; 多余; 奢侈 | super-(超), **flu(流)**, -ity(性质, 状态)<br>多得像流溢到所需数量之外, 因此表示过剩、多余 |
| effluent<br><br>adj. 流出的; 发出的 | ef-(出, 向外), **flu(流)**, -ent(…的)<br>从系统中向外流出的物质, 因此表示流出物、废水或流出的 |
| influential<br><br>adj. 有影响力的 | 与 influence“流入、影响”同源<br>能够对他人或事件产生影响的 |
| superfluous<br><br>adj. 多余的 | super-(超), **flu(流)**, -ous(…的)<br>多得向上溢流、超过需要, 因此表示多余的 |


### foli

叶

| 单词 | 拆解 |
| --- | --- |
| foliate<br><br>v. 生叶; 把...打成箔; 涂箔于<br>adj. 有叶的; 叶状的 | **foli(叶)**, -ate(做, 使)<br>围绕“叶”这一核心含义构成, 表示“生叶” |
| defoliant<br><br>n. 脱叶剂; 落叶剂 | 由 de“去除”与 foliage“叶”相关词干构成<br>使植物脱叶的药剂 |
| foliage<br><br>n. 簇叶; [总称] 叶子 | **foli(叶)**, -age(总称, 集合)<br>叶子的总称, 即"叶子" |
| folio<br><br>n. 对折纸; 对开本 | 源自拉丁语 folium（叶、纸页）, 表示一张对折纸页及由其形成的开本 |
| portfolio<br><br>n. 公文夹; 文件夹; 公事包 | 源自意大利语 portafoglio（携带纸页的套子）, 由“携带”与“纸页”形成, 后引申为作品集或投资组合 |
| foliar<br><br>adj. 叶(状)的 | **foli(叶)**, -ar(…的)<br>围绕“叶”这一核心含义构成, 表示“叶(状)的” |


### forc, fort

力量, 强壮

| 单词 | 拆解 |
| --- | --- |
| enforce<br><br>v. 强迫; 实施; 加强; 强制执行; 迫使 | en-(进入, 包围), force(词: 力量)<br>把力量施加进去, 使规则得到执行 |
| reinforce<br><br>v. 加强; 加固; 强化 | re-(回, 向后, 再次), in-(向内, 进入), **forc(力量, 强壮)**, e(连接字母)<br>再次把力量加进去, 即加强或增援 |
| effort<br><br>n. 努力 | ef-(出, 向外), **fort(力量, 强壮)**<br>把自身力量向外使出, 因此表示努力、力气 |
| enforcement<br><br>n. 强迫; 执行; 厉行 | enforce(词: 强制执行), -ment(行为, 过程)<br>使法律或规则得到执行的行为 |
| fortification<br><br>n. 筑堡; 设防; 防御工事; 防御区; 设防阵地 | **fort(力量, 强壮)**, i(连接字母), -fication(…化, 做…)<br>围绕“力量”这一核心含义构成, 表示“筑堡” |
| fortitude<br><br>n. 坚忍; 刚毅 | **fort(力量, 强壮)**, -itude(性质, 状态)<br>围绕“力量”这一核心含义构成, 表示“坚忍, 刚毅” |
| reinforcement<br><br>n. 加强; 增援; 加固 | reinforce(词: 加强), -ment(行为, 过程)<br>在前词基础上加“-ment”构成名词, 表示“加强” |
| effortless<br><br>adj. 不作努力的; 不卖力的; 不费力的 | effort(词: 努力), -less(无…的, 不…的)<br>在前词基础上加“-less”构成形容词, 表示“不作努力的” |
| forceful<br><br>adj. 强有力的; 坚强的 | **forc(力量, 强壮)**, e(连接字母), -ful(充满…的)<br>围绕“力量”这一核心含义构成, 表示“强有力的” |
| forcible<br><br>adj. 强迫的; 用暴力的 | **forc(力量, 强壮)**, -ible(可…的)<br>围绕“强壮”这一核心含义构成, 表示“强迫的” |


### form

形状, 形式

| 单词 | 拆解 |
| --- | --- |
| conform<br><br>v. 遵守; 符合; 顺从 | con-(与, 共同), **form(形状, 形式)**<br>使形状或行为与共同标准一致, 即遵从 |
| deform<br><br>v. 使变形 | 由 de“使离开正常状态”与 form“形状”构成<br>使形状变坏或扭曲 |
| reform<br><br>n. 改革; 改良<br>v. 改革; 改造 | re-(回, 向后, 再次), **form(形状, 形式)**<br>重新形成更好的制度或行为, 即改革 |
| transform<br><br>v. 使改观; 使变形; 使改变形态 | trans-(横过, 越过; 转变, 变换), **form(形状, 形式)**<br>跨越原有形式而改变, 即转变 |
| formalism<br><br>n. 形式主义; 拘泥形式 | formal(词: 形式), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“形式主义” |
| formalist<br><br>n. 形式主义者; 拘泥形式的人 | formal(词: 形式), -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“形式主义者” |
| formality<br><br>n. 例行公事; 正式手续; 遵守礼节 | formal(词: 形式的), -ity(性质, 状态)<br>遵循正式形式的状态或做法, 即正式手续、礼节或例行公事 |
| formation<br><br>n. 形成; 构成; 组成物; 结构; 编队 | **form(形状, 形式)**, -ation(行为, 结果)<br>形成某种形状或结构的过程 |
| former<br><br>n. 模型; 创造者; 线圈架; 〈英〉公学及其他中等学校的学生<br>adj. (两者中)前者的; 前; 以前的; 昔日的 pron.(两者中的)前者<br>pron. 前者 | 由 fore“前面、先前”形成的比较形式<br>表示时间上较早的、以前的 |
| formal<br><br>adj. 外形的; 形态的; 形式 (上) 的 | form(词: 形状), -al(…的)<br>由“形状”派生为当前词义 |
| informal<br><br>adj. 非正式的; 不拘礼仪的 | 由 in“非、不”与 formal“正式的”构成<br>非正式的 |
| transformational<br><br>adj. 改变的; 变形的 | transform(词: 改变), -ation(行为, 结果), -al(…的)<br>在前词基础上加“-ation”、“-al”构成形容词, 表示“改变的” |


### found, fund

底部, 基础

| 单词 | 拆解 |
| --- | --- |
| found<br><br>v. 创立; 创办; 创建 | **found(底部, 基础)**<br>围绕“底部”这一核心含义构成, 表示“创立, 创办, 创建” |
| foundation<br><br>n. 基础; 基金会; 根据; [复]地基 | **found(底部, 基础)**, -ation(行为, 结果)<br>打下底部基础的行为, 即"地基, 基础" |
| fund<br><br>n. 基金; 专款; 储备; [复]资金<br>v. ……提供资金; 资助 | **fund(底部, 基础)**<br>原义与基础、底部有关, 后引申为作为事业基础的资金 |
| fundamental<br><br>adj. 基本的; 重要的; 原音的<br>n. 基本原理; 原则; 基波 | 源自拉丁语 fundamentum“基础”形成的晚期拉丁语 fundamentalis<br>构成事物基础的, 即基本的; 名词化后指基本原理 |
| profound<br><br>adj. 深刻的; 渊博的; 深远的 | pro-(向前, 前进), **found(底部, 基础)**<br>深到底部 |


### fract, frag

碎, 打破

| 单词 | 拆解 |
| --- | --- |
| refract<br><br>v. 使折射 | re-(回, 向后, 再次), **fract(碎, 打破)**<br>使光线折回 |
| fraction<br><br>n. 分数; 小部分; 片断 | **fract(碎, 打破)**, -ion(行为, 结果)<br>被打碎分开的一部分, 即"部分" |
| fracture<br><br>n. 骨折; 断裂<br>v. 破裂; 折断 | **fract(碎, 打破)**, -ure(行为, 结果)<br>围绕“打破”这一核心含义构成, 表示“(使)断裂, 折断, 破裂” |
| fragility<br><br>n. 脆弱; 脆性; 易碎性 | **frag(碎, 打破)**, -ility(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“脆弱” |
| fragment<br><br>n. 碎片; 破片; 碎块<br>v. 破碎 | **frag(碎, 打破)**, -ment(物)<br>整体破碎后形成的一小块, 即碎片; 也可转化作动词 |
| frailty<br><br>n. 脆弱; 虚弱; 意志薄弱; 弱点 | frail(词: 脆弱的), -ty(性质, 状态)<br>在前词基础上加“-ty”构成名词, 表示“脆弱” |
| infraction<br><br>n. 犯规; 违法 | in-(无, 不, 非), **fract(碎, 打破)**, -ion(行为, 结果)<br>打破法律或规则的行为, 因此表示违法、犯规 |
| suffrage<br><br>n. 投票; 赞成 | suf-(在下, 向下), **frag(碎, 打破)**, e(连接字母)<br>古人以破瓦片投票选举 |
| fractional<br><br>adj. 部分的; 碎片的; 零碎的; 小数的 | fraction(词: 部分), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“部分的” |
| fragile<br><br>adj. 易碎的; 脆弱的; 娇柔的; 虚弱的 | **frag(碎, 打破)**, -ile(…的)<br>容易破碎的性质, 即"脆弱的" |
| frail<br><br>adj. 脆弱的; 易损的; 虚弱的 | 经古法语借自拉丁语 fragilis“易碎的”, 与 fragile 同源<br>由易碎引申为身体虚弱的 |
| refractive<br><br>adj. 折射的; 有折射力的 | refract(词: 使折射), -ive(…的)<br>在前词基础上加“-ive”构成形容词, 表示“折射的” |


### frater, fratr

兄弟

| 单词 | 拆解 |
| --- | --- |
| confraternity<br><br>n. 社团; 团体; 协会; 公会 | con-(与, 共同), **frater(兄弟)**, n(连接字母), -ity(性质, 状态)<br>共同结为兄弟 |
| fraternity<br><br>n. 友爱; 兄弟会; 互助会; 大学生联 谊会 | **fratern(兄弟)**, -ity(性质, 状态)<br>由兄弟关系引申为友爱或大学兄弟会组织 |
| fratricide<br><br>n. 杀兄弟(或姊妹)的行为; 杀兄弟(或姊妹)的人 | **fratr(兄弟)**, i(连接字母), **cid(切, 杀)**, e(连接字母)<br>由“兄弟”与“杀”共同限定词义, 表示“杀兄弟(或姊妹)的行为” |
| fraternal<br><br>adj. 兄弟的; 兄弟般的; 友好的 | **fratern(兄弟)**, -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“兄弟的” |


### frig

寒冷

| 单词 | 拆解 |
| --- | --- |
| refrigerate<br><br>v. 使冷; 冷冻 | re-(一再等加强意义), **frig(寒冷)**, -er(物), -ate(做, 使)<br>在前词基础上加“-ate”构成动词, 表示“使冷” |
| frigidity<br><br>n. 寒冷; 冷淡 | frigid(词: 寒冷的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“寒冷” |
| refrigerant<br><br>adj. 冷冻的; 冷却的; 清凉的<br>n. 清凉剂; 冷却剂; 冷冻剂 | refrigerate→refriger(词: 制冷), -ant(…的)<br>在制冷系统中传递热量的制冷剂 |
| refrigeration<br><br>n. 冷冻(法或作用); 冷却; 致冷(作用) | re-(一再等加强意义), **frig(寒冷)**, -er(物), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“冷冻” |
| refrigerator<br><br>n. (电)冰箱; 冷冻机; 冷藏库; 制冰机 | refrigerate→refrigerat(词: 冷却), -or(物)<br>持续冷却并保存食物的设备 |
| frigid<br><br>adj. 寒冷的 | **frig(寒冷)**, -id(…的)<br>围绕“寒冷”这一核心含义构成, 表示“寒冷的” |


### fruct(i), frug, fruit

享用, 利用; 果实, 收获

| 单词 | 拆解 |
| --- | --- |
| fructose<br><br>n. 〔化〕果糖; 左旋糖 | **fruct(果实, 收获)**, -ose(糖)<br>围绕“果实”这一核心含义构成, 表示“化〕果糖” |
| fruition<br><br>n. 享用; 享受; 结果实 | **fruit(享用, 利用)**, -ion(行为, 结果)<br>享用成果的过程, 引申为愿望实现、取得成果 |
| fruitful<br><br>adj. 果实结得多的; 多产的 | **fruit(果实, 收获)**, -ful(充满…的)<br>围绕“果实”这一核心含义构成, 表示“果实结得多的” |
| fruitless<br><br>adj. 不结果实的; 无效的; 无益的 | **fruit(果实, 收获)**, -less(无…的, 不…的)<br>围绕“果实”这一核心含义构成, 表示“不结果实的” |
| fruity<br><br>adj. 果味的 | **fruit(果实, 收获)**, -y(充满…的, 有…特征的, 像…的)<br>围绕“果实”这一核心含义构成, 表示“果味的” |


### fug

逃, 散

| 单词 | 拆解 |
| --- | --- |
| fugacity<br><br>n. 易逸性 | **fug(逃, 散)**, -acity(性质, 状态)<br>在前词基础上加“-acity”构成名词, 表示“易逸性” |
| fugitive<br><br>adj. 逃亡的; 短暂的<br>n. 逃亡者; 逃犯 | **fug(逃, 散)**, -itive(…的)<br>四处逃散躲避之人, 即"逃亡者" |
| subterfuge<br><br>n. 借口; 托词 | 源自拉丁语 subterfugere“逃避”<br>用表面理由掩盖真实意图, 以逃避正面应对, 即托词、借口或诡计 |
| centrifugal<br><br>adj. 离心的 | **centr(中心)**, i(连接字母), **fug(逃, 散)**, -al(…的)<br>由“中心”与“逃”共同限定词义, 表示“离心的” |


### fus

流, 倾注; 熔化

| 单词 | 拆解 |
| --- | --- |
| confuse<br><br>v. 使困惑; 混淆; 弄错 | co(n)-(与, 共同), **fus(流, 倾注; 熔化)**<br>把不同事物倒在一起混合, 引申为使思绪混乱、混淆 |
| diffuse<br><br>v. 扩散; 传播; 散布<br>adj. 弥漫的; 冗长的 | dif-(分开, 分离), **fus(流, 倾注; 熔化)**<br>向四周各个方向流淌散开, 即扩散或散布 |
