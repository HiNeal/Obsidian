## oyword-root-h


### habit

居住

| 单词 | 拆解 |
| --- | --- |
| cohabit<br><br>v. (男女) 同居; 姘居 | co-(与, 共同), **habit(居住)**<br>使“居住”共同结合或发挥作用, 因此表示“(男女) 同居, 姘居” |
| inhabit<br><br>v. 在某处定居; 繁殖; 居住于 | in-(向内, 进入), **habit(居住)**<br>进入其中居住, 即"定居" |
| cohabitation<br><br>n. 同居 | cohabit(词: 同居), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“同居” |
| habit<br><br>n. 习惯; 习性 | 源自拉丁语 habitus“状态、举止”, 与 habere“持有”相关<br>由经常保持的状态发展为习惯 |
| habitat<br><br>n. 栖息地; 产地; 住处; 聚集处; （动植物的）生活环境 | 直接来自拉丁语 habitat（它居住）, 后来指生物居住的环境 |
| habitation<br><br>n. 居住; 住处; 聚居地 | **habit(居住)**, -ation(行为, 结果)<br>围绕“居住”这一核心含义构成, 表示“居住, 住处” |
| habitude<br><br>n. 习俗; 习惯; 性情; 气质 | 源自法语 habitude（习惯、惯常状态）, 与 habit 同源; 记忆锚点为长期形成的习惯状态 |
| habitus<br><br>n. 习惯; 习性; 体质 | 源自拉丁语 habitus（状态、习性）, 记忆锚点为长期养成并体现在身体和行为中的习性 |
| inhabitant<br><br>n. 居民; 住户; 常住居民; 栖居的动物 | in-(向内, 进入), **habit(居住)**, -ant(人; 物)<br>居住在某地之内的人 |
| habitable<br><br>adj. 可居住的; 适于居住的 | **habit(居住)**, -able(可…的)<br>围绕“居住”这一核心含义构成, 表示“可居住的” |
| habitual<br><br>adj. 习惯的; 惯常的 | habit(词: 习惯), u(连接字母), -al(…的)<br>具有习惯特征的, 即惯常的 |


### hagi(o)

神圣, 圣徒

| 单词 | 拆解 |
| --- | --- |
| hagiography<br><br>n. 圣徒传记 | **hagi(o)(神圣, 圣徒)**, **graph(写, 画)**, -y(活动)<br>原指记录基督教圣徒生平的宗教传记, 引申为过于盲目吹捧赞扬的传记作品 |
| hagiology<br><br>n. 圣徒言行录; 圣徒学 | **hagi(o)(神圣, 圣徒)**, -logy(…学, …研究)<br>记录并研究圣徒生平与神圣事迹的学问 |


### hal

呼吸; 盐, 卤

| 单词 | 拆解 |
| --- | --- |
| exhale<br><br>v. 呼出; 呼气 | 源自拉丁语 exhalare（向外呼吸）, 表示呼出气体 |
| inhale<br><br>v. 吸入; 吸气 | 仿照 exhale 构成, 结合表示向内的 in- 与拉丁语 halare（呼吸）, 表示吸入 |
| exhalation<br><br>n. 呼气 | ex-(出, 向外), **hal(呼吸)**, -ation(行为, 结果)<br>把气息向外呼出的过程, 即呼气 |
| halitosis<br><br>n. 口臭 | 源自拉丁语 halitus“呼气”加表示病理状态的 -osis 形成<br>呼出的气味异常, 即口臭 |
| inhalant<br><br>n. 被吸入的东西(指药剂等) | in-(向内, 进入), **hal(呼吸)**, -ant(人; 物)<br>通过呼吸吸入体内的药剂或物质 |
| inhalation<br><br>n. 吸入; 吸入药剂 | inhale→inhal(词: 吸入), -ation(行为, 结果)<br>由“吸入”派生为当前词义 |


### hal(o)

呼吸; 盐, 卤

| 单词 | 拆解 |
| --- | --- |
| exhale<br><br>v. 呼出; 呼气; 散发 | ex-(出, 向外), **hal(o)(呼吸; 盐, 卤)**<br>将体内气体向外呼出 |
| inhale<br><br>v. 吸入; 吸气 | in-(向内, 进入), **hal(o)(呼吸; 盐, 卤)**<br>将空气或气体向肺部深处吸入 |


### hap

运气, 偶然

| 单词 | 拆解 |
| --- | --- |
| happen<br><br>v. 发生; 出现; 碰巧 | **hap(运气, 偶然)**, p(连接字母), -en(做, 使)<br>围绕“偶发”这一核心含义构成, 表示“(偶然)发生” |
| hap<br><br>n. 偶然; 机会; 运气<br>v. 偶然发生 | **hap(运气, 偶然)**<br>表示偶然发生的事情、机会或运气 |
| haphazard<br><br>n. 偶然性; 偶然事件<br>adj. 无计划的; 偶然的; 随便的<br>adv. 偶然地 | hap(词: 偶然), hazard(词: 风险)<br>由偶然与风险合成, 表示无计划、任意的 |
| mishap<br><br>n. 小灾难 | mis-(坏, 错误), **hap(运气, 偶然)**<br>不好的偶然事件, 即不幸、灾祸 |
| hapless<br><br>adj. 不幸的; 运气不好的 | **hap(运气, 偶然)**, -less(无…的, 不…的)<br>围绕“机会”这一核心含义构成, 表示“不幸的” |
| happy<br><br>adj. 幸福的; 幸运的 | **hap(运气, 偶然)**, p(连接字母), -y(充满…的, 有…特征的, 像…的)<br>围绕“机会”这一核心含义构成, 表示“幸福的” |
| haply<br><br>adv. 偶然地; 侥幸地; 或许 | **hap(运气, 偶然)**, -ly(…地)<br>围绕“偶发”这一核心含义构成, 表示“偶然地, 侥幸地” |
| perhaps<br><br>adv. 或许; 可能; 多半 | per-(通过, 贯穿), **hap(运气, 偶然)**, s(连接字母)<br>碰运气 |


### hard

强, 硬

| 单词 | 拆解 |
| --- | --- |
| harden<br><br>v. 变硬; 变坚固; 使变硬 | **hard(强, 硬)**, -en(做, 使)<br>围绕“硬”这一核心含义构成, 表示“变硬,变坚固” |
| hardener<br><br>n. 硬化剂 | **hard(强, 硬)**, -en(做, 使), -er(物)<br>使材料硬化的添加剂 |
| hardening<br><br>n. 硬化; 硬化剂 | **hard(强, 硬)**, -en(做, 使), -ing(物)<br>在前词基础上加“-ing”构成名词, 表示“硬化” |
| hardihood<br><br>n. 大胆; 刚毅; 鲁莽; 勇气; 胆子 | **hard(强, 硬)**, i(连接字母), -hood(性质, 状态)<br>表示与“强”有关的性质或状态, 即“大胆,刚毅” |
| hardiness<br><br>n. 强壮; 耐劳(性); 勇气; 胆子 | hardy→hardi(词: 难的), -ness(性质, 状态)<br>由“难的”派生为当前词义 |
| hardship<br><br>n. 苦难; 受苦 | hard(词: 艰难的), -ship(性质, 状态)<br>艰难的处境或经历, 即苦难 |
| hardware<br><br>n. 五金器具; (计算机)硬件 | **hard(强, 硬)**, ware(词: 器具)<br>原指坚硬的金属器具, 后来也指计算机实体设备, 即硬件 |
| hardy<br><br>adj. 强壮的; 耐劳的 | **hard(强, 硬)**, -y(充满…的, 有…特征的, 像…的)<br>围绕“强”这一核心含义构成, 表示“强壮的” |
| hardly<br><br>adv. 严厉地; 粗鲁地; 艰辛地; 费力地 | **hard(强, 硬)**, -ly(…地)<br>围绕“强”这一核心含义构成, 表示“严厉地,粗鲁地” |


### harmon

和谐, 和声

| 单词 | 拆解 |
| --- | --- |
| harmonize<br><br>v. 使协调; 使和谐 | **harmon(和谐, 和声)**, -ize(…化, 使成)<br>围绕“和谐”这一核心含义构成, 表示“使协调, 使和谐” |
| harmonica<br><br>n. 口琴 | 由 harmonic（和声的）形成的乐器名称, 因能奏出和声而得名 |
| harmonics<br><br>n. 和声学 | **harmon(和谐, 和声)**, -ics(…学)<br>在前词基础上加“-ics”构成名词, 表示“和声学” |
| harmonium<br><br>n. 簧风琴 | 源自 harmony“和声”形成的乐器名<br>表示以簧片发声、用于和声演奏的簧风琴 |
| harmony<br><br>n. 融洽; 和睦; 和声; 和谐; 协调 | **harmon(和谐, 和声)**, -y(性质, 状态)<br>围绕“和谐”这一核心含义构成, 表示“融洽, 和睦” |
| harmonic<br><br>adj. 和睦的; 融洽的; 和声的; 悦耳的 | **harmon(和谐, 和声)**, -ic(…的)<br>表示与“和谐”有关或具有该特征, 即“和睦的, 融洽的” |
| harmonious<br><br>adj. 协调的; 和谐的; 和睦的; 融洽的; 悦耳的 | **harmon(和谐, 和声)**, -ious(…的)<br>表示与“和谐”有关或具有该特征, 即“协调的, 和谐的” |


### hav

有, 持有

| 单词 | 拆解 |
| --- | --- |
| have<br><br>v. 有 | **hav(有, 持有)**, e(连接字母)<br>围绕“有”这一核心含义构成, 表示“有” |
| heave<br><br>v. 挺举; 升起 | 以“用力向上举”的动作画面记忆; 再引申为用力拉动或上下起伏 |
| behavior<br><br>n. 行为; 举止 | 由 behave“表现、举止”仿照 demeanour 等名词形成<br>一个人的表现方式, 即行为 |
| haven<br><br>n. 避难所; 安全地方 | **hav(有, 持有)**, -en(做, 使)<br>有救的地方 |
| having<br><br>n. 所有物; [常用复] 财产 | **hav(有, 持有)**, -ing(物)<br>所持有的东西, 常用复数表示财产 |


### head

头

| 单词 | 拆解 |
| --- | --- |
| headache<br><br>n. 头痛 | **head(头)**, ache(词: 疼痛)<br>头部的疼痛, 也可比喻棘手问题 |
| heading<br><br>n. 航向; 标题; 题词; 信头; 主题 | **head(头)**, -ing(物)<br>位于文字头部的内容即标题; 也可指朝向前方的航向 |
| headline<br><br>n. 大字标题; [复] 新闻提要 | **head(头)**, line(词: 排成一行)<br>位于新闻最前端的一行大字, 即标题、新闻提要 |
| headquarters<br><br>n. 指挥部; 总部; 总公司; [复] 司令部 | head(词: 主要的), quarters(词: 驻地)<br>主要驻地, 即总部 |
| headway<br><br>n. 前进; 进展 | head(词: 前端), way(词: 行进)<br>向前行进, 引申为取得进展 |
| headstrong<br><br>adj. 顽固的; 任性的 | **head(头)**, strong(词: 坚固的)<br>头脑和意志过分强硬、不肯转向, 因此表示顽固的、任性的 |
| overhead<br><br>n. 经常开支; 普通用费; 天花板<br>adj. 在头上的; 高架的<br>adv. 在头顶上; 在空中; 在高处 | over-(在上), **head(头)**<br>由“在上”与“头”共同限定词义, 表示“在头顶上” |
| ahead<br><br>adv. 在前; 向前; 提前 | a-(在..., ...的), **head(头)**<br>本义为“在头部、在前方”, 由此表示向前或提前 |


### hedron

面体

| 单词 | 拆解 |
| --- | --- |
| polyhedron<br><br>n. 多面体 | poly-(多, 复), **hedron(面体)**<br>由“多”与“面体”共同限定词义, 表示“多面体” |
| tetrahedron<br><br>n. 四面体 | tetra-(四), **hedron(面体)**<br>由四个平面围成的几何体 |


### hedral

面体

| 单词 | 拆解 |
| --- | --- |
| polyhedron<br><br>n. 多面体 | poly-(多, 复), **hedron(面体)**<br>由“多”与“面体”共同限定词义, 表示“多面体” |
| polyhedral<br><br>adj. 多面体的; 多面的 | poly-(多), **hedral(面体)**<br>具有多个平面的几何形态 |


### heir, hered, herit

继承

| 单词 | 拆解 |
| --- | --- |
| inherit<br><br>v. 继承; 经遗传获得(品质; 身体特征等) | in-(向内, 进入), **herit(继承)**<br>依法取得继承物, 因此表示继承; 其中 in- 不是否定义 |
| heir<br><br>n. 继承人; 后嗣 | **heir(继承)**<br>继承财产、职位或传统的人 |
| heredity<br><br>n. 遗传 | **hered(继承)**, -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“遗传” |
| heritage<br><br>n. 遗产; 继承物 | 源自古法语 heritage“继承物”, 与 heir“继承人”同源<br>从前人继承下来的财产或文化, 即遗产 |
| hereditary<br><br>adj. 世袭的; 遗传的 | 源自拉丁语 hereditarius“继承的”<br>由继承引申为遗传的、世袭的 |
| heritable<br><br>adj. 可继承的; 可遗传的 | **herit(继承)**, -able(可…的)<br>围绕“继承”这一核心含义构成, 表示“可继承的” |


### heli(o)

太阳

| 单词 | 拆解 |
| --- | --- |
| aphelion<br><br>n. 远日点 | 源自希腊语 apo“远离”与 hēlios“太阳”<br>行星轨道上距离太阳最远的点 |
| perihelion<br><br>n. 近日点 | 源自希腊语 peri“近旁、周围”与 hēlios“太阳”<br>行星轨道上距离太阳最近的点 |
| heliocentric<br><br>adj. 日心的; 以日心测量的 | **helio(太阳)**, **centr(中心)**, -ic(…的)<br>由“太阳”与“中心”共同限定词义, 表示“以太阳为中心的” |


### helic(o)

螺旋

| 单词 | 拆解 |
| --- | --- |
| helicity<br><br>n. 螺旋性 | **helic(螺旋)**, -ity(性质, 状态)<br>表示与“螺旋”有关的性质或状态, 即“螺旋性” |
| helicopter<br><br>n. 直升飞机; 直升机<br>v. 用直升机载送; 乘直升机旅行 | **helico(螺旋)**, **pter(翼, 翅)**<br>靠旋转的翼片升空飞行的航空器, 即直升机 |
| helipad<br><br>n. 直升飞机场 | 由 helicopter 截短为 heli, 再与 pad“起降平台”合成<br>直升机起降平台 |
| helix<br><br>n. 螺旋(形) | 直接借自希腊语 helix“螺旋、卷曲物”<br>指三维螺旋形结构 |
| helical<br><br>adj. 螺旋形的; 螺旋(线)的 | **helic(螺旋)**, -al(…的)<br>围绕“螺旋”这一核心含义构成, 表示“螺旋形的” |


### hend, hens

抓住, 包含

| 单词 | 拆解 |
| --- | --- |
| apprehend<br><br>v. 理解; 领悟; 逮捕; 拘押 | ap-(到, 朝, 向), pre-(先于, 预先), **hend(抓住, 包含)**<br>在心中把事物抓住即理解; 把人抓住则表示逮捕 |
| comprehend<br><br>v. 了解; 领悟; 包含; 包括; 理解 | com-(与, 共同), pre-(先于, 预先), **hend(抓住, 包含)**<br>事先将其完全把握抓牢, 即"理解" |
| apprehension<br><br>n. 忧虑; 挂念; 理解; 逮捕 | ap-(到, 朝, 向), pre-(先于, 预先), **hens(抓住, 包含)**, -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“理解” |
| comprehensibility<br><br>n. 理解力 | com-(与, 共同), pre-(先于, 预先), **hens(抓住, 包含)**, -ibility(可…性)<br>内容能够被完整抓住并理解的程度, 即可理解性 |
| apprehensive<br><br>adj. 有理解力的; 善领会的; 聪明的; 担心的 | ap-(到, 朝, 向), pre-(先于, 预先), **hens(抓住, 包含)**, -ive(…的)<br>在前词基础上加“-ive”构成形容词, 表示“有理解力的” |
| comprehensive<br><br>adj. 广泛的; 综合的; 包含内容多的; 有理解力的 | comprehend→comprehens(词: 包含; 理解), -ive(…的)<br>能够广泛包含各部分的, 即全面的 |


### hepat(o)

肝

| 单词 | 拆解 |
| --- | --- |
| hepatitis<br><br>n. 肝炎 | **hepat(肝)**, -itis(…炎)<br>“肝”发生炎症, 即“肝炎” |
| hepatic<br><br>adj. 肝的; 肝状的; 肝色的 | **hepat(肝)**, -ic(…的)<br>围绕“肝”这一核心含义构成, 表示“肝的” |


### her, hes

粘着, 附着

| 单词 | 拆解 |
| --- | --- |
| adhere<br><br>v. 遵守; 附着 | ad-(到, 朝, 向), **her(粘着, 附着)**, e(连接字母)<br>紧贴到另一表面并不脱离, 因此表示黏附、坚持 |
| hesitate<br><br>v. 犹豫不决; 踌躇; 顾虑 | 源自拉丁语 haesitare“粘住、迟疑”<br>像行动被粘住一样停顿不决, 即犹豫 |
| inhere<br><br>v. 生来即存在于; 本质上即属于; 原来就有 | in-(向内, 进入), **her(粘着, 附着)**, e(连接字母)<br>固有地附着在事物内部, 即内在、固有 |
| adhesion<br><br>n. 黏着; 黏合; 附着 | ad-(到, 朝, 向), **hes(粘着, 附着)**, -ion(行为, 结果)<br>两个表面黏附到一起的状态, 即黏着、附着力 |
| adhesiveness<br><br>n. 附着性; 黏着力 | adhesive(词: 粘着的), -ness(性质, 状态)<br>由“粘着的”派生为当前词义 |
| coherence<br><br>n. 黏着; 黏合性; 连贯 | co-(与, 共同), **her(粘着, 附着)**, -ence(性质, 状态)<br>使“粘着”共同结合或发挥作用, 因此表示“黏着” |
| hesitancy<br><br>n. 踌躇; 犹豫 | hesitate→hesit(词: 犹豫), -ancy(性质, 状态)<br>行动或判断迟疑不决的状态, 即犹豫 |
| adherent<br><br>adj. 黏着的; 附着的 | 经古法语借自拉丁语 adhaerens“黏附着的”<br>由物理黏附引申为拥护者、追随者 |
| hesitant<br><br>adj. 踌躇的; 犹豫的 | 与 hesitate“犹豫”同源, 来自拉丁语 haesitare“黏住、迟疑”<br>像被黏住一样迟迟不决 |
| incoherent<br><br>adj. 不连贯的; 无条理的 | in-(无, 不, 非), co-(与, 共同), **her(粘着, 附着)**, -ent(…的)<br>黏不在一起的 |
| inherent<br><br>adj. 固有的; 内在的 | in-(向内, 进入), **her(粘着, 附着)**, -ent(…的)<br>牢固附着在事物内部的, 即固有的 |


### heter(o)

异, 其他

| 单词 | 拆解 |
| --- | --- |
| heterodoxy<br><br>n. 违反公认标准; 异教; 异端 | **hetero(异, 其他)**, **dox(观点)**, -y(活动)<br>持有不同于正统的观点, 因此表示异端、非正统观点 |
| heterogeneity<br><br>n. 异质性; 不均匀性; 多相性; 不纯一性 | **hetero(异, 其他)**, **gene(族, 种类)**, -ity(性质, 状态)<br>由不同种类构成的状态, 即异质性 |
| heterosexuality<br><br>n. 异性爱 | heterosexual(词: 异性的), -ity(性质, 状态)<br>由“异性的”派生为当前词义 |
| heterosis<br><br>n. 杂种优势 | **heter(异, 其他)**, -osis(状态, 过程)<br>围绕“异”这一核心含义构成, 表示“杂种优势” |


### hibit

持, 握

| 单词 | 拆解 |
| --- | --- |
| exhibit<br><br>v. 展出; 展览; 展示; 陈列 | ex-(出, 向外), **hibit(持, 握)**<br>拿出去给人看 |
| inhibit<br><br>v. 阻止; 禁止; 抑制 | in-(向内, 进入), **hibit(持, 握)**<br>原指向内扣住、阻住, 后来表示抑制、禁止 |
| prohibit<br><br>v. 禁止; 阻止 | pro-(向前, 前进), **hibit(持, 握)**<br>持着东西(如棍棒等)在前面 |
| exhibition<br><br>n. 展览(会); 展示 | ex-(出, 向外), **hibit(持, 握)**, -ion(行为, 结果)<br>把物品拿出来给公众观看的活动, 即展览 |
| exhibitor<br><br>n. 展览会的参加者 | exhibit(词: 展览), -or(人)<br>在前词基础上加“-or”构成名词, 表示“展览会的参加者” |
| inhibition<br><br>n. 阻止; 禁止; 抑制 | inhibit(词: 禁止), -ion(行为, 结果)<br>由“禁止”派生为当前词义 |
| inhibitor<br><br>n. 阻止者; 禁止者; 抑制剂 | inhibit(词: 抑制), -or(物)<br>产生抑制作用的物质或装置 |


### hilar

高兴

| 单词 | 拆解 |
| --- | --- |
| exhilarate<br><br>v. 使高兴; 使兴奋 | ex-(出, 向外), **hilar(高兴)**, -ate(做, 使)<br>把喜悦和活力激发出来, 因此表示使高兴、使兴奋 |
| hilarity<br><br>n. 欢闹; 狂欢 | **hilar(高兴)**, -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“欢闹” |
| exhilarating<br><br>adj. 使人高兴的 | 词形来源：exhilarate + ing-form |
| hilarious<br><br>adj. 欢闹的; 狂欢的 | **hilar(高兴)**, -ious(…的)<br>表示与“高兴”有关或具有该特征, 即“欢闹的, 狂欢的” |


### hipp(o)

马

| 单词 | 拆解 |
| --- | --- |
| hippodrome<br><br>n. 跑马场; 赛马场; 马戏场 | **hippo(马)**, **drom(跑)**, e(连接字母)<br>跑马的地方 |
| hippopotamus<br><br>n. 河马 | **hippo(马)**, **potam(河)**, -us(名词词尾)<br>名称意为‘河中的马’, 即河马; -us 只是名词词尾 |


### holo

全

| 单词 | 拆解 |
| --- | --- |
| hologram<br><br>n. 综合衍射图; 全息图 | **holo(全)**, **gram(书写, 记录)**<br>由“全”与“书写”共同限定词义, 表示“综合衍射图, 全息图” |
| holograph<br><br>n. 亲笔文件<br>adj. 亲笔的 | **holo(全)**, **graph(写, 画)**<br>记录或描绘“全”的方法, 即“亲笔写的” |
| holography<br><br>n. 全息照相术; 全息摄影 | **holo(全)**, **graph(写, 画)**, y(连接字母)<br>记录或描绘“全”的方法, 即“全息照相术, 全息摄影” |


### homo

同, 同一; 人

| 单词 | 拆解 |
| --- | --- |
| homogeneity<br><br>n. 同种; 同质; 同性; 齐性; 均匀 | homo-(相同, 同一), **gene(出生, 产生)**, -ity(性质, 状态)<br>由“相同”与“出生”共同限定词义, 表示“同种, 同质, 同性” |
| homonym<br><br>n. 同音异义词; 同形异义词; 同形同音异义词; 同名的人 (或物) | 由希腊语 homos“相同”与 onyma“名称”构成<br>名称或形式相同而意义不同的词 |
| homosexual<br><br>adj. 同性恋的<br>n. 同性恋者 | homo-(相同, 同一), sex-(六), u(连接字母), -al(…的)<br>由“相同”与“六”共同限定词义, 表示“同性恋的 (人)” |


### hor, horr

怕

| 单词 | 拆解 |
| --- | --- |
| horrify<br><br>v. 使恐怖; 使毛骨悚然 | 源自拉丁语 horrere“毛发竖起”与 facere“使”<br>使人毛骨悚然 |
| horror<br><br>n. 恐惧; 厌恶; 震惊; 对某事物的强烈畏惧(或憎恨) | 源自拉丁语 horror“战栗、恐惧”<br>表示强烈恐惧或令人恐惧的事物 |
| horrendous<br><br>adj. 可怕的 | **horr(怕)**, -end(应被…的), -ous(…的)<br>表示与“怕”有关或具有该特征, 即“可怕的” |
| horrible<br><br>adj. 可怕的; 恐怖的 | **horr(怕)**, -ible(可…的)<br>围绕“怕”这一核心含义构成, 表示“可怕的, 恐怖的” |
| horrid<br><br>adj. 可怕的 | **horr(怕)**, -id(…的)<br>围绕“怕”这一核心含义构成, 表示“可怕的” |
| horrific<br><br>adj. 极其可怕的 | **horr(怕)**, i(连接字母), -fic(造成…的, 产生…的)<br>使人心生恐惧的, 即"可怕的" |


### hospit, host

客人; 敌人

| 单词 | 拆解 |
| --- | --- |
| hospital<br><br>n. 医院 | 源自拉丁语 hospitale“接待客人的住所”<br>由接待旅客的场所发展为收治病人的医院 |
| hospitality<br><br>n. 好客; 殷勤 | **hospit(客人)**, -ality(性质, 状态)<br>围绕“客人”这一核心含义构成, 表示“好客” |
| host<br><br>n. 主人; 主持人; 东道主; 主办方<br>v. 主办; 主持 | **host(客人)**<br>历史上“接待客人的主人”和“客人”共享同一来源, 现代表示主人或主办者 |
| hostage<br><br>n. 人质 | 源自古法语 ostage“担保、被扣留者”, 与 host“接待、留宿”相关<br>为保证履约而被对方扣留的人, 即人质 |
| hostel<br><br>n. 客店; 旅店; 廉价招待所 | **host(客人)**, -el(小)<br>围绕“客人”这一核心含义构成, 表示“廉价招待所” |
| hostess<br><br>n. 女主人 | **host(客人)**, -ess(女性, 雌性)<br>围绕“客人”这一核心含义构成, 表示“女主人” |
| hostile<br><br>adj. 敌对的; 敌意的; 不利的; 反对的<br>n. 敌对者 | **host(敌人)**, -ile(…的)<br>具有敌人般态度的, 即敌对、不友善的 |
| hostility<br><br>n. 敌意; 敌视; 敌对 (状态或行动) | 源自拉丁语 hostilitas, 核心 hostis 表示敌人<br>敌对的状态或行为 |
| hotel<br><br>n. 旅馆 | 经法语 hôtel 借入, 与 hostel 同源, 最终来自拉丁语 hospitale“客舍”<br>供旅客住宿的场所 |
| hotelier<br><br>n. 旅馆老板 | hotel(词: 旅馆), -ier(人)<br>在前词基础上加“-ier”构成名词, 表示“旅馆老板” |
| hospitable<br><br>adj. 好客的; 殷勤的; 招待周到的; 热情友好的 | **hospit(客人)**, -able(可…的)<br>围绕“客人”这一核心含义构成, 表示“好客的” |
| inhospitable<br><br>adj. 不好客的; 不殷勤的 | in-(无, 不, 非), hospitable(词: 好客的)<br>否定或缺少“好客的、殷勤的”所指的性质, 因此表示“不好客的, 不殷勤的” |


### hum

地; 嗡嗡声, 呼呼声

| 单词 | 拆解 |
| --- | --- |
| exhume<br><br>v. 掘出; 发掘 | ex-(出, 向外), **hum(地)**, e(连接字母)<br>把埋在地下的遗体挖出 |
| humiliate<br><br>v. 羞辱 | 源自晚期拉丁语 humiliare“使卑下”, 核心 humilis 表示低<br>使人感到地位被压低, 即羞辱 |
| exhumation<br><br>n. 掘出; 发掘; 掘墓 | ex-(出, 向外), **hum(地)**, -ation(行为, 结果)<br>把埋在地下的遗体挖出的过程 |
| humidifier<br><br>n. 增湿器; 湿润器 | humidify→humidifi(词: 使潮湿), -er(物)<br>由“使潮湿”派生为当前词义 |
| humidity<br><br>n. 湿气; 湿度 | humid(词: 多湿气的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“湿气” |
| humility<br><br>n. 谦卑 | **hum(地)**, -ility(性质, 状态)<br>把自己放在接近地面的低位, 即谦逊 |
| humbug<br><br>n. 骗子; 欺骗; 欺诈<br>v. 欺骗; 哄骗; 行骗 | 18世纪英语中出现, 确切来源未明<br>作为本土口语表示骗局、胡扯或骗子 |
| humdrum<br><br>n. 平凡; 单调; 无聊<br>v. 单调令味地进行<br>adj. 平凡的; 单调的; 令人厌烦的 | 英语本土叠韵构词, 由 hum 与 drum 的押韵组合形成<br>以单调声响联想到乏味平凡 |
| hummer<br><br>n. 用鼻子哼唱的人; 发嗡嗡声的东西; 蜂鸟 | **hum(嗡嗡声, 呼呼声)**, m(连接字母), -er(人)<br>发出嗡鸣声的人; 也可引申指发声物 |
| humble<br><br>adj. 谦虚的; 卑微的 | 源自拉丁语 humilis“低的、接近地面”<br>由位置低发展为谦逊或地位卑微 |
| humid<br><br>adj. 潮湿的; 湿热的 | 源自拉丁语 humidus“潮湿的”<br>表示空气或环境含水汽较多的 |
| posthumous<br><br>adj. 死亡的; 身后的; 遗腹的 | 源自拉丁语 postumus“最后出生的”, 后来受 post humum“埋葬之后”联想影响<br>现代表示在某人死后发生或出版的 |
| humming<br><br>adj. 发嗡嗡声的; 哼着唱的 | **humm(嗡嗡声, 呼呼声)**, -ing(…的)<br>发出持续嗡鸣声或哼唱声的 |


### hydr(o)

水

| 单词 | 拆解 |
| --- | --- |
| dehydration<br><br>n. 脱水 | de-(脱离, 取消, 除去), **hydr(水)**, -ation(行为, 结果)<br>由“脱离”与“水”共同限定词义, 表示“脱水” |
| hydrant<br><br>n. 消防龙头; 给水栓; 取水管 | **hydr(水)**, -ant(人; 物)<br>连接供水系统、用于取水的装置 |
| hydrobiology<br><br>n. 流体生物学 | **hydro(水)**, **bio(生命, 生物)**, -logy(…学, …研究)<br>由“水”与“生物”共同限定词义, 表示“流体生物学” |
| hydrogen<br><br>n. 氢气 | **hydro(水)**, **gen(出生, 产生)**<br>产生水 |
| hydrology<br><br>n. 水文学; 水理学 | **hydro(水)**, -logy(…学, …研究)<br>以“水”为研究对象的学科, 即“水文学, 水理学” |
| hydrometer<br><br>n. (液体) 比重计 | **hydro(水)**, **meter(测量器, 仪表)**<br>测量“水”的仪器或方法, 即“(液体) 比重计” |
| hydrophobia<br><br>n. 恐水病 | **hydro(水)**, **phob(怕, 厌恶)**, -ia(性质, 状态)<br>对“水”产生强烈恐惧或厌恶, 即“恐水病” |
| anhydrous<br><br>adj. 无水的 | an-(无, 不, 非), **hydr(水)**, -ous(…的)<br>否定或缺少“水”所指的性质, 因此表示“无水的” |
| hydrous<br><br>adj. 含水的; 水合的; 水化的; 水状的 | **hydr(水)**, -ous(…的)<br>表示与“水”有关或具有该特征, 即“含水的” |


### hyeto

雨, 下雨

| 单词 | 拆解 |
| --- | --- |
| hyetograph<br><br>n. 每年平均雨量分布图表; 雨量计 | **hyeto(雨, 下雨)**, **graph(写, 画)**<br>记录并绘制某流域暴雨降雨强度随时间变化的图表, 即降雨量过程线图 |
| hyetology<br><br>n. 雨量学; 降水学 | **hyeto(雨, 下雨)**, -logy(…学, …研究)<br>研究降雨规律与降水分布的科学 |


### hygr

湿

| 单词 | 拆解 |
| --- | --- |
| hygrometer<br><br>n. 湿度表 | **hygr(湿)**, o(连接字母), **meter(测量器, 仪表)**<br>测量“湿”的仪器或方法, 即“湿度表” |
| hygroscopic<br><br>adj. 吸湿的; 易吸水分的 | **hygr(湿)**, o(连接元音), **scop(镜, 观察; 目标)**, -ic(…的)<br>对环境湿度起反应并易于吸收空气水分的 |


### hypn(o)

睡眠

| 单词 | 拆解 |
| --- | --- |
| hypnosis<br><br>n. 催眠 (状态); 催眠术 | **hypn(睡眠)**, -osis(状态, 过程)<br>围绕“睡眠”这一核心含义构成, 表示“催眠 (状态)” |
| hypnotherapy<br><br>n. 催眠疗法 | **hypno(睡眠)**, **therapy(治疗, 疗法)**<br>由“睡眠”与“疗法”共同限定词义, 表示“催眠疗法” |
| hypnotism<br><br>n. 催眠状态; 催眠术 (研究) | 由 hypnotic“催眠的”相关词干形成<br>催眠的状态、方法或研究 |


### hypso

高度

| 单词 | 拆解 |
| --- | --- |
| hypsometer<br><br>n. 沸点测高器; 用三角测量法测量树的高度的仪器 | **hypso(高度)**, **meter(测量; 测量器, 仪表)**<br>利用三角测量原理或液体沸点测定山体与林木垂直高度的仪器, 即测高仪 |
| hypsometry<br><br>n. 测高法; 测高学 | **hypso(高度)**, **meter(测量; 测量器, 仪表)**, -y(活动)<br>通过气压或沸点等物理量测定海拔高度的技术与学科 |
