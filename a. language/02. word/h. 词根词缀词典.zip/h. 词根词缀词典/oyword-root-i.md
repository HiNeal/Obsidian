## oyword-root-i


### ichthy(o)

鱼

| 单词 | 拆解 |
| --- | --- |
| ichthyology<br><br>n. 鱼类学 | **ichthyo(鱼)**, -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“鱼类学” |
| ichthyosis<br><br>n. (鱼)鳞癣 | **ichthy(鱼)**, -osis(状态, 过程)<br>皮肤呈鱼鳞状的病症, 因此称为鱼鳞癣 |


### ide(o)

思想, 概念; 形态

| 单词 | 拆解 |
| --- | --- |
| idea<br><br>n. 思想; 概念; 意见; 观念 | 经拉丁语借自希腊语 idea“形态、所见”, 与 idein“看见”相关<br>由心中所见引申为观念 |
| ideal<br><br>adj. 完美的; 理想的1. 理想<br>n. 理想(的); 观念(的) | 由 idea“观念、典型”派生<br>符合心中完美典型的 |
| ideality<br><br>n. 理想; 想象力 | ideal(词: 理想), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“理想” |


### ident

相同

| 单词 | 拆解 |
| --- | --- |
| identical<br><br>adj. 完全相同的; 同一的 | **ident(相同)**, -ical(…的)<br>相同的, 引申强调"完全相同的" |
| identifiable<br><br>adj. 可看做是相同的; 可证明是同一的; 可辨认的 | identify→identifi(词: 识别; 确认), -able(可…的)<br>能够被辨认或确认身份的 |
| identification<br><br>n. 识别; 身份证明; 认同 | 源自 identify（识别、确认身份）形成的名词, 表示识别过程 |
| identify<br><br>v. 使等同于, 认为…一致; 识别, 鉴定 | **ident(相同)**, -ify(…化, 做…)<br>确认某对象与某身份相同, 即识别 |
| identity<br><br>n. 同一(性); 一致 | **ident(相同)**, -ity(性质, 状态)<br>表示与“相同”有关的性质或状态, 即“同一(性)” |


### idio

特殊, 个人

| 单词 | 拆解 |
| --- | --- |
| idiocy<br><br>n. 白痴; 极端愚蠢 | **idio(特殊, 个人)**, -cy(性质, 状态)<br>围绕“特殊的”这一核心含义构成, 表示“白痴” |
| idiom<br><br>n. 成语; 习语; 惯用语; (某时期或某地区的人的)语言和语法 | **idio(特殊, 个人)**, m(连接字母)<br>由个人或某群体独有的表达方式发展为成语、习语、惯用语、方言或语言风格 |
| idiot<br><br>n. 白痴; 笨蛋 | 源自希腊语 idiōtēs“私人、普通人”<br>由不参与公共事务的私人逐渐发展为愚笨者这一贬义 |


### ign

火

| 单词 | 拆解 |
| --- | --- |
| ignite<br><br>v. 点火; 使灼热 | 源自拉丁语 ignis“火”<br>与 ign“火”同源, 表示点燃或引发 |
| ignition<br><br>n. 点火; 着火; 发火装置 | **ign(火)**, -ition(行为, 结果)<br>在前词基础上加“-ition”构成名词, 表示“点火” |
| igneous<br><br>adj. 火的; 似火的 | **ign(火)**, -eous(…的)<br>围绕“火”这一核心含义构成, 表示“火的, 似火的” |
| ignitable<br><br>adj. 可燃的 | ignite→ignit(词: 点燃), -able(可…的)<br>能够被点燃的, 即可燃的 |


### im

相似, 酷似

| 单词 | 拆解 |
| --- | --- |
| imitate<br><br>v. 模仿; 摹拟; 仿制; 伪造; 效仿 | 源自拉丁语 imitari“仿效”<br>表示照着某人或某物的样子做 |
| image<br><br>n. 图像; 肖像; 形象; 映像; 翻版 | 经古法语借自拉丁语 imago“形象、肖像”<br>表示视觉形象或心中表象 |
| imagery<br><br>n. 像; 雕像; 意象; 形象化的描述; 比喻 | 由 image“形象、意象”派生为集合名词<br>表示作品中共同构成画面的意象系统 |
| imitation<br><br>n. 模仿; 摹拟; 仿制; 伪造 | imit(词: 模仿), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“模仿” |
| imitator<br><br>n. 模仿者; 临摹者; 仿造者; 伪造者 | imit(词: 模仿), -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“模仿者” |
| imitative<br><br>adj. 模仿的; 摹拟的; 仿制的; 伪造的 | imit(词: 模仿), -ative(…的)<br>在前词基础上加“-ative”构成形容词, 表示“模仿的” |


### imper

统治, 命令

| 单词 | 拆解 |
| --- | --- |
| imperative<br><br>adj. 必须的; 紧急的; 命令的; 强制的; 专横的<br>n. 当务之急 | **imper(统治, 命令)**, -ative(…的)<br>围绕“统治”这一核心含义构成, 表示“必须的” |
| imperator<br><br>n. 凯旋将军; 皇帝; [拉](古罗马)大将军 | **imper(统治, 命令)**, -ator(人)<br>围绕“统治”这一核心含义构成, 表示“(古罗马)大将军, 凯旋将军” |
| imperialism<br><br>n. 帝国主义 | imperial(词: 帝王的), -ism(主义)<br>由“帝王的”派生为当前词义 |
| imperialist<br><br>n. 帝国主义者 | imperial(词: 帝王的), -ist(人)<br>由“帝王的”派生为当前词义 |
| imperium<br><br>n. 绝对统治; 统治; 主权; [拉] 最高权力 | 源自拉丁语 imperium“命令权、统治权”<br>表示最高统治权或主权 |
| imperial<br><br>adj. 帝国的; 帝制的 | **imper(统治, 命令)**, -ial(…的)<br>与帝国统治或皇权有关的 |
| imperious<br><br>adj. 专横的; 傲慢的; 迫切的 | **imper(统治, 命令)**, -ious(…的)<br>表示与“统治”有关或具有该特征, 即“专横的” |


### insul

岛

| 单词 | 拆解 |
| --- | --- |
| insulate<br><br>v. 隔离; 使孤立; 使绝缘; 使绝热 | **insul(岛)**, -ate(做, 使)<br>使如岛般孤立 |
| isolate<br><br>v. 使隔离; 使分离; 使绝缘; 使孤立; 使脱离 | **isol(岛)**, -ate(做, 使)<br>使成岛状 |
| insular<br><br>n. 岛屿的; 像岛似的; 隔绝的; 思想狭窄的; 保守的 | **insul(岛)**, -ar(…的)<br>围绕“岛”这一核心含义构成, 表示“岛屿的” |
| insularity<br><br>n. 岛国性质; (思想; 观念等的)偏狭性 | insular(词: 岛的), -ity(性质, 状态)<br>由“岛的”派生为当前词义 |
| insulation<br><br>n. 隔离; 孤立; 绝缘; 绝热 | **insul(岛)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“隔离” |
| insulin<br><br>n. 胰岛素 | **insul(岛)**, -in(…素)<br>围绕“岛”这一核心含义构成, 表示“胰岛素” |
| peninsula<br><br>n. 半岛 | pen-(几乎), **insul(岛)**, a(连接字母)<br>和岛相似 |
| peninsular<br><br>adj. 半岛的 | 由 peninsula“半岛”派生; peninsula 源自拉丁语 paene“几乎”与 insula“岛”<br>与半岛有关的 |


### integr

完整

| 单词 | 拆解 |
| --- | --- |
| disintegrate<br><br>v. 使崩溃; 瓦解 | dis-(否定, 相反), **integr(完整)**, -ate(做, 使)<br>使完整整体分离成碎片, 因此表示瓦解、崩溃 |
| integrate<br><br>v. (使)成为一体; (使)合并; （使）成为一体; （使）合并 | **integr(完整)**, -ate(做, 使)<br>使各部分合成完整的一体, 即"整合" |
| disintegration<br><br>n. 崩溃; 溃散; 瓦解; 分裂; 分解 | disintegrate→disintegrat(词: 分解), -ion(行为, 结果)<br>由“分解”派生为当前词义 |
| integral<br><br>adj. 完整的; 必需的<br>n. 积分; 整体 | **integr(完整)**, -al(…的)<br>表示与“完整”有关或具有该特征, 即“构成整体所必需的” |
| integrality<br><br>n. 完整性 | integral(词: 整体), -ity(性质, 状态)<br>由“整体”派生为当前词义 |
| integrity<br><br>n. 完整; 完全; 完善; 诚实; 正直 | **integr(完整)**, -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“完整” |
| integrative<br><br>adj. 综合的; 一体化的 | **integr(完整)**, -ative(…的)<br>在前词基础上加“-ative”构成形容词, 表示“综合的” |


### iod

碘

| 单词 | 拆解 |
| --- | --- |
| iodate<br><br>v. 用碘处理 | **iod(碘)**, -ate(做, 使)<br>围绕“碘”这一核心含义构成, 表示“用碘处理” |
| iodide<br><br>n. 碘化物 | **iod(碘)**, -ide(化合物)<br>围绕“碘”这一核心含义构成, 表示“碘化物” |
| iodine<br><br>n. 碘 | **iod(碘)**, -ine(…的)<br>围绕“碘”这一核心含义构成, 表示“碘” |


### ir, irr

生气

| 单词 | 拆解 |
| --- | --- |
| irritate<br><br>v. 激怒; 使急躁; 刺激 | 源自拉丁语 irritare“刺激、激怒”<br>使人恼怒或使身体组织受到刺激 |
| ire<br><br>n. [诗] 怒火 | ir-(无, 不, 非), e(连接字母)<br>围绕“无”这一核心含义构成, 表示“怒火” |
| irritation<br><br>n. 激怒; 恼怒; 生气; 刺激物 | 与 irritate“刺激、激怒”同源<br>刺激造成的不适或恼怒 |
| irascible<br><br>adj. 易怒的; 性情暴躁的 | 源自拉丁语 irascibilis, 与 ira“愤怒”相关<br>容易发怒的 |
| irate<br><br>adj. 发怒的; 愤怒的; 激怒的 | 源自拉丁语 iratus“发怒的”, 来自 ira“愤怒”<br>非常生气的 |
| irritable<br><br>adj. 易激怒的; 烦躁的 | irritate→irrit(词: 刺激; 激怒), -able(可…的)<br>容易受到刺激或被激怒的 |
| irritating<br><br>adj. 气人的; 使人不愉快的 | 词形来源：irritate + ing-form |


### iso

等, 同

| 单词 | 拆解 |
| --- | --- |
| isobar<br><br>n. 等压线 | **iso(等, 同)**, **bar(o)(重, 压)**<br>气象图上把大气压强相等的各点连结而成的线, 即等压线 |
| isomorphism<br><br>n. 同型性; 同晶型性; [物] [化] (类质) 同晶型 (现象) | 由 iso“相同”与 morph“形态”形成<br>不同物质具有相同结构或形态的现象, 即同型性 |
| isotherm<br><br>n. 等温线; 恒温线 | iso-(相等, 相同), **therm(热)**<br>由“相等”与“温”共同限定词义, 表示“等温线, 恒温线” |
| isostatic<br><br>adj. 均衡的 | iso-(相等, 相同), **stat(静止, 稳定)**, -ic(…的)<br>各部分处于相等而稳定的平衡状态 |


### it

行, 走

| 单词 | 拆解 |
| --- | --- |
| initiation<br><br>n. 开始; 创始 | initiate→initiat(词: 入会), -ion(行为, 结果)<br>由“入会”派生为当前词义 |
| initiative<br><br>adj. 创始的; 初步的<br>n. 倡议; 新方案; 主动性 | in-(无, 不, 非; 向内, 进入), **it(行, 走)**, -iat(…的; 人; 物; 做, 使), -ive(人; 物) |
| itinerary<br><br>adj. 巡回的; 旅程的<br>n. 行程; 旅行计划 | 源自拉丁语 itinerarium（旅行路线）, 核心 iter、itiner- 意为旅程 |
| obituary<br><br>n. 讣告 | 源自中世纪拉丁语 obituarius, 与 obitus“死亡”同源<br>报道某人去世及生平的讣告 |
| initial<br><br>adj. 开始的; 最初的 | 源自拉丁语 initialis（开端的）, 核心 initium 意为开始 |
| itinerant<br><br>adj. 巡回的; 旅行的 | 源自拉丁语 itinerans“旅行的”, 核心 iter 表示旅程<br>四处巡回的 |
