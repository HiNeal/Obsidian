## oyword-root-m


### machin, mechan(o)

机器, 机械

| 单词 | 拆解 |
| --- | --- |
| mechanize<br><br>v. 使机械化; 用机械装备 | **mechan(机器, 机械)**, -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“使机械化” |
| machine<br><br>n. 机器; 机械<br>v. 机加工 | **machin(机器, 机械)**, e(连接字母)<br>围绕“机器”这一核心含义构成, 表示“机器, 机械” |
| machinery<br><br>n. 机械; 机构; [总称] 机器 | 由 machine（机器）派生, -ery 在此形成机器设备的集合义; 记忆锚点是“一整套机器” |
| machinist<br><br>n. 机工; 机械师 | **machin(机器, 机械)**, -ist(人)<br>表示从事或具有“机械”特征的人, 即“机工, 机械师” |
| mechanic<br><br>adj. 手工的; 机械的<br>n. 技工; 机械师 | **mechan(机器, 机械)**, -ic(人)<br>从事机器维修或操作的人, 即机械工 |
| mechanics<br><br>n. 力学; 机械学; 结构; 构成法; 技巧 | **mechan(机器, 机械)**, -ics(…学)<br>以“机械”为研究对象的学科, 即“力学” |
| mechanism<br><br>n. 机械装置; 机构; 机制; 机械论; 构造 | 源自希腊语 mekhane“机器、装置”形成的近代拉丁语 mechanismus<br>由机器内部运作方式发展为机制、方法 |
| machinable<br><br>adj. 可用机器做的 | **machin(机器, 机械)**, -able(可…的)<br>围绕“机器”这一核心含义构成, 表示“可用机器做的” |
| mechanical<br><br>adj. 机械 (制) 的; 用机械的; 机械学的; 机械似的; 呆板的 | **mechan(机器, 机械)**, -ical(…的)<br>与机器或机械运作有关的 |


### magn(i), macr(o)

长, 大

| 单词 | 拆解 |
| --- | --- |
| macroeconomics<br><br>n. 大经济学 | **macro(长, 大)**, economics(词: 经济学)<br>由“大”与“经济学”共同限定词义, 表示“大经济学” |
| macron<br><br>n. 长音符号 | 源自希腊语 makron“长的东西”<br>表示标在元音上方的长音符号 |
| macrophage<br><br>n. 巨噬细胞 | **macro(长, 大)**, **phag(吃, 食)**, e(连接字母)<br>能够吞噬异物的大型细胞, 即巨噬细胞 |
| macroscopic<br><br>adj. 肉眼可见的; 宏观的 | **macro(长, 大)**, **scop(镜, 观察)**, -ic(…的)<br>大到可直接观察, 因此表示肉眼可见的、宏观的 |


### maj, max(i)

大

| 单词 | 拆解 |
| --- | --- |
| magnify<br><br>v. 放大; 增强; 夸大 | **magn(长, 大)**, -ify(…化, 做…)<br>使事物显得或变得更大 |
| magnanimity<br><br>n. 大度; 宽宏大量 | **magn(长, 大)**, **anim(生命; 心意; 精神; 气息)**, -ity(性质, 状态)<br>由“大”与“心灵”共同限定词义, 表示“大度, 宽宏大量” |
| magnate<br><br>n. 大官; 贵人; 阔人 | 构词锚点：magn 表示“长, 大, 宏”; -ate 在此为名词或形容词词尾, 不取动词义<br>围绕“大”这一核心含义构成, 表示“大官” |
| magnification<br><br>n. 放大 (率) | **magni(长, 大)**, -fication(…化, 做…)<br>围绕“大”这一核心含义构成, 表示“放大 (率)” |
| magnifier<br><br>n. 放大者; 放大器; 放大镜 | **magni(长, 大)**, -fier(做…的人或物)<br>围绕“大”这一核心含义构成, 表示“放大者” |
| magnitude<br><br>n. 巨大; 规模; 重要性; 震级; 亮度 | **magn(长, 大)**, -itude(性质, 状态)<br>围绕“大”这一核心含义构成, 表示“巨大, 广大” |
| maxim<br><br>n. 格言 | 经法语借自拉丁语 maxima“最大的命题”<br>被视为普遍成立的格言 |
| maximum<br><br>n. 最大值; 最大限度 | **maxi(大)**, m(连接字母), -um(名词词尾)<br>可达到的最大值或最高限度 |
| majesty<br><br>n. 雄伟; 壮丽; 庄严; 权威; (对君主的尊称)陛下 | **maj(大)**, -est(最…), -y(活动)<br>围绕“大”这一核心含义构成, 表示“威严” |
| major<br><br>n. 主修专业; 专业学生; 少校<br>v. 主修; 专攻<br>adj. 主要的; 重大的 | 源自拉丁语 maior“较大的”<br>表示较大、主要的, 也可转化为专业或军衔名词 |
| majority<br><br>n. 多数; 大多数 | major(词: 较大的; 多数), -ity(性质, 状态)<br>数量较大的部分, 即多数 |
| mayor<br><br>n. 市长 | 经古法语 maire 借自拉丁语 maior“较大的、较高的”<br>指城市中职位最高的行政长官 |
| mayoress<br><br>n. 女市长; 市长夫人 | mayor(词: 市长), -ess(女性, 雌性)<br>在前词基础上加“-ess”构成名词, 表示“女市长” |
| magnanimous<br><br>adj. 大度的; 宽宏大量的 | **magn(长, 大)**, **anim(生命; 心意; 精神; 气息)**, -ous(…的)<br>由“大”与“心灵”共同限定词义, 表示“宽宏大量的” |
| magnificent<br><br>adj. 壮丽的; 宏伟的; 令人印象深刻的 | **magni(长, 大)**, -fic(造成…的, 产生…的), -ent(…的)<br>做得宏大 |
| majestic<br><br>adj. 雄伟的; 壮丽的; 崇高的 | **maj(大)**, -est(最…), -ic(…的)<br>表示与“大”有关或具有该特征, 即“雄伟的, 壮丽的” |
| mayoral<br><br>adj. 市长的 | mayor(词: 市长), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“市长的” |


### mall

铁锤, 木槌

| 单词 | 拆解 |
| --- | --- |
| mallet<br><br>n. 木槌 | **mall(铁锤, 木槌)**, -et(小)<br>词根本身即表示“木槌”, 整词沿用该义 |
| malleus<br><br>n. 锤骨 | **mall(铁锤, 木槌)**, e(连接字母), -us(名词词尾)<br>围绕“铁锤”这一核心含义构成, 表示“锤骨” |
| mamma<br><br>n. 乳房 | 词形来源：mama |
| mammal<br><br>n. 哺乳动物 | **mamm(乳房)**, -al(物)<br>以乳房哺育幼崽的动物, 即哺乳动物 |
| mammalogy<br><br>n. 哺乳动物学 | 由拉丁语 mamma“乳房”与希腊语 logy“研究”构成<br>研究哺乳动物的学科 |
| malleable<br><br>adj. 可锻的; 韧性的; 易适应的 | **mall(铁锤, 木槌)**, e(连接字母), -able(可…的)<br>可用铁锤敲打的 |
| mammalian<br><br>adj. 哺乳动物的 | mammal(词: 哺乳动物), -ian(…的)<br>在前词基础上加“-ian”构成形容词, 表示“哺乳动物的” |
| mammary<br><br>adj. 乳房的 | **mamm(乳房)**, -ary(…的)<br>围绕“乳房”这一核心含义构成, 表示“乳房的” |


### mamm(i), mamm(o)

乳房

| 单词 | 拆解 |
| --- | --- |
| mamma<br><br>n. 乳房 | 词形来源：mama |
| mammal<br><br>n. 哺乳动物 | **mamm(乳房)**, -al(物)<br>以乳房哺育幼崽的动物, 即哺乳动物 |
| mammalian<br><br>adj. 哺乳动物的 | mammal(词: 哺乳动物), -ian(…的)<br>在前词基础上加“-ian”构成形容词, 表示“哺乳动物的” |
| mammalogy<br><br>n. 哺乳动物学 | 由拉丁语 mamma“乳房”与希腊语 logy“研究”构成<br>研究哺乳动物的学科 |
| mammary<br><br>adj. 乳房的 | **mamm(乳房)**, -ary(…的)<br>围绕“乳房”这一核心含义构成, 表示“乳房的” |


### man, main

留, 居住

| 单词 | 拆解 |
| --- | --- |
| remain<br><br>v. 保持; 逗留; 剩余 | re-(回, 向后, 再次), **main(留, 居住)**<br>由“去”与“留”共同限定词义, 表示“留下, 逗留, 继续存在下去, 保持” |
| manor<br><br>n. 庄园; 庄园中的住宅 | 经古法语 manoir“住所、庄园”进入英语<br>指领主庄园及其住宅 |
| mansion<br><br>n. 公馆; 豪宅; 大厦; 宅邸 | **man(留, 居住)**, -sion(行为, 结果)<br>供人长期居住的大型住宅 |
| permanence<br><br>n. 永久 (性); 持久 (性) | per-(通过, 贯穿), **man(留, 居住)**, -ence(性质, 状态)<br>一直停留下去 |
| permanency<br><br>n. 永久 (或持久) 的事物; 永久的职位 | 由 permanent“永久的”派生<br>持久不变的状态 |
| remainder<br><br>n. 留下的人; 余物; 残余; 余数; 剩余部分 | re-(回, 向后, 再次), **main(留, 居住)**, d(连接字母), -er(物)<br>其他部分移走后留下的东西, 即剩余物 |
| remnant<br><br>adj. 剩余的<br>n. 残余部分; 剩余部分; (织物的)零头; 布头 | 经古法语 remenant（剩下的）进入英语, 表示残余部分 |
| manorial<br><br>adj. 庄园的 | manor(词: 庄园), -ial(…的)<br>在前词基础上加“-ial”构成形容词, 表示“庄园的” |
| permanent<br><br>adj. 持久的; 固定的; 不变的; 永久的 | per-(通过, 贯穿), **man(留, 居住)**, -ent(…的)<br>始终停留而不消失或改变, 因此表示永久的、固定的 |
| remanent<br><br>adj. 留下的; 剩余的 | re-(回, 向后, 再次), **man(留, 居住)**, -ent(…的)<br>在其他部分离去后仍留下, 因此表示残留的、剩余的 |


### man(i), man(u)

手

| 单词 | 拆解 |
| --- | --- |
| emancipate<br><br>v. 解放 | e-(出, 向外), **man(手)**, **cip(抓夺)**, -ate(做, 使)<br>使人脱离他人之手的控制, 即解放 |
| maintain<br><br>v. 保持; 维护; 维修 | **main(留, 居住)**, **tain(持, 守)**<br>原指用手握住并保持, 后来表示维持、保养或坚持 |
| manage<br><br>v. 管理; 经营; 处理; 设法; 对付 | 源自意大利语 maneggiare“用手操控”, 核心来自拉丁语 manus“手”<br>由用手驾驭发展为设法处理、管理 |
| manipulate<br><br>v. 操纵; 操作; 巧妙地处理 | 源自拉丁语 manipulus（一把、一小队）, 核心 manus 意为手, 后来表示用手操作或操纵 |
| manufacture<br><br>n. 制造; 制造业<br>v. 制造; 加工 | **manu(手)**, **fact(做)**, -ure(行为, 结果)<br>原指用手制作, 后来泛指工业制造 |
| maintenance<br><br>n. 维护; 保养; 维持; (依法应负担的)生活费; 抚养费 | **main(留, 居住)**, **ten(持, 守)**, -ance(性质, 状态)<br>使事物持续保持原有状态, 因此表示维持、保养 |
| manager<br><br>n. 管理人; 经营者; 经理 | **man(手)**, a(连接字母), **ger(做, 管理)**<br>原指用手驾驭、操控的人, 后来表示经理、管理者 |
| manicurist<br><br>n. 指甲修剪师 | **mani(手)**, **cur(关心, 注意)**, -ist(人)<br>专门护理手和指甲的人 |
| manifesto<br><br>n. 宣言; 政治宣言 | 源自意大利语 manifesto“公开声明”<br>与 manifest“公开表明”直接相关, 表示政治宣言或公开声明 |
| manner<br><br>n. 举止; 礼貌; 方式; 风俗 | 经古法语 maniere“方式、样式”进入英语<br>表示做事方式、态度或种类 |
| manual<br><br>adj. 手工的<br>n. 使用手册, 指南 | **manu(手)**, -al(…的)<br>围绕“手”这一核心含义构成, 表示“手的, 手工做的, 用手的” |
| manumission<br><br>n. 释放; 解放 | **manu(手)**, **miss(投放, 发送)**, -ion(行为, 结果)<br>把受控制者从手中放走, 即释放奴隶 |
| manuscript<br><br>n. 手写本; 手稿; 原稿 | **manu(手)**, **script(写)**<br>由“手”与“写”共同限定词义, 表示“手写本, 手稿, 原稿” |


### mancy, mancer

占卜

| 单词 | 拆解 |
| --- | --- |
| geomancy<br><br>n. 泥土占卜 | **ge(o)(地)**, **mancy(占卜)**<br>古希腊借土地泥纹预测吉凶的泥土占卜, 英语学术界借以指代中国传统风水堪舆学 |
| necromancer<br><br>n. 向亡魂问卜的巫术者; 巫术师; 行妖术者 | **necr(o)(死, 死尸)**, o(连接元音), **mancer(占卜者)**<br>声称能通灵招魂、向亡魂问卜未来的巫术师, 即死灵法师 |
| necromancy<br><br>n. 向亡魂问卜的巫术; 巫术; 妖术 | **necro(死, 死尸)**, **mancy(占卜)**<br>由“死”与“占卜”共同限定词义, 表示“向亡魂问卜的巫术” |


### mand, mend

命令

| 单词 | 拆解 |
| --- | --- |
| command<br><br>n. 命令; 指挥权; 掌握<br>v. 命令; 指挥; 博得 | com-(与, 共同), **mand(命令)**<br>使“命令”共同结合或发挥作用, 因此表示“命令, 指挥” |
| commend<br><br>v. 委托; 嘉奖; 推荐 | com-(与, 共同), **mend(命令)**<br>把某人或某物郑重托付并给予肯定, 因此表示推荐、嘉奖 |
| mandate<br><br>n. 命令; 指令; 要求<br>v. 委任统治 | **mand(命令)**, -ate(做, 使)<br>围绕“命令”这一核心含义构成, 表示“命令, 训令, 委任” |
| commander<br><br>n. 指挥官; 司令官 | com-(与, 共同), **mand(命令)**, -er(人)<br>向群体发出命令并负责指挥的人 |
| demand<br><br>n. 需求; 要求<br>v. 强烈要求; 需要 | de-(一再等加强意义), **mand(命令)**<br>强烈发出命令式要求, 即要求、需要 |
| mandamus<br><br>n. 训令 | 直接来自拉丁语 mandamus“我们命令”<br>法院命令公职人员履行职责的令状 |
| mandatory<br><br>adj. 强制的; 法定的<br>n. 受托人 | **mand(命令)**, -atory(…的)<br>围绕“命令”这一核心含义构成, 表示“命令的, 强制性的, 委托的” |
| recommendation<br><br>n. 推荐; 建议; 劝告 | re-(回, 向后, 再次), com-(与, 共同), **mend(命令)**, -ation(行为, 结果)<br>把某人或方案再次郑重托付给他人考虑, 即推荐、建议 |


### mar(i), mir

海; 惊奇, 惊异

| 单词 | 拆解 |
| --- | --- |
| admire<br><br>v. 赞赏; 羡慕; 赞美; 钦佩; 仰慕 | ad-(到, 朝, 向), **mir(惊奇, 惊异)**, e(连接字母)<br>怀着惊叹看待某人某物, 因此表示赞赏、钦佩 |
| mariculture<br><br>n. 水产物的养殖 | **mari(海)**, **cult(耕作, 培养)**, -ure(行为, 结果)<br>由“海”与“养殖”共同限定词义, 表示“水产物的养殖” |
| mariner<br><br>n. 海员; 水手 | marine→marin(词: 海上的), -er(人)<br>在海上工作的人, 即水手 |
| submarine<br><br>n. 潜水艇; 海底生物<br>v. 用潜水艇攻击; 在下疾行; 在下滑动<br>adj. 海中的; 生长在海中的 | sub-(在下, 向下), **mar(海)**, -ine(…的)<br>由“在下”与“海”共同限定词义, 表示“海面下的, 海底的” |
| admiration<br><br>n. 赞赏; 羡慕; 钦佩 | 源自拉丁语 admiratio“惊奇、赞叹”, 与 admire 同源<br>由惊奇发展为钦佩、赞赏 |
| marvel<br><br>n. 奇迹<br>v. 感到惊讶; 大为赞叹 | 经古法语 merveille 借自拉丁语 mirabilia“奇异之物”<br>指令人惊奇的事物, 也可作动词表示惊叹 |
| miracle<br><br>n. 奇迹 | **mir(惊奇, 惊异)**, -acle(抽象及实物名词)<br>围绕“惊奇”这一核心含义构成, 表示“奇迹” |
| mirage<br><br>n. 奇景; 幻景; 海市蜃楼 | 源自法语 mirage“幻景”, 与 mirer“观看、惊异”相关<br>由空气折射形成的虚像, 即海市蜃楼 |
| mirror<br><br>n. 镜子 | 经古法语 mireor 进入英语, 远源与“观看、惊奇”有关<br>指反射影像的镜子 |
| antisubmarine<br><br>adj. 反潜艇的 | anti-(反对, 相反), sub-(在下, 向下), **mar(海)**, -ine(…的)<br>由“反对”与“在下”与“海”共同限定词义, 表示“反潜艇的” |
| marine<br><br>adj. 海洋的; 海生的; 航海的<br>n. 水兵; 海军陆战队士兵 | **mar(海)**, -ine(…的)<br>表示与“海”有关或具有该特征, 即“海洋的” |
| maritime<br><br>adj. 海的; 海上的; 海事的; 海运的; 近海的 | 源自拉丁语 maritimus“海的”, 核心 mare 表示海<br>表示与海洋、航运有关的 |
| ultramarine<br><br>adj. 海外的; 在海那边的 | ultra-(超过, 超越), **mar(海)**, -ine(…的)<br>由“超过”与“海”共同限定词义, 表示“海外的, 在海那边的” |
| admirable<br><br>adj. 令人赞赏的; 可钦佩的 | ad-(到, 朝, 向), **mir(惊奇, 惊异)**, -able(可…的)<br>能使人感到惊叹并赞赏, 因此表示令人钦佩的 |
| marvelous<br><br>adj. 奇迹(般)的 | marvel(词: 奇异事物), -ous(…的)<br>由“奇异事物”派生为当前词义 |
| miraculous<br><br>adj. 不可思议的; 奇迹般的 | 源自拉丁语 miraculosus“奇迹般的”, 与 miracle 同源<br>像奇迹一样非凡的 |


### mang, mark

记号, 符号; 边界

| 单词 | 拆解 |
| --- | --- |
| margin<br><br>n. 页边的空白; 边缘; 余地; 余裕 | 经法语借自拉丁语 margo“边缘”<br>指页面或区域边缘, 也引申为余量和差额 |
| marginalia<br><br>n. 旁注 | marginal(词: 有旁注的), -ia(性质, 状态)<br>在前词基础上加“-ia”构成名词, 表示“旁注” |
| marker<br><br>n. 标示物; 标识器; 书签 | **mark(符号)**, -er(物)<br>用于标示位置或信息的物品 |
| marking<br><br>n. 打记号; 作标志; 记号; 识别标志 | **mark(符号)**, -ing(行为, 过程)<br>围绕“记号”这一核心含义构成, 表示“打记号, 作标志” |
| material<br><br>n. 材料; 原料; 人才<br>adj. 物质的 | 源自拉丁语 materia“木材、材料”<br>表示构成或制作事物所用的原料 |
| maternity<br><br>n. 母性; 妇产科医院<br>adj. 产妇的; 孕妇的 | **mater(母)**, n(连接字母), -ity(性质, 状态)<br>表示与“母”有关的性质或状态, 即“母性” |
| matriarch<br><br>n. 女家长; 女族长 | **matri(母)**, **arch(统治)**<br>母系家族中居首并统领众人的女性, 即女家长、女族长 |
| matriarchy<br><br>n. 母权制; 母系氏族制 | 由希腊语 mater“母亲”与 archy“统治”构成<br>由女性或母系掌权的制度 |
| matrimony<br><br>n. 婚姻; 结婚 | **matri(母)**, -mony(状态, 结果)<br>围绕“母”这一核心含义构成, 表示“婚姻, 结婚” |
| matrix<br><br>n. 基质; 母体; 策源地; 矩阵; 模型 | 直接借自拉丁语 matrix“母体、孕育处”, 来自 mater“母亲”<br>由孕育其他事物的母体发展为矩阵、基质 |
| matron<br><br>n. 主妇; 老妇 | 源自拉丁语 matrona“已婚妇女、女主人”<br>表示主管家庭或机构的成年女性 |
| metropolis<br><br>n. 大城市; 大都会; 首府 | **metro(母)**, **polis(城市)**<br>母城 |
| metropolitan<br><br>n. 大都市居民<br>adj. 大都市的; 大都会的 | **metro(母)**, **polit(政治)**, -an(…的)<br>原指母城或主教座城, 后来表示大都市的; metro 在此不是现代‘地铁’义 |
| marginal<br><br>adj. 边缘的; 边际的; 有旁注的 | margin(词: 边缘), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“边缘的” |
| marked<br><br>adj. 打上记号的; 有标记的; 显著的 | **mark(符号)**, -ed(…的)<br>围绕“记号”这一核心含义构成, 表示“打上记号的, 有标记的” |
| remarkable<br><br>adj. 卓越的; 引人注目的; 值得注意的; 非凡的 | re-(回, 向后, 再次), **mark(符号)**, -able(可…的)<br>值得反复做记号标注的, 即"值得注意的" |
| maternal<br><br>adj. 母亲的; 母性的; 母系的 | **mater(母)**, n(连接字母), -al(…的)<br>表示与“母”有关或具有该特征, 即“母亲的” |


### mater, matr(i), metr(o)

母

| 单词 | 拆解 |
| --- | --- |
| material<br><br>n. 材料; 原料; 人才<br>adj. 物质的 | 源自拉丁语 materia“木材、材料”<br>表示构成或制作事物所用的原料 |
| maternal<br><br>adj. 母亲的; 母性的; 母系的 | **mater(母)**, n(连接字母), -al(…的)<br>表示与“母”有关或具有该特征, 即“母亲的” |
| maternity<br><br>n. 母性; 妇产科医院<br>adj. 产妇的; 孕妇的 | **mater(母)**, n(连接字母), -ity(性质, 状态)<br>表示与“母”有关的性质或状态, 即“母性” |
| matriarch<br><br>n. 女家长, 女族长 | **matri(母)**, **arch(统治)**<br>母系家族中居首并统领众人的女性, 即女家长、女族长 |
| matriarchy<br><br>n. 母权制, 母系氏族制 | 由希腊语 mater“母亲”与 archy“统治”构成<br>由女性或母系掌权的制度 |
| matrimony<br><br>n. 婚姻, 结婚 | **matri(母)**, -mony(状态, 结果)<br>围绕“母”这一核心含义构成, 表示“婚姻, 结婚” |
| matrix<br><br>n. 基质; 母体; 策源地; 矩阵; 模型 | 直接借自拉丁语 matrix“母体、孕育处”, 来自 mater“母亲”<br>由孕育其他事物的母体发展为矩阵、基质 |
| matron<br><br>n. 主妇, 老妇 | 源自拉丁语 matrona“已婚妇女、女主人”<br>表示主管家庭或机构的成年女性 |
| metropolis<br><br>n. 大城市, 大都会, 首府 | **metro(母)**, **polis(城市)**<br>母城 |
| metropolitan<br><br>n. 大都市居民<br>adj. 大都市的; 大都会的 | **metro(母)**, **polit(政治)**, -an(…的)<br>原指母城或主教座城, 后来表示大都市的; metro 在此不是现代‘地铁’义 |


### meas, mens

测量

| 单词 | 拆解 |
| --- | --- |
| measure<br><br>n. 尺寸; 量度器; 量度标准<br>v. 测量; 测度; 估量 | **meas(测量)**, -ure(行为, 结果)<br>测定大小或数量的行为, 也可指措施 |
| dimension<br><br>n. 尺寸; 程度; 范围; 维（度）; [常用复] 大小<br>v. 标尺寸; 形成...尺寸 | di-(分开, 分离), **mens(测量)**, -ion(行为, 结果)<br>分别量出事物各方向的尺度, 即尺寸、维度 |
| immensity<br><br>n. 广大; 巨大; 无限 | immense→immens(词: 极广大的), -ity(性质, 状态)<br>由“极广大的”派生为当前词义 |
| measurement<br><br>n. 测量; 度量 | measure(词: 测量), -ment(行为, 过程)<br>在前词基础上加“-ment”构成名词, 表示“测量” |
| mensuration<br><br>n. 测定; 测量 | 源自拉丁语 mensuratio“测量”<br>测定长度、面积或体积的过程 |
| immense<br><br>adj. 极大的; 巨大的 | im-(无, 不, 非), **mens(测量)**, e(连接字母)<br>无法测量的 |
| measurable<br><br>adj. 可测量的; 显著的 | measure→measur(词: 测量), -able(可…的)<br>能够被测量或明显达到一定程度的 |


### med(i), mes(o), meri, mid

中间

| 单词 | 拆解 |
| --- | --- |
| intermediate<br><br>n. 中间物; 调停者; 中级<br>v. 起媒介作用<br>adj. 中间的; 中级的 | inter-(在...之间), **medi(中间)**, -ate(做, 使)<br>由“在…之间”与“中间”共同限定词义, 表示“中间的, 居间的” |
| mediation<br><br>n. 居中调停; 调解 | **medi(中间)**, -ation(行为, 结果)<br>围绕“中间”这一核心含义构成, 表示“居中调停, 调解” |
| mediator<br><br>n. 居中人; 调解者; 调停者 | **medi(中间)**, -ator(人)<br>围绕“中间”这一核心含义构成, 表示“居中人” |
| Mediterranean<br><br>adj. 地中海的; 地中海地区的<br>n. 地中海 | 源自拉丁语 medius“中间”与 terra“陆地”<br>意为“陆地之间的海”, 即地中海 |
| medium<br><br>n. 媒介; 中间物<br>adj. 中等的; 中号的 | **medi(中间)**, -um(名词词尾)<br>处在两端中间的事物, 引申为媒介或中等程度 |
| meridian<br><br>n. 子午线; 经线; 顶点<br>adj. 子午线的; 最高点的; 顶点的 | 源自拉丁语 meridianus“正午的”, 由 medius“中间”与 dies“日”相关形式构成<br>太阳正午所在南北线, 即子午线 |
| midday<br><br>n. 日中; 正午; 中午 | **mid(中间)**, day(词: 日)<br>由“中间”与“日”共同限定词义, 表示“日中, 正午” |
| midnight<br><br>n. 午夜; 子夜; 半夜 | **mid(中间)**, night(词: 夜)<br>由“中间”与“夜”共同限定词义, 表示“午夜, 子夜, 半夜” |
| midland<br><br>n. 中部地方; 内地 | mid(词: 中部), land(词: 土地)<br>位于一国中部的地区 |
| midsummer<br><br>n. 盛夏; 仲夏 | **mid(中间)**, summer(词: 过夏天)<br>由“中间”与“夏天”共同限定词义, 表示“盛夏, 仲夏” |
| midway<br><br>n. 中途 | mid(词: 中间), way(词: 路程)<br>位于路程中间, 即中途 |
| immediate<br><br>adj. 立即的; 直接的; 最接近的 | 构词锚点：im 表示“无, 不, 非”; medi 表示“中间”; -ate 在此为形容词词尾, 不取动词义<br>无中间间隙或环节的 |
| medial<br><br>adj. 中间的; 中央的; 居中的 | **medi(中间)**, -al(…的)<br>表示与“中间”有关或具有该特征, 即“中间的, 中央的, 居中的” |
| medieval<br><br>adj. 中古时代的; 中世纪的; 守旧的 | **medi(中间)**, **ev(年龄, 时代)**, -al(…的)<br>处在古代与近代之间时期的, 即中世纪的 |
| mediocre<br><br>adj. 平常的; 普通的 | 源自拉丁语 mediocris（中等高度、普通的）, 表示平庸的 |


### med, medic(o)

治疗, 康复

| 单词 | 拆解 |
| --- | --- |
| medicate<br><br>v. 用药治疗; 加药物于 | **medic(治疗, 康复)**, -ate(做, 使)<br>围绕“医疗”这一核心含义构成, 表示“用药治疗” |
| medicaid<br><br>n. (美国的)医疗补助方案(或项目) | **medic(治疗, 康复)**, aid(词: 援助)<br>由“医疗”与“援助”共同限定词义, 表示“(美国的)医疗补助方案(或项目)” |
| medicament<br><br>n. 药物; 药剂 | 源自拉丁语 medicamentum“药物”, 核心 medicari 表示治疗<br>用于治疗的药剂 |
| medicine<br><br>n. 医学; 医术; 内科学; 内服药(剂); 药 | **medic(治疗, 康复)**, -ine(药物)<br>用于治疗的药物, 并由此指医学或医术 |
| remedy<br><br>n. 药物; 治疗法; 治疗<br>v. 治疗; 补救; 矫正 | 源自拉丁语 remedium“治疗、补救”<br>表示解决问题或治疗疾病的办法 |
| medical<br><br>adj. 医学的; 医术的; 医疗的; 内科的 | **medic(治疗, 康复)**, -al(…的)<br>与医疗、治疗有关的 |
| medico-legal<br><br>adj. 法医学的 | **medico(治疗, 康复)**, **leg(法)**, -al(…的)<br>由“医疗”与“法”共同限定词义, 表示“法医学的” |
| remedial<br><br>adj. 治疗的; 治疗上 (用) 的; 补救的 | 源自拉丁语 remedialis, 与 remedy“补救”同源<br>用于纠正缺陷或治疗的 |


### meg(a)

大, 百万

| 单词 | 拆解 |
| --- | --- |
| megaphone<br><br>n. 扩音器; 大喇叭 | **meg(a)(大, 百万)**, **phon(o)(声音)**<br>用于将声音放大传播的大喇叭装置 |
| megalopolis<br><br>n. 巨大都市; 连绵大都市圈 | **meg(a)(大, 百万)**, **polis, polit(城市)**<br>由多个中心城市连绵构成的庞大都市群 |


### megal(o)

特大

| 单词 | 拆解 |
| --- | --- |
| megalith<br><br>n. 巨石; 大石块 | **mega(大, 百万)**, **lith(石)**<br>由“大”与“石”共同限定词义, 表示“巨石, 大石块” |
| megalomania<br><br>n. 妄自尊大; 夸大狂 | **megalo(特大)**, **mania(狂热, 精神失常)**<br>由“特大”与“狂热”共同限定词义, 表示“妄自尊大” |
| megalopolis<br><br>n. 特大的城市 | **megalo(特大)**, **polis(城市)**<br>由“特大”与“城市”共同限定词义, 表示“特大的城市” |
| megaphone<br><br>n. 扩音器; 大喇叭 | **meg(a)(大, 百万)**, **phon(o)(声音)**, e(连接字母)<br>用于放大声音的手持喇叭筒, 即扩音器 |


### melan(o)

黑

| 单词 | 拆解 |
| --- | --- |
| melancholy<br><br>n. 忧郁; 悲哀<br>adj. 忧郁的; 令人沮丧的 | **melan(o)(黑)**, **chol(e)(胆汁)**, -y(性质, 状态)<br>源于古希腊四体液说中的“黑胆汁”, 认为其过多会导致人陷入忧郁沉重 |
| melanoma<br><br>n. 黑色素瘤 | **melan(o)(黑)**, -oma(肿瘤)<br>由皮肤黑色素细胞发生恶性增殖形成的肿瘤 |


### member, memor, mnus, mnemo

记忆

| 单词 | 拆解 |
| --- | --- |
| commemorate<br><br>v. 纪念 | com-(与, 共同), **memor(记忆)**, -ate(做, 使)<br>让众人共同记住某人某事, 因此表示纪念 |
| amnesia<br><br>n. 记忆缺失; 健忘 | 直接源自希腊语 amnesia“遗忘”<br>核心记忆点是“失去记忆” |
| amnesty<br><br>n. 大赦; 特赦 | 经拉丁语借自希腊语 amnestia“遗忘”<br>把过错视作忘却, 由此表示赦免 |
| commemoration<br><br>n. 纪念; 纪念会; 纪念物 | com-(与, 共同), **memor(记忆)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“纪念” |
| memorandum<br><br>n. 备忘录; 内部通知; 建议书 | 直接采用拉丁语 memorandum（应当记住的事）, 表示备忘录 |
| memorial<br><br>adj. 纪念的<br>n. 纪念馆; 纪念碑 | **memor(记忆)**, -ial(…的)<br>用于保存记忆、纪念某人某事的 |
| memory<br><br>n. 记忆(力); 回忆; 纪念 | **memor(记忆)**, -y(性质, 状态)<br>围绕“记忆”这一核心含义构成, 表示“记忆(力)” |
| mnemonics<br><br>n. 记忆法 | **mnemon(记忆)**, -ics(…学)<br>在前词基础上加“-ics”构成名词, 表示“记忆法” |
| remembrance<br><br>n. 回忆; 记忆(力) | remember→remembr(词: 记得), -ance(性质, 状态)<br>记忆或纪念 |
| commemorative<br><br>adj. 纪念性的 | com-(与, 共同), **memor(记忆)**, -ative(…的)<br>在前词基础上加“-ative”构成形容词, 表示“纪念性的” |
| immemorial<br><br>adj. 无法追忆的; 远古的 | im-(无, 不, 非), **memor(记忆)**, -ial(…的)<br>否定或缺少“记忆”所指的性质, 因此表示“无法追忆的” |
| memorable<br><br>adj. 难忘的; 值得纪念的 | **memor(记忆)**, -able(可…的)<br>围绕“记忆”这一核心含义构成, 表示“难忘的, 值得纪念的” |
| mnemonic<br><br>adj. 记忆的 | **mnemon(记忆)**, -ic(…的)<br>表示与“记忆”有关或具有该特征, 即“记忆的” |


### ment

心智, 思想

| 单词 | 拆解 |
| --- | --- |
| ament<br><br>n. 智力有缺陷者 | 源自拉丁语 amentum“带、绳”<br>因柔荑花序形似垂下的带子而得名 |
| comment<br><br>n. 评论; 意见w评论<br>v. 评论; 评注 | 借自拉丁语 commentum“构想、解释”<br>由解释性文字发展为评论 |
| commentary<br><br>n. 评论; 评注; 批评; 实况报道 | comment(词: 评论), -ary(物)<br>由一系列评论构成的文字, 即评论或评注 |
| commentator<br><br>n. 评论员; 解说员 | comment(词: 评论), -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“评论员” |
| dementia<br><br>n. 痴呆; 智力衰失 | 源自拉丁语 dementia“精神失常”, 由 de“脱离”与 mens“心智”构成<br>心智功能严重衰退 |
| mentality<br><br>n. 心态; 心理; 智力 | mental(词: 心智的), -ity(性质, 状态)<br>由“心智的”派生为当前词义 |
| mentalism<br><br>n. 精神论; 心灵主义 | mental(词: 精神病患者), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“精神论, 心灵主义” |
| mentation<br><br>n. 心理活动; 思想 | 源自拉丁语 mens、ment-（心智）加 -ation, 表示思考或心理活动过程 |
| mention<br><br>n. 提及; 说起<br>v. 提及; 提到 | 源自拉丁语 mentio（提及、提醒）, 表示说到 |
| mentor<br><br>n. 导师; 顾问 | 来自希腊史诗《奥德赛》人物 Mentor 的名字<br>由专名转化为给予经验指导的人 |
| demented<br><br>adj. 失去理智的; 疯狂的 | dement(词: 使发狂), -ed(…的)<br>由“使发狂”派生为当前词义 |
| mental<br><br>adj. 智力的; 精神的; 思想的; 内心的; 思想上的 | 源自拉丁语 mens、ment-（心智）形成, 表示心智的、精神的 |


### merc

商业

| 单词 | 拆解 |
| --- | --- |
| commercialize<br><br>v. 使商业化; 使商品化 | commercial(词: 商品化的), -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“使商业化, 使商品化” |
| merchandise<br><br>v. 买卖; 促销<br>n. 商品; 货物 | 经古法语 marchandise（商品、商业）进入英语, 表示货物 |
| commerce<br><br>n. 贸易; 商业 | com-(与, 共同), **merc(商业)**, e(连接字母)<br>使“商业”共同结合或发挥作用, 因此表示“商业” |
| commercial<br><br>adj. 商业的; 商务的; 已商用量产的; 市售的<br>n. 商业广告 | com-(与, 共同), **merc(商业)**, -ial(…的)<br>与商业相关的, 即"商业的" |
| commercialism<br><br>n. 商业主义; 利润第一主义 | commercial(词: 商业广告节目), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“商业主义” |
| mercantilism<br><br>n. 重商主义; 商业理论; 商业活动; 商界习俗; 商用术语 | mercantile→mercantil(词: 商业的), -ism(主义)<br>由“商业的”派生为当前词义 |
| mercenary<br><br>adj. 为钱而工作的; 被雇的; 图利的<br>n. 唯利是图者; 雇佣兵 | **merc(商业)**, -en(做, 使), -ary(…的)<br>围绕“商业”这一核心含义构成, 表示“为钱的, 惟利是图的, 贪财的, 雇佣的” |
| merchant<br><br>n. 商人; 商贩<br>adj. 商业的 | **merc(商业)**, h(连接字母), -ant(人; 物)<br>从事商业的人, 即商人 |
| mercy<br><br>n. 仁慈; 宽容; 怜悯 | 经古法语 merci 进入英语, 原有恩惠、宽恕之义<br>表示对处于弱势者的怜悯或宽容 |
| mercantile<br><br>adj. 商业的; 贸易的; 商人的; 重商主义的 | **merc(商业)**, -ant(…的), -ile(…的)<br>围绕“商业”这一核心含义构成, 表示“商业的, 贸易的, 商人的” |
| merciful<br><br>adj. 宽大的; 仁慈的; 慈悲的 | mercy→merci(词: 仁慈), -ful(充满…的)<br>内心充满仁慈和怜悯的 |


### merg, mers

沉, 浸

| 单词 | 拆解 |
| --- | --- |
| emerge<br><br>v. (从隐蔽处或暗处)浮现; 出现; 露出; 摆脱出来; 暴露 | e-(出, 向外), **merg(沉, 浸)**, e(连接字母)<br>从沉浸之处向外浮现, 即"出现, 露出" |
| merge<br><br>v. 合并; 吞没 | **merg(沉, 浸)**, e(连接字母)<br>围绕“沉”这一核心含义构成, 表示“合并” |
| submerge<br><br>v. 沉没; 使…淹没; 把…浸入 | sub-(在下, 向下), **merg(沉, 浸)**, e(连接字母)<br>由“在下”与“沉”共同限定词义, 表示“沉没, 使…淹没, 把…浸入” |
| emergence<br><br>n. 浮现; 出现; 显现 | e-(出, 向外), **merg(沉, 浸)**, -ence(性质, 状态)<br>从被遮蔽或沉没的状态中出来, 因此表示出现、显现 |
| emergency<br><br>n. 突然出现的情况; 突然事件; 紧急情况; 急疗; 紧急事件<br>adj. 应急的 | e-(出, 向外), **merg(沉, 浸)**, -ency(性质, 状态)<br>突然浮现、必须立即处理的情况, 即紧急情况 |
| immersion<br><br>n. 沉浸; 浸没 | 源自拉丁语 immersio, 与 immerse“浸入”同源<br>浸没; 引申为全身心投入 |
| merger<br><br>n. 合并; 归并 | 由 merge“合并”派生为过程或结果名词<br>表示企业、组织等的合并 |
| submersion<br><br>n. 沉没; 浸没 | 源自拉丁语 submersio, 与 submerge“沉到下面”同源<br>浸没或沉入水下 |
| demersal<br><br>adj. 居于水底的 | de-(下降, 降低), **mers(沉, 浸)**, -al(…的)<br>沉到水底并生活在底层, 因此表示底栖的 |
| emergent<br><br>adj. 浮现的; 突然出现的; 紧急的; 意外的 | 源自拉丁语 emergens“浮现的”, 与 emerge 同源<br>正在出现、突现的 |
| submersed<br><br>adj. 在水下的; 生于水下的 | sub-(在下, 向下), **mers(沉, 浸)**, -ed(…的)<br>由“在下”与“沉”共同限定词义, 表示“在水下的” |


### meter

测量; 测量器, 仪表

| 单词 | 拆解 |
| --- | --- |
| geometry<br><br>n. 几何形状; 几何图形; 几何(学); 几何结构 | **geo(地)**, **metr(测量)**, -y(活动)<br>原指测量土地, 后来发展为研究空间形状的几何学 |
| meter<br><br>n. 米; 公尺 | 测量长度单位<br>作为测量长度的标准单位, 因此表示米、公尺 |
| metrology<br><br>n. 计量学; 度量衡学 | 源自希腊语 metron“尺度、测量”与 -logy“研究”<br>表示研究测量单位和方法的计量学 |
| micrometer<br><br>n. 测微计 | **micro(微, 小)**, **meter(测量器, 仪表)**<br>测量“微”的仪器或方法, 即“测微计” |
| symmetry<br><br>n. 对称 (性) | 经拉丁语借自希腊语 symmetria, 由 syn“共同”与 metron“尺度”构成<br>各部分尺度相称, 即对称 |
| trigonometry<br><br>n. 三角 (学) | tri-(三, 三次), **gon(角)**, o(连接元音), **metr(测量)**, -y(活动)<br>测量“三、角”的仪器或方法, 即“三角 (学)” |
| microbiology<br><br>n. 微生物学 | **micro(微, 小)**, **bio(生命, 生物)**, -logy(…学, …研究)<br>以“微、生物”为研究对象的学科, 即“微生物学” |
| microcosm<br><br>n. 微观世界; 微观宇宙; 小天地; 小世界 | **micro(微, 小)**, **cosm(世界, 宇宙)**<br>由“微”与“世界”共同限定词义, 表示“微观世界, 微观宇宙” |
| microphone<br><br>n. 扩音器; 麦克风; 话筒 | **micro(微, 小)**, **phon(声音)**, e(连接字母)<br>把微小声音放大 |
| microscope<br><br>n. 显微镜 | **micro(微, 小)**, **scop(镜, 观察)**, e(连接字母)<br>由“微”与“镜”共同限定词义, 表示“显微镜” |
| symmetrical<br><br>adj. 对称的 | 源自 symmetry“共同尺度、对称”派生为形容词<br>表示两侧或各部分在尺度和排列上相称的 |
| trigonometric<br><br>adj. 三角学的; 三角法的 | 由 trigon“ 三角形”与表示“测量”的 -metric 结合<br>表示与三角测量或三角函数有关的 |
| microbial<br><br>adj. 微生物的 | microbe→microb(词: 微生物), -ial(…的)<br>由“微生物”派生为当前词义 |


### micro

微, 小

| 单词 | 拆解 |
| --- | --- |
| microbial<br><br>adj. 微生物的 | microbe→microb(词: 微生物), -ial(…的)<br>由“微生物”派生为当前词义 |
| microbiology<br><br>n. 微生物学 | **micro(微, 小)**, **bio(生命, 生物)**, -logy(…学, …研究)<br>以“微、生物”为研究对象的学科, 即“微生物学” |
| microcosm<br><br>n. 微观世界, 微观宇宙 | **micro(微, 小)**, **cosm(世界, 宇宙)**<br>由“微”与“世界”共同限定词义, 表示“微观世界, 微观宇宙” |
| micrometer<br><br>n. 测微计 | **micro(微, 小)**, **meter(测量器, 仪表)**<br>测量“微”的仪器或方法, 即“测微计” |
| microphone<br><br>n. 扩音器; 麦克风; 话筒 | **micro(微, 小)**, **phon(声音)**, e(连接字母)<br>把微小声音放大 |
| microscope<br><br>n. 显微镜 | **micro(微, 小)**, **scop(镜, 观察)**, e(连接字母)<br>由“微”与“镜”共同限定词义, 表示“显微镜” |


### migr

迁移

| 单词 | 拆解 |
| --- | --- |
| emigrate<br><br>v. 移居 (外国); 移出; 移居国外 | e-(出, 向外), **migr(迁移)**, -ate(做, 使)<br>由“向外”与“迁移”共同限定词义, 表示“移居国外” |
| immigrate<br><br>v. (从外国) 移来; 移居入境; （从外地）移居; 移入 | im-(向内, 进入), **migr(迁移)**, -ate(做, 使)<br>迁入另一个国家长期居住 |
| emigrant<br><br>n. 移民; 侨民<br>adj. 移民的; 移居的 | e-(出, 向外), **migr(迁移)**, -ant(人; 物)<br>迁出本国到国外定居的人 |
| emigration<br><br>n. 移居; 移民出境; 迁往外国 (的人) | 与 emigrate“迁出”同源, 由 e“向外”与 migrare“迁移”构成<br>迁出本国的行为 |
| immigrant<br><br>n. 移民; 侨民<br>adj. 移民的 | im-(向内, 进入), **migr(迁移)**, -ant(人; 物)<br>迁移进入一个国家或地区的人, 即移民 |
| immigration<br><br>n. 移居入境 | immigrate→immigrat(词: 使移居入境), -ion(行为, 结果)<br>由“使移居入境”派生为当前词义 |
| migrant<br><br>n. 迁移者; 候鸟 | **migr(迁移)**, -ant(人; 物)<br>从一地迁往另一地的人或动物 |
| migration<br><br>n. 移居外国; 迁居 | **migr(迁移)**, -ation(行为, 结果)<br>迁移的行为, 即"迁徙" |
| migrator<br><br>n. 移居者; 候鸟 | **migr(迁移)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“移居者” |
| transmigration<br><br>n. 移居 | 源自拉丁语 transmigratio, 由 trans“越过”与 migrare“迁移”构成<br>迁移到另一处; 也指灵魂转生 |
| migratory<br><br>adj. 迁移的; 移居的; 流动的 | **migr(迁移)**, -atory(…的)<br>在前词基础上加“-atory”构成形容词, 表示“迁移的” |


### milit

兵

| 单词 | 拆解 |
| --- | --- |
| militancy<br><br>n. 战斗性; 战斗精神; 交战状态; 好战 | **milit(兵)**, -ancy(性质, 状态)<br>围绕“兵”这一核心含义构成, 表示“战斗性, 战斗精神” |
| militarism<br><br>n. 军国主义; 好战精神 | **milit(兵)**, -ar(…的), -ism(主义)<br>表示与“兵”有关的性质或状态, 即“军国主义” |
| militarist<br><br>n. 军国主义者; 军事家 | military→militar(词: 军事的), -ist(人)<br>鼓吹军国主义或军事扩张的人 |
| militant<br><br>adj. 战斗(性)的; 好战的; 交战中的 | **milit(兵)**, -ant(…的)<br>在前词基础上加“-ant”构成形容词, 表示“战斗” |
| militaristic<br><br>adj. 军国主义的; 穷兵黩武的 | militarist(词: 军国主义者), -ic(…的)<br>在前词基础上加“-ic”构成形容词, 表示“军国主义的” |


### min(i)

突出, 伸出; 小

| 单词 | 拆解 |
| --- | --- |
| diminish<br><br>v. 减少; 减弱; 降低; 贬低; 轻视 | 源自拉丁语 diminuere“使变小”相关形式<br>表示使数量、力量或重要性减少 |
| diminution<br><br>n. 缩小; 缩减; 减小 | di-(分开, 分离), **min(小)**, **ut(用)**, -ion(行为, 结果)<br>使数量或程度变小的过程, 即减少、缩小 |
| miniature<br><br>n. 缩图; 小画像<br>adj. 小规模的; 纤小的 | 源自拉丁语 minium“红色颜料”相关形式, 原指手稿中的彩绘<br>因彩绘常很小, 后来发展出微型之义 |
| miniaturization<br><br>n. 小型化 | miniature→miniatur(词: 缩图), -ization(行为, …化)<br>由“缩图”派生为当前词义 |
| minibus<br><br>n. 小公共汽车 | **mini(突出, 伸出)**, bus(词: 公共汽车)<br>由“小”与“公共汽车”共同限定词义, 表示“小公共汽车” |
| minim<br><br>n. 微物; 小量 | 借自拉丁语 minimus“最小的”<br>由最小单位引申为极小量或二分音符 |
| minimum<br><br>n. 最小值<br>adj. 最小的; 最低的 | 直接采用拉丁语 minimum“最小的事物”<br>表示最低值或最低限度 |
| minor<br><br>adj. 次要的; 较小的; 轻微的; 辅修的<br>n. 未成年人; 辅修科目 | 源自拉丁语 minor“较小的”<br>表示较小、次要的; 也可转化作名词 |
| minority<br><br>n. 少数; 少数派; 少数民族; 未成年 | minor(词: 较小的), -ity(性质, 状态)<br>表示与“较小的”有关的性质或状态, 即“少数派” |
| minuet<br><br>n. 小步舞(曲) | **minu(减少, 变小)**, -et(小)<br>围绕“小”这一核心含义构成, 表示“小步舞(曲)” |
| minus<br><br>n. 减号; 负数; 缺点<br>adj. 负的; 减的<br>prep. 减去 | **min(小)**, -us(名词词尾)<br>使数量变小的, 即减去、负的 |
| minute<br><br>adj. 细微的; 详细的<br>n. 分钟; 会议记录 | 源自拉丁语 minutus“被减小的、细小的”<br>与 min“小”同源; 时间被细分后的一份即一分钟 |
| prominent<br><br>adj. 突出的; 显著的; 重要的; 杰出的 | pro-(向前, 前进), **min(突出, 伸出)**, -ent(…的)<br>由“向前”与“突出”共同限定词义, 表示“突出的, 显要的” |
| diminutive<br><br>adj. 小(型)的 | 源自拉丁语 diminutivus, 与 diminish“减小”同源<br>表示较小形式或爱称的 |


### minis

服务, 管理

| 单词 | 拆解 |
| --- | --- |
| administer<br><br>v. 给予帮助; 管理; 施行 | ad-(到, 朝, 向), minister(词: 管理; 服务)<br>面向事务提供管理或服务, 即管理、施行 |
| administration<br><br>n. 管理; 行政; 行政机关; 当局; 政府 | administer→administr(词: 管理), -ation(行为, 结果)<br>实施管理的过程, 也指承担管理职能的政府 |
| administrator<br><br>n. 行政人员; 管理者 | administer→administr(词: 管理), -ator(人; 物)<br>负责实施管理的人, 即行政人员或管理者 |
| minister<br><br>n. 部长; 牧师; 公使; 大臣<br>v. 侍候 | 来自拉丁语 minister“仆人、服务者”<br>由替上级服务的人发展为部长、牧师或公使, 也可表示服侍 |
| ministry<br><br>n. (政府的)部; 神职; 牧师职位; (尤指基督教新教的)全体牧师 | **minis(服务, 管理)**, t(连接字母), -ry(行为, 状态)<br>围绕“服务”这一核心含义构成, 表示“(政府的)部, (尤指基督教新教的)全体牧师, 神职, 牧师职位” |
| administrative<br><br>adj. 行政的; 管理的 | administer→administr(词: 管理), -ative(…的)<br>与实施管理或行政事务有关的 |
| ministerial<br><br>adj. 部长的; 部的 | minister(词: 部长), -ial(…的)<br>在前词基础上加“-ial”构成形容词, 表示“部长的” |


### mis(o)

憎恨, 厌恶

| 单词 | 拆解 |
| --- | --- |
| misanthropy<br><br>n. 厌恶人类; 厌世; 愤世嫉俗 | **mis(憎恨, 厌恶)**, **anthrop(人类)**, -y(活动)<br>憎恨或厌恶人类的状态 |
| misogyny<br><br>n. 厌女症; 厌女癖; 厌恶女人 | **miso(憎恨, 厌恶)**, **gyn(女人, 雌性)**, y(连接字母)<br>在前词基础上加“-y”构成名词, 表示“厌女症” |
| misanthropic<br><br>adj. 厌恶人类(者)的; 厌世(者)的 | mis-(坏, 错误), **anthrop(人类)**, -ic(…的)<br>由“坏”与“人类”共同限定词义, 表示“厌恶人类(者)的, 厌世(者)的” |


### misc, ming, med

混杂, 混合

| 单词 | 拆解 |
| --- | --- |
| meddle<br><br>v. 干预; 动乱 | 核心意象是把自己混入不属于自己的事务中, 由此表示干预或多管闲事 |
| mingle<br><br>v. 混合 | **ming(混杂, 混合)**, l(连接字母), e(连接字母)<br>使不同的人或事物混合在一起 |
| miscegenation<br><br>n. 人种混杂; 混血 | **misc(混杂, 混合)**, e(连接字母), **gen(出生, 产生)**, -ation(行为, 结果)<br>由“混杂”与“种类”共同限定词义, 表示“人种混杂, 混血” |
| miscellany<br><br>n. 混杂; 杂物; 杂集; 杂录 | 源自拉丁语 miscellanea“混杂的事物”<br>不同类别作品或材料的杂集 |
| miscibility<br><br>n. 可混合 | **misc(混杂, 混合)**, -ibility(可…性)<br>围绕“混合”这一核心含义构成, 表示“可混合” |
| promiscuity<br><br>n. 混杂 (性); 杂乱 | pro-(向前, 前进), **misc(混杂, 混合)**, u(连接字母), -ity(性质, 状态)<br>由“向前”与“混杂”共同限定词义, 表示“混杂 (性)” |
| immiscible<br><br>adj. 不能混合的 | im-(无, 不, 非), **misc(混杂, 混合)**, -ible(可…的)<br>否定或缺少“混合”所指的性质, 因此表示“不能混合的” |
| miscellaneous<br><br>adj. 混杂的; 各种各样的 | 源自拉丁语 miscellaneus（混合的）, 表示各种各样混在一起的 |
| promiscuous<br><br>adj. 混杂的; 杂乱的 | 源自拉丁语 promiscuus“混杂的”, 由 pro“向前”与 miscere“混合”相关形式构成<br>混杂而不加选择的 |


### miss, mit

投放, 发送

| 单词 | 拆解 |
| --- | --- |
| commit<br><br>v. 犯(罪); 承诺; 犯（罪）; 做（坏事） | com-(与, 共同), **mit(投放, 发送)**<br>共同发送委派出去, 即"托付, 交付" |
| dismiss<br><br>v. 开除; 免职; 解散; 解雇; （法官）驳回 | dis-(否定, 相反), **miss(投放, 发送)**<br>由“除去”与“投”共同限定词义, 表示“开除, 免职” |
| omit<br><br>v. 省略; 遗漏; 删去 | o(连接字母), **mit(投放, 发送)**<br>把本应放入的部分送开、留下不写, 因此表示省略、遗漏 |
| promise<br><br>v. 允诺; 约定; 预示<br>n. 诺言; 约定的事情; 有指望 | 源自拉丁语 promittere（向前发送、保证）, 表示承诺 |
| submit<br><br>v. 提交; 呈递; 屈服; 服从; 建议认为 | sub-(在下, 向下), **mit(投放, 发送)**<br>把材料递交到上级手下, 因此表示提交; 也可指屈服 |
| intermix<br><br>v. (使) 混合; (使) 混杂 | inter-(在...之间), **mix(混合)**<br>由“在…之间”与“混合”共同限定词义, 表示“(使) 混合, (使) 混杂” |
| admission<br><br>n. 承认; 准许进入; 入场费 | ad-(到, 朝, 向), **miss(投放, 发送)**, -ion(行为, 结果)<br>被允许进入或承认事实的行为, 即准入、承认 |
| commissary<br><br>n. 委员; 代表 | com-(与, 共同), **miss(投放, 发送)**, -ary(人)<br>受共同委派执行职务的人, 即委员或代表 |
| commission<br><br>n. 委员会; 佣金; 正式委托; 犯(罪/错)<br>v. 正式委托; 任命…为军官 | com-(与, 共同), **miss(投放, 发送)**, -ion(行为, 结果)<br>共同托付发送出去的行为, 即"委托" |
| committee<br><br>n. 委员会 | com-(与, 共同), **mit(投放, 发送)**, t(连接字母), -ee(接受动作的人)<br>受共同委托处理事务的一群人, 即委员会 |
| emissary<br><br>n. 派出的密使; 间谍 | e-(出, 向外), **miss(投放, 发送)**, -ary(人)<br>被派出去执行任务的人, 即使者或密使 |
| emit<br><br>v. 发出; 排放; 散发 | e-(出, 向外), **mit(投放, 发送)**<br>把光、热、声音等向外发出, 因此表示发射、散发 |
| intermission<br><br>n. 中间休息; 间歇; 中断 | inter-(在...之间), **miss(投放, 发送)**, -ion(行为, 结果)<br>中间插入 |
| manumission<br><br>n. 释放; 解放 | **manu(手)**, **miss(投放, 发送)**, -ion(行为, 结果)<br>把受控制者从手中放走, 即释放奴隶 |
| missile<br><br>n. 导弹; 投射物<br>adj. 可发射的 | **miss(投放, 发送)**, -ile(…的)<br>围绕“投”这一核心含义构成, 表示“发射物, 投掷物, 导弹, 飞弹” |
| missionary<br><br>adj. 传教的<br>n. 传教士 | **miss(投放, 发送)**, -ion(行为, 结果), -ary(人)<br>受委派出去传教的人, 即传教士 |
| remittance<br><br>n. 汇款 | re-(回, 向后, 再次), **mit(投放, 发送)**, t(连接字母), -ance(性质, 状态)<br>把钱发送回去 |
| transmitter<br><br>n. 传送者; 发射机; 发报机 | trans-(横过, 越过), **mit(投放, 发送)**, t(连接字母), -er(人)<br>发送信息的人; 也可引申指发射装置 |
| mixer<br><br>n. 混合者; 搅拌器 | **mix(混合)**, -er(人)<br>进行混合的人; 也可引申指混合机器 |
| mixture<br><br>n. 混合; 混合物; 混合剂 | 由 mix（混合）派生, 既表示混合行为, 也更常表示混合后形成的混合物 |
| emissive<br><br>adj. 发出的; 发射的 | e-(出, 向外), **miss(投放, 发送)**, -ive(…的)<br>能够把能量或物质向外发出, 因此表示发射的、辐射的 |
| intermittent<br><br>adj. 间歇的 | inter-(在...之间), **mit(投放, 发送)**, t(连接字母), -ent(…的)<br>由“在…之间”与“投”共同限定词义, 表示“间歇的” |


### mix

混合

| 单词 | 拆解 |
| --- | --- |
| intermix<br><br>v. (使)混合, (使)混杂 | inter-(在...之间), **mix(混合)**<br>由“在…之间”与“混合”共同限定词义, 表示“(使) 混合, (使) 混杂” |
| mixer<br><br>n. 混合者; 搅拌器 | **mix(混合)**, -er(人)<br>进行混合的人; 也可引申指混合机器 |
| mixture<br><br>n. 混合; 混合物; 混合剂 | 由 mix（混合）派生, 既表示混合行为, 也更常表示混合后形成的混合物 |


### mob, mot,mov

动, 移动

| 单词 | 拆解 |
| --- | --- |
| mobilize<br><br>v. 动员(起来); 使可动; 使流通 | 由 mobile“可移动的”派生<br>使人员或资源行动起来 |
| automobile<br><br>n. 汽车<br>adj. 汽车的 | auto-(自己, 自动), **mob(动, 移动)**, -ile(…的)<br>能够自行移动的车辆, 即汽车 |
| demobilization<br><br>n. 复员 | demobilize→demobiliz(词: 使复员), -ation(行为, 结果)<br>由“使复员”派生为当前词义 |
| immobility<br><br>n. 不动性; 固定性 | im-(无, 不, 非), **mob(动, 移动)**, -ility(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“不动性” |
| mobile<br><br>n. 风铃; 悬挂饰物<br>adj. 可移动的; 易变的 | **mob(动, 移动)**, -ile(…的)<br>围绕“动”这一核心含义构成, 表示“运动的, 流动的” |
| mobility<br><br>n. 易动性; 运动性; 变动性 | **mob(动, 移动)**, -ility(性质, 状态)<br>能够移动的性质, 即"移动出行" |
| mobster<br><br>n. 暴徒; 匪徒 | **mob(动, 移动)**, -ster(人, 常带贬义)<br>围绕“动”这一核心含义构成, 表示“暴徒, 匪徒” |
| remote<br><br>n. 遥控器<br>adj. 偏远的; 遥远的; 偏僻的; 疏远的 | re-(回, 向后, 再次), **mot(动, 移动)**, e(连接字母)<br>向后移开、距离很远的, 即"遥远的" |
| immobile<br><br>adj. 不动的; 固定的 | im-(无, 不, 非), **mob(动, 移动)**, -ile(…的)<br>否定或缺少“动”所指的性质, 因此表示“不动的, 固定的” |


### mod

尺度

| 单词 | 拆解 |
| --- | --- |
| accommodate<br><br>v. 容纳; 供应; 使适应; 使迁就; 调节 | ac-(到, 朝, 向), com-(与, 共同), **mod(方式, 模式)**, -ate(做, 使)<br>使完全按合适的方式安顿好, 即"提供住宿", 引申为"容纳, 迁就" |
| moderate<br><br>n. 温和派; 稳健的人<br>v. 缓和; 节制; 主持<br>adj. 温和的; 适度的; 中等的 | 源自拉丁语 moderari“按尺度控制”, 核心 modus 表示尺度、方式<br>表示保持在适中范围, 也可作动词表示调节 |
| modify<br><br>v. 修改; 更改; 修饰 | **mod(方式, 模式)**, -ify(…化, 做…)<br>改变原有的模式或状态, 即“修改, 更改” |
| modulate<br><br>v. 调整; 调节; 调制 (mod 尺度; -ul(e) 名词后缀; -ate 动词后缀) | **mod(方式, 模式)**, -ulate(做, 使)<br>使信号或程度按一定模式变化, 即调节、调制 |
| accommodation<br><br>n. 膳宿供应; 适应; 调节; 住处; 食宿招待 | ac-(到, 朝, 向), com-(与, 共同), **mod(方式, 模式)**, -ation(行为, 结果)<br>使住处适合人的需要, 因此表示住宿、住处或调节 |
| moderation<br><br>n. 中等; 适度; 温和; 节制 | 与 moderate“使适度”同源, 核心拉丁语 modus 表示尺度<br>保持在合理尺度内 |
| modesty<br><br>n. 谦虚; 节制; 中肯 | modest(词: 谦逊的), -y(性质, 状态)<br>由“谦逊的”派生为当前词义 |
| modification<br><br>n. 缓和; 减轻; 限制; 修改; 改变 | **mod(方式, 模式)**, i(连接字母), -fication(…化, 做…)<br>使方式模式发生改变的行为, 即"调整" |
| module<br><br>n. 系数 (mod 尺度; -ule 名词后缀); （航天器上各个独立的）舱; 模块; 模(数) | **mod(尺度)**, -ule(小)<br>原指较小的尺度单位, 后指可独立组合的模块 |
| modulus<br><br>n. 模量; 模数; 系数 | 直接来自拉丁语 modulus“尺度、小量”, 为 modus 的小称<br>数学或物理中的模、系数 |
| modest<br><br>adj. 谦虚的; 有节制的; 不过分的; 适度的; 谦逊的 | **mod(尺度)**, -est(最…)<br>行为保持在适当尺度内, 不过分张扬, 即谦逊的 |
| modular<br><br>adj. 制成标准尺寸的 (mod 尺度; -ular 形容词后缀); 模(数)的 | **mod(方式, 模式)**, -ular(…的)<br>由模块这一标准模式构成, 表示模块化的 |


### mod, mo(u)ld

方式, 模式

| 单词 | 拆解 |
| --- | --- |
| modality<br><br>n. 形式; 方式; 样式; 模态 | **mod(方式, 模式)**, -ality(性质, 状态)<br>某种表达、感知或存在的方式 |
| mode<br><br>n. 模式; 方式 | **mod(方式, 模式)**, e(连接字母)<br>做事或存在的方式、模式 |
| model<br><br>n. 模型; 雏型; 模范; 样式; 模特儿<br>v. 使模仿 | **mod(方式, 模式)**, -el(小)<br>围绕“模式”这一核心含义构成, 表示“模型, 雏型” |
| model(l)ing<br><br>n. 造型 (术); 模特儿职业 | model→modell(词: 塑造; 模型), -ing(物; 行业; 行为, 过程)<br>英式拼写双写 l, 表示塑造模型或当模特的过程 |
| modernity<br><br>n. 现代性; 新式 | modern(词: 现代人), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“现代性” |
| mo(u)ld<br><br>n. 模子; 模型; 铸模<br>v. 用模子做; 塑造 | mould 与 mold 是英美拼写变体; “模具”义直接转化为动词“用模具塑造” |
| mo(u)lder<br><br>n. 制模工; 造型者 | **mould(方式, 模式)**, -er(人)<br>在前词基础上加“-er”构成名词, 表示“制模工” |
| mo(u)lding<br><br>n. 模制; 浇铸; 模制件; 铸造物; 造型 (法) | **mould(方式, 模式)**, -ing(物; 行业; 行为, 过程)<br>在前词基础上加“-ing”构成名词, 表示“模制” |
| modal<br><br>adj. 形式的; 方式的; 形态的 | **mod(方式, 模式)**, -al(…的)<br>表示与“方式”有关或具有该特征, 即“形式的, 方式的, 形态的” |
| modern<br><br>adj. 现代的; 近代的 | **mod(方式, 模式)**, -ern(方向, 地点)<br>围绕“方式”这一核心含义构成, 表示“现代的” |
| outmoded<br><br>adj. 过时的; 旧式的 | out-(出, 外, 远), **mod(方式, 模式)**, -ed(…的)<br>已经超出当前通行模式, 因此表示过时的、旧式的 |


### mon

提醒, 警告

| 单词 | 拆解 |
| --- | --- |
| admonish<br><br>v. 警告 | 中古英语经古法语借入, 源自拉丁语 admonere“提醒、警告”<br>记忆为通过警告促使某人注意 |
| monitor<br><br>n. 监督器; 级长; 监听员<br>v. 监视; 监听; 监督 | 直接采用拉丁语 monitor（提醒者、警告者）, 后来指监视设备 |
| admonishment<br><br>n. 告诫; 劝告 | admonish(词: 告诫), -ment(行为, 过程)<br>在前词基础上加“-ment”构成名词, 表示“告诫” |
| admonition<br><br>n. 告诫; 劝告; 忠告 | 源自拉丁语 admonitio“警示性的提醒”, 与 admonish 同源<br>表示劝诫、警告 |
| monitory<br><br>adj. 训诫的<br>n. 诫谕信 | monitor(词: 告诫物), -y(充满…的, 有…特征的, 像…的)<br>具有提醒或告诫作用的 |
| monument<br><br>n. 纪念碑; 纪念像; 纪念物; 历史遗迹; 典范 | **mon(提醒, 警告)**, u(连接字母), -ment(物)<br>用来提醒后人铭记人物或事件的物体, 即纪念碑 |
| premonition<br><br>n. 先兆; 预兆 | 源自拉丁语 praemonitio“预先警告”, 由 prae“在前”与 monere“提醒”构成<br>对未来事件的不祥预感 |
| monumental<br><br>adj. 纪念的; 不朽的; 巨大的; 非常的 | monument(词: 纪念碑), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“纪念的” |


### monstr

显示, 显现

| 单词 | 拆解 |
| --- | --- |
| demonstrate<br><br>v. 表明; 证明; 示范; 演示; 示威 | de-(一再等加强意义), **monstr(显示, 显现)**, -ate(做, 使)<br>充分显示出来, 即展示、证明 |
| remonstrate<br><br>v. 抗议; 抗辩; 规劝 | re-(反对, 相反), **monstr(显示, 显现)**, -ate(做, 使)<br>在前词基础上加“-ate”构成动词, 表示“抗议” |
| demonstration<br><br>n. 表演; 示范; 表示; 示威(运动) | de-(一再等加强意义), **monstr(显示, 显现)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“表演” |
| demonstrative<br><br>adj. 说明的; 指示的 | de-(一再等加强意义), **monstr(显示, 显现)**, -ative(…的)<br>在前词基础上加“-ative”构成名词或形容词, 表示“. 论证的, 感情外露的, 指示的” |
| demonstrator<br><br>n. 证明者; 示范者; 示威者 | de-(一再等加强意义), **monstr(显示, 显现)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“证明者” |
| monster<br><br>n. 怪物; 妖怪 | 经古法语借自拉丁语 monstrum“征兆、怪异之物”, 与 monere“警示”相关<br>被视为异常征兆的怪物 |
| monstrosity<br><br>n. 怪形; 怪物 | **monstr(显示, 显现)**, -osity(性质, 状态)<br>在前词基础上加“-osity”构成名词, 表示“怪形” |
| remonstrance<br><br>n. 抗议; 抗辩; 规劝; 告诫; 谏书 | re-(回, 向后, 再次), **monstr(显示, 显现)**, -ance(性质, 状态)<br>把反对理由明确展示给对方, 因此表示抗议、规劝 |
| monstrous<br><br>adj. 怪异的; 怪形的 | **monstr(显示, 显现)**, -ous(…的)<br>在前词基础上加“-ous”构成形容词, 表示“怪异的” |


### morph(o)

形

| 单词 | 拆解 |
| --- | --- |
| geomorphology<br><br>n. 地貌学 | **geo(地)**, **morpho(形)**, -logy(…学, …研究)<br>研究地表形态及其形成过程的学科, 即地貌学 |
| morphogenesis<br><br>n. 形态发生; 形态形成 | **morpho(形)**, **gen(出生, 产生)**, -esis(行为, 过程)<br>由“形”与“出生”共同限定词义, 表示“形态发生, 形态形成” |
| morphology<br><br>n. 形态学 | **morpho(形)**, -logy(…学, …研究)<br>以“形”为研究对象的学科, 即“形态学” |
| amorphous<br><br>adj. 无定形的; 模糊的 | a-(无, 不, 非), **morph(形)**, -ous(…的)<br>否定或缺少“形”所指的性质, 因此表示“无定形的” |
| homomorphic<br><br>adj. [生] 同形的 | homo-(相同, 同一), **morph(形)**, -ic(…的)<br>由“相同”与“形”共同限定词义, 表示“同形的” |
| isomorphic<br><br>adj. 同形的; 同态的 | iso-(相等, 相同), **morph(形)**, -ic(…的)<br>由“相同”与“形”共同限定词义, 表示“同形的, 同态的” |
| polymorphic<br><br>adj. 多形的 | poly-(多, 复), **morph(形)**, -ic(…的)<br>由“多”与“形”共同限定词义, 表示“多形的” |


### mort

死

| 单词 | 拆解 |
| --- | --- |
| immortalize<br><br>v. 使不朽; 使不灭; 使永存 | immortal(词: 不朽人物), -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“使不朽, 使不灭, 使永存” |
| mortify<br><br>v. 腐坏; 坏死; 使受辱; 使难堪; 使羞愧 | **mort(死)**, -ify(…化, 做…)<br>使难堪如死 |
| immortality<br><br>n. 不朽; 永存 | immortal(词: 不朽人物), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“不朽” |
| mortality<br><br>n. 致死性; 必死性; 死亡数; 死亡率 | mortal(词: 生物), -ity(性质, 状态)<br>由“生物”派生为当前词义 |
| mortician<br><br>n. 殡仪业者; 承办丧葬者 | **mort(死)**, -ician(人)<br>围绕“死”这一核心含义构成, 表示“殡仪业者, 承办丧葬者” |
| mortification<br><br>n. 脱疽; [医] 坏疽; [植] 坏死 | **mort(死)**, i(连接字母), -fication(…化, 做…)<br>围绕“死”这一核心含义构成, 表示“坏疽, 脱疽” |
| mortuary<br><br>adj. 丧葬的; 悲哀的; 埋葬的<br>n. 停尸间; 太平间 | **mort(死)**, u(连接字母), -ary(…的)<br>围绕“死”这一核心含义构成, 表示“停尸室, 太平间, 殡仪馆” |
| postmortem<br><br>n. 尸体检查; 验尸<br>adj. 死后的; 事后的 | post-(在后, 之后), **mort(死)**, -em(行为的结果)<br>由“在后”与“死”共同限定词义, 表示“死后(的)” |
| immortal<br><br>adj. 不死的; 永生的; 不朽的 | im-(无, 不, 非), **mort(死)**, -al(…的)<br>否定或缺少“死”所指的性质, 因此表示“不死的, 永生的, 不朽的” |
| mortal<br><br>adj. 终有一死的; 临死的; 致死的; 致命的; 必死的<br>n. 凡人; 人类 | **mort(死)**, -al(…的)<br>表示与“死”有关或具有该特征, 即“终有一死的, 死的, 临死的” |


### mount

上, 升

| 单词 | 拆解 |
| --- | --- |
| dismount<br><br>v. 下马; 下车; 卸下 | dis-(否定, 相反), **mount(上, 升)**<br>从马背、车上或高处下来, 因此表示下马、下车或卸下 |
| amount<br><br>n. 数量; 总额<br>v. 总计; 等同于 | 经古法语 amonter“向上、合计”进入英语, 核心与 mount“上升”相关<br>数值加总上升到某个总量 |
| mount<br><br>n. 山峰; 底座<br>v. 登上; 骑上; 增加 | **mount(上, 升)**<br>向上登到较高处, 也可转化作名词表示山峰或支架 |
| mountain<br><br>n. 山; 山岳; 高山 | 源自拉丁语 mons、mont-“山”形成的古法语 montaigne<br>高出周围地面的巨大地形, 即山 |
| mountaineer<br><br>n. 登山家; 山地人<br>v. 登山 | mountain(词: 山), -eer(人)<br>在前词基础上加“-eer”构成名词或动词, 表示“山地人” |
| mountainous<br><br>adj. 多山的; 如山的; 巨大的 | mountain(词: 山), -ous(…的)<br>多山的, 或规模像山一样巨大的 |


### muc, mucil

粘, 粘液

| 单词 | 拆解 |
| --- | --- |
| mucin<br><br>n. 黏蛋白 | **muc(粘, 粘液)**, -in(…素)<br>围绕“粘”这一核心含义构成, 表示“黏蛋白” |
| mucosa<br><br>n. 黏膜 | 直接采用现代拉丁语 mucosa, 是 mucosus（黏液的）的阴性形式, 指黏膜 |
| mucositis<br><br>n. 黏膜炎 | 由 mucosa“黏膜”与 itis“炎症”构成<br>黏膜炎 |
| mucus<br><br>n. 黏液 | **muc(粘, 粘液)**, -us(名词词尾)<br>围绕“粘液”这一核心含义构成, 表示“黏液” |
| mucocutaneous<br><br>adj. 黏膜与皮肤的 | 由 muco“黏膜”与 cutaneous“皮肤的”构成<br>同时涉及黏膜和皮肤的 |
| mucoid<br><br>adj. 黏液样的 | **muc(粘, 粘液)**, -oid(似…的（物）)<br>形状像“粘液”, 即“黏液样的” |
| mucous<br><br>adj. 黏液的 | **muc(粘, 粘液)**, -ous(…的)<br>表示与“粘液”有关或具有该特征, 即“黏液的” |


### mon, mun

公共, 共同; 职责, 服务; 礼物

| 单词 | 拆解 |
| --- | --- |
| community<br><br>n. 社区; 团体; 共享; 群体; （生物的）群落 | com-(与, 共同), **mun(公共, 共同)**, -ity(性质, 状态)<br>共同拥有公共事物的群体, 即人群、社区或团体 |
| munificence<br><br>n. 慷慨; 毫不吝啬 | **mun(职责, 服务)**, i(连接字母), -fic(造成…的, 产生…的), -ence(性质, 状态)<br>乐于赠送礼物、给予帮助的性质, 即慷慨 |
| commonplace<br><br>adj. 普通的; 平凡的 | common(词: 共同的), place(词: 主题位置)<br>原为“共同主题”, 后引申为常见而平凡的事物 |
| communal<br><br>adj. 社区的; 共有的 | com-(与, 共同), **mun(公共, 共同)**, -al(…的)<br>使“公共”共同结合或发挥作用, 因此表示“社区的, 共有的” |
| munificent<br><br>adj. 慷慨解囊的; 毫不吝啬的; (所给的东西)大量的 | 源自拉丁语 munificus, 由 munus“礼物”与 facere“做”构成<br>乐于赠礼, 即慷慨的 |
| uncommon<br><br>adj. 不寻常的; 非凡的; 稀有的 | un-(无, 不, 非), common(词: 常见的)<br>不常见的、非凡的 |


### mund

世界; 清洁

| 单词 | 拆解 |
| --- | --- |
| mundane<br><br>adj. 平凡的; 单调的; 世俗的; 尘世的 | 源自拉丁语 mundus“世界”<br>属于尘世日常世界的, 即世俗或平凡的 |
| mundanity<br><br>n. 平凡; 尘世; 世俗事物 | **mund(世界; 清洁)**, -an(…的), -ity(性质, 状态)<br>属于尘世现世的平凡琐碎状态 |


### mur

墙壁

| 单词 | 拆解 |
| --- | --- |
| mure<br><br>v. 监禁; 禁锢; 把⋯⋯镶在墙上; 把⋯⋯埋在墙里 | **mur(墙壁)**, e(连接字母)<br>用墙包围起来 |
| mural<br><br>adj. 壁的; 壁上的; 壁似的<br>n. 壁画 | **mur(墙壁)**, -al(…的)<br>围绕“墙壁”这一核心含义构成, 表示“墙壁 (上) 的, 似墙壁的” |
| muralist<br><br>n. 壁画家; 壁饰家 | mural(词: 壁画), -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“壁画家” |
| muscle<br><br>n. 肌肉; 臂力 | **muscl(肌)**, e(连接字母)<br>表示产生身体力量的肌肉, 并可转化作动词 |
| muscularity<br><br>n. 强健; 强有力 | muscular(词: 有力的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“强健, 强有力” |
| musculature<br><br>n. 肌 (肉); 肌织; 肌系 | 源自拉丁语 musculatura（肌肉组织）, 表示身体或某部位全部肌肉的组织结构 |
| extramural<br><br>adj. 墙外的; 城外的; 大学之墙以外的 | extra-(在外, 向外), **mur(墙壁)**, -al(…的)<br>由“以外, 超过”与“墙壁”共同限定词义, 表示“墙外的” |
| intramural<br><br>adj. (国家; 城市; 团体等) 自己范围内的; 内部的; (器官) 壁内的 | intra-(在内, 内部), **mur(墙壁)**, -al(…的)<br>由“内部”与“墙壁”共同限定词义, 表示“(国家、城市、团体等) 自己范围内的, 内部的” |
| muscular<br><br>adj. 肌 (肉) 的; 肌肉发达的; 强健的; 强有力的 | **muscul(肌)**, -ar(…的)<br>与肌肉相关且发达的, 即"肌肉发达的" |
| musculoskeletal<br><br>adj. 肌与骨的 | **muscul(肌)**, o(连接元音), skeleton→skelet(词: 骨骼), -al(…的)<br>由“肌”与“骨骼”共同限定词义, 表示“肌与骨的” |


### muscul, muscl

肌

| 单词 | 拆解 |
| --- | --- |
| muscle<br><br>n. 肌肉; 臂力 | **muscl(肌)**, e(连接字母)<br>表示产生身体力量的肌肉, 并可转化作动词 |
| muscular<br><br>adj. 肌(肉)的; 肌肉发达的, 强健的, 强有力的 | **muscul(肌)**, -ar(…的)<br>与肌肉相关且发达的, 即"肌肉发达的" |
| muscularity<br><br>n. 强健, 强有力 | muscular(词: 有力的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“强健, 强有力” |
| musculature<br><br>n. 肌(肉); 肌织, 肌系 | 源自拉丁语 musculatura（肌肉组织）, 表示身体或某部位全部肌肉的组织结构 |
| musculoskeletal<br><br>adj. 肌与骨的 | **muscul(肌)**, o(连接元音), skeleton→skelet(词: 骨骼), -al(…的)<br>由“肌”与“骨骼”共同限定词义, 表示“肌与骨的” |


### mut

变换

| 单词 | 拆解 |
| --- | --- |
| commute<br><br>v. 变换; 用...交换 | com-(与, 共同), **mut(变换)**, e(连接字母)<br>使“变换”共同结合或发挥作用, 因此表示“变换” |
| mutate<br><br>v. (使)变异; (使)突变 | **mut(变换)**, -ate(做, 使)<br>围绕“变换”这一核心含义构成, 表示“(使)变异” |
| permute<br><br>v. 变更; 交换 | per-(通过, 贯穿), **mut(变换)**, e(连接字母)<br>由“通过”与“变换”共同限定词义, 表示“变更” |
| transmute<br><br>v. (使)变形; (使)变质 | 源自“跨越原有形态而改变”的构词意象; 现代英语不能按 trans + mute 拆解<br>表示使物质或性质转变成另一种 |
| commutator<br><br>n. 转换器; 交换机; 整流器 | com-(与, 共同), **mut(变换)**, -ator(物)<br>用于转换或换向的装置, 即转换器、整流器 |
| immutability<br><br>n. 不变性 | im-(无, 不, 非), **mut(变换)**, -ability(可…性)<br>否定或缺少“变换”所指的性质, 因此表示“不变性” |
| mutant<br><br>adj. 突变的<br>n. 突变体; 突变异种 | **mut(变换)**, -ant(…的)<br>围绕“变换”这一核心含义构成, 表示“变异的” |
| mutineer<br><br>n. 叛变者; 反抗者 | 源自 mutiny（叛变）派生, 表示参加叛变或反抗的人 |
| mutiny<br><br>n. 叛变; 反抗 | 经法语 mutiner“反抗”借入, 可能与 meute“骚动群体”相关<br>士兵或船员集体反叛 |
| mutuality<br><br>n. 相互关系; 相关; 感情的共鸣; 亲密 | mutual(词: 相互的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“相互关系” |
| transmutation<br><br>n. 变形; 变质; 演变; 衍变 | trans-(横过, 越过), **mut(变换)**, -ation(行为, 结果)<br>由“横过”与“变换”共同限定词义, 表示“变形” |
| mutagenic<br><br>adj. 诱变的 | **mut(变换)**, a(连接字母), **gen(出生, 产生)**, -ic(…的)<br>由“变换”与“出生”共同限定词义, 表示“诱变的” |
| mutual<br><br>adj. 相互的; 彼此的; 共同的 | **mut(变换)**, -ual(…的)<br>围绕“变换”这一核心含义构成, 表示“相互的, 彼此的” |


### my(o)

肌

| 单词 | 拆解 |
| --- | --- |
| myalgia<br><br>n. 肌痛 | **my(肌)**, **alg(痛)**, -ia(性质, 状态)<br>由“肌”与“痛”共同限定词义, 表示“肌痛” |
| myasthenia<br><br>n. 肌无力 | 由希腊语 mys“肌肉”与 astheneia“无力”构成<br>肌肉无力 |
| myocarditis<br><br>n. 心肌炎 | 由 myo“肌肉”、card“心脏”与 itis“炎症”构成<br>心肌炎 |
| myocyte<br><br>n. 肌细胞 | **myo(肌)**, **cyt(细胞)**, e(连接字母)<br>由“肌”与“细胞”共同限定词义, 表示“肌细胞” |
| myoma<br><br>n. 肌瘤 | **my(肌)**, -oma(肿瘤, 肿块)<br>由肌肉组织形成的肿瘤, 即肌瘤 |
| myositis<br><br>n. 肌炎 | **myo(肌)**, s(连接字母), -itis(…炎)<br>“肌”发生炎症, 即“肌炎” |
| myotonia<br><br>n. 肌强直 | 由 myo“肌肉”与 tonos“张力”构成<br>肌肉松弛延迟、张力异常 |


### myc(o)

真菌

| 单词 | 拆解 |
| --- | --- |
| mycobacterium<br><br>n. 分支杆菌 | **myco(真菌)**, bacterium(词: 杆菌属)<br>围绕“真菌”这一核心含义构成, 表示“分支杆菌” |
| mycology<br><br>n. 真菌学; 霉菌学 | **myco(真菌)**, -logy(…学, …研究)<br>以“真菌”为研究对象的学科, 即“真菌学, 霉菌学” |
| mycoplasma<br><br>n. 支原体; 支浆体 | **myco(真菌)**, plasma(词: 原生质)<br>由“真菌”与“血浆、原生质”共同限定词义, 表示“支原体, 支浆体” |
| myco(r)rhiza<br><br>n. 菌根 | **myco(真菌)**, r(连接字母), **rhiz(根)**, a(连接字母)<br>围绕“真菌”这一核心含义构成, 表示“菌根” |
| mycosis<br><br>n. 真菌病; 霉菌病 | **myc(真菌)**, -osis(病症)<br>围绕“真菌”这一核心含义构成, 表示“真菌病, 霉菌病” |
| mycostatin<br><br>n. 制霉菌素 | **myco(真菌)**, **stat(静止, 稳定)**, -in(…素)<br>使真菌生长停住的物质, 即制霉菌素 |


### myel(o)

髓

| 单词 | 拆解 |
| --- | --- |
| myelin<br><br>n. 髓磷脂; 髓脂质 | **myel(髓)**, -in(…素)<br>围绕“髓”这一核心含义构成, 表示“髓磷脂” |
| myelitis<br><br>n. 脊髓炎; 骨髓炎 | **myel(髓)**, -itis(…炎)<br>“髓”发生炎症, 即“脊髓炎” |
| myelofibrosis<br><br>n. 骨髓纤维变性; 骨髓纤维化 | **myelo(髓)**, **fibr(纤维)**, -osis(状态, 过程)<br>由“髓”与“纤维”共同限定词义, 表示“骨髓纤维变性, 骨髓纤维化” |
| myelography<br><br>n. 脊髓 (X 线) 造影术 | **myelo(髓)**, **graph(写, 画)**, -y(活动)<br>记录或描绘“髓”的方法, 即“脊髓 (X 线) 造影术” |
| myeloma<br><br>n. (骨) 髓瘤 | **myel(髓)**, -oma(肿瘤, 肿块)<br>围绕“髓”这一核心含义构成, 表示“(骨) 髓瘤” |
| myelopathy<br><br>n. 脊髓病; 骨髓 (组织) 病 | **myelo(髓)**, **pathy(疾病, 疗法)**<br>由“髓”与“疾病”共同限定词义, 表示“脊髓病” |
| myeloid<br><br>adj. 骨髓的; 脊髓的 | **myel(髓)**, -oid(似…的（物）)<br>形状像“髓”, 即“骨髓的” |


### myri(a)

一万, 无数

| 单词 | 拆解 |
| --- | --- |
| myriad<br><br>n. 无数; 无数的人<br>adj. 无数的; 种种的 | **myri(一万, 无数)**, -ad(群体)<br>词根本身即表示“无数”, 整词沿用该义 |
| myriapod<br><br>n. 多足动物 (如马陆、百足虫) | **myri(a)(一万, 无数)**, **pod(足, 脚)**<br>足肢极多、数不胜数的节肢动物 |


### myst

神秘

| 单词 | 拆解 |
| --- | --- |
| mystify<br><br>v. 使神秘化; 蒙蔽; 迷惑 | **myst(神秘)**, -ify(…化, 做…)<br>在前词基础上加“-fy”构成动词, 表示“使神秘化” |
| mystery<br><br>n. 神秘; 奥秘; 神秘的事物 | 源自希腊语 mystērion（秘密仪式、秘密之事）, 记忆锚点为不向外人揭示的秘密 |
| mystic<br><br>adj. 神秘的; 奥秘的<br>n. 神秘主义者 | **myst(神秘)**, -ic(…的)<br>围绕“神秘”这一核心含义构成, 表示“神秘的, 不可思议的, 神秘主义 (者) 的” |
| mysticism<br><br>n. 神秘主义; 神秘教; 玄想 | mystic(词: 神秘主义者), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“神秘主义” |
| mystification<br><br>n. 神秘化; 故弄玄虚 | **myst(神秘)**, i(连接字母), -fication(…化, 做…)<br>围绕“神秘”这一核心含义构成, 表示“神秘化, 故弄玄虚” |
| mystique<br><br>n. 神秘气氛; 神秘性; 奥妙; 秘诀 | 借自法语 mystique“神秘的气质”<br>围绕某人或事物形成的神秘魅力 |
| mysterious<br><br>adj. 神秘的; 不可思议的; 故弄玄虚的 | mystery→mysteri(词: 谜), -ous(…的)<br>具有谜一般特征的, 即神秘的 |
| mystical<br><br>adj. 神秘的; 不可理解的 | mystic(词: 神秘的), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“神秘的” |


### myth(o)

神话

| 单词 | 拆解 |
| --- | --- |
| mythic(al)<br><br>adj. 神话(式)的; 幻想出来的, 虚构的 | **myth(神话)**, -ical(…的)<br>表示与“神话”有关或具有该特征, 即“神话(式)的” |
| mythologic(al)<br><br>adj. 神话(中)的; 神话学(上)的; 像神话的, 虚构的 | myth(词: 神话), o(连接元音), **log(说, 言)**, -ical(…的)<br>与神话叙述或神话学有关的 |
| mythology<br><br>n. 神话学; 神话集; [总称]神话 | **mytho(神话)**, -logy(…学, …研究)<br>以“神话”为研究对象的学科, 即“神话” |
| mythos<br><br>n. [总称]神话 | **mytho(神话)**, s(连接字母)<br>围绕“神话”这一核心含义构成, 表示“神话” |
