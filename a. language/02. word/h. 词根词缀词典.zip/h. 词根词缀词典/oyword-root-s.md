## oyword-root-s


### sacr, secr, sanct

神圣

| 单词 | 拆解 |
| --- | --- |
| consecrate<br><br>v. 奉为神圣; 供献 | con-(与, 共同), **secr(神圣)**, -ate(做, 使)<br>使“神圣的”共同结合或发挥作用, 因此表示“奉为神圣” |
| desecrate<br><br>v. 亵渎; 侮辱 | de-(脱离, 取消, 除去), **secr(神圣)**, -ate(做, 使)<br>除去神圣性, 即亵渎 |
| sanctify<br><br>v. 使神圣; 使圣洁 | **sanct(神圣)**, i(连接字母), -fy(…化, 做…)<br>词根本身即表示“使神圣”, 整词沿用该义 |
| sacrament<br><br>n. 圣礼; 圣事; 誓言<br>v. 使立誓; 使宣誓 | **sacr(神圣)**, a(连接字母), -ment(物)<br>被视为神圣的仪式或事物, 即圣礼 |
| sacramental<br><br>adj. 圣礼的; 圣餐的; 受圣礼约束的 | 源自拉丁语 sacramentalis, 与 sacrament“圣礼”同源<br>与圣礼有关或具有神圣仪式性质的 |
| sacrifice<br><br>n. 牺牲; 祭品<br>v. 牺牲; 献祭 | **sacr(神圣)**, i(连接字母), **fic(做)**, e(连接字母)<br>把普通事物做成献给神的圣物, 后来泛指牺牲 |
| sanction<br><br>n. 批准; 制裁<br>v. 批准; 对……实施制裁 | **sanct(神圣)**, -ion(行为, 结果)<br>围绕“神圣的”这一核心含义构成, 表示“(尤指教会的) 法令” |
| sanctity<br><br>n. 圣洁; 神圣; 尊严; 神圣不可侵犯性 | **sanct(神圣)**, -ity(性质, 状态)<br>表示与“神圣的”有关的性质或状态, 即“圣洁” |
| sanctuary<br><br>n. 圣所; 圣殿; 教堂 | **sanct(神圣)**, u(连接字母), -ary(场所)<br>神圣或受保护的场所, 即圣所、避难所 |
| sanctum<br><br>n. 圣所 | **sanct(神圣)**, -um(名词词尾)<br>神圣而不受打扰的地方, 即圣所或私人密室 |
| execrable<br><br>adj. 可咒的; 讨厌的 | 源自拉丁语 exsecrabilis“可诅咒的”<br>坏到令人诅咒, 即极糟的 |
| sacral<br><br>adj. 宗教仪式的; 神圣的 | **sacr(神圣)**, -al(…的)<br>表示与“神圣的”有关或具有该特征, 即“宗教仪式的” |
| sacred<br><br>adj. 上帝的; 神的; 神圣的; 受尊重的; 宗教的 | **sacr(神圣)**, -ed(…的)<br>被视为神圣或应受尊重的 |
| sacrosanct<br><br>adj. 极神圣的; 不可侵犯的 | **sacr(神圣)**, o(连接元音), **sanct(神圣)**<br>由“神圣的”与“神圣的”共同限定词义, 表示“极神圣的” |


### sal(i), salt

盐

| 单词 | 拆解 |
| --- | --- |
| salad<br><br>n. 色拉 | **sal(盐)**, -ad(群体)<br>一种用盐调拌的凉菜 |
| salary<br><br>n. 薪金; 工资; （尤指按月领的）薪水 | **sal(盐)**, -ary(物)<br>历史上与盐或购盐津贴相关的报酬, 后来表示薪金 |
| salina<br><br>n. 盐碱滩; 盐沼区 | 直接来自拉丁语 salina“盐场”, 核心 sal 表示盐<br>盐沼或盐碱地 |
| saline<br><br>n. 盐湖; 盐田; 碱盐泻药<br>adj. 盐的; 苦涩的; 由碱金属组成的 | **sal(盐)**, -ine(…的)<br>围绕“盐”这一核心含义构成, 表示“盐的, 含盐的, 咸的” |
| salinity<br><br>n. 盐浓度; 咸度; 含盐量 | **sali(盐)**, n(连接字母), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“盐浓度” |
| salt<br><br>n. 盐 | **salt(盐)**<br>核心义即盐 |
| salaried<br><br>adj. 拿薪水的; 有薪水的 | salary→salari(词: 薪水), -ed(…的)<br>由“薪水”派生为当前词义 |
| salty<br><br>adj. (含) 盐的; 咸的 | **salt(盐)**, -y(充满…的, 有…特征的, 像…的)<br>围绕“盐”这一核心含义构成, 表示“(含) 盐的, 咸的” |


### sav, saf, salv

救助, 保存

| 单词 | 拆解 |
| --- | --- |
| save<br><br>v. 拯救; 搭救; 储蓄; 节省; 免去<br>prep. 除…之外 | **sav(救助, 保存)**, e(连接字母)<br>词根本身即表示“救助”, 整词沿用该义 |
| safety<br><br>n. 安全; 安全场所 | safe(词: 安全的), -ty(性质, 状态)<br>免受危险或伤害的状态 |
| salvage<br><br>n. 救助; 抢救<br>v. 抢救; 打捞; 挽救 | 源自古法语 salvage“救回的财物”, 与拉丁语 salvare“救助”相关<br>由从危险中救回财物发展为打捞、挽救 |
| salvation<br><br>n. 救助; 拯救 | **salv(救助, 保存)**, -ation(行为, 结果)<br>围绕“救助”这一核心含义构成, 表示“救助” |
| salvo<br><br>n. 保留(条款); 遁词; 借口; (名誉等的)保全手段 | 源自拉丁语 salvo（保留、除外）时表示保留条款; 另一同形词经意大利语表示齐射 |
| salvor<br><br>n. 难船救助人员; 救援船; 打捞船 | **salv(救助, 保存)**, -or(人)<br>表示从事或具有“救助”特征的人, 即“难船救助人员” |
| saving<br><br>n. 节省; 节俭; 存款; 节约; (复数)储蓄金 | **sav(救助, 保存)**, -ing(物)<br>围绕“救助”这一核心含义构成, 表示“节约, 节省” |
| safe<br><br>adj. 安全的; 平安的; 牢靠的; 可靠的 | **saf(救助, 保存)**, e(连接字母)<br>围绕“救助”这一核心含义构成, 表示“安全的, 平安的” |


### san, salub, salut

健全, 健康

| 单词 | 拆解 |
| --- | --- |
| sanitize<br><br>v. 使卫生; 使清洁; 使消毒 | 由 sanitary“卫生的”派生<br>使清洁、消毒; 也可指删去敏感内容 |
| insanity<br><br>n. 神志不清; 精神错乱; 精神病 | insane→insan(词: 患精神病的), -ity(性质, 状态)<br>由“患精神病的”派生为当前词义 |
| sanatorium<br><br>n. 疗养院; 休养地 | 源自现代拉丁语 sanatorium, 核心 sanare 表示治疗<br>供病人疗养康复的场所 |
| sanitarian<br><br>n. 公共卫生学家<br>adj. 卫生的; 保健的 | 源自 sanitary“卫生的”形成, 词干 sanit- 最终与拉丁语 sanitas“健康”相关<br>从事公共卫生工作的人, 即卫生专家 |
| sanitation<br><br>n. 公共卫生; 环境卫生 | 由 sanitary“卫生的”相关词干派生, 核心 sanus 表示健康<br>保持环境卫生的措施 |
| sanity<br><br>n. 神志正常; 心智健全 | **san(健全, 健康)**, -ity(性质, 状态)<br>表示与“健全”有关的性质或状态, 即“神志正常, 心智健全” |
| insane<br><br>adj. 发狂的; 患精神病的; 疯狂的 | in-(无, 不, 非), sane(词: 精神健全的)<br>精神不健全的; 也可口语表示极端荒唐 |
| salubrious<br><br>adj. 有益健康的 | **salub(健全, 健康)**, r(连接字母), -ious(…的)<br>表示与“健康”有关或具有该特征, 即“有益健康的” |
| salutary<br><br>adj. 有益健康的 | **salut(健全, 健康)**, -ary(…的)<br>围绕“健康”这一核心含义构成, 表示“有益健康的” |
| sane<br><br>adj. 健康的; 没有疾病的; 神志正常的; 心智健全的; 理智的 | 源自拉丁语 sanus“健康的、健全的”<br>由身体健康发展为心智健全 |
| sanitary<br><br>adj. 卫生的; 关心环境卫生的; 清洁的 | 源自拉丁语 sanitas“健康”形成的形容词<br>与保持健康和环境卫生有关的 |
| unsanitary<br><br>adj. 有碍健康的; 不卫生的 | un-(无, 不, 非), sanitary(词: 卫生的)<br>否定或缺少“卫生的”所指的性质, 因此表示“有碍健康的, 不卫生的” |


### sangui(n)

血

| 单词 | 拆解 |
| --- | --- |
| consanguinity<br><br>n. 同血缘; 同宗 | 源自拉丁语 consanguinitas, 由 con“共同”与 sanguis“血”构成<br>共享血缘, 即血亲关系 |
| consanguineous<br><br>adj. 同血缘的; 同宗的; 血亲的 | con-(与, 共同), **sanguin(血)**, -eous(…的)<br>使“血”共同结合或发挥作用, 因此表示“同血缘的, 同宗的, 血亲的” |
| sanguinary<br><br>adj. 血淋淋的; 血腥的; 嗜血成性的; 残忍的 | **sanguin(血)**, -ary(…的)<br>围绕“血”这一核心含义构成, 表示“血淋淋的, 血腥的” |


### sarc(o)

肉

| 单词 | 拆解 |
| --- | --- |
| osteosarcoma<br><br>n. 骨肉瘤 | **osteo(骨)**, **sarc(肉)**, -oma(肿瘤, 肿块)<br>由“骨”与“肉”共同限定词义, 表示“骨肉瘤” |
| sarcoma<br><br>n. 肉瘤 | **sarc(肉)**, -oma(肿瘤, 肿块)<br>围绕“肉”这一核心含义构成, 表示“肉瘤” |
| sarcoid<br><br>adj. 肉的; 肉状的; 肉质的 | **sarc(肉)**, -oid(似…的（物）)<br>形状像“肉”, 即“肉的” |


### sat(i), satis, satur

足, 饱

| 单词 | 拆解 |
| --- | --- |
| sate<br><br>v. 使充分满足; 使饱享 | 古英语本土动词, 核心义为使人获得充分满足<br>表示使吃饱、使满足 |
| satisfy<br><br>v. 使满足; 使满意 | **satis(足, 饱)**, -fy(…化, 做…)<br>在前词基础上加“-fy”构成动词, 表示“使满足,使满意” |
| saturate<br><br>v. 使湿透; 使饱和 | **satur(足, 饱)**, -ate(做, 使)<br>使达到完全充满的状态, 即饱和、浸透 |
| dissatisfaction<br><br>n. 不满 | dis-(否定, 相反), **satis(足, 饱)**, -faction(制作, 形成)<br>由“否定”与“满”共同限定词义, 表示“不满” |
| satiation<br><br>n. 充分满足; 饱享 | **sati(足, 饱)**, -ation(行为, 结果)<br>围绕“足”这一核心含义构成, 表示“充分满足, 饱享” |
| satiety<br><br>n. 饱足; 厌腻 | **sati(足, 饱)**, -ety(性质, 状态)<br>围绕“足”这一核心含义构成, 表示“饱足” |
| supersaturation<br><br>n. 过饱和 (现象) | super-(超), **satur(足, 饱)**, -ation(行为, 结果)<br>由“上”与“饱”共同限定词义, 表示“过饱和 (现象)” |
| insatiate<br><br>adj. 不满足的 | 构词锚点：in 表示“无, 不, 非”; sati 表示“足, 饱, 满”; -ate 在此为形容词词尾, 不取动词义<br>否定或缺少“足”所指的性质, 因此表示“不满足的” |
| satisfiable<br><br>adj. 能满足的 | satisfy→satisfi(词: 满足), -able(可…的)<br>能够得到满足的 |
| unsatisfactory<br><br>adj. 不能令人满意的; 不得人心的; 不符合要求的; 不足的 | un-(无, 不, 非), satisfactory(词: 令人满意的)<br>不能令人满意或未达到标准的 |
| unsaturated<br><br>adj. 不饱和的; 未饱和的; 非饱和的 | un-(无, 不, 非), **satur(足, 饱)**, -at(…的), -ed(…的)<br>否定或缺少“饱”所指的性质, 因此表示“不饱和的, 未饱和的, 非饱和的” |


### scend, scens, scent

攀爬

| 单词 | 拆解 |
| --- | --- |
| ascend<br><br>v. 上升; 登高; 攀登 | 源自拉丁语 ascendere, 由 ad“向”与 scandere“攀爬”形成<br>向上攀爬, 即上升 |
| condescend<br><br>v. 谦逊; 俯就; 屈尊 | con-(与, 共同), de-(下降, 降低), **scend(攀爬)**<br>向下爬 |
| descend<br><br>v. 下降; 传下; 遗传; 下来 | de-(下降, 降低), **scend(攀爬)**<br>从较高处向下攀行, 因此表示下降 |
| ascendency<br><br>n. 优势; 支配地位 | 词形来源：ascendancy |
| ascension<br><br>n. 上升; 升高 | 源自拉丁语 ascendere“向上攀爬”形成 ascensio<br>向上升起的过程, 即上升、升天 |
| descendent<br><br>n. 子孙; 后代; 后裔 | 词形来源：descendant |
| descender<br><br>n. 下降者; 下降物 | descend(词: 下降), -er(人)<br>在前词基础上加“-er”构成名词, 表示“下降者” |
| descent<br><br>n. 下降; 血统; 遗传 | de-(下降, 降低), **scent(攀爬)**<br>从较高处向下攀行的过程, 即下降; 也可指血统、来源 |
| transcendent<br><br>adj. 卓越的; 出类拔萃的; 超常的<br>n. 卓越的人; 超绝物 | transcend(词: 超越), -ent(…的)<br>由“超越”派生为当前词义 |


### sci

知

| 单词 | 拆解 |
| --- | --- |
| conscience<br><br>n. 良心; 良知; 内疚; 愧疚 | con-(与, 共同; 彻底, 完全, 加强), **sci(知)**, -ence(性质, 状态)<br>人与自己共同知道、在内心作判断的意识, 即良心 |
| consciousness<br><br>n. 意识; 觉悟; 知觉 | conscious(词: 有意识的), -ness(性质, 状态)<br>在前词基础上加“-ness”构成名词, 表示“意识” |
| geoscience<br><br>n. 地球科学 | **geo(地)**, science(词: 科学)<br>研究地球系统的科学 |
| omniscience<br><br>n. 全知; 无所不知; 无限知识 | omni-(全, 总, 泛), **sci(知)**, -ence(性质, 状态)<br>由“全”与“知”共同限定词义, 表示“全知, 无所不知” |
| pseudoscience<br><br>n. 假科学; 伪科学 | pseudo-(假的), science(词: 科学)<br>由“假的”与“科学”共同限定词义, 表示“假科学, 伪科学” |
| science<br><br>n. 科学 | **sci(知)**, -ence(性质, 状态)<br>系统的知识 |
| scientist<br><br>n. 科学家 | science→scient(词: 科学), -ist(人)<br>从事科学研究的人 |
| conscientious<br><br>adj. 凭良心的; 诚心的; 认真的 | 经法语借自中世纪拉丁语 conscientiosus, 来自 conscientia“良知”<br>受良知约束而认真负责的 |
| conscious<br><br>adj. 意识到的; 有知觉的 | con-(与, 共同), **sci(知)**, -ous(…的)<br>知道得清楚的 |
| prescient<br><br>adj. 预知的; 有先见之明的 | pre-(先于, 预先), **sci(知)**, -ent(…的)<br>由“先”与“知”共同限定词义, 表示“预知的, 有先见之明的” |
| subconscious<br><br>adj. 下意识的; 潜意识的 | sub-(在下, 向下), con-(与, 共同), **sci(知)**, -ous(…的)<br>位于清醒意识之下的心理活动, 因此表示潜意识的 |
| unconscious<br><br>adj. 失去知觉的; 不省人事的; 无意识的; 未察觉的 | un-(无, 不, 非), conscious(词: 有意识的)<br>否定或缺少“意识的”所指的性质, 因此表示“无意识的, 不知不觉的” |


### scler(o)

硬; 巩膜

| 单词 | 拆解 |
| --- | --- |
| arteriosclerosis<br><br>n. [医] 动脉硬化 (症) | **arteri(动脉)**, o(连接元音), **scler(硬)**, -osis(状态, 过程)<br>由“动脉”与“硬”共同限定词义, 表示“动脉硬化 (症)” |
| sclera<br><br>n. 巩膜 | 借自现代拉丁语, 源自希腊语 skleros“坚硬”<br>眼球坚韧的白色外膜 |
| scleroderma<br><br>n. 硬皮病 | **sclero(硬)**, **derm(皮肤)**, a(连接字母)<br>由“硬”与“皮肤”共同限定词义, 表示“硬皮病” |
| sclerosis<br><br>n. 硬化(症) | **scler(硬)**, -osis(状态, 过程)<br>围绕“硬”这一核心含义构成, 表示“硬化(症)” |
| sclerotic<br><br>adj. 巩膜的; 硬化的 | **scler(硬)**, -otic(…的)<br>围绕“硬”这一核心含义构成, 表示“巩膜的, 硬化的” |


### scop

镜, 观察; 目标

| 单词 | 拆解 |
| --- | --- |
| microscope<br><br>n. 显微镜 | **micro(微, 小)**, **scop(镜, 观察)**, e(连接字母)<br>由“微”与“镜”共同限定词义, 表示“显微镜” |
| microscopy<br><br>n. 显微镜学; 显微镜检查 | **micro(微, 小)**, **scop(镜, 观察)**, y(连接字母)<br>在前词基础上加“-y”构成名词, 表示“显微镜学” |
| laryngoscope<br><br>n. 喉镜 | **laryngo(喉)**, **scop(镜, 观察)**, e(连接字母)<br>由“喉”与“镜”共同限定词义, 表示“喉镜” |
| ophthalmoscope<br><br>n. 检眼镜 | **ophthalmo(眼)**, **scop(镜, 观察)**, e(连接字母)<br>由“眼”与“镜”共同限定词义, 表示“检眼镜” |
| macroscopic<br><br>adj. 肉眼可见的; 宏观的 | **macro(长, 大)**, **scop(镜, 观察)**, -ic(…的)<br>大到可直接观察, 因此表示肉眼可见的、宏观的 |


### scrap

刮, 擦

| 单词 | 拆解 |
| --- | --- |
| scrape<br><br>n. 擦伤; 刮<br>v. 擦伤; 刮掉; 削去; 擦坏; 勉强获得 | 日耳曼语源, 受古诺尔斯语 skrapa 同源形式影响<br>表示用硬物刮擦表面 |
| scraper<br><br>n. 刮刀; 刮削器; 铲土机; 刮擦者 | **scrap(刮, 擦)**, -er(人)<br>进行刮削的人; 也可引申指刮削工具 |
| scraping<br><br>n. 刮擦的, 吝啬的; 刮, 擦, [常用复]刮削下来的碎屑<br>adj. 刮; 擦; 刮擦的; 吝啬的; [常用复]刮削下来的碎屑 | scrape→scrap(词: 刮擦), -ing(行为, 过程)<br>刮擦的行为、刮下的碎屑, 或具有刮擦特征的 |
| scrapper<br><br>n. 处理废料的人 | **scrap(刮, 擦)**, p(连接字母), -er(人)<br>表示从事或具有“刮”特征的人, 即“处理废料的人” |
| scrappy<br><br>adj. 由碎料做成的, 杂凑的; 片断的; 散漫的 | scrap→scrapp(词: 碎片), -y(充满…的, 有…特征的, 像…的)<br>由“碎片”派生为当前词义 |


### scrib, script

写

| 单词 | 拆解 |
| --- | --- |
| proscribe<br><br>v. (古罗马)公布(死囚等的)姓名 | pro-(向前, 前进), **scrib(写)**, e(连接字母)<br>原指把被放逐或处死者姓名公开写出, 后来表示禁止、剥夺 |
| inscription<br><br>n. 编入名单; 注册; 铭刻; 铭文; 碑文 | in-(向内, 进入), **scrip(写)**, -tion(行为, 结果)<br>写刻在物体表面之中的文字, 即铭文 |
| manuscript<br><br>n. 手写本; 手稿; 原稿 | **manu(手)**, **script(写)**<br>由“手”与“写”共同限定词义, 表示“手写本, 手稿, 原稿” |
| postscript<br><br>n. 信后的附言; (书后的)附录; 跋 | post-(在后, 之后), **script(写)**<br>由“在后”与“写”共同限定词义, 表示“信后的附言” |
| scripture<br><br>n. 手稿; 文稿; 文件 | **script(写)**, -ure(行为, 结果)<br>围绕“写”这一核心含义构成, 表示“手稿” |
| subscriber<br><br>n. 签名者; 签署者; 报刊订户 | sub-(在下, 向下), **scrib(写)**, -er(人)<br>在⋯下面写上自己的名字者 |
| subscription<br><br>n. 签名; 签署; 预订 | sub-(在下, 向下), **script(写)**, -ion(行为, 结果)<br>原指在文书下方签名, 后来扩展为订阅、认购 |
| transcript<br><br>n. 转抄; 誊写; 抄写; 副本 | 源自拉丁语 transcriptum, 与 transcribere“抄写”同源, 由 trans“转移”与 scribere“写”构成<br>转写所得的副本 |
| describable<br><br>adj. 可描写的; 可描绘的 | de-(一再等加强意义), **scrib(写)**, -able(可…的)<br>可以用文字清楚描写的 |
| descriptive<br><br>adj. 描写的; 描述的 | de-(一再等加强意义), **script(写)**, -ive(…的)<br>以文字描写事物特征的, 即描述性的 |
| scribal<br><br>adj. 抄写(员)的; 作者的 | **scrib(写)**, -al(…的)<br>表示与“写”有关或具有该特征, 即“抄写(员)的” |


### scrut

检查

| 单词 | 拆解 |
| --- | --- |
| scrutinize<br><br>v. 细看; 细阅; 仔细检查 | 由 scrutiny“仔细检查”派生; scrutiny 原指筛选碎屑<br>像筛选一样仔细检查 |
| scrutineer<br><br>n. 检查人; 监票人; [英] 选票检查人 | 源自 scrutiny（审查）派生, 表示负责仔细审查的人, 尤指检查选票的监票人 |
| scrutiny<br><br>n. 细看; 细阅; 仔细检查; 监视 | scrutinize→scrutin(词: 仔细检查), -y(活动)<br>在前词基础上加“-y”构成名词, 表示“细看” |
| scrutinizing<br><br>adj. 细看的; 仔细检查的 | 词形来源：scrutinize + ing-form |


### sec, secut, sequ,su

跟随, 伴随

| 单词 | 拆解 |
| --- | --- |
| execute<br><br>v. 处死; 处决; 实施; 执行; 实行 | 源自拉丁语 exsequi（贯彻到底、执行）, 表示实施计划或处决 |
| persecute<br><br>v. 迫害 | per-(通过, 贯穿), **secut(跟随, 伴随)**, e(连接字母)<br>一直跟随 |
| pursue<br><br>v. 追赶; 追踪; 追求; 从事; 追查 | 经古法语 poursuivre“跟随、追赶”进入英语<br>表示持续跟随目标并努力获得 |
| suit<br><br>v. 合适; 适合; 中…的意 | 源自古法语 suite“随从、相随的一组事物”<br>由彼此相随、相配发展出适合之义 |
| consequence<br><br>n. 结果; 影响; n -后果 | con-(与, 共同), **sequ(跟随, 伴随)**, -ence(性质, 状态)<br>紧随某事而来的结果, 因此表示后果、结果 |
| persecutor<br><br>n. 迫害着 | persecute→persecut(词: 迫害), -or(人)<br>实施迫害的人 |
| pursuit<br><br>n. 追赶; 追求; 职业; 工作 | 经古法语 poursuite“追赶、追求”进入英语<br>表示追求某目标的行动 |
| second<br><br>n. 秒; 瞬间; 第二名<br>v. 当...助手; 支持<br>adj. 第二的; 其次的; 次要的<br>num. 第二 | 经古法语借自拉丁语 secundus“跟随的、下一个”, 与 sequi“跟随”同源<br>跟在第一之后, 即第二 |
| consecutive<br><br>adj. 连贯的; 连续不断的 | con-(与, 共同), **secut(跟随, 伴随)**, -ive(…的)<br>一个紧跟着一个而没有中断, 因此表示连续的 |
| obsequious<br><br>adj. 卑躬的; 奉承的 | ob-(对着, 朝向, 在前), **sequ(跟随, 伴随)**, -ious(…的)<br>跟随在后的 |
| secondary<br><br>adj. 中等教育的; 次要的 | second(词: 次要的), -ary(…的)<br>跟随主要事物之后、处于第二位, 因此表示次要的、第二的 |
| subsequent<br><br>adj. 随后的; 后来的; 继…之后的 | sub-(在下, 向下), **sequ(跟随, 伴随)**, -ent(…的)<br>由“随后”与“跟随”共同限定词义, 表示“随后的, 后来的, 继…之后的” |
| suitable<br><br>adj. 合适的; 适宜的 | suit(词: 适合), -able(可…的)<br>能够与要求相配、适合使用的 |


### sect, seg

切, 分

| 单词 | 拆解 |
| --- | --- |
| bisect<br><br>v. 二等分; 平分 | bi-(两, 双), **sect(切, 分)**<br>由“两”与“分”共同限定词义, 表示“二等分, 平分” |
| intersect<br><br>v. 交叉; 横切 | inter-(在...之间), **sect(切, 分)**<br>由“在…之间”与“切”共同限定词义, 表示“交叉, 横切” |
| transect<br><br>v. 横切; 切断; 横断 | tra-(横过, 越过), n(连接字母), **sect(切, 分)**<br>由“横越”与“切”共同限定词义, 表示“横切, 切断, 横断” |
| dissector<br><br>n. 解剖者; 解剖学家; 解剖器 | dis-(分离, 除去), **sect(切, 分)**, -or(人)<br>进行解剖的人; 也可引申指解剖器具 |
| insect<br><br>n. 昆虫; 类似昆虫的小动物; 卑鄙的人<br>adj. 昆虫的; 卑劣的 | in-(向内, 进入), **sect(切, 分)**<br>身体像被切分成若干部段的动物, 即昆虫 |
| section<br><br>n. 部分; 部门; 截面; 章节; 剖视图<br>v. 切断; 划分 | **sect(切, 分)**, -ion(行为, 结果)<br>围绕“切”这一核心含义构成, 表示“切开, 切断” |
| segment<br><br>n. 部分; 片断; 切片 | **seg(切, 分)**, -ment(物)<br>从整体中切分出来的一部分或片段 |
| segmentation<br><br>n. 分割; 切断; 分节; 细胞分裂 | segment(词: 分割), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“分割” |
| vivisection<br><br>n. 活体解剖 | **vivi(活)**, **sect(切, 分)**, -ion(行为, 结果)<br>对活体进行切开研究的行为 |


### seism(o)

地震

| 单词 | 拆解 |
| --- | --- |
| seismogram<br><br>n. 震波图; 地震波曲线 | **seismo(地震)**, **gram(书写, 记录)**<br>由“地震”与“书写”共同限定词义, 表示“震波图, 地震波曲线” |
| seismograph<br><br>n. 地震仪 | **seismo(地震)**, **graph(写, 画)**<br>记录或描绘“地震”的方法, 即“地震仪” |
| seismologist<br><br>n. 地震学者 | **seismo(地震)**, -logist(…学家)<br>在前词基础上加“-logist”构成名词, 表示“地震学者” |
| seismology<br><br>n. 地震学 | **seismo(地震)**, -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“地震学” |
| seismological<br><br>adj. 地震学的 | **seismo(地震)**, -logical(…学的)<br>围绕“地震”这一核心含义构成, 表示“地震学的” |


### selen(o)

月球

| 单词 | 拆解 |
| --- | --- |
| Selene<br><br>n. (希腊神话中的)月神 | **selen(月球)**, e(连接字母)<br>希腊神话中月亮的拟人化神祇 |
| Selenite<br><br>n. (想像中的)月球居民 | **selen(月球)**, -ite(人)<br>围绕“月球”这一核心含义构成, 表示“(想像中的)月球居民” |
| selenology<br><br>n. 月球学; 月球地质学 | **selen(o)(月球)**, -logy(…学, …研究)<br>研究月球及其地质物理构造的学科, 即月球学 |


### selen(i)

硒

| 单词 | 拆解 |
| --- | --- |
| selenium<br><br>n. 硒 | **selen(月球)**, -ium(化学元素或阳离子)<br>词根本身即表示“硒”, 整词沿用该义 |
| selenography<br><br>n. 月面学; 月球地形学 | **selen(i)(硒)**, o(连接元音), **graph(写, 画)**, -y(活动)<br>绘制并研究月球表面地形特征的学科 |


### sembi, simil, simul

相同, 相似

| 单词 | 拆解 |
| --- | --- |
| assemble<br><br>v. 组装; 集合; 装配 | as-(到, 朝, 向), **sembl(相同, 相似)**, e(连接字母)<br>把相同或相关部分聚到一起, 因此表示集合、装配 |
| assimilate<br><br>v. 同化; 使相同 | as-(到, 朝, 向), **simil(相同, 相似)**, -ate(做, 使)<br>使事物变得与周围相同或相似, 因此表示同化、吸收 |
| resemble<br><br>n. 类似; 像<br>v. 类似; 相似; 与……相像; 与相像 | re-(回, 向后, 再次), **sembl(相同, 相似)**, e(连接字母)<br>与某人某物呈现相似形态, 因此表示像、类似 |
| simulate<br><br>v. 模仿; 模拟; 假装; 冒充 | **simul(相同, 相似)**, -ate(做, 使)<br>围绕“相同”这一核心含义构成, 表示“模仿, 模拟” |
| semblance<br><br>n. 假象; 外表; 貌似物; 类似 | **sembl(相同, 相似)**, -ance(性质, 状态)<br>表示与“相似”有关的性质或状态, 即“相似, 貌似物” |
| similar<br><br>n. 类似物<br>adj. 相似的; 类似的 | **simil(相同, 相似)**, -ar(…的)<br>围绕“相似”这一核心含义构成, 表示“相似的(东西), 类似的(东西)” |
| simile<br><br>n. 比喻; 明喻; 直比 | **simil(相同, 相似)**, e(连接字母)<br>相似, 引申为比喻 |
| similitude<br><br>n. 相似; 类似(物) | **simil(相同, 相似)**, -itude(性质, 状态)<br>围绕“相似”这一核心含义构成, 表示“相似, 类似(物)” |
| simulacrum<br><br>n. 像; 影; 幻影; 模拟物; 假的东西 | 源自拉丁语 simulacrum“形象、肖像”<br>表示与原物相似的形象、幻象或复制品 |
| simulation<br><br>n. 模仿; 模拟; 假装; 冒充 | **simul(相同, 相似)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“模仿” |
| simulator<br><br>n. 模拟器; 模拟装置; 假装者; 模仿者 | **simul(相同, 相似)**, -ator(物)<br>产生与真实环境相似效果的装置, 即模拟器 |
| simulcast<br><br>n. 同步联播节目<br>v. 同步联播 | **simul(相同, 相似)**, **cast(投, 发射)**<br>由“相同”与“投”共同限定词义, 表示“无线电和电视同时联播节目” |
| simultaneity<br><br>n. 同时发生; 同时存在; 同时性 | 由 simultaneous“同时的”派生, 核心拉丁语 simul 表示同时<br>同时发生或存在的性质 |
| verisimilitude<br><br>n. 逼真(的事物); 貌似真实(的事物) | **veri(真实)**, **simil(相同, 相似)**, -itude(性质, 状态)<br>由“真实”与“相似”共同限定词义, 表示“逼真, 貌似真实(的事物)” |
| simulant<br><br>adj. 假装的; 模拟的; 拟态的 | **simul(相同, 相似)**, -ant(…的)<br>围绕“相同”这一核心含义构成, 表示“假装的, 模拟的” |
| simultaneous<br><br>adj. 同时发生的; 同时存在的; 同时的; 一齐的; 同时发生（或进行）的 | **simul(相同, 相似)**, t(连接字母), -aneous(…的)<br>同一时间 |


### semei(o)

症状, 符号

| 单词 | 拆解 |
| --- | --- |
| semeiology<br><br>n. 症状学; 符号学 | **semeio(症状, 符号)**, -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“症状学” |
| semeiotic<br><br>adj. 症状的; 符号学的 | **semei(o)(症状, 符号)**, -tic(…的)<br>与符号表达或疾病征候特征相关的 |


### sen

老

| 单词 | 拆解 |
| --- | --- |
| senate<br><br>n. 大学理事会; (美国等国家的)参议院 | 构词锚点：sen 表示“老”; -ate 在此为名词或形容词词尾, 不取动词义<br>围绕“老”这一核心含义构成, 表示“(古罗马的) 元老院” |
| senator<br><br>n. (古罗马) 元老院的议员; 参议员; 上议员 | **sen(老)**, -ator(人)<br>在前词基础上加“-or”构成名词, 表示“古罗马” |
| senescence<br><br>n. 衰老; 老朽 | **sen(老)**, -escence(开始或正在形成某种状态)<br>围绕“老”这一核心含义构成, 表示“衰老, 老朽” |
| senility<br><br>n. 衰老; 老迈; 老态龙钟 | **sen(老)**, -ility(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“衰老” |
| senior<br><br>n. 年长者; 资深人士; 毕业班学生<br>adj. 资深的; 年长的; 高级的 | **sen(老)**, -ior(较…的)<br>围绕“老”这一核心含义构成, 表示“美］(大学或高中)毕业班学生” |
| seniority<br><br>n. 年长; 资历深; 职位高 | senior(词: 年长者), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“年长” |
| senatorial<br><br>adj. 元老院 (议员) 的; 参议院的; 参议员的 | 源自拉丁语 senatorius, 与 senator“元老、参议员”同源<br>与参议院或参议员有关的 |
| senescent<br><br>adj. 衰老的; 老朽的 | **sen(老)**, -escent(开始或正在形成…的)<br>围绕“老”这一核心含义构成, 表示“衰老的, 老朽的” |
| senile<br><br>adj. 老年 (期) 的; 衰老的; 年老所致的 | **sen(老)**, -ile(…的)<br>围绕“老”这一核心含义构成, 表示“老年 (期) 的” |


### sens, sent

感觉

| 单词 | 拆解 |
| --- | --- |
| assent<br><br>v. 赞同 | 源自拉丁语 assentire“同意”, 由 ad“向”与 sentire“感觉、意见”形成<br>使自己的意见朝向并符合他人, 即赞同 |
| consent<br><br>n. 同意; 许可<br>v. 同意; 允许 | 源自拉丁语 consentire（共同感受、意见一致）, 由“共同持有一种看法”引申为同意 |
| desensitization<br><br>n. 脱敏 (现象) | de-(脱离, 取消, 除去), sensitive→sensit(词: 敏感), -ization(行为, …化)<br>使敏感反应降低或消失的过程, 即脱敏 |
| dissension<br><br>n. 意见分歧; 争论; 不和; 纠纷 | dis-(否定, 相反), **sens(感觉)**, -ion(行为, 结果)<br>由“分离”与“感觉”共同限定词义, 表示“意见分歧, 争论” |
| extrasensory<br><br>adj. 超感官的; 感官以外的 | extra-(超过, 额外), **sens(感觉)**, -ory(…的)<br>由“以外, 超过”与“感觉”共同限定词义, 表示“超感觉的” |
| hypersensitive<br><br>adj. 过敏的 | hyper-(超过, 极度), **sens(感觉)**, -itive(…的)<br>由“超过”与“感觉”共同限定词义, 表示“过敏的” |
| insensible<br><br>adj. 无感觉的; 失去知觉的 | in-(无, 不, 非), **sens(感觉)**, -ible(可…的)<br>否定或缺少“感觉”所指的性质, 因此表示“无感觉的” |


### serv, serf

奴, 服务

| 单词 | 拆解 |
| --- | --- |
| subserve<br><br>v. 对…有帮助; 辅助; 促进 | sub-(在下, 向下), **serv(奴, 服务)**, e(连接字母)<br>从侧面服务 |
| disservice<br><br>n. 危害; 损害 | 由 dis“相反、损害”与 service“帮助”构成<br>看似服务却造成损害 |
| serf<br><br>n. 农奴 | **serf(奴, 服务)**<br>受土地和领主束缚的农奴 |
| serfdom<br><br>n. 农奴制; 农奴地位; 奴役 | **serf(奴, 服务)**, -dom(性质, 状态)<br>在前词基础上加“-dom”构成名词, 表示“农奴制” |
| servant<br><br>n. 仆人; 佣人; (公司或机构的)雇员; 奴仆般受制(或献身)于…的人 | **serv(奴, 服务)**, -ant(人; 物)<br>从事服务的人, 即仆人、雇员 |
| servility<br><br>n. 奴性; 奴态; 屈从 | **serv(奴, 服务)**, -ility(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“奴性” |
| servitude<br><br>n. 奴隶状态; 奴役; 苦役 | **serv(奴, 服务)**, -itude(性质, 状态)<br>围绕“奴”这一核心含义构成, 表示“奴隶状态” |
| serviceable<br><br>adj. 有用的; 肯帮忙的 | **serv(奴, 服务)**, -ice(性质, 状态), -able(可…的)<br>围绕“服务”这一核心含义构成, 表示“有用的, 肯帮忙的” |
| servile<br><br>adj. 奴隶(般)的; 奴性的 | **serv(奴, 服务)**, -ile(…的)<br>围绕“奴”这一核心含义构成, 表示“奴隶(般)的, 奴性的” |
| subservient<br><br>adj. 辅助性的; 有帮助的; 顺从的; 奉承的 | 源自拉丁语 subserviens“辅助、服侍的”<br>由服务于某目的引申为顺从奉承的 |


### serv

保持, 留心

| 单词 | 拆解 |
| --- | --- |
| observe<br><br>v. 观察; 注意到; 遵守; 奉行; 评论说 | ob-(对着, 朝向, 在前), **serv(保持, 留心)**, e(连接字母)<br>把注意力保持在眼前对象上, 即观察; 也引申为遵守 |
| preserve<br><br>v. 保护; 保存; 维持(原状); 保藏; 腌制<br>n. 保护区; 蜜饯 | pre-(先于, 预先), **serv(保持, 留心)**, e(连接字母)<br>预先留心并保持事物原状, 即保护或保存 |
| conservation<br><br>n. 保存; 保护; 守恒; 不灭 | con-(与, 共同), **serv(保持, 留心)**, -ation(行为, 结果)<br>共同把资源保持下来的行为, 即保护或保存 |
| conserve<br><br>n. 蜜饯; 果脯<br>v. 节省; 保护; 节约; 保存 | con-(与, 共同), **serv(保持, 留心)**, e(连接字母)<br>把资源完整保持下来, 即保存或节约 |
| observance<br><br>n. 遵守; 奉行; 惯例; 仪式 | ob-(对着, 朝向, 在前), **serv(保持, 留心)**, -ance(性质, 状态)<br>认真留心并按规定行事, 即遵守、奉行或惯例 |
| observatory<br><br>n. 天文台; 气象台; 了望台 | ob-(对着, 朝向, 在前), **serv(保持, 留心)**, -atory(场所)<br>持续留心观察天体等对象的场所, 即观测台 |
| reserve<br><br>n. 储备品; 贮量; 后备军<br>v. 保留; 保存; 预订 | re-(回, 向后, 再次), **serv(保持, 留心)**, e(连接字母)<br>把一部分留在后面以备使用, 即保留或预订 |
| reservist<br><br>n. 后备役军人 | reserve→reserv(词: 保留), -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“后备役军人” |
| reservoir<br><br>n. 贮水池; 贮藏处; 贮备<br>v. 储藏 | 直接借自法语 réservoir（储存处）, 表示水库或储液器 |
| observing<br><br>adj. 注意的; 留心的; 观察力敏锐的 | ob-(对着, 朝向, 在前), **serv(保持, 留心)**, -ing(…的)<br>持续留心观察的, 即注意敏锐的 |
| reserved<br><br>adj. 保留的; 预定的; 缄默的; 储蓄的 | reserve→reserv(词: 保留), -ed(…的)<br>在前词基础上加“-ed”构成形容词, 表示“保留的” |


### set

放

| 单词 | 拆解 |
| --- | --- |
| settle<br><br>v. 解决; 定居; 安放; 结算支付; 降落 | 源自古英语 setlan“使安定、安置”<br>由使某物安稳放置发展出定居、解决、结算等义 |
| unsettle<br><br>v. 不安宁; 混乱 | un-(反, 相反动作), settle(词: 使安定)<br>使原本安定的状态发生相反变化, 即扰乱或使不安 |
| upset<br><br>v. 使不安; 使心烦意乱; 使生气; 搅乱; 打翻<br>adj. 心烦的 | **up(上, 向上)**, **set(放)**<br>把原来安放好的状态掀翻, 因此表示推翻、扰乱或使不安 |
| setback<br><br>n. 挫折; 阻碍 | set(词: 使处于), back(词: 向后)<br>使进展后退的事情, 即挫折 |
| setting<br><br>n. 背景; 环境; 情节背景 | **set(放)**, t(连接字母), -ing(物)<br>把事物放在某种位置或环境中的过程, 也指背景设定 |
| settlement<br><br>n. 协议; 和解; 定居地; 定居点; 清偿; 结算; 沉降; 下陷; 村落; 殖民(地) | 由 settle（安定、解决）派生; 核心锚点是“使事情安定下来”, 由此表示定居过程、定居点、协议、解决或结算 |
| settled<br><br>adj. 固定的; 不变的; 永久的; 定居的; 付清的 | 词形来源：settle + ed-form |


### sid, sed, sess

坐

| 单词 | 拆解 |
| --- | --- |
| obsess<br><br>v. 使着迷; 使沉迷; 使迷恋; （使）痴迷; （使）心神不宁 | ob-(对着, 朝向, 在前), **sess(坐)**<br>由“对着”与“坐”共同限定词义, 表示“使着迷, 使痴迷” |
| preside<br><br>v. 作会议的主席; 主持; 指挥; 统辖 | pre-(先于, 预先), **sid(坐)**, e(连接字母)<br>坐在前面主要位置上 |
| reside<br><br>v. 居住; 存在 | re-(回, 向后, 再次), **sid(坐)**, e(连接字母)<br>在某处安坐并长期停留, 因此表示居住 |
| supersede<br><br>v. 取代; 凌驾于 | super-(上), **sed(坐)**, e(连接字母)<br>坐到其上取而代之, 即"取代" |
| dissidence<br><br>n. 意见不同; 不一致; 不同意; 异议 | dis-(否定, 相反), **sid(坐)**, -ence(性质, 状态)<br>与众人分开坐, 形象地表示意见不同、持异议 |
| dissident<br><br>adj. 意见不同的; 持不同政见的<br>n. 意见不同的人; 持不同政见者 | 源自拉丁语 dissidens“意见不同的”, 由 dis“分开”与 sedere“坐”构成<br>坐在不同一边的人, 即持异议者 |
| president<br><br>n. 总统; 大学校长; 会长; 总裁; 董事长 | pre-(先于, 预先), **sid(坐)**, -ent(人; 物)<br>坐在众人前方主持事务的人, 即主席或总统 |
| presidium<br><br>n. 主席团 | 直接借自拉丁语 praesidium“保护、驻守”, 现代政治义经俄语传入<br>常务主席团或最高领导机构 |
| resident<br><br>n. 居民; 住户<br>adj. 居住的; 定居的 | re-(回, 向后, 再次), **sid(坐)**, -ent(人; 物)<br>在某地安居的人, 即居民 |
| sediment<br><br>n. 沉淀物; 沉积物 | **sed(坐)**, i(连接字母), -ment(物)<br>沉坐到底部的物质, 即沉淀物或沉积物 |
| session<br><br>n. (进行某活动的)一段时间; 会议; 会期 | **sess(坐)**, -ion(行为, 结果)<br>围绕“坐”这一核心含义构成, 表示“会议, 一届会期” |
| subsidence<br><br>n. 沉降; 沉淀; 平息 | sub-(在下, 向下), **sid(坐)**, -ence(性质, 状态)<br>地面或结构向下沉降, 仿佛坐下, 因此表示下沉、沉降 |
| assiduous<br><br>adj. 勤勉的; 刻苦的 | as-(到, 朝, 向), **sid(坐)**, -uous(…的)<br>能坐得住的 |
| considerable<br><br>adj. 相当大的; 相当重要的; 相当多的 | consider(词: 考虑), -able(可…的)<br>本义为值得考虑的, 由“不可忽视”引申为相当大的 |
| considerate<br><br>adj. 体谅的; 周全的; 考虑周到的 | consider(词: 考虑), -ate(…的)<br>会考虑他人需要和感受的, 即体贴的 |
| residential<br><br>adj. 居住的; 住宅的 | resident(词: 居住者), -ial(…的)<br>在前词基础上加“-ial”构成形容词, 表示“居住的” |
| residual<br><br>adj. 残余的; 残存的 | re-(回, 向后, 再次), **sid(坐)**, -ual(…的)<br>留在老地方 |
| sessional<br><br>adj. 开会的; 会议的; 开庭的; 法庭的 | session(词: 期间), -al(…的)<br>由“期间”派生为当前词义 |
| subsidiary<br><br>adj. 辅助的; 次要的 | sub-(在下, 向下), **sid(坐)**, i(连接字母), -ary(…的)<br>坐在次要位置上的 |


### sign

记号, 做记号

| 单词 | 拆解 |
| --- | --- |
| assign<br><br>v. 分配; 指派; 布置; 指定; 确定 | as-(到, 朝, 向), **sign(记号, 做记号)**<br>给人或任务作上特定标记、划归某处, 因此表示指派、分配 |
| designate<br><br>v. 指明; 选派; 指派 | de-(一再等加强意义), **sign(记号, 做记号)**, -ate(做, 使)<br>给人或事物作上明确标记, 即指定、命名 |
| assignment<br><br>n. 委派的任务; 指定工作; 家庭作业; （布置的）作业; （分派的）任务 | as-(到, 朝, 向), **sign(记号, 做记号)**, -ment(结果)<br>经过指定、标记后形成的任务或作业 |
| design<br><br>n. 设计; 图样; 意图<br>v. 设计; 构思; 计划 | de-(一再等加强意义), **sign(记号, 做记号)**<br>给事物作出明确标记并规划方案, 即设计 |
| signal<br><br>n. 信号; 暗号<br>v. 发信号; 表明<br>adj. 显著的 | **sign(记号, 做记号)**, -al(…的)<br>围绕“记号”这一核心含义构成, 表示“信号, 暗号” |
| signatory<br><br>adj. 签署的; 签约的<br>n. 协议的签署者; 签约国 | **sign(记号, 做记号)**, -atory(…的)<br>围绕“记号”这一核心含义构成, 表示“签署者, 签约国” |


### sino, sinic(o)

中国

| 单词 | 拆解 |
| --- | --- |
| Sinology<br><br>n. 汉学; 中国学 | **sino, sinic(o)(中国)**, -logy(…学, …研究)<br>专门研究中国历史、语言、文化与社会的学术领域 |
| Sinophile<br><br>n. 亲华者; 赞赏中国文化者<br>adj. 亲华的 | **sino, sinic(o)(中国)**, **phil(o)(爱)**<br>极度热爱并赞赏中国传统文化与社会的人 |


### sinu

弯曲, 凹处

| 单词 | 拆解 |
| --- | --- |
| insinuate<br><br>v. 暗示 | in-(向内, 进入), **sinu(弯曲, 凹处)**, -ate(做, 使)<br>沿弯曲缝隙悄悄进入, 比喻委婉暗示 |
| sinus<br><br>n. 湾; 穴; 弯 | 直接来自拉丁语 sinus“弯曲、海湾、凹处”<br>由弯曲凹处引申为鼻窦等腔隙 |
| sinusoid<br><br>n. 正弦曲线 | **sinu(弯曲, 凹处)**, s(连接字母), -oid(似…的（物）)<br>形状像“弯曲”, 即“正弦曲线” |
| sinuous<br><br>adj. 蜿蜒弯曲的; 迂回的; 错综复杂的 | **sinu(弯曲, 凹处)**, -ous(…的)<br>表示与“弯曲”有关或具有该特征, 即“蜿蜒的, 弯曲的” |


### sist

立

| 单词 | 拆解 |
| --- | --- |
| assist<br><br>v. 帮助; 援助; 辅助; 协助 | as-(到, 朝, 向), **sist(立)**<br>站到其身旁支持, 即"帮助" |
| desist<br><br>v. 停止 | de-(脱离, 取消, 除去), **sist(立)**<br>从原有行动中退开并停住, 即停止 |
| insist<br><br>v. 坚决主张; 坚持; 坚决认为（或主张、要求） | in-(向内, 进入), **sist(立)**<br>站定在某一立场中, 即坚持 |
| persist<br><br>v. 坚持; 持续 | per-(通过, 贯穿), **sist(立)**<br>始终站稳、不从原处退开, 因此表示坚持、持续 |
| subsist<br><br>v. 生存; 存在 | sub-(在下, 向下), **sist(立)**<br>继续保持 |
| assistant<br><br>n. 助手; 助理<br>adj. 助理的; 辅助的 | as-(到, 朝, 向), **sist(立)**, -ant(人; 物)<br>站在旁边提供协助的人, 即助手 |
| existence<br><br>n. 存在(物) | exist(词: 存在), -ence(性质, 状态)<br>由“存在”派生为当前词义 |
| resister<br><br>n. 抵抗者; 反抗者 | re-(回, 向后, 再次), **sist(立)**, -er(人)<br>站出来抵抗的人, 即抵抗者、反抗者 |
| consistent<br><br>adj. 一致的; 协调的; 一贯的; —致的; （观点或看法）连贯的 | con-(与, 共同), **sist(立)**, -ent(…的)<br>站在一起 |
| irresistible<br><br>adj. 不可抵抗的; 不可抗拒的 | ir-(无, 不, 非), re-(回, 向后, 再次), **sist(立)**, -ible(可…的)<br>不可坚持的 |
| persistent<br><br>adj. 坚持的; 持久的 | persist(词: 坚持), -ent(…的)<br>在前词基础上加“-ent”构成形容词, 表示“坚持的” |
| resistive<br><br>adj. 抵抗(性)的 | resist(词: 抵抗), -ive(…的)<br>在前词基础上加“-ive”构成形容词, 表示“抵抗” |


### sit(o)

食物

| 单词 | 拆解 |
| --- | --- |
| parasite<br><br>n. 寄生虫; 寄生菌; 寄生物 | 源自希腊语 parasitos（在旁边吃饭的人）, 后来指依附他者生活的生物或人 |
| parasitism<br><br>n. 寄生 (现象); 寄生状态 | 由 parasite“寄生生物”形成<br>一种生物依赖并损害宿主生存的关系, 即寄生 |
| parasitology<br><br>n. 寄生虫学; 寄生物学 | 由 parasite“寄生物”与 logy“研究”构成<br>研究寄生生物及其宿主关系的学科 |
| parasitical<br><br>adj. 寄生的; 由寄生虫引起的 | parasite→parasit(词: 寄生生物), -ical(…的)<br>在前词基础上加“-ical”构成形容词, 表示“寄生的” |


### situ(t)

放, 建立

| 单词 | 拆解 |
| --- | --- |
| situate<br><br>v. 使位于; 使坐落于; 将…置于背景中 | **situ(t)(放, 建立)**, -ate(做, 使)<br>将建筑、位置或事件放置在特定地理或背景环境中 |
| situation<br><br>n. 形势; 处境; 状况; 位置 | situate→situat(词: 位于), -ion(行为, 结果)<br>人或事物所处的具体位置环境与发展态势 |


### soci(o)

结伴, 社会

| 单词 | 拆解 |
| --- | --- |
| associate<br><br>n. 伙伴; 同事<br>v. 联系; 结交<br>adj. 副的; 准的 | as-(到, 朝, 向), **soci(结伴, 社会)**, -ate(做, 使)<br>强化“结伴”这一动作或状态, 因此表示“把…联系在一起, 交往” |
| association<br><br>n. 协会; 社团; 联合; 交往; 联想 | associate→associat(词: 联系; 结交), -ion(行为, 结果)<br>把人或事物联系在一起的过程或组织 |
| sociable<br><br>adj. 好交际的; 社交的; 过社会生活的<br>n. 联谊会 | **soci(结伴, 社会)**, -able(可…的)<br>围绕“结伴”这一核心含义构成, 表示“好交际的, 喜欢群居的” |
| social<br><br>adj. 社会的; 社交的<br>n. 联欢会; 社交聚会 | **soci(结伴, 社会)**, -al(…的)<br>结伴共处于社会中的, 即"群居的" |
| socialism<br><br>n. 社会主义 | social(词: 社会的), -ism(主义)<br>表示与“社会”有关的性质或状态, 即“社会主义” |
| sociality<br><br>n. 好交际; 社交性; 社交行为; 社会性; 群居性 | social(词: 社会的), -ity(性质, 状态)<br>由“社会的”派生为当前词义 |
| socialization<br><br>n. 社会化 | social(词: 社会的), -ization(行为, …化)<br>在前词基础上加“-ization”构成名词, 表示“社会化” |
| society<br><br>n. 社会; 协会; 社团; 社交界; 群体 | **soci(结伴, 社会)**, -ety(性质, 状态)<br>在前词基础上加“-ety”构成名词, 表示“社会” |
| sociologist<br><br>n. 社会学家 | **socio(结伴, 社会)**, -logist(…学家)<br>围绕“社会”这一核心含义构成, 表示“社会学家” |
| sociology<br><br>n. 社会学 | **socio(结伴, 社会)**, -logy(…学, …研究)<br>以“社会”为研究对象的学科, 即“社会学” |
| sociopath<br><br>n. 反社会的人; 不爱社交的人 | **socio(结伴, 社会)**, **path(疾病, 疗法)**<br>由“社会”与“疾病”共同限定词义, 表示“反社会的人” |
| societal<br><br>adj. 社会的 | **soci(结伴, 社会)**, -et(小), -al(…的)<br>表示与“社会”有关或具有该特征, 即“社会的” |
| socioeconomic<br><br>adj. 社会经济 (学) 的 | **socio(结伴, 社会)**, **eco(家, 环境)**, **nom(…学)**, -ic(…的)<br>由“社会”与“家”与“学”共同限定词义, 表示“社会经济 (学) 的” |
| sociopolitical<br><br>adj. 社会政治的 | **socio(结伴, 社会)**, political(词: 政治的)<br>由“社会”与“政治的”共同限定词义, 表示“社会政治的” |


### sol(i)

单独; 太阳

| 单词 | 拆解 |
| --- | --- |
| desolate<br><br>adj. 荒凉的 | de-(下降, 降低; 否定, 相反; 脱离, 离去; 取消, 除去; 一再等加强意义), **sol(单独)**, -ate(做, 使)<br>彻底被抛弃而显得孤独隔绝的, 即荒凉 |
| solarize<br><br>v. 晒; 使经受日晒作用 | solar(词: 太阳的), -ize(…化, 使成)<br>由“太阳的”派生为当前词义 |
| desolation<br><br>n. 孤寂; 荒凉; 渺无人烟 | 与 desolate“荒凉的、使孤独”同源<br>被遗弃后形成的荒凉或悲痛状态 |
| sole<br><br>n. 脚底<br>adj. 单独的; 唯一的; 仅有的 | “唯一的”源自拉丁语 solus“单独”; “脚底”则是日耳曼语源的同形词<br>两个同形义项来源不同, 不强行合并拆解 |
| soliloquy<br><br>n. 独白; 自言自语 | 源自拉丁语 soliloquium, 由 solus“独自”与 loqui“说”构成<br>独自说话, 即独白 |
| solitude<br><br>n. 孤独; 隐居; 寂寞 | **sol(单独)**, -itude(性质, 状态)<br>围绕“单独”这一核心含义构成, 表示“孤独” |
| solo<br><br>n. 独奏; 独唱; 单独的<br>adj. 独奏的; 独唱的; 单独的 | 源自意大利语 solo（单独的）, 表示由一个人单独演唱或演奏的段落 |
| soloist<br><br>n. 独唱者; 独奏者 | solo(词: 独唱), -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“独唱者” |
| insolation<br><br>n. 曝晒; 日射; 日光浴 | 由拉丁语 insolatio“曝晒”, 核心 sol 表示太阳<br>太阳辐射照射量 |
| solarium<br><br>n. 日光浴室; 日光治疗室 | **sol(太阳)**, -arium(场所, 地点)<br>接受阳光照射的场所, 即日光浴室 |
| solarization<br><br>n. 晒; 经受日晒作用 | **sol(太阳)**, -ar(…的), -ization(行为, …化)<br>受太阳强光作用而发生变化的过程 |
| solitary<br><br>adj. 单独的; 独居的 | **soli(单独)**, t(连接字母), -ary(…的)<br>围绕“单独”这一核心含义构成, 表示“单独的” |
| extrasolar<br><br>adj. 太阳系以外的 | extra-(在外, 向外), **sol(太阳)**, -ar(…的)<br>由“以外”与“太阳”共同限定词义, 表示“太阳系以外的” |


### solid

坚实

| 单词 | 拆解 |
| --- | --- |
| consolidate<br><br>v. 巩固; 加强 | con-(与, 共同), **solid(坚实)**, -ate(做, 使)<br>强化“坚实的”这一动作或状态, 因此表示“巩固, 加强” |
| solidify<br><br>v. (使) 团结; (使) 固化; 充实; 巩固 | 由 solid“固体的、牢固的”派生<br>使凝固或使关系巩固 |
| consolidation<br><br>n. 巩固; 加强 | 与 consolidate“使坚固、合并”同源, 最终来自拉丁语 solidus“坚固”<br>使多个部分合为稳固整体 |
| solidarity<br><br>n. 团结 (一致); 休戚相关 | 经法语 solidarité 借入, 来自 solide“牢固的”<br>成员牢固联结形成的团结一致 |
| solidity<br><br>n. 固体 (性); 坚固; 稳健; 殷实; 完整性 | **solid(坚实)**, -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“固体” |


### solv, solut

松开, 解开

| 单词 | 拆解 |
| --- | --- |
| absolve<br><br>v. 免除; 赦免 | ab-(脱离, 离去), **solv(松开, 解开)**, e(连接字母)<br>把人从罪责或义务的束缚中解开, 因此表示赦免、免除 |
| dissolve<br><br>v. (使)溶解; (使)融化; 解散; 取消; （使）溶解 | dis-(否定, 相反), **solv(松开, 解开)**, e(连接字母)<br>由“否定”与“解开”共同限定词义, 表示“(使)溶解, (使)融化” |
| resolution<br><br>n. 坚决; 坚定; 决心; 不屈不挠 | 源自拉丁语 resolutio“解开、分解”, 与 resolve 同源<br>由解开问题引申为决定、解决方案 |
| resolve<br><br>v. 解决; 决定; 决心; 分解<br>n. 决心; 坚决; 决定 | re-(回, 向后, 再次), **solv(松开, 解开)**, e(连接字母)<br>把纠结的问题解开, 即解决或下定决心 |
| solution<br><br>n. 解决(办法); 溶解(作用或状态); 瓦解 | **solut(松开, 解开)**, -ion(行为, 结果)<br>围绕“解开”这一核心含义构成, 表示“解决(办法)” |
| solvency<br><br>n. 溶解本领; 偿付能力 | **solv(松开, 解开)**, -ency(性质, 状态)<br>围绕“解开”这一核心含义构成, 表示“溶解本领” |
| insolvent<br><br>adj. 破产的; 无力还债的 | in-(无, 不, 非), **solv(松开, 解开)**, -ent(…的)<br>无法解决的 |
| resolute<br><br>adj. 坚决的; 不屈的 | re-(回, 向后, 再次), **solut(松开, 解开)**, e(连接字母)<br>不放松 |
| resolved<br><br>adj. 决心的; 坚决的; 坚定的 | 词形来源：resolve + ed-form |
| solvable<br><br>adj. 可解释的; 可解答的; 能溶解的 | **solv(松开, 解开)**, -able(可…的)<br>围绕“解开”这一核心含义构成, 表示“可解释的, 可解答的” |


### somn(i), somn(o)

睡眠

| 单词 | 拆解 |
| --- | --- |
| insomnia<br><br>n. 失眠(症); 失眠症 | in-(无, 不, 非), **somn(睡眠)**, -ia(性质, 状态)<br>否定或缺少“睡眠”所指的性质, 因此表示“失眠(症)” |
| insomniac<br><br>n. 失眠症患者 | insomnia→insomni(词: 失眠), -ac(…的)<br>患有失眠症的; 转化作名词时指失眠者 |
| somnambulist<br><br>n. 梦游者; 梦行者 | **somn(睡眠)**, **ambul(行走)**, -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“梦游者” |
| somnolence<br><br>n. 思睡; 困倦 | **somno(睡眠)**, -lence(性质, 状态)<br>围绕“睡眠”这一核心含义构成, 表示“思睡, 困倦” |
| somnolent<br><br>adj. 想睡的; 困倦的 | **somno(睡眠)**, -lent(…的)<br>在前词基础上加“-lent”构成形容词, 表示“想睡的” |


### son(o)

声音

| 单词 | 拆解 |
| --- | --- |
| dissonance<br><br>n. 不和谐; 不一致 | dis-(否定, 相反), **son(声音)**, -ance(性质, 状态)<br>声音彼此分离、不和谐, 因此表示不和谐、不一致 |
| resonance<br><br>n. 回声; 反响 | re-(回, 向后, 再次), **son(声音)**, -ance(性质, 状态)<br>声音反射回来并持续振动, 因此表示共鸣、反响 |
| sonics<br><br>n. 声能学 | **son(声音)**, -ics(…学)<br>以“声音”为研究对象的学科, 即“声能学” |
| ultrasonic<br><br>adj. 超音速的<br>n. 超声波 | ultra-(超过, 超越), **son(声音)**, -ic(…的)<br>由“超过”与“声音”共同限定词义, 表示“超音速的, 超声的” |
| unison<br><br>n. 同音; 齐唱; 一致; 调和 | uni-(一, 单一), **son(声音)**<br>同一声音 |
| resonant<br><br>adj. 回响的; 反响的 | 借自法语或拉丁语 resonans“回响的”, 与 resound 同源<br>能产生回响或引起共鸣的 |
| sonic<br><br>adj. 声音的; 音速的 | **son(声音)**, -ic(…的)<br>表示与“声音”有关或具有该特征, 即“声音的” |
| subsonic<br><br>adj. 亚音速的 | sub-(在下, 向下), **son(声音)**, -ic(…的)<br>由“在下”与“声音”共同限定词义, 表示“亚音速的” |
| supersonic<br><br>adj. 超音速的 | super-(超), **son(声音)**, -ic(…的)<br>由“超”与“声音”共同限定词义, 表示“超音速的” |


### soph

聪明, 智慧

| 单词 | 拆解 |
| --- | --- |
| philosophize<br><br>v. 推究哲理 | 由 philosophy“哲学”派生<br>进行哲学思考或议论 |
| sophisticate<br><br>n. 久经世故的人; 精于...之道的人<br>v. 篡改; 曲解; 使变得世故 | sophist(词: 诡辩者), -ic(…的), -ate(做, 使)<br>在前词基础上加“-ic”、“-ate”构成动词或名词, 表示“诡辩” |
| philosopher<br><br>n. 哲学家; 学者; 思想家 | **philo(爱)**, **soph(聪明, 智慧)**, -er(人)<br>热爱并追求智慧的人, 即哲学家、思想家 |
| philosophy<br><br>n. 哲学; 人生哲学; 哲学体系; 思想体系 | **philo(爱)**, **soph(聪明, 智慧)**, -y(活动)<br>热爱并追求智慧的思想活动 |
| sophist<br><br>n. 诡辩家; 大智者; 博学者 | **soph(聪明, 智慧)**, -ist(人)<br>表示从事或具有“聪明”特征的人, 即“诡辩家” |
| sophistry<br><br>n. 诡辩 (法) | sophist(词: 诡辩者), -ry(行为, 状态)<br>在前词基础上加“-ry”构成名词, 表示“诡辩” |
| philosophical<br><br>adj. 哲学家的; 哲学 (上) 的 | 由 philosophy“哲学”派生; philosophy 字面为“爱智慧”<br>与哲学思考有关的 |
| sophisticated<br><br>adj. 精密复杂的; 见多识广的; 高级的; 老练的 | **soph(聪明, 智慧)**, -istic(…的), -at(…的), -ed(…的)<br>表示与“聪明”有关或具有该特征, 即“世故的” |


### speci(o), sort

种类; 方式

| 单词 | 拆解 |
| --- | --- |
| specialize<br><br>v. 专门研究; 专攻; 专门化 | special(词: 专门的), -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“专门研究” |
| specify<br><br>v. 具体指定; 详细说明 | **speci(种类)**, -fy(…化, 做…)<br>明确指出属于哪一种或具体要求 |
| assortment<br><br>n. 各式各样; 什锦物 | as-(到, 朝, 向), **sort(种类)**, -ment(物)<br>按种类分好并汇集的一组物品, 即什锦或各式物品 |
| consort<br><br>n. 配偶; 夫妻<br>v. 陪伴; 结交; 符合 | con-(与, 共同), **sort(种类)**<br>同一类 |
| consortium<br><br>n. 财团; 联合企业; 联营组织; 合作协议 | 源自拉丁语 consors“伙伴、共同参与者”<br>多个伙伴共同组成的联合体, 即财团或联盟 |
| speciality<br><br>n. 特性; 特质; 专业; 专长 | special(词: 专辑), -ity(性质, 状态)<br>由“专辑”派生为当前词义 |
| species<br><br>n. (单复同)种; 物种 | 源自拉丁语 species“外观, 种类”, 与词根 speci(种类)同源<br>生物分类中最基本的类别单位, 即“物种, 种类” |
| specification<br><br>n. 规格; 规范; 标准; 明细单; 详细说明书 | **speci(种类)**, -fication(…化, 做…)<br>围绕“种类”这一核心含义构成, 表示“规格, 规范, 标准” |
| specimen<br><br>n. 样品; 标本 | **speci(种类)**, -men(行为的结果)<br>代表某一种类的实物, 即"标本" |
| conspecific<br><br>adj. 同种的 | 由 con-（共同）与 specific（物种的）结合形成, 表示属于同一物种的 |
| special<br><br>adj. 特殊的; 专门的 | **speci(种类)**, -al(…的)<br>界、门、纲、目、科、属、种 |


### spect, specul, spic

看

| 单词 | 拆解 |
| --- | --- |
| speculate<br><br>v. 推测; 投机 | **specul(看)**, -ate(做, 使)<br>围绕“看”这一核心含义构成, 表示“思索, 推测” |
| aspect<br><br>n. (问题; 事物等的)方面; （问题、事物等的）方面 | a-(无, 不, 非; 在..., ...的; 一再等加强意义), **spect(看)**<br>事物朝向观看者的一面, 即外观、方面 |
| conspectus<br><br>n. 一览表; 大纲; 概况 | con-(与, 共同), **spect(看)**, -us(名词词尾)<br>全看到 |
| expectant<br><br>adj. 预期的; 期待的<br>n. 预期者; 期待者; 候选人 | 与 expect“等待、期待”同源<br>正在期待某事发生的 |
| expectation<br><br>n. 盼望; 期待; 期望 | expect(词: 盼望), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“盼望” |
| inspection<br><br>n. 检查; 审查 | in-(向内, 进入), **spect(看)**, -ion(行为, 结果)<br>向内部仔细看的行为, 即检查 |
| introspection<br><br>n. 内省; 自我反省 | intro-(向内, 在内), **spect(看)**, -ion(行为, 结果)<br>由“向内”与“看”共同限定词义, 表示“内省, 自我反省” |
| perspective<br><br>n. 视角; 观点; 透视法 | per-(通过, 贯穿), **spect(看)**, -ive(…的)<br>彻底贯穿地看待事物的角度, 即"观点, 看法"; 引申指绘画中表现远近关系的"透视" |
| retrospection<br><br>n. 回顾; 追溯 | retro-(回, 向后), **spect(看)**, -ion(行为, 结果)<br>回头观看过去的过程, 即回顾、追溯 |
| spectacle<br><br>n. 壮观景象; 奇观; 精彩表演; (复数)眼镜 | **spect(看)**, -acle(抽象及实物名词)<br>供人观看的宏大场面, 即壮观景象; 复数引申指眼镜 |
| spectator<br><br>n. 观众; 旁观者 | **spect(看)**, -ator(人)<br>观看的人, 即"观众" |
| speculator<br><br>n. 思索者; 推理者; 抽象的理论家; 投机者; 投机商 | **specul(看)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“思索者” |
| speculum<br><br>n. 古代的金属镜; (光学仪器中的) 反射镜 | **specul(看)**, -um(名词词尾)<br>供观看或反射影像的器具, 即镜或窥器 |
| auspicious<br><br>adj. 吉兆的; 幸运的 | auspice→auspic(词: 吉兆), -ious(…的)<br>由“吉兆”派生为当前词义 |
| circumspect<br><br>adj. 谨慎的; 小心的; 慎重的; 仔细的 | circum-(四周, 周围), **spect(看)**<br>向四周细看 |
| conspicuous<br><br>adj. 易见的; 明显的; 惹人注意的 | con-(与, 共同), **spic(看)**, -uous(…的)<br>清楚进入众人视线, 因此表示显眼的、明显的 |
| perspicacious<br><br>adj. 有洞察力的; 领悟的 | per-(通过, 贯穿), **spic(看)**, -acious(…的)<br>能看透的 |
| prospective<br><br>adj. 盼望中的; 未来的 | pro-(向前, 前进; 在前, 预先; 赞成, 支持), **spect(看)**, -ive(…的)<br>朝前观看并指向未来, 因此表示预期的、未来的 |
| respectable<br><br>adj. 可敬的; 值得尊敬的 | re-(回, 向后, 再次), **spect(看)**, -able(可…的)<br>值得人回头再看、重视, 因此表示可敬的、体面的 |
| respectful<br><br>adj. 尊敬人的; 恭敬的 | respect(词: 尊敬), -ful(充满…的)<br>在前词基础上加“-ful”构成形容词, 表示“尊敬人的, 恭敬的” |


### spectr(o)

光谱

| 单词 | 拆解 |
| --- | --- |
| spectrograph<br><br>n. 摄谱仪; 分光摄像仪 | **spectro(光谱)**, **graph(写, 画)**<br>围绕“光谱”这一核心含义构成, 表示“摄谱仪, 分光摄像仪” |
| spectrometer<br><br>n. 分光计; 分光仪 | **spectro(光谱)**, **meter(测量器, 仪表)**<br>测量“光谱”的仪器或方法, 即“分光计, 分光仪” |
| spectrophotometer<br><br>n. 分光光度计 | **spectro(光谱)**, **photo(光)**, **meter(测量器, 仪表)**<br>测量“光谱、光”的仪器或方法, 即“分光光度计” |
| spectroscopy<br><br>n. 光谱学 | 由 spectro“光谱”与 scopy“观察研究”构成<br>研究光谱的学科 |
| spectrum<br><br>n. 范围; 光谱; 波谱; 谱; 系列 | **spectr(光谱)**, -um(名词词尾)<br>光按不同波长展开形成的谱, 也引申为连续范围 |
| spectral<br><br>adj. 光谱的 | **spectr(光谱)**, -al(…的)<br>围绕“光谱”这一核心含义构成, 表示“光谱的” |
| spectroscopic<br><br>adj. 分光镜的; 光谱学的 | **spectro(光谱)**, **scop(镜, 观察)**, -ic(…的)<br>由“光谱”与“镜”共同限定词义, 表示“分光镜的” |


### sper

希望

| 单词 | 拆解 |
| --- | --- |
| prosper<br><br>v. 繁荣; 昌盛 | pro-(向前, 前进), **sper(希望)**<br>事情如所希望地向前发展, 因此表示繁荣、昌盛 |
| despair<br><br>n. 绝望; 令人绝望的事<br>v. 绝望; 感到绝望 | 源自古法语 desperer（失去希望）, 可追溯至拉丁语 dēspērāre |
| desperado<br><br>n. 亡命徒; 暴徒 | 借自西班牙语 desesperado“绝望的人”<br>因铤而走险而成为亡命徒 |
| desperation<br><br>n. 绝望 | 与 despair“绝望”同源, 最终源自拉丁语 desperare<br>失去希望后的绝望状态 |
| Esperanto<br><br>n. 世界语 | 由创始人柴门霍夫的笔名 Doktoro Esperanto 命名; Esperanto 在该语言中意为“希望者” |
| prosperity<br><br>n. 繁荣; 兴旺; 昌盛 | prosper(词: 繁荣), -ity(性质, 状态)<br>成功发展并富足的状态 |
| despairing<br><br>adj. 绝望的 | despair(词: 绝望), -ing(…的)<br>感到或表现出绝望的 |
| desperate<br><br>adj. 绝望的; 不顾一切的; 极度渴望的; 危急严峻的 | 构词锚点：de 表示“取消, 除去”; sper 表示“希望”; -ate 在此为形容词词尾, 不取动词义<br>失去希望的, 即绝望的、不顾一切的 |
| prosperous<br><br>adj. 繁荣的; 兴旺的 | prosper(词: 繁荣), -ous(…的)<br>在前词基础上加“-ous”构成形容词, 表示“繁荣的” |


### sperm(o), spermat(o), spermato

精子, 精液

| 单词 | 拆解 |
| --- | --- |
| spermatogenesis<br><br>n. 精子发生 | **spermato(精子, 精液)**, **gen(出生, 产生)**, -esis(行为, 过程)<br>由“精子”与“出生”共同限定词义, 表示“精子发生” |
| spermine<br><br>n. 精胺; 精素; 精硷 (用作补药) | **sperm(精子, 精液)**, -ine(…的)<br>由“精子”与“…的”构成相关物质名称, 即“精胺, 精素, 精硷 (用作补药)” |
| spermatic<br><br>adj. 精子的; 精液的; 精囊的; 睾丸的 | **spermat(精子, 精液)**, -ic(…的)<br>表示与“精子”有关或具有该特征, 即“精子的” |


### spers

散

| 单词 | 拆解 |
| --- | --- |
| disperse<br><br>v. (使) 分散; 散开; 散去 | 前缀 dis- 在此历史上缩合为 di-, 结合 spers“散”<br>使事物向不同方向散开 |
| intersperse<br><br>v. 散置; 散布; 点缀 | inter-(在...之间), **spers(散)**, e(连接字母)<br>由“在…之间”与“散”共同限定词义, 表示“散置” |
| dispersal<br><br>n. 分散; 疏散; 散布 | di-(分开, 分离), **spers(散)**, -al(行为, 过程)<br>分开散布的行为或过程, 即分散、疏散 |
| dispersion<br><br>n. 分散; 散布; 驱散 | disperse→dispers(词: 分散), -ion(行为, 结果)<br>由“分散”派生为当前词义 |
| dispersive<br><br>adj. 散的; 分散的; 散乱的 | disperse→dispers(词: 分散), -ive(…的)<br>由“分散”派生为当前词义 |


### spher(o)

球

| 单词 | 拆解 |
| --- | --- |
| sphere<br><br>n. 球; 球面; 球体<br>v. 包围; 使成球体; 放入球内 | 经拉丁语借自希腊语 sphaira“球”<br>表示球体, 并由球形范围引申为领域 |
| sphericity<br><br>n. 球状; 圆体 | **spher(球)**, -icity(性质, 状态)<br>在前词基础上加“-ic”、“-ity”构成名词, 表示“球状” |
| spheroid<br><br>n. 球(状)体; 扁球体; 椭球体 | **spher(球)**, -oid(似…的（物）)<br>形状像“球”, 即“球(状)体” |
| spherical<br><br>adj. 球形的; 球面的; 天体的 | **spher(球)**, -ical(…的)<br>围绕“球”这一核心含义构成, 表示“球形的” |
| spheroidal<br><br>adj. 球状的; 扁球体的; 椭球体的 | spheroid(词: 球状的), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“球状的” |


### sphygm(o)

脉搏

| 单词 | 拆解 |
| --- | --- |
| sphygmomanometer<br><br>n. 血压计 | **sphygm(o)(脉搏)**, mano(词: 压力), **meter(测量; 测量器, 仪表)**<br>通过充气袖带阻断肱动脉并感应脉搏波动来测定血压数值的医疗仪器, 即血压计 |
| sphygmograph<br><br>n. 脉搏描记器; 脉波图仪 | **sphygm(o)(脉搏)**, **graph(写, 画)**<br>将脉搏跳动波形自动记录绘制出来的仪器 |


### spir(o)

呼吸; 螺旋, 盘绕

| 单词 | 拆解 |
| --- | --- |
| inspire<br><br>v. 鼓舞; 激励; 给…以灵感; 吸入 | in-(向内, 进入), **spir(呼吸)**, e(连接字母)<br>原指把气息吹入, 后来表示激励、启发 |
| perspire<br><br>v. 出汗; 排汗 | per-(通过, 贯穿), **spir(呼吸)**, e(连接字母)<br>液体仿佛穿过皮肤呼出, 因此表示出汗、排汗 |
| aspire<br><br>n. 希望<br>v. 渴望; 追求; 有志于 | 经法语借自拉丁语 aspirare, 由 ad“向”与 spirare“呼吸”构成<br>原有朝向某物呼吸之意, 引申为渴望、追求 |
| conspirator<br><br>n. 共谋者; 阴谋家 | con-(与, 共同), **spir(呼吸)**, -ator(人)<br>同呼吸者 |
| conspiracy<br><br>n. 共谋; 同谋; 阴谋; 密谋; 合谋 | con-(与, 共同), **spir(呼吸)**, -acy(性质, 状态)<br>多人像共同呼吸一样秘密协同行动, 即阴谋 |
| expiration<br><br>n. 吐气; 断气; 死亡; 告终; 终止 | 源自拉丁语 expiratio“呼出”, 与 expire 同源<br>由呼出最后一口气引申为终止、到期 |
| inspiration<br><br>n. 吸入; 吸气; 鼓舞; 激励; 灵感 | in-(向内, 进入), **spir(呼吸)**, -ation(行为, 结果)<br>原指把气息吹入, 后来指把思想和动力注入, 即灵感、激励 |
| respiration<br><br>n. 呼吸(作用) | re-(回, 向后, 再次), **spir(呼吸)**, -ation(行为, 结果)<br>气息有节律地往返进出身体的过程, 即呼吸作用 |
| spirit<br><br>n. 精神; 心灵; 灵魂 | 源自拉丁语 spiritus“呼吸、生命气息”, 与 spirare“呼吸”相关<br>由生命气息发展为精神、心灵 |
| spirograph<br><br>n. 呼吸描记器 | **spiro(呼吸)**, **graph(写, 画)**<br>记录或描绘“呼吸”的方法, 即“呼吸描记器” |
| spirometry<br><br>n. 呼吸量测定法 | 由 spiro-“呼吸”与表示“测量”的 -metry 结合<br>指测量肺部呼吸容量和流量 |
| spiritual<br><br>adj. 精神的; 心灵的; 宗教的<br>n. 灵歌(宗教歌曲; 最初为美国黑人奴隶所唱) | spirit(词: 精神), -ual(…的)<br>与精神、心灵或宗教有关的 |


### splen(o)

脾

| 单词 | 拆解 |
| --- | --- |
| splenectomy<br><br>n. 脾切开术 | 由 splen“脾”与 ectomy“切除术”构成<br>脾切除术 |
| splenomegaly<br><br>n. 脾大 | **spleno(脾)**, **megal(特大)**, -y(活动)<br>由“脾”与“特大”共同限定词义, 表示“脾大” |
| splenic<br><br>adj. 脾的; 位于脾 (附近) 的 | **splen(o)(脾)**, -ic(…的)<br>与人体解剖结构中的脾脏有关的, 即脾的 |


### splend

发光

| 单词 | 拆解 |
| --- | --- |
| splendo(u)r<br><br>n. 壮丽; 辉煌; 显赫; 杰出卓越 | 经法语借自拉丁语 splendor“光辉”<br>表示辉煌壮丽; 英式可拼 splendour |
| resplendent<br><br>adj. 灿烂的; 光辉的 | resplend(词: 灿烂), -ent(…的)<br>由“灿烂”派生为当前词义 |
| splendid<br><br>adj. 有光彩的; 灿烂的; 壮丽的; 显著的; 杰出的 | **splend(发光)**, -id(…的)<br>围绕“发光”这一核心含义构成, 表示“有光彩的, 灿烂的” |


### spond, spons

允诺, 约定; 自愿, 自发

| 单词 | 拆解 |
| --- | --- |
| correspond<br><br>v. 相符合; 相一致; 相当; 类似; 通信 | cor-(与, 共同), re-(回, 向后, 再次), **spond(允诺, 约定)**<br>双方作出相互回应, 因此表示通信, 也引申为相符、对应 |
| respond<br><br>v. 回答; 答复; 响应; 有反应; 作出反应 | re-(回, 向后, 再次), **spond(允诺, 约定)**<br>对先前的话或请求作出回应, 因此表示回答、反应 |
| correspondence<br><br>n. 符合; 一致; 通信; 联络 | correspond(词: 符合), -ence(性质, 状态)<br>在前词基础上加“-ence”构成名词, 表示“符合” |
| correspondent<br><br>n. 记者; 通讯员; 通信者 | correspond(词: 通信; 相对应), -ent(人; 物)<br>负责通信或报道的人, 即通讯员 |
| response<br><br>n. 回答; 答复; 响应; 反应 | re-(回, 向后, 再次), **spons(允诺, 约定)**, e(连接字母)<br>对先前的话或请求作出回应, 因此表示回答、反应 |
| sponsor<br><br>n. 保证人; 赞助者; 发起者<br>v. 发起; 赞助; 倡议 | **spons(允诺, 约定)**, -or(人)<br>原指作出承诺、担保的人; 名词转化为动词后表示赞助、支持 |


### spong(i), spongio

海绵

| 单词 | 拆解 |
| --- | --- |
| sponge<br><br>n. 海绵动物; 海绵块<br>v. 用海绵擦 | 经拉丁语借自希腊语 spongos“海绵”<br>核心义即海绵, 也可转化作动词 |
| sponging<br><br>n. 海绵擦法; 海绵擦浴 | **spong(海绵)**, -ing(行为, 过程)<br>围绕“海绵”这一核心含义构成, 表示“海绵擦法, 海绵擦浴” |
| spongiform<br><br>adj. 海绵状(组织)的 | **spongi(海绵)**, -form(…形状的)<br>围绕“海绵”这一核心含义构成, 表示“海绵状(组织)的” |
| spongy<br><br>adj. 海绵质的; 海绵状的; 多孔的; 有吸水性的; 轻软而富有弹性的 | **spong(海绵)**, -y(充满…的, 有…特征的, 像…的)<br>围绕“海绵”这一核心含义构成, 表示“海绵质的, 海绵状的” |


### spor(i), spor(o)

孢子

| 单词 | 拆解 |
| --- | --- |
| spore<br><br>n. 孢子<br>v. 长孢子 | **spor(孢子)**, e(连接字母)<br>表示生物繁殖或传播所用的孢子 |
| sporophyte<br><br>n. 孢子体 | **sporo(孢子)**, **phyt(植物)**, e(连接字母)<br>由“孢子”与“植物”共同限定词义, 表示“孢子体” |


### st(a), stat

站立

| 单词 | 拆解 |
| --- | --- |
| apostate<br><br>n. 背教者; 变节者; 脱党者 | apo-(分开, 离去), **stat(站立)**, e(连接字母)<br>离教而立 |
| armistice<br><br>n. 停战; 休战 | **arm(武器, 武装)**, i(连接字母), **st(站立)**, -ice(性质, 状态)<br>战事停立 |
| distance<br><br>n. 距离 | di-(分开, 分离), **st(站立)**, -ance(性质, 状态)<br>分立于两处 |
| obstacle<br><br>n. 障碍; 障碍物 | ob-(对着, 朝向, 在前; 反对, 阻碍; 彻底, 完全, 加强), **sta(站立)**, -cle(小)<br>站在前方挡住去路的事物, 即障碍 |
| prostitute<br><br>n. 娼妓; 妓女 | 源自拉丁语 prostituere“公开陈列”, 由 pro“在前”与 statuere“放置”构成<br>由公开供人使用发展为卖淫者及贬损义 |
| rest<br><br>n. 其余; 剩余者 | re-(回, 向后, 再次), **st(站立)**<br>立在后面者 |
| stable<br><br>adj. 稳定的; 安定的; 坚固的<br>n. 马房; 牛棚<br>v. 赶入马房; 被关在马厩 | **st(站立)**, -able(可…的)<br>能够稳稳站立不倒的, 即"稳定的" |
| stance<br><br>n. 站立的姿势; 姿态; 态度 | **st(站立)**, -ance(性质, 状态)<br>表示与“站立”有关的性质或状态, 即“站立的姿势” |
| stature<br><br>n. 身高; 身材; (精神; 道德等的)高度; （精神、道德等的）高度 | **stat(站立)**, -ure(行为, 结果)<br>词根本身即表示“身高”, 整词沿用该义 |
| status<br><br>n. 地位; 状态; 身份 | **stat(站立)**, -us(名词词尾)<br>立于社会的方式 |
| system<br><br>n. 系统; 体系; 制度 | sy-(共同), **st(站立)**, -em(行为的结果)<br>共立于一处 |
| constant<br><br>adj. 不变的; 恒定的 | con-(与, 共同), **st(站立)**, -ant(…的)<br>各方共同稳稳站立不变的, 即"持续不变的" |


### stand, stan(t), stag(n), stin

站立

| 单词 | 拆解 |
| --- | --- |
| stagnate<br><br>v. (使) 停滞; (使) 迟钝; (使) 变萧条 | **stagn(站立)**, -ate(做, 使)<br>围绕“站立”这一核心含义构成, 表示“停滞, 不发展” |
| substantiate<br><br>v. 证明; 证实 | sub-(在下, 向下), **stant(站立)**, i(连接字母), -ate(做, 使)<br>在主张下面立起事实支撑, 因此表示证明、证实 |
| understand<br><br>v. 理解; 懂得; 了解; 获悉; 谅解 | under-(在下, 低于), **stand(站立)**<br>站在⋯之下 |
| withstand<br><br>v. 承受; 经受住; 抵住; 顶住 | with-(反对, 相反), **stand(站立)**<br>站在相反方向抵住压力, 因此表示承受、抵抗 |
| stage<br><br>n. 舞台; 阶段<br>v. 举办; 组织 | 经古法语 estage 进入英语, 远源与“站立的位置”有关<br>由位置发展为舞台或发展阶段 |
| stagger<br><br>n. 蹒跚; 踌躇<br>v. 蹒跚; 犹豫; 使摇摆<br>adj. 交错的; 错开的 | 核心意义是站立不稳、摇晃前进<br>也可引申为错开安排或使震惊 |
| staging<br><br>n. 脚手架 | **stag(站立)**, -ing(行为, 过程)<br>供人或材料站立、施工的平台结构, 即脚手架 |
| bystander<br><br>n. 旁观者 | by-(旁边), **stand(站立)**, -er(人)<br>站在旁边的人 |
| stanchion<br><br>n. 支柱 | 经古法语 estanchon 借入, 来自拉丁语 stans“站立的”<br>竖立支撑的柱子 |
| standard<br><br>n. 标准; 规格; 水准<br>adj. 标准的; 常规的 | 经古法语 estandard 进入英语, 原指竖立的军旗或集结标志<br>由共同标志发展为统一标准 |
| standee<br><br>n. (车; 船上)站立乘客; [美口](戏院中)站票看客 | **stand(站立)**, -ee(接受动作的人)<br>围绕“站立”这一核心含义构成, 表示“(戏院中)站票看客” |
| standpoint<br><br>n. 立场; 立足点 | stand(词: 站立), point(词: 位置; 点)<br>站立并观察问题的位置, 即立场、立足点 |
| stagnant<br><br>adj. 停滞的; 迟钝的; 呆笨的; 不景气的 | **stagn(站立)**, -ant(…的)<br>像水停站不流一样的, 即停滞的 |
| obstinate<br><br>adj. 倔强的; 顽固的 | 构词锚点：ob 表示“对着, 朝向, 在前”; stin 表示“站立”; -ate 在此为形容词词尾, 不取动词义<br>稳立不动的 |
| staunch<br><br>adj. 坚定的; 坚固的; 忠实的 | 经古法语 estanche“水密的、坚固的”借入<br>由不渗漏引申为坚定可靠的 |


### stat

静止, 稳定

| 单词 | 拆解 |
| --- | --- |
| thermostat<br><br>n. 恒温器 | **thermo(热)**, **stat(静止, 稳定)**<br>使温度保持稳定的装置, 即恒温器 |
| static<br><br>adj. 静止的; 静态的; 呆板的<br>n. 静电; 静电噪音 | **stat(静止, 稳定)**, -ic(…的)<br>保持静止不动或稳定不变的状态 |
| status<br><br>n. 地位; 身份; 状况; 状态 | **stat(静止, 稳定)**, -us(名词词尾)<br>人或事物所站立确立的社会地位或所处状态 |


### stann(i)

锡

| 单词 | 拆解 |
| --- | --- |
| stannous<br><br>adj. 亚锡的; 二价锡的 | **stann(i)(锡)**, -ous(…的)<br>特指含有低价二价锡化合物的, 如防蛀牙膏中的氟化亚锡 |
| stannic<br><br>adj. 锡的; 四价锡的 | **stann(i)(锡)**, -ic(…的)<br>含有四价高价态金属锡的 |


### stell(i)

星

| 单词 | 拆解 |
| --- | --- |
| interstellar<br><br>adj. 星际的 | inter-(在...之间), **stell(星)**, -ar(…的)<br>由“在…之间”与“星”共同限定词义, 表示“星际的” |
| stellar<br><br>adj. 星的; 星球的; 恒星的; 杰出的; 主要的 | **stell(星)**, -ar(…的)<br>围绕“星”这一核心含义构成, 表示“星的, 星球的” |
| stellate<br><br>adj. 星形的; 像星的; 放线状的 | 构词锚点：stell 表示“星”; -ate 在此为形容词词尾, 不取动词义<br>围绕“星”这一核心含义构成, 表示“星形的, 像星的, 放线状的” |


### sten(o)

少, 狭窄

| 单词 | 拆解 |
| --- | --- |
| stenographer<br><br>n. 速记员 | stenograph(词: 速记), -er(人)<br>在前词基础上加“-er”构成名词, 表示“速记员” |
| stenography<br><br>n. 速记; 速记法; 速记学 | stenograph(词: 速记), -y(活动)<br>在前词基础上加“-y”构成名词, 表示“速记” |
| stenosis<br><br>n. 狭窄 | **sten(o)(少, 狭窄)**, -osis(病症)<br>人体血管管腔、心脏瓣膜或椎管异常变窄导致流通受阻的病理状态, 即狭窄 |


### stereo

坚固, 实心; 立体

| 单词 | 拆解 |
| --- | --- |
| stereochemistry<br><br>n. 立体化学 | **stereo(坚固, 实心)**, chemistry(词: 化学)<br>由“立体的”与“化学”共同限定词义, 表示“立体化学” |
| stereogram<br><br>n. 立体图; 体视图; 立体照片; 体视照片 | **stereo(坚固, 实心)**, **gram(书写, 记录)**<br>由“立体的”与“书写”共同限定词义, 表示“立体图, 体视图” |
| stereotyped<br><br>adj. 形成固定的; 陈旧的 | **stereo(坚固, 实心)**, **typ(印, 模型)**, -ed(…的)<br>围绕“坚固的”这一核心含义构成, 表示“形成固定的” |


### stern(o)

胸(骨)

| 单词 | 拆解 |
| --- | --- |
| sternal<br><br>adj. 胸骨的 | **stern(胸(骨))**, -al(…的)<br>胸(骨)的性质, 引申为adj.* |
| sternum<br><br>n. 胸骨 | **stern(o)(胸(骨))**, -um(名词词尾; 化学元素或物质)<br>位于胸前正中支撑肋骨保护心肺的扁平骨骼, 即胸骨 |


### stil(i)

滴

| 单词 | 拆解 |
| --- | --- |
| distil(l)<br><br>v. 蒸馏; 滴下; 渗出 | 源自拉丁语 destillare“滴下”<br>通过使液体蒸发后再滴下凝结来提纯, 即蒸馏 |
| instil(l)<br><br>v. 滴入; 灌输 | 源自拉丁语 instillāre（逐滴注入）; instill 是美式拼法, instil 是英式拼法 |
| distillate<br><br>n. 馏出物; 馏出液; 精华 | distill(词: 蒸馏), -ate(人; 物)<br>由“蒸馏”派生为当前词义 |
| distillation<br><br>n. 蒸馏作用; 蒸馏物; 蒸馏(法) | distill(词: 蒸馏), -ation(行为, 结果)<br>通过蒸发和冷凝进行提纯的过程 |
| distillery<br><br>n. 蒸馏室; 酒厂 | distill(词: 蒸馏), -ery(场所)<br>在前词基础上加“-ery”构成名词, 表示“蒸馏室” |


### sting(u), stinct, stimul

刺; 熄灭; 激起, 推动

| 单词 | 拆解 |
| --- | --- |
| distinguish<br><br>v. 区分; 辨别; 使出众; 使有别于<br>adj. 杰出的; 突出的 | 源自“用标记刺出差别”的构词意象<br>表示识别并指出不同之处 |
| extinct<br><br>v. 灭绝<br>adj. 灭绝的; 熄灭的 | ex-(出, 向外), **tinct(熄灭)**<br>生命之火被完全熄灭的, 即灭绝的 |
| extinguish<br><br>v. 熄灭; 消灭 | 源自拉丁语 extinguere（熄灭、扑灭）, 经法语进入英语 |
| distinction<br><br>n. 区别; 差别; 卓越; 杰出 | 源自拉丁语 distinctio“区分、分别”<br>与 distinguish“区分”同源, 表示区别或由区别形成的卓越 |
| instinct<br><br>n. 本能; 直觉; 生性; 天性 | in-(向内, 进入), **stinct(激起, 推动)**<br>从内部激起并推动行为的力量, 即本能、直觉 |
| stimulant<br><br>n. 兴奋剂; 刺激物; 酒 | **stimul(刺)**, -ant(人; 物)<br>产生刺激作用的物质, 即兴奋剂、刺激物 |
| stimulative<br><br>adj. 刺激的; 促进的<br>n. 刺激; 促进因素 | **stimul(刺)**, -ative(…的)<br>在前词基础上加“-ative”构成名词或形容词, 表示“刺激的” |
| stimulus<br><br>n. 刺激 (stimuli 为复数形式); 刺激（物）; 促进因素 | **stimul(刺)**, -us(名词词尾)<br>像尖刺一样促使反应的因素, 即刺激 |
| stinger<br><br>n. 刺激者; 讽刺者; 刺 | **sting(刺)**, -er(人)<br>进行刺击的人; 也可引申指刺器或带来突然冲击的事物 |
| instinctive<br><br>adj. 本能的; 天性的 | instinct(词: 本能), -ive(…的)<br>在前词基础上加“-ive”构成形容词, 表示“本能的” |
| stingy<br><br>adj. 有刺的; 会刺的; 吝啬的 | **sting(刺)**, -y(充满…的, 有…特征的, 像…的)<br>围绕“刺”这一核心含义构成, 表示“有刺的, 会刺的” |


### stom, stomat(o)

口

| 单词 | 拆解 |
| --- | --- |
| stoma<br><br>n. (昆虫的)气门; 呼吸孔; [植] 气孔; [动] 口 | **stoma(口)**<br>围绕“口”这一核心含义构成, 表示“气孔” |
| stomatitis<br><br>n. 口炎 | **stomat(口)**, -itis(…炎)<br>“口”发生炎症, 即“口炎” |
| stomatology<br><br>n. 口腔学 | **stomato(口)**, -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“口腔学” |
| stomatal<br><br>adj. (有)气孔的; (有)气门的 | **stomat(口)**, -al(…的)<br>表示与“口”有关或具有该特征, 即“(有)气孔的” |


### strain(t), strict, string

拉, 紧

| 单词 | 拆解 |
| --- | --- |
| constrain<br><br>v. 强迫、强使; 硬作出; 攫住; 抑制 | con-(与, 共同), **strain(拉, 紧)**<br>强化“拉”这一动作或状态, 因此表示“强迫、强使” |
| constraint<br><br>n. 限制; 约束; 克制 | con-(与, 共同), **straint(拉, 紧)**<br>强化“拉”这一动作或状态, 因此表示“强迫, 勉强” |
| constrict<br><br>v. 压缩, 收紧 | con-(与, 共同), **strict(拉, 紧)**<br>使“紧”共同结合或发挥作用, 因此表示“压缩, 收紧” |
| restrain<br><br>v. 抑制; 克制; 约束 | re-(回, 向后, 再次), **strain(拉, 紧)**<br>向后拉紧, 阻止继续行动, 因此表示抑制、约束 |
| restraint<br><br>n. 抑制, 限制, 克制 | re-(回, 向后, 再次), **straint(拉, 紧)**<br>把行动向后拉紧并限制住, 因此表示抑制、约束 |
| restrict<br><br>v. 限制; 限定; 约束 | re-(回, 向后, 再次), **strict(拉, 紧)**<br>反复拉紧收束, 即"限制" |
| restrictive<br><br>adj. 限定的 | restrict(词: 限定), -ive(…的)<br>在前词基础上加“-ive”构成形容词, 表示“限定的” |
| strain<br><br>n. (植物的)株; 张力; 拉力; （精神上的）紧张<br>v. 张力; 拉紧; 扭伤; 过劳; 极度紧张; 应变; 尽力使用; 使紧张; 绷紧; 拉伤; 尽力 | **strain(拉, 紧)**<br>拉紧造成张力或过劳, 也可表示尽力 |
| stress<br><br>n. 压力; 应力; 重音; 强调; 着重<br>v. 压力, 应力, 重音; 强调, 着重 | 中古英语经古法语 estresse 借入, 源自拉丁语 strictus“拉紧的”<br>由拉紧引申为压力、重音和强调 |
| strict<br><br>adj. 严格的; 严厉的 | **strict(拉, 紧)**<br>围绕“拉”这一核心含义构成, 表示“严格的” |
| stricture<br><br>n. 狭窄; [常用复]苛评, 责难; 束缚(物), 限制(物) | **strict(拉, 紧)**, -ure(行为, 结果)<br>在前词基础上加“-ure”构成名词, 表示“苛评, 责难” |
| stringent<br><br>adj. 紧急的; 严厉的 | **string(拉, 紧)**, -ent(…的)<br>围绕“紧”这一核心含义构成, 表示“紧急的” |


### strat(i), strat(o)

层

| 单词 | 拆解 |
| --- | --- |
| stratify<br><br>v. (使)成层; (使)分层 | **strati(层)**, -fy(…化, 做…)<br>围绕“层”这一核心含义构成, 表示“(使)成层” |
| stratification<br><br>n. 分层 | **strati(层)**, -fication(…化, 做…)<br>围绕“层”这一核心含义构成, 表示“分层” |
| stratigraphy<br><br>n. 地层学 | 由 stratum“地层”与 graphy“记录、研究”构成<br>研究地层层序的学科 |
| stratocumulus<br><br>n. 层积云 | **strato(层)**, **cumul(积云)**, -us(名词词尾)<br>积云状团块铺成层状的云, 即层积云 |
| stratosphere<br><br>n. 平流层; 同温层; 最上层; 最高档; 艰深的学科领域 | **strato(层)**, sphere(词: 范围)<br>由“层”与“范围”共同限定词义, 表示“平流层, 同温层” |
| stratum<br><br>n. 地层; 阶层 | **strat(层)**, -um(名词词尾)<br>一层地层或社会阶层 |
| stratus<br><br>n. 层云 | **strat(层)**, -us(名词词尾)<br>围绕“层”这一核心含义构成, 表示“层云” |
| stratiform<br><br>adj. 层状的 | **strati(层)**, -form(…形状的)<br>围绕“层”这一核心含义构成, 表示“层状的” |


### strid, strif, striv

发出刺耳声; 竞争, 奋斗

| 单词 | 拆解 |
| --- | --- |
| strive<br><br>v. 努力; 奋斗; 力求; 反抗; 斗争 | 经古法语 estriver“争斗、努力”进入英语<br>表示付出很大努力争取目标 |
| stride<br><br>n. 大步; 进展<br>v. 大步走; 跨过 | 表示迈大步前进<br>由步伐引申为取得进展 |
| strife<br><br>n. 竞争; 冲突; 争吵; 斗争 | **strif(竞争, 奋斗)**, e(连接字母)<br>词根本身即表示“竞争”, 整词沿用该义 |
| strident<br><br>adj. 轧轧响的; 刺耳的 | **strid(发出刺耳声)**, -ent(…的)<br>围绕“发出刺耳声”这一核心含义构成, 表示“轧轧响的, 刺耳的” |


### struct

建造

| 单词 | 拆解 |
| --- | --- |
| construct<br><br>v. 构筑; 建设; 建造 | con-(与, 共同), **struct(建造)**<br>共同搭建而成, 即"建造" |
| obstruct<br><br>v. 设置障碍; 阻碍; 阻塞; 妨碍 | ob-(对着, 朝向, 在前; 反对, 阻碍; 彻底, 完全, 加强), **struct(建造)**<br>在道路前方建起阻挡, 因此表示阻塞、妨碍 |
| construction<br><br>n. 建造; 建设; 建筑物 | con-(与, 共同), **struct(建造)**, -ion(行为, 结果)<br>把材料共同建造成结构的过程或结果 |
| destruction<br><br>n. 毁坏; 破坏; 毁灭 | de-(脱离, 取消, 除去), **struct(建造)**, -ion(行为, 结果)<br>把已经建成的结构除去、破坏的过程或结果 |
| reconstruction<br><br>n. 再建; 重建 | re-(回, 向后, 再次), con-(与, 共同), **struct(建造)**, -ion(行为, 结果)<br>把结构重新建造起来, 因此表示重建、复原 |
| structure<br><br>n. 构造; 结构(物) | **struct(建造)**, -ure(行为, 结果)<br>建造形成的组织或构造, 即建筑物、结构 |
| substructure<br><br>n. 下部结构; 下层建筑 | sub-(在下, 向下), structure(词: 结构)<br>由“在下”与“结构”共同限定词义, 表示“下部结构, 下层建筑” |
| superstructure<br><br>n. 上部结构; 上层建筑 | super-(上), structure(词: 结构)<br>由“上”与“结构(物)”共同限定词义, 表示“上部结构, 上层建筑” |
| constructive<br><br>adj. 建设(性)的 | con-(与, 共同), **struct(建造)**, -ive(…的)<br>有助于构建和发展的, 即建设性的 |
| destructive<br><br>adj. 破坏(性)的; 毁灭(性)的; 破坏性的; 有害的 | de-(脱离, 取消, 除去), **struct(建造)**, -ive(…的)<br>会把已经建成的结构破坏掉的 |
| indestructible<br><br>adj. 破坏不了的; 毁灭不了的 | in-(无, 不, 非), de-(脱离, 取消, 除去), **struct(建造)**, -ible(可…的)<br>不可能被破坏结构的, 即坚不可摧的 |
| structural<br><br>adj. 构造的; 结构(上)的; 建筑的 | structure→structur(词: 结构), -al(…的)<br>与结构构造有关的, 即结构上的 |


### styl

文体, 风格

| 单词 | 拆解 |
| --- | --- |
| style<br><br>n. 风格; 款式; 样式; 时尚 | 经古法语借自拉丁语 stilus“书写尖笔”<br>由书写工具引申为写作方式, 再泛化为风格 |
| stylish<br><br>adj. 时髦的, 时式的; 漂亮的 | **styl(文体, 风格)**, -ish(…的)<br>围绕“式样”这一核心含义构成, 表示“时髦的, 时式的” |
| stylist<br><br>n. 文体(批评)家; (服装、家具等的)设计师; 以动作正确优美著称的运动员 | **styl(文体, 风格)**, -ist(人)<br>表示从事或具有“文体”特征的人, 即“文体(批评)家” |
| stylistic(al)<br><br>adj. 文体(上)的; 风格(上)的 | stylist(词: 文体学家), -ical(…的)<br>在前词基础上加“-ic”构成形容词, 表示“文体(上)的” |
| stylistics<br><br>n. 文体学; 风格学 | stylist(词: 文体学家), -ics(…学)<br>在前词基础上加“-ics”构成名词, 表示“文体学” |


### styl(i), styl(o)

尖, 茎突

| 单词 | 拆解 |
| --- | --- |
| stylus<br><br>n. 尖笔; 铁笔; 唱针 | **styl(尖, 茎突)**, -us(名词词尾)<br>尖端可用于刻写或触控的笔状工具, 即尖笔或触控笔 |
| stylish<br><br>adj. 时髦的; 漂亮的; 格调高雅的 | style→styl(词: 风格), -ish(…的)<br>具有鲜明独特风格和优雅格调的 |


### sum, sumpt

总; 拿, 取

| 单词 | 拆解 |
| --- | --- |
| summarize<br><br>v. 概括; 总结 | **su(跟随, 伴随)**, **m(提醒, 警告)**, m(连接字母), -ar(…的), -ize(…化, 使成)<br>把内容归并成总和或要点, 因此表示总结、概括 |
| assume<br><br>n. 假设)<br>v. 假设; 假定; 承担 (assumption; 设想; 承担（责任）; 取得（权力） | as-(到, 朝, 向), **sum(拿, 取)**, e(连接字母)<br>把某种看法或角色拿到自己身上, 即"假定"; 引申指主动担起职责, "承担" |
| consume<br><br>v. 消耗; 消费; 吃喝; 吃; 喝 | con-(与, 共同), **sum(拿, 取)**, e(连接字母)<br>完全拿取用尽, 即"消耗, 消费" |
| presume<br><br>v. 假设; 假定; 妄行; 擅自做; 料想 | pre-(先于, 预先), **sum(拿, 取)**, e(连接字母)<br>在证据充分之前先把某事当真, 因此表示假定、擅自 |
| sulphate<br><br>n. 硫酸盐; 硫酸酯<br>v. 硫酸盐化 | 构词锚点：sulph 表示“硫”; -ate 在名词义中是化学命名词尾, 指硫酸盐; 动词义由该名词转化而来 |
| sulphonate<br><br>n. 磺酸盐 | **sulpho(硫)**, n(连接字母), -ate(做, 使)<br>围绕“硫”这一核心含义构成, 表示“磺酸盐” |
| sum<br><br>n. 总数; 金额; 算术题<br>v. 总结; 概括; 合计 | 经法语借自拉丁语 summa“总数、总和”, 原为 summus“最高的”的阴性形式<br>由最终合计引申为总数、求和 |
| summa<br><br>n. (某门学科的) 总结; 总结性论文 (尤指哲学论文) | 直接来自拉丁语 summa“总和、最高概括”<br>某学科的综合性总结 |
| summary<br><br>adj. 概括的; 简易的<br>n. 摘要; 概要 | **summ(总)**, -ary(…的)<br>把总体要点集中呈现的文字, 即摘要 |
| summation<br><br>n. 总数; 和; 累积 (作用); (判决前的) 辩论总结; 求和 (法) | **sum(总)**, m(连接字母), -ation(行为, 结果)<br>求出总和的过程或结果, 即总和、求和 |
| summit<br><br>n. 顶点; 最高阶层; 最高级会议<br>adj. 政府首脑的; 最高级的 | 经古法语 somete 进入英语, 源自拉丁语 summum“最高点”<br>指山顶, 也可表示最高级会议 |
| assumption<br><br>n. 假定; 设想; 采取 | as-(到, 朝, 向), **sumpt(拿, 取)**, -ion(行为, 结果)<br>把某观点拿来作为前提, 即假设; 也可表示承担 |
| consumption<br><br>n. 消耗(量); 消费(量) | con-(与, 共同), **sumpt(拿, 取)**, -ion(行为, 结果)<br>把资源拿来用尽的过程, 即消费、消耗或消耗量 |
| presumption<br><br>n. 假定; 假设; 推测 | pre-(先于, 预先), **sumpt(拿, 取)**, -ion(行为, 结果)<br>在证据充分前先取一个判断作为前提, 因此表示假定、推测 |
| resume<br><br>n. (求职用的)履历; 简历; 摘要<br>v. (中断后)重新开始; 继续; 恢复 | re-(回, 向后, 再次), **sum(拿, 取)**, e(连接字母)<br>重新拿起接续下去, 即"继续" |
| resumption<br><br>n. 恢复; 再开始; 再取回 | re-(回, 向后, 再次), **sumpt(拿, 取)**, -ion(行为, 结果)<br>重新取回原有活动并继续, 因此表示恢复、再开始 |
| sulphide<br><br>n. 硫化物 | **sulph(硫)**, -ide(化合物)<br>围绕“硫化”这一核心含义构成, 表示“硫化物” |
| sulphite<br><br>n. 亚硫酸盐 | **sulph(硫)**, -ite(矿物)<br>含亚硫酸根的物质, 即亚硫酸盐 |
| sulphur<br><br>n. 硫; 硫磺 | 经拉丁语 sulfur 进入英语<br>表示化学元素硫, 英式传统拼作 sulphur |
| presumptive<br><br>adj. 可据以推定的; 假定的; 设想的 | 与 presume“预先假定”同源<br>根据现有证据推定的 |
| sulphurous<br><br>adj. 硫的; 含硫的; 有燃烧硫磺的气味的 | sulphur(词: 硫), -ous(…的)<br>在前词基础上加“-ous”构成形容词, 表示“硫的, 含硫的” |


### sulf(o), sulph(o)

硫

| 单词 | 拆解 |
| --- | --- |
| sulphate<br><br>n. 硫酸盐; 硫酸酯<br>v. 硫酸盐化 | 构词锚点：sulph 表示“硫”; -ate 在名词义中是化学命名词尾, 指硫酸盐; 动词义由该名词转化而来 |
| sulphide<br><br>n. 硫化物 | **sulph(硫)**, -ide(化合物)<br>围绕“硫化”这一核心含义构成, 表示“硫化物” |
| sulphite<br><br>n. 亚硫酸盐 | **sulph(硫)**, -ite(矿物)<br>含亚硫酸根的物质, 即亚硫酸盐 |
| sulphonate<br><br>n. 磺酸盐 | **sulpho(硫)**, n(连接字母), -ate(做, 使)<br>围绕“硫”这一核心含义构成, 表示“磺酸盐” |
| sulphur<br><br>n. 硫; 硫磺 | 经拉丁语 sulfur 进入英语<br>表示化学元素硫, 英式传统拼作 sulphur |
| sulphurous<br><br>adj. 硫的, 含硫的; 有燃烧硫磺的气味的 | sulphur(词: 硫), -ous(…的)<br>在前词基础上加“-ous”构成形容词, 表示“硫的, 含硫的” |


### sur

确信; 安全

| 单词 | 拆解 |
| --- | --- |
| assure<br><br>n. V 向……保证; 保证; 保险<br>v. 使确信; 使放心; 向⋯保证 | 经古法语 assurer 传入, 与 sure“确定的”同源<br>使某人确定、放心, 即保证 |
| ensure<br><br>v. 保证; 担保 | en-(进入, 包围), sure(词: 确信的)<br>使结果进入确定状态, 即确保 |
| assurance<br><br>n. 确信 | assure→assur(词: 保证), -ance(性质, 状态)<br>由“保证”派生为当前词义 |
| insurance<br><br>n. 保险; 保险金; 保险费 | 与 insure“确保、承保”同源<br>通过合同分担风险的保障 |
| insurer<br><br>n. 承保人 | insure→insur(词: 保险), -er(人)<br>由“保险”派生为当前词义 |
| surety<br><br>n. 确实; 肯定; 保证; 担保; 保证人 | sure(词: 确信), -ty(性质, 状态)<br>由“确信”派生为当前词义 |
| surely<br><br>adv. 确实; 无疑; 一定; 稳当地; 踏实地 | sur-(上), e(连接字母), -ly(…地)<br>围绕“上”这一核心含义构成, 表示“确实, 无疑, 一定” |


### surg

升起

| 单词 | 拆解 |
| --- | --- |
| insurgence<br><br>n. 起义; 暴动; 造反(指行动) | in-(向内, 进入), **surg(升起)**, -ence(性质, 状态)<br>在内部群起反抗的状态, 即起义、暴动 |
| insurgency<br><br>n. 起义; 暴动; 造反(指行动或性质; 状态) | 与 insurgent“起而反抗者”同源, 源自拉丁语 insurgere“升起”<br>有组织的武装反抗 |
| surge<br><br>n. 激增; 浪涌; 涌动<br>v. 激增; 奔涌 | **surg(升起)**, e(连接字母)<br>围绕“升起”这一核心含义构成, 表示“巨浪, 波浪, 波涛” |
| insurgent<br><br>adj. 起义的; 造反的 | in-(向内, 进入), **surg(升起)**, -ent(…的)<br>在群体内部起身反抗的, 即起义的、造反的 |
