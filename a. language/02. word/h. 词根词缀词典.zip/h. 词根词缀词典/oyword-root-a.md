## oyword-root-a


### ac(u), acer, acet(o), acr(o)

尖锐; 顶端; 高处; 酸苦

| 单词 | 拆解 |
| --- | --- |
| acid<br><br>n. 酸<br>adj. 酸的; 讽刺的; 尖刻的 | 源自拉丁语 acidus（酸的）, 由“味道尖锐”发展为酸性物质 |
| acme<br><br>n. 顶点; 最高点 | 源自希腊语 akmē“最高点”<br>表示发展或成就的顶点 |
| acupuncture<br><br>n. 针刺 (疗法); 针灸治疗; 中医针灸疗法 | **acu(尖锐)**, **punct(点, 刺)**, -ure(行为, 结果)<br>用尖锐的针刺入特定穴位的疗法, 即针灸 |
| acrid<br><br>adj. 辛辣的; 刻薄的 | **acr(尖锐)**, -id(…的)<br>味道或言辞像尖刺般刺激, 即辛辣、尖刻的 |
| acrimonious<br><br>adj. 尖酸的; 讽刺的 | **acr(尖锐)**, i(连接字母), **moni(状态, 结果)**, -ous(…的)<br>表示与“尖”有关或具有该特征, 即“尖酸的, 讽刺的” |
| acute<br><br>adj. 敏锐的; 严重的; (疾病 )急性的; 深刻的 | 源自拉丁语 acutus（尖锐的）, 由物理上的尖锐引申为敏锐、剧烈或急性的 |


### aem, haem(o), haemat(o)

血

| 单词 | 拆解 |
| --- | --- |
| anaemia<br><br>n. 贫血症 | an-(无, 不, 非), **aem(血)**, -ia(性质, 状态)<br>以“血”为语义核心构成, 表示“贫血症” |
| hematology<br><br>n. 血液学 | **hemato(血)**, -logy(…学, …研究)<br>以“血”为研究对象的学科, 即“血液学” |
| hemoglobin<br><br>n. 血红蛋白 | 由希腊语 haima“血”与 globin“球蛋白”构成<br>血液中携氧的球蛋白 |


### em, hem(o), hemat(o)

血

| 单词 | 拆解 |
| --- | --- |
| hematite<br><br>n. 赤铁矿; 红铁矿 | **hemat(血)**, -ite(矿物)<br>粉末常呈血红色的铁矿物, 即赤铁矿 |
| hematology<br><br>n. 血液学 | **hemato(血)**, -logy(…学, …研究)<br>以“血”为研究对象的学科, 即“血液学” |
| hemodynamics<br><br>n. 血流动力学 | **hemo(血)**, **dynam(力, 力量)**, -ics(…学)<br>以“血、力”为研究对象的学科, 即“血流动力学” |
| hemophilia<br><br>n. 血友病 | **hemo(血)**, **phil(爱)**, -ia(性质, 状态)<br>由“血”与“爱”共同限定词义, 表示“血友病” |


### aer(i), aer(o)

空中, 空气

| 单词 | 拆解 |
| --- | --- |
| aerodynamics<br><br>n. 空气动力学 | **aero(空中, 空气)**, **dynam(力, 力量)**, -ics(…学)<br>以“空气、力”为研究对象的学科, 即“空气动力学” |
| aeronautics<br><br>n. 航空学; 航空术 | **aero(空中, 空气)**, **naut(船)**, -ics(…学)<br>以“航空、船”为研究对象的学科, 即“航空学” |
| aerospace<br><br>n. 宇宙空间 | **aero(空中, 空气)**, space(词: 空间)<br>涵盖地球大气层与外层空间的领域, 即航空航天空间 |
| aerial<br><br>adj. 空气的; 大气的; 航空的 | **aeri(空中, 空气)**, -al(…的)<br>表示与“空气”有关或具有该特征, 即“空气的, 大气的” |


### ag, ig, act

做, 行动

| 单词 | 拆解 |
| --- | --- |
| mitigate<br><br>v. 减轻; 缓和 | 源自拉丁语 mitigare“使柔和”<br>表示减轻严重程度或缓和影响 |
| agenda<br><br>n. 议事日程; 潜在意图; 议题 | 直接来自拉丁语 agenda（应当去做的事情）, 是 agere（做）的动形容词复数 |
| agent<br><br>n. 剂; 代理人; 代理商; 作用者 | **ag(做, 行动)**, -ent(人; 物)<br>执行行动或代表他人办事的人, 即代理人 |
| navigator<br><br>n. 领航员; 航行者 | **nav(船)**, **ig(做, 行动)**, -ator(人)<br>由“船”与“行动”共同限定词义, 表示“领航员, 航行者” |
| transaction<br><br>n. 交易; 事务(≠ transition 过渡); 业务 | trans-(横过, 越过), **act(做, 行动)**, -ion(行为, 结果)<br>跨越双方之间达成的行为, 即"交易, 事务" |
| exact<br><br>adj. 精密的 | ex-(出, 向外), **act(做, 行动)**<br>里里外外都做到了 |
| inactive<br><br>adj. 不活泼的; 没有生气的 | in-(无, 不, 非), **act(做, 行动)**, -ive(…的)<br>否定或缺少“做”所指的性质, 因此表示“不活泼的, 没有生气的” |
| prodigal<br><br>adj. 挥霍的; 浪费的 | 源自拉丁语 prodigus“挥霍的”, 与 prodigere“赶走、耗尽”相关<br>挥霍无度的; 回归的浪子 |


### agog

引导, 带领

| 单词 | 拆解 |
| --- | --- |
| pedagogue<br><br>n. 教师(常含蔑视之意) | 源自希腊语 paidagogos, 由 pais“儿童”与 agogos“引导者”构成<br>原指带领儿童者, 后指教师 |
| pedagogy<br><br>n. 教育学; 教学法; 教师职业 | **ped(儿童)**, **agog(引导, 带领)**, -y(活动)<br>引导儿童学习的活动和理论, 即教育学 |
| demagogic<br><br>adj. 煽动的; 蛊惑的 | **dem(人民)**, **agog(引导, 带领)**, -ic(…的)<br>以煽动方式带领或操纵民众, 因此表示蛊惑人心的 |


### agon

竞争, 斗争

| 单词 | 拆解 |
| --- | --- |
| agonize<br><br>v. 使极度痛苦; 折磨 | **agon(竞争, 斗争)**, -ize(…化, 使成)<br>使事物呈现“竞争”与“…化, 使成”所表达的状态, 即“使极度痛苦, 折磨” |
| agony<br><br>n. 极度痛苦; 痛苦的挣扎; 极度的痛苦 | **agon(竞争, 斗争)**, -y(性质, 状态)<br>围绕“竞争”这一核心含义构成, 表示“极度痛苦, 痛苦的挣扎” |
| agonistic<br><br>adj. 论战的; 好争论的 | **agon(竞争, 斗争)**, -istic(…的)<br>围绕“竞争”这一核心含义构成, 表示“论战的” |
| antagonistic<br><br>adj. 敌对的 | ant-(反对, 相反), **agon(竞争, 斗争)**, -istic(…的)<br>由“反对”与“竞争”共同限定词义, 表示“敌对的” |


### agr(i), agr(o)

田地, 土地

| 单词 | 拆解 |
| --- | --- |
| agrarian<br><br>n. 土地平等论者<br>adj. 农业的; 土地的; 耕地的 | **agr(田地, 土地)**, -arian(人)<br>围绕“农田”这一核心含义构成, 表示“土地的, 耕地的, 农业的” |
| agriculture<br><br>n. 农业; 农艺; 农学 | **agri(田地, 土地)**, **cult(耕作, 培养)**, -ure(行为, 结果)<br>耕田种地 |
| agriculturist<br><br>n. 农学家 | agriculture→agricultur(词: 农业), -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“农学家” |
| agronomist<br><br>n. 农(艺)学家 | agronomy→agronom(词: 农学), -ist(人)<br>研究农学及作物土地管理的人 |
| agronomy<br><br>n. 农学; 农艺学 | 经法语借入, 由希腊语 agros“田地”与 nomos“管理、安排”构成<br>记忆为管理田地的学科, 即农学 |


### alg

痛

| 单词 | 拆解 |
| --- | --- |
| analgesia<br><br>n. 痛觉缺失; 无痛 | an-(无, 不, 非), **alg(痛)**, -esia(状态, 情况)<br>处于无痛状态, 即痛觉缺失 |
| arthralgia<br><br>n. 关节痛 | **arthr(关节)**, **alg(痛)**, -ia(性质, 状态)<br>由“关节”与“痛”共同限定词义, 表示“关节痛” |
| hyperalgesia<br><br>n. 痛觉过敏 | hyper-(超过, 极度), **alg(痛)**, -esia(状态, 情况)<br>痛觉超过正常程度, 即痛觉过敏 |
| nostalgia<br><br>n. 怀旧; 乡愁; 思乡之情 | 源自希腊语 nostos（归乡）与 algos（痛苦）, 原指思乡病 |


### ali

其他

| 单词 | 拆解 |
| --- | --- |
| alienate<br><br>v. 转让; 使不和 | 源自拉丁语 alienare“使疏远”, 来自 alienus“属于别人的”<br>使某人变得像外人, 即疏远 |
| alias<br><br>n. 化名; 别名 | 直接来自拉丁语 alias“在别的时候; 以别的方式”<br>引申为在另一身份下使用的别名 |
| alien<br><br>n. 外国人; 外星人; 外来者; 外侨; 外星生物<br>adj. 外国的; 陌生的; 异类的 | **ali(其他)**, -en(做, 使)<br>来自其他地方之人, 即"外地人" |


### all(o)

其他, 不同

| 单词 | 拆解 |
| --- | --- |
| parallel<br><br>adj. 平行的<br>n. 平行线; 相似之物; 相似之处; 比得上<br>v. 与…… | 源自希腊语 para“在旁”与 allēlos“彼此”<br>表示彼此并列、延伸而不相交, 亦引申为相似 |
| parallelogram<br><br>n. 平行四边形 | parallel(词: 平行的), o(连接元音), **gram(书写, 记录)**<br>具有两组平行边的图形 |


### alter, ulter, altru

其他

| 单词 | 拆解 |
| --- | --- |
| adulterate<br><br>v. 掺杂; 掺假 | 源自拉丁语 adulterare“腐坏、掺假”<br>记忆为掺入异物而使品质不纯 |
| alter<br><br>v. 改变; 更改; 修改 | **alter(其他)**<br>变成其他样子, 即“改变” |
| alternate<br><br>n. 替补者; 候补<br>v. 交替; 轮流<br>adj. 交替的; 间隔的 | **alter(其他)**, n(连接字母), -ate(做, 使)<br>围绕“其他”这一核心含义构成, 表示“交替(的), 轮流(的)” |
| altercation<br><br>n. 争论; 口角 | **alter(其他)**, c(连接字母), -ation(行为, 结果)<br>双方轮番激烈争辩, 因此表示争论、口角 |
| alternative<br><br>adj. 两者择一的; 替代的; 非传统的<br>n. 可供选择的办法 | **alter(其他)**, n(连接字母), -ative(…的)<br>围绕"其他"这一核心含义构成, 表示可供替代选择的; 引申指与主流不同的, 即"非传统的" |
| altruism<br><br>n. 利他主义 | **altru(其他)**, -ism(主义)<br>把他人的利益置于自身之前, 即利他主义 |


### am(i)

爱, 友善

| 单词 | 拆解 |
| --- | --- |
| amateur<br><br>n. 业余爱好者; 外行<br>adj. 业余爱好的; 业余的 | 借自法语 amateur（爱好者）, 源自拉丁语 amare（爱）, 指因爱好而从事而非以此为职业的人 |
| amenity<br><br>n. 适意; 令人愉快的举动 | 源自拉丁语 amoenitas“宜人、愉悦”相关形式<br>由宜人的性质发展为提高舒适度的设施 |
| amity<br><br>n. 友好; 和善 | **am(爱, 友善)**, -ity(性质, 状态)<br>表示与“友善”有关的性质或状态, 即“友好, 和善” |
| amour<br><br>n. 不正当的男女关系 | **am(爱, 友善)**, -our(性质, 状态)<br>围绕“爱”这一核心含义构成, 表示“不正当的男女关系” |
| amiable<br><br>adj. 友善的; 和蔼可亲的 | **ami(爱, 友善)**, -able(可…的)<br>围绕“友善”这一核心含义构成, 表示“友善的, 和蔼可亲的” |
| amicable<br><br>adj. 友好的; 和善的 | **am(爱, 友善)**, -ic(…的), -able(可…的)<br>表示与“友善”有关或具有该特征, 即“友好的, 和善的” |
| amorous<br><br>adj. 色情的; 多情的; 恋爱的 | 经古法语借自拉丁语 amorosus, 核心 amor 表示“爱”<br>表示多情的、恋爱的 |


### ambul, ambl

行走

| 单词 | 拆解 |
| --- | --- |
| amble<br><br>n. 漫步 | **ambl(行走)**, e(连接字母)<br>由“行走”发展为缓慢、轻松地漫步 |
| ambulance<br><br>n. 流动医院; 野战医院; 救护车 | **ambul(行走)**, -ance(性质, 状态)<br>原指随军移动的医院, 后来转指运送病人的救护车 |
| preamble<br><br>n. 序言; 绪论 | pre-(先于, 预先), **ambl(行走)**, e(连接字母)<br>走在前面 |
| ambulatory<br><br>adj. 可走动的; 行走的 | **ambul(行走)**, -atory(…的)<br>围绕“行走”这一核心含义构成, 表示“可走动的, 行走的” |


### ampl(i)

宽, 大

| 单词 | 拆解 |
| --- | --- |
| amplify<br><br>v. 增强; 扩大 (声音); 充实 (陈述等); 扩大（声音）; 充实（陈述等） | **ampl(宽, 大)**, -ify(…化, 做…)<br>使范围、声音或影响变大 |
| amplifier<br><br>n. 放大器; 扩音机 | **ampli(宽, 大)**, -fier(做…的人或物)<br>围绕“大”这一核心含义构成, 表示“放大器” |
| amplitude<br><br>n. 广阔; 充足 | 源自拉丁语 amplitudo“广大、宽广”, 来自 amplus“大的、丰富的”<br>由范围广大引申为振幅、幅度 |
| ample<br><br>adj. 足够的; 丰裕的; 丰满的; 硕大的 | **ampl(宽, 大)**, e(连接字母)<br>由宽广引申为数量充足、足够的 |


### andr(o)

雄性, 男人

| 单词 | 拆解 |
| --- | --- |
| androgyne<br><br>n. 具有男女两性的人; 阴阳人 | 经拉丁语借自希腊语 androgunos, 由 andr“男人”与 gyne“女人”构成<br>兼具男性与女性特征者 |
| android<br><br>n. (科幻) 机器人; 似人自动机 | **andr(雄性, 男人)**, -oid(似…的（物）)<br>似...之物 |
| andrology<br><br>n. 人学; [医] 男科学 | **andro(雄性, 男人)**, -logy(…学, …研究)<br>以“男人”为研究对象的学科, 即“人学” |


### anim

生命; 心灵; 精神

| 单词 | 拆解 |
| --- | --- |
| animate<br><br>v. 使活泼; 激励 | **anim(生命)**, -ate(做, 使)<br>围绕“心灵”这一核心含义构成, 表示“使活泼, 激励” |
| animal<br><br>n. 动物<br>adj. 动物的; 肉体的 | **anim(生命)**, -al(…的)<br>围绕“呼吸”这一核心含义构成, 表示“动物” |
| animator<br><br>n. 赋予生气者; 鼓舞者 | **anim(生命)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“赋予生气者” |
| animism<br><br>n. 万物有灵论; [宗教] 泛灵论 | **anim(精神)**, -ism(主义)<br>认为万物都具有心灵或精神, 由此指泛灵论 |
| animosity<br><br>n. 憎恶; 仇恨 | **anim(生命; 心意; 精神; 气息)**, -osity(性质, 状态)<br>围绕“心灵”这一核心含义构成, 表示“憎恶, 仇恨” |
| equanimity<br><br>n. 沉着; 镇定; 平静 | **equ(相等)**, **anim(生命; 心意; 精神; 气息)**, -ity(性质, 状态)<br>内心保持平衡、不偏不摇, 因此表示沉着、镇定 |
| reanimation<br><br>n. 再生; 复活; 重振精神 | re-(回, 向后, 再次), **anim(生命)**, -ation(行为, 结果)<br>由“再次”与“心灵”共同限定词义, 表示“再生, 复活” |
| inanimate<br><br>adj. 无生命的; 无生气的 | 构词锚点：in 表示“无, 不, 非”; anim 表示“呼吸, 生命”; -ate 在此为形容词词尾, 不取动词义<br>否定或缺少“心灵”所指的性质, 因此表示“无生命的” |
| magnanimous<br><br>adj. 大度的; 宽宏大量的 | **magn(长, 大)**, **anim(生命; 心意; 精神; 气息)**, -ous(…的)<br>由“大”与“心灵”共同限定词义, 表示“宽宏大量的” |
| unanimous<br><br>adj. 一致的; 意见一致的 | un-(一, 单一), **anim(生命; 心意; 精神; 气息)**, -ous(…的)<br>众人如同具有同一个心意的, 即一致同意的 |


### ann, enn

年

| 单词 | 拆解 |
| --- | --- |
| annals<br><br>n. 编年史 | 来自拉丁语 annales libri“逐年的书”, 核心 ann 表示年<br>按年份记录的编年史 |
| annual<br><br>adj. 每年的; 年度的<br>n. 年刊; 年报; 一年生植物 | **ann, enn(年)**, -ual(…的)<br>一年一度发生的, 即每年的 |
| anniversary<br><br>n. 周年纪念日; 周年纪念 | **ann, enn(年)**, i(连接元音), **vers, vert(转)**, -ary(物)<br>岁月回转满一整年时的纪念日 |


### anth

花

| 单词 | 拆解 |
| --- | --- |
| anther<br><br>n. 花药(花的带花粉部分); 花粉囊 | 源自希腊语 antheros“开花的”相关形式<br>指花中产生并携带花粉的花药 |
| anthocyanin<br><br>n. 花色素苷; 花青素 | **antho(花)**, **cyan(蓝, 青)**, -in(…素)<br>由“花”与“青”共同限定词义, 表示“花色素苷, 花青素” |
| anthology<br><br>n. (诗; 文; 曲; 画等的)选集; 文学精华录 | **antho(花)**, **log(说, 言)**, -y(活动)<br>原指采集花朵, 后比喻汇集成组的诗文选集 |
| chrysanthemum<br><br>n. [植] 菊(花) | **chrys(金黄色)**, **anth(花)**, -em(行为的结果), -um(名词词尾)<br>名称原意为金黄色的花, 即菊花 |
| Helianthus<br><br>n. [植] 向日葵属 | **heli(太阳)**, **anth(花)**, -us(名词词尾)<br>向着太阳的花 |


### anthrop(e)

人类

| 单词 | 拆解 |
| --- | --- |
| anthropoid<br><br>n. 类人猿<br>adj. 似人的 | **anthrop(人类)**, -oid(似…的（物）)<br>外形像人, 既可指似人的, 也可指类人猿 |
| anthropologist<br><br>n. 人类学家 | **anthropo(人类)**, -logist(…学家)<br>研究人类及其社会文化的学者 |
| anthropomorphism<br><br>n. 拟人说 | 由 anthropo“人”与 morph“形态”形成<br>把非人事物赋予人的形态或性格, 即拟人 |
| misanthropy<br><br>n. 厌恶人类; 厌世; 愤世嫉俗 | **mis(憎恨, 厌恶)**, **anthrop(人类)**, -y(活动)<br>憎恨或厌恶人类的状态 |
| paleoanthropology<br><br>n. 古人类学 | paleo-(古, 旧), **anthropo(人类)**, -logy(…学, …研究)<br>以“古、人类”为研究对象的学科, 即“古人类学” |
| philanthropist<br><br>n. 博爱主义者; 慈善家 | **phil(爱)**, **anthrop(人类)**, -ist(人)<br>由“爱”与“人类”共同限定词义, 表示“博爱主义者, 慈善家” |


### apt, ept

适合, 适应

| 单词 | 拆解 |
| --- | --- |
| adapt<br><br>v. 使适应; 使适合; 改编 | ad-(到, 朝, 向), **apt(适合, 适应)**<br>使趋向于适合, 即"使适应" |
| adaptation<br><br>n. 适应; 适合; 改编本 | ad-(到, 朝, 向), **apt(适合, 适应)**, -ation(行为, 结果)<br>使事物趋向适合环境的过程或结果 |
| adept<br><br>n. 能手; 内行<br>adj. 熟练的; 内行的 | ad-(到, 朝, 向), **ept(适合, 适应)**<br>已经适应某项工作并非常合适, 因此表示熟练的、擅长的 |
| aptitude<br><br>n. 天赋; 天资; 天生的才能; 资质 | **apt(适合, 适应)**, -itude(性质, 状态)<br>围绕“适合”这一核心含义构成, 表示“天赋, 天资, 天生的才能” |
| ineptitude<br><br>n. 不适当; 愚蠢; 无能 | inept(词: 不适当的), -itude(性质, 状态)<br>在前词基础上加“-itude”构成名词, 表示“不适当” |
| adaptable<br><br>adj. 能适应的; 适应性强的; 可改编的 | adapt(词: 适应), -able(可…的)<br>在前词基础上加“-able”构成形容词, 表示“能适应的, 适应性强的” |
| adaptive<br><br>adj. 适应的; 适合的 | adapt(词: 适应), -ive(…的)<br>在前词基础上加“-ive”构成形容词, 表示“适应的, 适合的” |
| inept<br><br>adj. 不适当的; 笨拙的; 无能的 | in-(无, 不, 非), **ept(适合, 适应)**<br>否定或缺少“适合”所指的性质, 因此表示“不适当的” |


### aqu(a)

水

| 单词 | 拆解 |
| --- | --- |
| aquaculture<br><br>n. 水产养殖; (植物的) 溶液培养 | **aqua(水)**, **cult(耕作, 培养)**, -ure(行为, 结果)<br>由“水”与“养殖”共同限定词义, 表示“水产养殖” |
| aqualung<br><br>n. 水中呼吸器 | **aqua(水)**, lung(词: 肺)<br>由“水”与“肺”共同限定词义, 表示“水中呼吸器” |
| aquanaut<br><br>n. 潜航员; 海底作业员 | **aqua(水)**, **naut(船)**<br>像航海者一样在水下活动和观察的人, 即海底观察员 |
| aquarelle<br><br>n. 有透明感的水彩画 | 经法语借自意大利语 acquarella“水彩画”, 核心 acqua 表示水<br>以水调色绘成的画 |
| aquarium<br><br>n. 养鱼缸; 水族馆 | **aqu(水)**, -arium(场所, 地点)<br>围绕“水”这一核心含义构成, 表示“养鱼缸” |
| aquatint<br><br>n. [印] 凹版腐蚀制版法 | **aqua(水)**, tint(词: 浅色)<br>利用酸液腐蚀形成深浅色调的凹版技法, 即凹版腐蚀制版法 |
| aqueduct<br><br>n. 导水管; 引水槽; 沟渠 | **aqu(水)**, e(连接字母), **duct(引, 导)**<br>由“水”与“引导”共同限定词义, 表示“导水管” |
| aqueous<br><br>adj. 水的; 多水的 | **aqu(水)**, -eous(…的)<br>围绕“水”这一核心含义构成, 表示“水的” |


### arbitr

判断

| 单词 | 拆解 |
| --- | --- |
| arbitrate<br><br>v. 仲裁; 公断 | **arbitr(判断)**, -ate(做, 使)<br>围绕“判断”这一核心含义构成, 表示“仲裁, 公断” |
| arbitrage<br><br>n. 仲裁; 公断 | 源自法语 arbitrage“仲裁、裁定”, 与 arbitre“仲裁者”相关<br>由判断裁定发展为仲裁及跨市场套利 |
| arbitrator<br><br>n. 仲裁人 | **arbitr(判断)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“仲裁人” |
| arbitral<br><br>adj. 仲裁 (人) 的; 公断 (人) 的 | **arbitr(判断)**, -al(…的)<br>表示与“判断”有关或具有该特征, 即“仲裁 (人) 的, 公断 (人) 的” |
| arbitrary<br><br>adj. 任意的; 武断的; 专横的; 反复无常的 | **arbitr(判断)**, -ary(…的)<br>全凭个人判断的, 即"任意的" |


### arch(y)

为首; 统治

| 单词 | 拆解 |
| --- | --- |
| anarchy<br><br>n. 无政府状态; 混乱 | an-(无, 不, 非), **archy(统治)**<br>没有统治者或有效统治的状态, 即无政府状态 |
| archbishop<br><br>n. 大主教 | **arch(为首)**, bishop(词: 主教)<br>由“为首的”与“主教”共同限定词义, 表示“大主教” |
| archdiocese<br><br>n. 大主教管区 | **arch(为首)**, diocese(词: 主教教区)<br>由“大的”与“主教管区”共同限定词义, 表示“大主教管区” |
| matriarch<br><br>n. 女家长; 女族长 | **matri(母)**, **arch(统治)**<br>母系家族中居首并统领众人的女性, 即女家长、女族长 |
| monarch<br><br>n. 君主; 帝王 | mon-(单一, 独), **arch(统治)**<br>由一人独自统治, 即君主、帝王 |
| monarchy<br><br>n. 君主政体; 君主制度 | mon-(单一, 独), **archy(为首)**<br>由一人居首统治的政体, 即君主制度 |
| patriarch<br><br>n. 家长; 族长 | **patri(父祖)**, **arch(统治)**<br>父系家族中居首并统领众人的人, 即家长、族长 |
| patriarchy<br><br>n. 父权制; 父权制社会 | **patri(父祖)**, **archy(为首)**<br>围绕“首领”这一核心含义构成, 表示“父权制(社会)” |


### arch(a), archeo,archae(o)

古代; 原始

| 单词 | 拆解 |
| --- | --- |
| archaeology<br><br>n. 考古学 | **archaeo(古代; 原始)**, -logy(…学, …研究)<br>以“古代的”为研究对象的学科, 即“考古学” |
| archaeologist<br><br>n. 考古学家 | **archaeo(古代; 原始)**, -logist(…学家)<br>研究古代事物的学者, 即"考古学家" |
| archaeopteryx<br><br>n. 始祖鸟 | 词形来源：archeopteryx |
| Archaean<br><br>n. 太古代<br>adj. 太古代的 | **archae(古代; 原始)**, -an(…的)<br>围绕“古代的”这一核心含义构成, 表示“太古代(的)” |
| archetype<br><br>n. 原始模型; 原形 | **arch(为首)**, e(连接字母), type(词: 型)<br>由“原始的”与“模型”共同限定词义, 表示“原始模型, 原形” |


### ard, ars

热情; 灼热, 燃烧

| 单词 | 拆解 |
| --- | --- |
| ardour<br><br>n. 热情; 热心 | 词形来源：ardor |
| arson<br><br>n. 放火; 纵火 | 源自古法语 arson“燃烧”<br>表示故意放火或纵火罪 |
| arsonist<br><br>n. 放火犯; 纵火者 | arson(词: 放火), -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“放火犯” |
| ardent<br><br>adj. 热情的; 热烈的; 强烈的 | 源自拉丁语 ardens（燃烧着的）, 由燃烧引申为热烈、热情的 |


### arm

武器, 武装; 手臂

| 单词 | 拆解 |
| --- | --- |
| disarm<br><br>v. 缴械; 裁军 | dis-(否定, 相反), **arm(武器, 武装)**<br>把武器从人或国家手中移除, 因此表示缴械、裁军 |
| alarm<br><br>n. 警报; 惊恐; 闹钟<br>v. 使惊恐; 向……报警 | 源自意大利语呼喊 all'arme“拿起武器”<br>由紧急召集武装发展为警报和惊恐 |
| armament<br><br>n. 军队; 武器 | **arm(武器, 武装)**, a(连接字母), -ment(物)<br>用于武装的武器或军事装备 |
| armature<br><br>n. 盔甲; (动植物的)防护器官 | 源自拉丁语 armatura（装备、武装）, 记忆锚点是起支撑或防护作用的内部骨架、装甲或保护结构 |
| armistice<br><br>n. 停战; 休战 | **arm(武器, 武装)**, i(连接字母), **st(站立)**, -ice(性质, 状态)<br>战事停立 |
| disarmament<br><br>n. 裁减军备 | 由 disarm“解除武装”派生<br>削减或解除武器的过程 |
| armless<br><br>adj. 无武器的 | **arm(武器, 武装)**, -less(无…的, 不…的)<br>围绕“武器”这一核心含义构成, 表示“无武器的” |


### art

技巧; 技艺

| 单词 | 拆解 |
| --- | --- |
| artifice<br><br>n. 技巧; 诡计 | 经盎格鲁-诺曼法语借自拉丁语 artificium, 由 ars“技艺”与 facere“制作”构成<br>由精巧制作引申为巧计、诡计 |
| artisan<br><br>n. 手艺人; 工匠 | **art(技艺)**, -is(性质, 状态), -an(…的)<br>表示与“技艺”有关的性质或状态, 即“手艺人, 工匠” |
| artist<br><br>n. 艺术家 | **art(技艺)**, -ist(人)<br>表示从事或具有“技艺”特征的人, 即“艺术家” |
| artificial<br><br>adj. 人造的; 人工的; 不自然的 | **art(技艺)**, i(连接字母), -fic(造成…的, 产生…的), -ial(…的)<br>以技艺做成 |


### arter, asteri

动脉

| 单词 | 拆解 |
| --- | --- |
| arteriography<br><br>n. 动脉照相术; [医] 动脉脉搏描记法 | 由 arterio“动脉”与 graphy“记录、成像”构成<br>对动脉进行影像记录 |
| arteriosclerosis<br><br>n. [医] 动脉硬化 (症) | **arteri(动脉)**, o(连接元音), **scler(硬)**, -osis(状态, 过程)<br>由“动脉”与“硬”共同限定词义, 表示“动脉硬化 (症)” |
| arteritis<br><br>n. [医] 动脉炎 | **arter(动脉)**, -itis(…炎)<br>“动脉”发生炎症, 即“动脉炎” |
| artery<br><br>n. 动脉; 干线(指主要公路; 河流; 铁路线等) | 源自希腊语 arteria“动脉”, 经拉丁语进入英语<br>由输送血液的主要血管引申为交通干线 |
| arterial<br><br>adj. 动脉的 | **arteri(动脉)**, -al(…的)<br>表示与“动脉”有关或具有该特征, 即“动脉的” |


### arthr(o), articul

关节

| 单词 | 拆解 |
| --- | --- |
| articulate<br><br>v. 明白地说; 以关节连接; 使成为系统的整体<br>adj. 发音清晰的; 口才好的 | **articul(关节)**, -ate(做, 使)<br>围绕“关节”这一核心含义构成, 表示“连接, 使接合” |
| arthritis<br><br>n. [医] 关节炎 | **arthr(关节)**, -itis(…炎)<br>“关节”发生炎症, 即“关节炎” |
| arthropod<br><br>n. 节肢动物 | **arthro(关节)**, **pod(足, 脚)**<br>由“关节”与“足”共同限定词义, 表示“节肢动物(的)” |
| articulation<br><br>n. 连接; 接合; 发音 | articulate→articulat(词: 发音清晰的), -ion(行为, 结果)<br>由“发音清晰的”派生为当前词义 |
| osteoarthritis<br><br>n. 骨关节炎 | **osteo(骨)**, **arthr(关节)**, -itis(…炎)<br>“骨、关节”发生炎症, 即“骨关节炎” |
| articular<br><br>adj. 关节的 | **articul(关节)**, -ar(…的)<br>围绕“关节”这一核心含义构成, 表示“关节的” |


### astr(o), aster

星, 天体

| 单词 | 拆解 |
| --- | --- |
| astrodome<br><br>n. (飞机机身顶部透明的半圆形的) 天文观察窗; 天文航行舱 | **astro(星, 天体)**, dome(词: 圆顶)<br>由“天体”与“圆顶、穹隆”共同限定词义, 表示“(飞机机身顶部透明的半圆形的) 天文观察窗” |
| astrodynamics<br><br>n. 天文动力学 | **astro(星, 天体)**, **dynam(力, 力量)**, -ics(…学)<br>以“天体、力”为研究对象的学科, 即“天文动力学” |
| astrologer<br><br>n. 星占学家; 星占术家 | astrology→astrolog(词: 占星术), -er(人)<br>从事占星术的人 |
| astrology<br><br>n. 星占学; 占星术; 占星学 | **astro(星, 天体)**, -logy(…学, …研究)<br>以“星”为研究对象的学科, 即“星占学, 占星术” |
| astronautics<br><br>n. 宇宙航行学 | **astro(星, 天体)**, **naut(船)**, -ics(…学)<br>以“宇宙、船”为研究对象的学科, 即“宇宙航行学” |
| astrophotography<br><br>n. 天体照相术 | **astro(星, 天体)**, **photo(光)**, **graph(写, 画)**, -y(活动)<br>把天体的影子记录下来 |
| disaster<br><br>n. 灾难; 灾祸 | 经法语、意大利语进入英语, 历史意象是 disastro（不利的星象）, 即灾难 |
| astral<br><br>adj. 星的; 星状的 | **astr(星, 天体)**, -al(…的)<br>表示与“星”有关或具有该特征, 即“星的” |
| disastrous<br><br>adj. 灾难的 | disaster→disastr(词: 灾难), -ous(…的)<br>造成严重灾难的 |


### aud(i), audit, ed

听

| 单词 | 拆解 |
| --- | --- |
| obey<br><br>v. 听从; 服从; 顺从 | 经古法语 obeir 进入英语, 源自拉丁语 oboedire（倾听、服从） |
| audience<br><br>n. 读者; 观众 | **audi(听)**, -ence(性质, 状态)<br>表示与“听”有关的性质或状态, 即“听众” |
| audiology<br><br>n. 听觉学 | **audi(听)**, o(连接元音), -logy(…学, …研究)<br>以“听”为研究对象的学科, 即“听觉学” |
| audiometry<br><br>n. 测听术; 听力测定 | **audi(听)**, o(连接元音), **metr(测量)**, -y(性质, 状态)<br>测量“听”的仪器或方法, 即“测听术” |
| audit<br><br>n. 审计; 查账<br>v. 审计; 旁听 | **audit(听)**<br>听取账目 |
| auditorium<br><br>n. 礼堂; 观众席 | **audit(听)**, -orium(场所, 地点)<br>听讲的地方 |
| obedience<br><br>n. 听从; 服从 | 经古法语借自拉丁语 oboedientia“听从”<br>服从命令或权威 |
| audible<br><br>adj. 听得见的 | **aud(听)**, -ible(可…的)<br>围绕“听”这一核心含义构成, 表示“听得见的” |
| auditory<br><br>adj. 听觉的 | **audit(听)**, -ory(…的)<br>围绕“听”这一核心含义构成, 表示“听觉的” |
| inaudible<br><br>adj. 听不见的 | in-(无, 不, 非), **aud(听)**, -ible(可…的)<br>否定或缺少“听”所指的性质, 因此表示“听不见的” |


### auc, aug

增加

| 单词 | 拆解 |
| --- | --- |
| augment<br><br>v. 增加; 扩大; 加强; 提高 | 源自拉丁语 augmentare（增加）, 核心锚点是使数量或规模增长; 现代英语中整体作动词使用 |
| inaugurate<br><br>v. 开始; 开创; 使就任 | 源自拉丁语 inaugurare（通过占卜正式就任）, 后来表示正式开始、就职 |
| auction<br><br>n. 拍卖; 拍卖会<br>v. 拍卖; 竞拍 | 源自拉丁语 auctio（增加）, 因为竞买者不断提高出价而得名 |
| auctioneer<br><br>n. 拍卖商<br>v. 拍卖 | auction(词: 拍卖), -eer(人)<br>在前词基础上加“-eer”构成名词或动词, 表示“拍卖商” |
| augmentation<br><br>n. 增加; 扩大 | augment(词: 增加), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“增加” |
| augur<br><br>n. 占卜官; 预言者<br>v. 预示; 预言 | 直接借自拉丁语 augur“占兆者”<br>由观察征兆预测发展为预示 |
| augmentative<br><br>adj. 有增加力的 | augment(词: 增加), -ative(…的)<br>在前词基础上加“-ative”构成形容词, 表示“有增加力的” |


### aur(i), aur(o)

耳; 金

| 单词 | 拆解 |
| --- | --- |
| aural<br><br>adj. 耳的; 听觉的; 电视伴音; 气味的; 先兆的<br>n. 耳的; 听觉的; 电视伴音 | **aur(耳)**, -al(…的)<br>与耳或听觉有关的 |
| auricle<br><br>n. 耳廓; 心耳 | **auri(耳)**, -cle(小)<br>形似小耳朵, 因此指耳廓或心耳 |
| auricular<br><br>adj. 耳的; 听觉的; 心耳的 | **auri(耳)**, -cular(…的)<br>围绕“耳”这一核心含义构成, 表示“耳的” |
| auric<br><br>adj. 金的; 含金的; 三价金的 | **aur(金)**, -ic(…的)<br>由“金”派生, 指金的或三价金的 |


### av, avar

强烈的欲望

| 单词 | 拆解 |
| --- | --- |
| avarice<br><br>n. 贪婪 | **avar(强烈的欲望)**, -ice(性质, 状态)<br>围绕“强烈的欲望”这一核心含义构成, 表示“贪婪” |
| avidity<br><br>n. 热望; 热情; 贪婪 | avid(词: 渴望的), -ity(性质, 状态)<br>由“渴望的”派生为当前词义 |
| avaricious<br><br>adj. 贪婪的 | 经古法语借入, 源自拉丁语 avarus“贪婪的”<br>表示贪得无厌的 |
| avid<br><br>adj. 渴望的; 贪婪的 | **av(强烈的欲望)**, -id(…的)<br>围绕“强烈的欲望”这一核心含义构成, 表示“渴望的” |


### avi

鸟

| 单词 | 拆解 |
| --- | --- |
| aviary<br><br>n. 鸟舍; 鸟类饲养场 | **avi(鸟)**, -ary(场所)<br>饲养鸟类的场所, 即鸟舍 |
| aviation<br><br>n. 航空; 航空学; 飞行术 | **avi(鸟)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“航空” |
| aviator<br><br>n. 飞行员; 飞机驾驶员 | **avi(鸟)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“飞行员” |
| avifauna<br><br>n. (某一地区; 时期或环境内的)鸟类 | **avi(鸟)**, fauna(词: 动物群)<br>由“鸟”与“动物群”共同限定词义, 表示“(某一地区、时期或环境内的)鸟类” |
| avian<br><br>adj. 鸟的; 鸟纲的 | **avi(鸟)**, -an(…的)<br>围绕“鸟”这一核心含义构成, 表示“鸟的” |
