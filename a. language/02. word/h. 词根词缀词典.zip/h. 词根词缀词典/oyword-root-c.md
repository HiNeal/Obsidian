## oyword-root-c


### caco

不良; 令人不快

| 单词 | 拆解 |
| --- | --- |
| cacophony<br><br>n. 不和谐的音调; 粗音调; 声音异常 | **caco(不良)**, **phon(声音)**, -y(性质, 状态)<br>由“令人不快”与“声音”共同限定词义, 表示“不和谐的音调” |
| cacography<br><br>n. 拙劣的书写; 恶劣的字体; 拼写错误 | **caco(不良; 令人不快)**, **graph(写, 画)**, -y(活动)<br>书写不良或字体难看拙劣 |


### cad, cas, cay, cid

降, 落

| 单词 | 拆解 |
| --- | --- |
| coincide<br><br>v. 一致; 符合; 同时发生 | co-(与, 共同), in-(向内, 进入), **cid(降, 落)**, e(连接字母)<br>共同落在同一点或同一时间, 即同时发生、巧合 |
| decay<br><br>n. 腐烂; 衰败<br>v. 使衰退; 使腐败; 腐烂 | de-(下降, 降低), **cay(降, 落)**<br>不断降低跌落、逐渐衰败, 引申为"分解" |
| calculate<br><br>v. 计算; 考虑; 打算 | **calcul(计算)**, -ate(做, 使)<br>最初指用小石子计数, 后来泛指计算 |
| accident<br><br>n. 事故; 意外; 偶然的事 | 源自拉丁语 accidere“偶然发生”<br>表示意外发生的事情, 即事故 |
| cascade<br><br>n. 小瀑布 | **cas(降, 落)**, c(连接字母), -ade(行为, 结果)<br>围绕“降”这一核心含义构成, 表示“小瀑布” |
| case<br><br>n. 情况; 案例; 箱子; 容器(suitcase) | **cas(降, 落)**, e(连接字母)<br>原指发生、落到某种情形, 发展为具体案例或情况 |
| casualty<br><br>n. 受害者; 遇难者; 毁坏物; 损坏物; 伤亡人员 | **cas(降, 落)**, -ual(…的), -ty(性质, 状态)<br>表示与“降”有关的性质或状态, 即“受害者, 遇难者, 毁坏物, 损坏物” |
| coincidence<br><br>n. 巧合; 一致; 同时发生 | 源自中世纪拉丁语 coincidentia, 与 coincide“同时发生、相合”同源<br>两个事件恰好同时发生 |
| decadence<br><br>n. 颓废; 堕落 | de-(下降, 降低), **cad(降, 落)**, -ence(性质, 状态)<br>从原有高度向下坠落, 借喻道德或文化衰败, 即颓废 |
| incident<br><br>n. 事件; 事变; （两国间的）冲突 | in-(向内, 进入), **cid(降, 落)**, -ent(人; 物)<br>落到当前情境中发生的事情, 即事件 |
| occasion<br><br>n. 时刻; 场合; 机会; 理由; 时机<br>v. 引起; 惹起 | oc-(对着, 朝向, 在前), **cas(降, 落)**, -ion(行为, 结果)<br>原指事情落到眼前的时机, 后来表示场合、时机; 不宜只写‘事情落下来’ |
| calcium<br><br>n. 钙 | **calci(石灰, 钙石)**, -um(化学元素或物质)<br>名称源于石灰相关物质, 表示化学元素钙 |
| calculator<br><br>n. 计算者; 计算机; 计算器 | **calcul(计算)**, -ator(物)<br>执行计算的工具或装置, 即计算器 |
| calculus<br><br>n. 微积分; 结石 | **calcul(石灰, 钙石)**, -us(名词词尾)<br>原指用于计数的小石子, 后来发展为微积分; 医学中也指结石 |
| chalk<br><br>n. 粉笔; 白垩 | 源自拉丁语 calx（石灰）<br>指白色碳酸钙软岩（白垩）, 引申为书写用的粉笔 |
| accidental<br><br>adj. 偶然的; 意外的 | accident(词: 意外事件), -al(…的)<br>由“意外事件”派生为当前词义 |
| casual<br><br>adj. 随意的; 休闲的 | **cas(降, 落)**, -ual(…的)<br>突然降临的 |
| deciduous<br><br>adj. 脱落的 | de-(脱离, 取消, 除去), **cid(降, 落)**, u(连接字母), -ous(…的)<br>叶子会按季节脱离并落下的, 即落叶的 |
| incidental<br><br>adj. 偶然的; 附带发生的 | incident(词: 事件), -al(…的)<br>由“事件”派生为当前词义 |


### calc(i)

计算; 石灰, 钙石

| 单词 | 拆解 |
| --- | --- |
| calculate<br><br>v. 计算; 考虑; 打算 | **calcul(计算)**, -ate(做, 使)<br>最初指用小石子计数, 后来泛指计算 |
| calcification<br><br>n. 钙化(作用) | **calci(石灰, 钙石)**, -fication(…化, 做…)<br>使事物呈现“石灰”与“…化”所表达的状态, 即“钙化(作用)” |
| calcite<br><br>n. 方解石 | **calc(石灰, 钙石)**, -ite(矿物)<br>以碳酸钙为主要成分的矿物, 即方解石 |
| calcium<br><br>n. 钙 | **calci(石灰, 钙石)**, -um(化学元素或物质)<br>名称源于石灰相关物质, 表示化学元素钙 |
| calculator<br><br>n. 计算者; 计算机; 计算器 | **calcul(计算)**, -ator(物)<br>执行计算的工具或装置, 即计算器 |
| calculus<br><br>n. 微积分; 结石 | **calcul(石灰, 钙石)**, -us(名词词尾)<br>原指用于计数的小石子, 后来发展为微积分; 医学中也指结石 |
| chalk<br><br>n. 粉笔; 白垩 | 源自拉丁语 calx（石灰）<br>指白色碳酸钙软岩（白垩）, 引申为书写用的粉笔 |
| calcareous<br><br>adj. 石灰质的; 钙的 | **calc(石灰, 钙石)**, -ar(…的), -eous(…的)<br>围绕“石灰”这一核心含义构成, 表示“石灰质的, 钙的” |


### cale, calor(i)

热

| 单词 | 拆解 |
| --- | --- |
| caloric<br><br>adj. 热的; 热量的; 卡的 | **calor(热)**, -ic(…的)<br>围绕“热”这一核心含义构成, 表示“热 (量), 热质” |
| calorie<br><br>n. (热量单位) 卡 | **calor(热)**, -ie(小称, 爱称)<br>用于计量热量的单位 |
| calorimeter<br><br>n. 量热器; 卡计; 热量计 | **calori(热)**, **meter(测量器, 仪表)**<br>测量“热”的仪器或方法, 即“量热器” |
| calorimetry<br><br>n. 量热法; 量热学 | **calori(热)**, **metr(测量)**, -y(活动)<br>测量“热”的仪器或方法, 即“量热法” |
| calorific<br><br>adj. 生热的; 热量的 | **calori(热)**, -fic(造成…的, 产生…的)<br>能够产生热量或与热量有关, 即生热的、热量的 |


### calypt

遮盖

| 单词 | 拆解 |
| --- | --- |
| apocalyptic<br><br>adj. 大灾难的; 世界末日的 | apo-(分开, 离去), **calypt(遮盖)**, -ic(…的)<br>原指揭开遮盖、显露神启, 后来常表示毁灭性的大灾难或世界末日般的 |
| eucalyptus<br><br>n. 桉树; 尤加利树 | 由希腊语 eu“良好”与 calypt“遮盖”构成<br>花蕾被帽状结构良好覆盖, 因而得名桉树 |


### camp

田野, 平地

| 单词 | 拆解 |
| --- | --- |
| camp<br><br>n. 营地; 阵营<br>v. 露营; 宿营 | **camp(田野, 平地)**<br>原指可驻扎的平地, 后表示营地及宿营 |
| campaign<br><br>n. 运动(社会/政治/营销); 战役<br>v. 发起(或参加)运动 | 经法语 campagne“旷野、战场”进入英语<br>由战场上的连续行动发展为有组织的活动 |
| campaigner<br><br>n. 参加运动的人; 参加多次战役的军人; 竞选者 | campaign(词: 运动, 战役), -er(人)<br>发起或参加某项社会运动的人, 即活动家、倡导者 |
| campus<br><br>n. 校园; 学校场地; 大学 | **camp(田野, 平地)**, -us(名词词尾)<br>原指开阔场地, 后来专指学校或机构园区 |
| champion<br><br>v. 支持; 拥护<br>n. 冠军; 优胜者; 第一名 | 经古法语借自中世纪拉丁语 campio“战士”<br>由代表一方战斗的人发展为冠军或拥护者 |


### cand, cend, cens

白; 白热, 发光

| 单词 | 拆解 |
| --- | --- |
| cense<br><br>v. 用香熏; 向 (神) 焚香 | **cens(评估, 判断)**, e(连接字母)<br>围绕“评估”这一核心含义构成, 表示“用香熏” |
| incense<br><br>v. 用香熏; 烧香; 激怒 | in-(无, 不, 非), cense(词: 用香熏)<br>以“烧香”为语义核心构成, 表示“用香熏” |
| candidate<br><br>n. 候选人; 求职者; (英)考生 | 源自拉丁语 candidatus（穿白袍的人）, 古罗马求职者以白袍表明身份<br>引申指供选择的对象 |
| candle<br><br>n. 蜡烛 | **cand(白热, 发光)**, -le(小, 物)<br>发出微小光亮的物体, 即蜡烛 |
| candour<br><br>n. 坦白; 正直; 公正 | **cand(白热, 发光)**, -our(性质, 状态)<br>围绕“白”这一核心含义构成, 表示“坦白, 正直, 公正” |
| censer<br><br>n. 香炉 | 经法语借自拉丁语与 incense“香”相关的形式<br>指焚香用的香炉 |
| incandescence<br><br>n. 白热; 白炽 | incandesce→incandesc(词: 使白热化), -ence(性质, 状态)<br>由“使白热化”派生为当前词义 |
| incendiary<br><br>adj. 放火的; 纵火的; 能引起燃烧的; 煽动的<br>n. 燃烧弹 | in-(向内, 进入), **cend(白热, 发光)**, i(连接字母), -ary(…的)<br>能够点起火焰的物品或言论, 因此表示燃烧弹、煽动性的 |
| candid<br><br>adj. 坦白的; 诚实的 | **cand(白热, 发光)**, -id(…的)<br>围绕“白”这一核心含义构成, 表示“坦白的, 诚实的” |


### cap, capit, chap

头, 首; 冠

| 单词 | 拆解 |
| --- | --- |
| decapitate<br><br>v. 斩首; 砍头 | de-(脱离, 取消, 除去), **capit(头, 首)**, -ate(做, 使)<br>把头从身体上除去, 因此表示斩首 |
| cap<br><br>n. 帽子; 盖; 上限<br>v. 覆盖; 限制上限 | **cap(头, 首)**<br>戴在头部或覆盖顶部的帽、盖, 也可转化作动词 |
| cape<br><br>n. 披肩; 斗篷 | 经古法语 cape 借入, 最终源自晚期拉丁语 cappa“斗篷”<br>指披在肩上的无袖斗篷 |
| capital<br><br>n. 首都; 资本; 资金; 大写字母<br>adj. 死罪的 | **capit(头, 首)**, -al(物)<br>居于首要位置之物, 可指首都、资本或大写字母 |
| captain<br><br>n. 上尉; 队长; 船长 | 源自拉丁语 caput“头、首领”形成的晚期拉丁语 capitaneus, 经法语进入英语<br>位于一队之首的人, 即队长、船长 |
| chapeau<br><br>n. 帽子 | 借自法语 chapeau“帽子”, 最终源自拉丁语 cappa“斗篷、帽”<br>直接以法语帽子为记忆点 |
| chaplet<br><br>n. 花冠; 项圈; (昆虫的)刺冠 | **chap(头, 首)**, -let(小)<br>围绕“冠”这一核心含义构成, 表示“花冠” |
| chapter<br><br>n. (书等的)章; (人生或历史的)重要时期; （书等的）章; （人生或历史的）重要时期 | **chap(头, 首)**, t(连接字母), -er(物)<br>原指按首字母或标题划分的部分, 后来指章节 |


### cap(t), cept, ceive, cip, cup

抓夺; 容纳

| 单词 | 拆解 |
| --- | --- |
| captivate<br><br>v. 迷惑 | captive→captiv(词: 俘虏), -ate(做, 使)<br>由“俘虏”派生为当前词义 |
| conceive<br><br>v. 构思; 设想; 想象 | con-(与, 共同), **ceive(抓夺)**<br>把零散信息一起抓入心中形成想法, 因此表示构想、设想 |
| deceive<br><br>v. 欺骗; 蒙蔽; 误导 | de-(脱离, 取消, 除去), **ceive(抓夺)**<br>设法把人从真实情况中引开, 因此表示欺骗 |
| percept<br><br>v. 感觉; 感知 | per-(通过, 贯穿), **cept(取, 接受)**<br>被感官完整接收并形成的知觉内容, 即知觉、感知对象 |
| captive<br><br>adj. 被关押的; 受控制的<br>n. 俘虏 | **capt(抓夺)**, -ive(…的)<br>围绕“抓”这一核心含义构成, 表示“俘虏, 被监禁的人” |
| capture<br><br>n. 俘获; 捕获物<br>v. 俘获; 捕捉; 夺取 | **capt(抓夺)**, -ure(行为, 结果)<br>抓住、夺取或纳入的行为及结果, 即捕获; 也引申为准确呈现、吸引注意或唤起想象 |
| escape<br><br>n. 逃跑; 逃避现实<br>v. 逃跑; 被忽视; 未被注意到(the name escapes me) | 经古法语进入英语, 历史意象是“从斗篷或束缚中脱出”<br>表示摆脱控制或危险 |
| occupant<br><br>n. 占有人; 占用者 | oc-(对着, 朝向, 在前), **cup(抓夺)**, -ant(人; 物)<br>占据某个位置或空间的人 |
| occupation<br><br>n. 职业; 占领; 居住; 占据 | oc-(对着, 朝向, 在前), **cup(抓夺)**, -ation(行为, 结果)<br>占住并掌握一个位置, 因此表示占领; 长期占据时间的工作即职业 |
| perceive<br><br>v. 察觉; 意识到; 理解; 看待 | per-(通过, 贯穿), **ceive(抓夺)**<br>把感官获得的信息完整抓住, 因此表示察觉、理解 |
| principal<br><br>adj. 最重要的; 主要的; 本金的<br>n. 校长; 负责人; 主角; 本金; 委托人 | **prin(第一, 首要)**, **cip(抓夺)**, -al(…的)<br>处于首要位置的人, 因此可指负责人、校长; 作形容词表示主要的 |
| recipient<br><br>adj. 容纳的; 感受性强的<br>n. 接受者; 受方 | re-(回, 向后, 再次), **cip(抓夺)**, -ient(…的)<br>接过并接受某物的人, 即接受者、收件人 |
| capacious<br><br>adj. 宽敞的; 容积大的 | **cap(容纳)**, -acious(…的)<br>能够容纳很多东西的, 即宽敞的 |
| deceptive<br><br>adj. 误导的; 欺骗性的 | de-(脱离, 取消, 除去), **cept(取, 接受)**, -ive(…的)<br>把人从真实情况中引开的, 即欺骗性的 |
| imperceptible<br><br>adj. 感觉不到的 | im-(无, 不, 非), per-(通过, 贯穿), **cept(取, 接受)**, -ible(可…的)<br>否定或缺少“通过、认为”所指的性质, 因此表示“感觉不到的” |


### carb(o)

碳

| 单词 | 拆解 |
| --- | --- |
| carbide<br><br>n. 碳化物; 碳化钙 | **carb(碳)**, -ide(化合物)<br>围绕“碳”这一核心含义构成, 表示“碳化物” |
| carbohydrate<br><br>n. 碳水化合物; 糖类 | 构词锚点：carbo 表示“碳”; hydr 表示“水”; -ate 在此为名词或形容词词尾, 不取动词义<br>由“碳”与“水”共同限定词义, 表示“碳水化合物, 糖类” |
| carbon<br><br>n. 碳; 复写纸; 复写的副本 | **carb(碳)**, -on(粒子; 单位, 个体)<br>表示化学元素碳 |
| carbonite<br><br>n. 碳质炸药; 硝酸甘油; 硝酸钾; 锯屑炸药 | carbon(词: 碳), -ite(矿物)<br>含碳的物质, 此处指碳质炸药 |
| carbonic<br><br>adj. (含)碳的 | carbon(词: 碳), -ic(…的)<br>由“碳”派生为当前词义 |
| carboniferous<br><br>adj. 含碳的 | carbon(词: 碳), i(连接字母), **fer(带, 拿)**, -ous(…的)<br>携带或承载“碳”的事物, 即“含碳的” |


### card(i), cardio

心脏

| 单词 | 拆解 |
| --- | --- |
| bradycardia<br><br>n. [医] 心搏缓慢 | 由希腊语 bradys“缓慢”与 kardia“心脏”构成<br>心跳缓慢, 即心动过缓 |
| cardiology<br><br>n. 心病学 | **cardio(心脏)**, -logy(…学, …研究)<br>以“心脏”为研究对象的学科, 即“心病学” |
| cardiotonic<br><br>adj. 强心的<br>n. 强心剂 | 源自 cardio（心脏）与 tonic（增强张力的）组合, 表示增强心脏收缩力的 |
| electrocardiogram<br><br>n. 心电图 | **electr(电)**, o(连接元音), **cardio(心脏)**, **gram(书写, 记录)**<br>由“电”与“心脏”与“书写”共同限定词义, 表示“心电图” |
| tachycardia<br><br>n. 心动过速; 心搏过速 | 由表示“快速”的 tachy- 与表示“心脏”的 cardi- 结合<br>指心率异常加快的状态 |
| cardiac<br><br>adj. 心脏的 | **cardi(心脏)**, -ac(…的)<br>围绕“心脏”这一核心含义构成, 表示“心脏的” |


### carn(i)

肉

| 单词 | 拆解 |
| --- | --- |
| incarnate<br><br>v. 体现; 使具体化; 使实体化<br>adj. 化身的; 实体化的; 肉色的 | in-(向内, 进入), **carn(肉)**, -ate(做, 使)<br>使抽象事物进入肉身、获得形体, 因此表示化身、体现 |
| carnage<br><br>n. 残杀; 大屠杀; 被屠杀者的尸体 | 源自拉丁语 caro、carn-“肉”形成的法语 carnage“大量尸肉”<br>由遍地尸肉的景象发展为大屠杀 |
| carnality<br><br>n. 肉欲; 好色 | carnal(词: 肉欲的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“肉欲” |
| carnation<br><br>n. 肉色; 淡红色 | **carn(肉)**, -ation(行为, 结果)<br>围绕“肉”这一核心含义构成, 表示“肉色, 淡红色” |
| carnival<br><br>n. 狂欢节; 狂欢 | **carni(肉)**, **val(值, 价值)**<br>传统解释为斋期前向肉食告别的节庆, 后来表示狂欢节 |
| carnivore<br><br>n. 食肉动物; 食虫植物 | **carni(肉)**, **vor(吃)**, e(连接字母)<br>吃肉的(动物), 即"食肉动物" |
| incarnadine<br><br>n. 肉色; 深红色<br>v. 染红<br>adj. 肉色的; 深红色的; 血污的 | 源自法语 incarnadin“肉色的”<br>与 carn“肉”同源, 以鲜肉的颜色记忆为深红色、肉色的 |
| incarnation<br><br>n. 化身; 体现; 肉化 | 源自拉丁语 incarnatio, 由 in“进入”与 caro“肉身”构成<br>进入肉身, 即化身 |
| carnal<br><br>adj. 肉体的; 好色的; 世俗的 | **carn(肉)**, -al(…的)<br>表示与“肉”有关或具有该特征, 即“肉体的” |


### carp(o)

果实

| 单词 | 拆解 |
| --- | --- |
| endocarp<br><br>n. 内果皮 | end(o)-(在内, 内部), **carp(o)(果实)**<br>果实最内层包裹种子的硬质果皮结构 |
| pericarp<br><br>n. 果皮 | peri-(四周, 近), **carp(o)(果实)**<br>环绕并包裹果实果肉与种子的外层组织 |


### cast

纯; 投, 发射

| 单词 | 拆解 |
| --- | --- |
| cast<br><br>n. 铸件; 全体演员 | **cast(投, 发射)**<br>核心动作是投、掷, 由此发展出投射、铸造等义 |
| broadcast<br><br>v. 广播 | broad(词: 广泛的), cast(词: 投射; 散布)<br>向广大范围散布信号, 即广播 |
| castigate<br><br>v. 严惩; 谴责; 修订 | **cast(纯)**, **ig(做, 行动)**, -ate(做, 使)<br>做使...纯洁的事 |
| casting<br><br>n. 投; 掷; 扔 | **cast(投, 发射)**, -ing(物)<br>围绕“投”这一核心含义构成, 表示“投, 掷, 扔” |
| broadcasting<br><br>n. 广播 | broadcast(词: 广播), -ing(行为, 过程)<br>在前词基础上加“-ing”构成名词, 表示“广播” |
| chaste<br><br>adj. 纯洁的; 贞洁的; 朴实的 | 经古法语借自拉丁语 castus“纯洁的”<br>表示贞洁、纯洁的 |


### cau

小心, 警惕

| 单词 | 拆解 |
| --- | --- |
| caution<br><br>n. 谨慎; 警告<br>v. 警告; 提醒; 告诫 | **caut(小心, 警惕)**, -ion(行为, 结果)<br>保持警惕和小心的状态, 也可表示警告 |
| precaution<br><br>n. 预防措施; 警惕 | pre-(先于, 预先), **caut(小心, 警惕)**, -ion(行为, 结果)<br>事前采取的小心防范措施 |
| cautious<br><br>adj. 小心的; 谨慎的 | **caut(小心, 警惕)**, -ious(…的)<br>保持小心警惕的 |


### ceal, cell

隐藏

| 单词 | 拆解 |
| --- | --- |
| conceal<br><br>v. 隐藏; 隐瞒; 掩盖 | con-(与, 共同), **ceal(隐藏)**<br>使“隐藏”共同结合或发挥作用, 因此表示“隐藏, 隐瞒” |
| cell<br><br>n. 细胞; 单人牢房; 密室; 蜂房巢室; 电池 | 经古法语借自拉丁语 cella“小房间、储藏室”<br>核心空间义为封闭的小室, 后用于牢房和生物细胞 |
| cellar<br><br>n. 地窖; 地下室 | **cell(隐藏)**, -ar(…的)<br>小室 |


### ced, ceed, cess

行走; 退让

| 单词 | 拆解 |
| --- | --- |
| accede<br><br>v. 就任; 就职; 加入 | 源自拉丁语 accedere, 由 ad“向”与 cedere“行进、让步”构成<br>由走近引申为同意、就任 |
| concede<br><br>v. 承认; 允许 | con-(与, 共同), **ced(退让)**, e(连接字母)<br>共同退让一步, 引申为承认或让步 |
| exceed<br><br>v. 超过; 超出; 胜过 | ex-(出, 向外), **ceed(行走)**<br>由“超过”与“行”共同限定词义, 表示“超过, 超出” |
| intercede<br><br>v. 调停; 仲裁; 求情 | inter-(在...之间), **ced(行走)**, e(连接字母)<br>走到两方之间调停, 因此表示斡旋、代为求情 |
| precede<br><br>v. 居先; 优先; 领先 | pre-(先于, 预先), **ced(行走)**, e(连接字母)<br>由“先”与“行”共同限定词义, 表示“居先, 优先, 领先” |
| proceed<br><br>v. 继续做(或从事; 进行); 行进; 接下来做; 继续进行 | pro-(向前, 前进), **ceed(行走)**<br>向前继续行走, 即"继续" |
| recede<br><br>v. 后退; 退回 | re-(回, 向后, 再次), **ced(退让)**, e(连接字母)<br>向后走开, 因此表示后退、退去 |
| succeed<br><br>v. 成功; 继承 | suc-(在下, 向下), **ceed(行走)**<br>在前者之后接续其位置, 后来也表示顺利达到目标、成功 |
| access<br><br>n. 通路; 入径; 查阅 (或使用; 接近)的机会 (或权利) | ac-(到, 朝, 向), **cess(行走)**<br>走近并到达某处的途径或权利, 因此表示进入、使用权 |
| antecedent<br><br>adj. 先前的; 在前的<br>n. 前情; 先行词; 祖先 | ante-(先于, 早于), **ced, ceed, cess(行走; 退让)**, -ent(…的)<br>在时间或逻辑上行进在前面的事物或状态, 即“先前的, 先例, 前身” |
| excess<br><br>n. 超过<br>adj. 过量的 | ex-(出, 向外), **cess(行走)**<br>由“超过”与“行”共同限定词义, 表示“超越” |
| intercession<br><br>n. 调停; 调解; 求情 | inter-(在...之间), **cess(行走)**, -ion(行为, 结果)<br>介入两方之间进行调停或代求, 即斡旋、代祷 |
| necessity<br><br>n. 必要(性); 必需品; 必不可少的事物 | **necess(必要, 需要)**, -ity(性质, 状态)<br>必须具备或不可避免的状态, 即必要性 |
| precession<br><br>n. 先行; 前行 | pre-(先于, 预先), **cess(行走)**, -ion(行为, 结果)<br>由“前”与“行”共同限定词义, 表示“先行, 前行” |
| procedure<br><br>n. 程序; 步骤; 手续 | pro-(向前, 前进), **ced(行走)**, -ure(行为, 结果)<br>按照既定方向一步步向前进行, 因此表示程序、步骤 |
| proceeding<br><br>n. 进程; 程序; 进行 | 词形来源：proceed + ing-form |
| process<br><br>n. 进程; 流程; 工序<br>v. 处理; 加工 | pro-(向前, 前进), **cess(行走)**<br>由“前进”与“行”共同限定词义, 表示“进行, 手续, 方法” |
| recess<br><br>n. 休假; 休会; 休息 | re-(回, 向后, 再次), **cess(行走)**<br>从工作或会议中向后退开一段时间, 因此表示休息、休会 |
| successor<br><br>n. 继承人; 继任者; 接班人; 接替者; 后继的事物 | suc-(在下, 向下), **cess(行走)**, -or(人)<br>接续者 |
| inaccessible<br><br>adj. 难以接近的; 难以达到的 | 由 in“不可”与 accessible“可到达的”构成<br>无法到达、接近或获得的 |
| necessary<br><br>adj. 必要的; 必需的; 必然的 | ne-(无, 不, 非), **cess(退让)**, -ary(…的)<br>不能退让或无法缺少的, 即必要的 |
| successive<br><br>adj. 连续的; 接连的 | suc-(在下, 向下; 随后, 在后), **cess(行走)**, -ive(…的)<br>一个在另一个之后接着走来, 因此表示连续的 |


### ceiv, ceipt, cept

认为; 取, 接受

| 单词 | 拆解 |
| --- | --- |
| accept<br><br>v. 接受; 领受; 认可 | ac-(到, 朝, 向), **cept(取, 接受)**<br>把递来的事物接到手中, 因此表示接受、领受 |
| conceive<br><br>v. 构思; 设想; 想象 | con-(与, 共同), **ceive(抓夺)**<br>把零散信息一起抓入心中形成想法, 因此表示构想、设想 |
| deceive<br><br>v. 欺骗; 蒙蔽; 误导 | de-(脱离, 取消, 除去), **ceive(抓夺)**<br>设法把人从真实情况中引开, 因此表示欺骗 |
| intercept<br><br>v. 拦截; 截击 | inter-(在...之间), **cept(取, 接受)**<br>从中截取 |
| receive<br><br>v. 收到; 遭受; 接见 | re-(回, 向后, 再次), **ceive(抓夺)**<br>把送来的事物接到自己手中, 因此表示收到、接待 |
| acceptance<br><br>n. 接受; 接纳; 承认 | accept(词: 接受), -ance(性质, 状态)<br>在前词基础上加“-ance”构成名词, 表示“接受” |
| concept<br><br>n. 概念; 观念 | con-(与, 共同), **cept(取, 接受)**<br>统一思想认识 |
| conception<br><br>n. 概念; 观念; 设想 | concept(词: 概念), -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“概念” |
| exception<br><br>n. 例外; 除外 | except(词: 除), -ion(行为, 结果)<br>由“除”派生为当前词义 |
| perceive<br><br>v. 察觉; 意识到; 理解; 看待 | per-(通过, 贯穿), **ceive(抓夺)**<br>把感官获得的信息完整抓住, 因此表示察觉、理解 |
| receipt<br><br>n. 收条; 收据; 收到 | re-(回, 向后, 再次), **ceipt(取, 接受)**<br>接收到款项或物品后取得的书面凭证, 即收据 |
| receiver<br><br>n. (电话)听筒; 收音机; 电视机; 收赃人 | receive→receiv(词: 收到), -er(物)<br>接收信息的装置, 也可引申指接收人 |
| conceivable<br><br>adj. 可想像的; 想得到的; 可相信的 | conceive→conceiv(词: 构思), -able(可…的)<br>由“构思”派生为当前词义 |
| except<br><br>prep. 除⋯之外 | ex-(出, 向外), **cept(取, 接受)**<br>由“向外”与“认为”共同限定词义, 表示“除⋯之外” |


### celer

快, 速

| 单词 | 拆解 |
| --- | --- |
| accelerate<br><br>v. 加速; 促进 | ac-(到, 朝, 向), **celer(快, 速)**, -ate(做, 使)<br>使变得更快, 即"加速" |
| decelerate<br><br>v. (使)减速 | de-(下降, 降低), **celer(快, 速)**, -ate(做, 使)<br>由“使…变成”与“速”共同限定词义, 表示“(使)减速” |
| acceleration<br><br>n. 加速; 加速作用 | accelerate→acceler(词: 加速), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“加速” |
| accelerator<br><br>n. 加速者; 加速器 | accelerate→acceler(词: 加速), -ator(物)<br>使速度增加的装置或部件 |
| accelerometer<br><br>n. 加速计(仪) | 由 acceleration“加速度”的词干 acceler- 与表示测量仪器的 -ometer 构成<br>测量加速度的仪器 |
| celerity<br><br>n. 迅速; 敏捷 | **celer(快, 速)**, -ity(性质, 状态)<br>表示与“速”有关的性质或状态, 即“迅速, 敏捷” |
| deceleration<br><br>n. 减速 | de-(下降, 降低), **celer(快, 速)**, -ation(行为, 结果)<br>使速度降下来, 即减速过程 |


### cens

评估, 判断

| 单词 | 拆解 |
| --- | --- |
| censor<br><br>n. 检查员<br>v. 检查; 审查; 删改 | **cens(评估, 判断)**, -or(人)<br>原指负责评判、审查的人, 即审查员; 名词转化为动词后表示审查 |
| censorship<br><br>n. 审查制度; 信息管控 | censor(词: 审查者; 审查), -ship(性质, 状态)<br>实施审查的制度或状态 |
| censure<br><br>n. 严厉批评; 谴责<br>v. 严厉批评; 斥责 | **cens(评估, 判断)**, -ure(行为, 结果)<br>围绕“评估”这一核心含义构成, 表示“谴责, 责难, 指责, 抨击” |


### cent(i)

百; 百分之一

| 单词 | 拆解 |
| --- | --- |
| centralize<br><br>v. 集中 | **centr(中心)**, -al(…的), -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“集中” |
| concentrate<br><br>v. 集中 (心思); (使)浓缩; 集中（心思）; （使）浓缩 | con-(与, 共同), **centr(中心)**, -ate(做, 使)<br>使“中心”共同结合或发挥作用, 因此表示“集中 (心思)” |
| decentralize<br><br>v. 分散(行政权等) | de-(脱离, 取消, 除去), centralize(词: 集中)<br>取消权力或资源的集中状态, 即分散、去中心化 |
| cent<br><br>n. 分; 分币; 百 | **cent(百分之一)**<br>一个基本单位的百分之一, 即分币 |
| centenarian<br><br>n. 百岁老人<br>adj. 百岁老人的 | centenary→centenari(词: 一百年), -an(…的)<br>由“一百年”派生为当前词义 |
| centenary<br><br>adj. 一百年的<br>n. 一百年 | **cent(百)**, **en(年)**, -ary(…的)<br>由“一百年”构成, 表示百年或百周年的 |
| centimetre<br><br>n. 厘米; 公分 | **centi(百分之一)**, metre(词: 米)<br>一米的百分之一, 即厘米 |
| centipede<br><br>n. 蜈蚣 | **centi(百)**, **pede(脚)**<br>名称意为‘百足’, 指有许多足的蜈蚣 |
| century<br><br>n. 世纪; 百年 | 源自拉丁语 centuria（一百个组成的一组）, 由 centum（一百）发展为一百年 |
| percent<br><br>n. 每百中; 百分之... | per-(通过, 贯穿), **cent(百)**<br>按每一百计算, 即百分之 |
| percentage<br><br>n. 百分数; 百分率 | 由 percent“百分之…”形成 percentage<br>以百分数表示的比例, 即百分率 |
| centralism<br><br>n. 中央集权制; 集中制 | 由 central“中央的”形成 centralism<br>权力集中于中央的制度, 即集中制 |
| centralization<br><br>n. 集中; 中央集权 | **centr(中心)**, -al(…的), -ization(行为, …化)<br>在前词基础上加“-ization”构成名词, 表示“集中” |
| centricity<br><br>n. 中心; 中央 | **centr(中心)**, -icity(性质, 状态)<br>围绕“中心”这一核心含义构成, 表示“中心” |
| centrifugation<br><br>n. 离心作用 | **centr(中心)**, i(连接字母), **fug(逃, 散)**, -ation(行为, 结果)<br>由“中心”与“逃”共同限定词义, 表示“离心作用” |
| concentration<br><br>n. 集中 | concentrate→concentr(词: 集中), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“集中” |
| centigrade<br><br>n. 摄氏温度<br>adj. 摄氏度的 | **centi(百分之一)**, **grad(步, 级)**, e(连接字母)<br>把冰点和沸点间隔分成一百级的温标, 即摄氏温标 |
| anthropocentric<br><br>adj. 以人类为宇宙中心的 | **anthropo(人类)**, **centr(中心)**, -ic(…的)<br>由“人类”与“中心”共同限定词义, 表示“以人类为宇宙中心的” |
| central<br><br>adj. 中心的; 中央的 | **centr(中心)**, -al(…的)<br>表示与“中心”有关或具有该特征, 即“中心的” |
| centrifugal<br><br>adj. 离心的 | **centr(中心)**, i(连接字母), **fug(逃, 散)**, -al(…的)<br>由“中心”与“逃”共同限定词义, 表示“离心的” |
| centripetal<br><br>adj. 向心的 | **centr(中心)**, i(连接字母), **pet(追求, 争夺)**, -al(…的)<br>由“中心”与“追求”共同限定词义, 表示“向心的” |
| eccentric<br><br>adj. 古怪的; 不同圆心的<br>n. 怪人 | ec-(出, 向外), **centr(中心)**, -ic(…的)<br>中心以外的 |
| heliocentric<br><br>adj. 日心的; 以日心测量的 | **helio(太阳)**, **centr(中心)**, -ic(…的)<br>由“太阳”与“中心”共同限定词义, 表示“以太阳为中心的” |


### centr(o)

中心

| 单词 | 拆解 |
| --- | --- |
| centralize<br><br>v. 集中 | **centr(中心)**, -al(…的), -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“集中” |
| concentrate<br><br>v. 集中 (心思); (使)浓缩; 集中（心思）; （使）浓缩 | con-(与, 共同), **centr(中心)**, -ate(做, 使)<br>使“中心”共同结合或发挥作用, 因此表示“集中 (心思)” |
| decentralize<br><br>v. 分散(行政权等) | de-(脱离, 取消, 除去), centralize(词: 集中)<br>取消权力或资源的集中状态, 即分散、去中心化 |
| centralism<br><br>n. 中央集权制; 集中制 | 由 central“中央的”形成 centralism<br>权力集中于中央的制度, 即集中制 |
| centralization<br><br>n. 集中; 中央集权 | **centr(中心)**, -al(…的), -ization(行为, …化)<br>在前词基础上加“-ization”构成名词, 表示“集中” |
| centricity<br><br>n. 中心; 中央 | **centr(中心)**, -icity(性质, 状态)<br>围绕“中心”这一核心含义构成, 表示“中心” |
| centrifugation<br><br>n. 离心作用 | **centr(中心)**, i(连接字母), **fug(逃, 散)**, -ation(行为, 结果)<br>由“中心”与“逃”共同限定词义, 表示“离心作用” |
| concentration<br><br>n. 集中 | concentrate→concentr(词: 集中), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“集中” |
| anthropocentric<br><br>adj. 以人类为宇宙中心的 | **anthropo(人类)**, **centr(中心)**, -ic(…的)<br>由“人类”与“中心”共同限定词义, 表示“以人类为宇宙中心的” |
| central<br><br>adj. 中心的; 中央的 | **centr(中心)**, -al(…的)<br>表示与“中心”有关或具有该特征, 即“中心的” |
| centrifugal<br><br>adj. 离心的 | **centr(中心)**, i(连接字母), **fug(逃, 散)**, -al(…的)<br>由“中心”与“逃”共同限定词义, 表示“离心的” |
| centripetal<br><br>adj. 向心的 | **centr(中心)**, i(连接字母), **pet(追求, 争夺)**, -al(…的)<br>由“中心”与“追求”共同限定词义, 表示“向心的” |
| eccentric<br><br>adj. 古怪的; 不同圆心的<br>n. 怪人 | ec-(出, 向外), **centr(中心)**, -ic(…的)<br>中心以外的 |
| heliocentric<br><br>adj. 日心的; 以日心测量的 | **helio(太阳)**, **centr(中心)**, -ic(…的)<br>由“太阳”与“中心”共同限定词义, 表示“以太阳为中心的” |


### cephal

头

| 单词 | 拆解 |
| --- | --- |
| hydrocephalus<br><br>n. 脑积水; 脑水肿; 水脑 | **hydro(水)**, **cephal(头)**, -us(名词词尾)<br>由“水”与“头”共同限定词义, 表示“脑积水, 脑水肿, 水脑” |
| autocephalous<br><br>adj. 自有首领的; 独立的 | auto-(自己, 自动), **cephal(头)**, -ous(…的)<br>由“自己”与“头”共同限定词义, 表示“自有首领的, 独立的” |
| cephalic<br><br>adj. 头的; 头部的 | **cephal(头)**, -ic(…的)<br>表示与“头”有关或具有该特征, 即“头的, 头部的” |


### cern, cret, crimin

辨别; 分开

| 单词 | 拆解 |
| --- | --- |
| discern<br><br>v. 辨别; 看出; 觉察出; 分辨出 | dis-(否定, 相反), **cern(辨别)**<br>由“否定”与“辨别”共同限定词义, 表示“辨别, 看出” |
| discriminate<br><br>v. 歧视; 区别; 区分; 辨别<br>adj. 有分辨能力的; 显著的; 〈古〉明确的 | dis-(否定, 相反), **crimin(辨别)**, -ate(做, 使)<br>由“分离”与“辨别”共同限定词义, 表示“歧视, 区别, 区分, 辨别” |
| discernment<br><br>n. 看出; 觉察; 识别 | discern(词: 辨别), -ment(结果)<br>由“辨别”派生为当前词义 |
| discretion<br><br>n. 离散; 辨别(力); 谨慎 | 源自拉丁语 discretio“辨别、判断”<br>审慎判断以及自行决定的权力 |
| discrimination<br><br>n. 歧视; 辨别力; 鉴赏力; 识别; 区别 | dis-(否定, 相反), **crimin(辨别)**, -ation(行为, 结果)<br>先辨别差异, 后来也指基于差异作不公正对待, 即歧视 |
| discriminator<br><br>n. 辨别者; 歧视者; 鉴别器 | dis-(否定, 相反), **crimin(辨别)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“辨别者” |
| discernible<br><br>adj. 看得清的; 辨别得出的; 可辨别的 | dis-(否定, 相反), **cern(辨别)**, -ible(可…的)<br>由“否定”与“辨别”共同限定词义, 表示“可辨别的, 看得出的” |
| discreet<br><br>adj. 谨慎的; 考虑周到的 | 经古法语借自拉丁语 discretus“分辨开的、审慎的”<br>能分辨何时沉默, 即谨慎的 |
| discrete<br><br>adj. 分离的; 无联系的; 离散的 | dis-(否定, 相反), **cret(分开)**, e(连接字母)<br>由“分离”与“分开”共同限定词义, 表示“分离的” |
| discriminative<br><br>adj. 有辨别力的; 有识别力的; 差别对待的; 歧视的 | dis-(否定, 相反), **crimin(辨别)**, -ative(…的)<br>在前词基础上加“-ative”构成形容词, 表示“有辨别力的” |


### cert

确信, 确定

| 单词 | 拆解 |
| --- | --- |
| ascertain<br><br>v. 查明; 弄清; 确定 | 源自古法语 acertener“使确定”, 由 a- 与 certain“确定的”形成<br>通过查证使事情确定, 即查明 |
| certify<br><br>v. 证明; 颁发专业合格证书 | **cert(确信, 确定)**, -ify(…化, 做…)<br>使某事得到确定和正式证明, 即认证 |
| ascertainment<br><br>n. 查明; 确定 | ascertain(词: 查明), -ment(行为, 过程)<br>在前词基础上加“-ment”构成名词, 表示“查明” |
| certainty<br><br>n. 确实; 必然; 肯定; 必然的事 | 经古法语 certainete 借入, 与 certain“确定的”同源<br>确定无疑的状态 |
| certificate<br><br>n. 证书; 执照; 合格证 | 构词锚点：cert 表示“确实, 确信, 确定”; fic 表示“造成…的, 产生…的”; -ate 在此为名词或形容词词尾, 不取动词义<br>围绕“确实”这一核心含义构成, 表示“证明书, 证书” |
| certification<br><br>n. 证明; 证明书 | **cert(确信, 确定)**, i(连接字母), **fic(做)**, -ation(行为, 结果)<br>经权威机构核准确认的证明文件, 即证书、鉴定 |
| certifier<br><br>n. 证明者 | **cert(确信, 确定)**, i(连接字母), -fier(做…的人或物)<br>围绕“确实”这一核心含义构成, 表示“证明者” |
| ascertainable<br><br>adj. 可查明的; 可确定的 | ascertain(词: 查明), -able(可…的)<br>在前词基础上加“-able”构成形容词, 表示“可查明的, 可确定的” |
| certain<br><br>adj. 确定的; 某种程度的; 有限的 | 经古法语 certain 进入英语, 源自表示“确定”的拉丁语形式<br>表示已确定、无疑的 |
| uncertain<br><br>adj. 不确定的; 没把握的 | un-(无, 不, 非), certain(词: 确定的)<br>否定或缺少“确实的”所指的性质, 因此表示“不确定的, 没把握的” |


### chir(o), cheir(o)

手

| 单词 | 拆解 |
| --- | --- |
| chiropodist<br><br>n. 手足病医生 (尤指足病医生) | **chiro(手)**, **pod(足, 脚)**, -ist(人)<br>由“手”与“足”共同限定词义, 表示“手足病医生 (尤指足病医生)” |
| chiropody<br><br>n. 手足病治疗 | **chiro(手)**, **pod(足, 脚)**, y(连接字母)<br>在前词基础上加“-y”构成名词, 表示“手足病治疗” |
| chiropractic<br><br>adj. 用手按摩脊柱治疗法的 | 由希腊语 cheiro“手”与 praktikos“实践、操作”构成<br>以手法操作进行的脊椎治疗 |


### chem(i), chem(o), chemico

化学

| 单词 | 拆解 |
| --- | --- |
| chemical<br><br>adj. 化学的; 化学上用的<br>n. 化学药品 | **chem(化学)**, -ical(…的)<br>围绕“化学”这一核心含义构成, 表示“化学的, 化学上用的” |
| chemiluminescence<br><br>n. 化学发光; 化合光 | **chemi(化学)**, **lumin(光, 照)**, -escence(开始或正在形成某种状态)<br>由“化学”与“光”共同限定词义, 表示“化学发光” |
| chemisorption<br><br>n. 化学吸着 | **chemi(化学)**, **sorp(吸, 吞)**, -tion(行为, 结果)<br>通过化学作用发生的吸附, 即化学吸附 |
| chemist<br><br>n. 化学家 | **chem(化学)**, -ist(人)<br>表示从事或具有“化学”特征的人, 即“化学家” |
| chemistry<br><br>n. 化学 | chemist(词: 化学工作者), -ry(行为, 状态)<br>在前词基础上加“-ry”构成名词, 表示“化学” |
| chemosphere<br><br>n. 光化圈; 臭氧层 | 由 chemo“化学”与 sphere“层、区域”构成<br>以化学反应为特征的大气区域 |
| chemotaxis<br><br>n. 趋化性; 趋药性 | 由 chemo“化学物质”与 taxis“定向运动”构成<br>生物对化学刺激作出的定向运动 |
| chemotherapy<br><br>n. 化学疗法 | **chemo(化学)**, **therapy(治疗, 疗法)**<br>由“化学”与“疗法”共同限定词义, 表示“化学疗法” |


### chlor(o)

绿, 氯

| 单词 | 拆解 |
| --- | --- |
| chloral<br><br>n. 氯醛; 三氯乙醛; 水合氯醛 | 源自 chlor“氯”形成的化学名称<br>表示三氯乙醛及相关化合物 |
| chlorate<br><br>n. 氯酸盐 | 构词锚点：chlor 表示“绿, 氯”; -ate 在此为化学命名词尾, 不取动词义<br>围绕“氯”这一核心含义构成, 表示“氯酸盐” |
| chloride<br><br>n. 氯化物 | **chlor(绿, 氯)**, -ide(化合物)<br>围绕“氯”这一核心含义构成, 表示“氯化物” |
| chlorine<br><br>n. 氯; 氯气 | **chlor(绿, 氯)**, -ine(…的)<br>围绕“氯”这一核心含义构成, 表示“氯, 氯气” |
| chlorite<br><br>n. 亚氯酸盐; 绿泥石 | **chlor(绿, 氯)**, -ite(矿物)<br>含亚氯酸根的物质, 即亚氯酸盐; 另可同形指绿泥石矿物 |
| chloroform<br><br>n. 氯仿 | 由 chloro“氯”与 formic acid“甲酸”的 form- 混合命名<br>含氯的有机化合物氯仿 |
| chlorophyll<br><br>n. 叶绿素 | **chloro(绿, 氯)**, **phyll(叶)**<br>由“绿”与“叶”共同限定词义, 表示“叶绿素” |
| chlorosis<br><br>n. 缺绿病; 萎黄病 | **chlor(绿, 氯)**, -osis(状态, 过程)<br>围绕“绿”这一核心含义构成, 表示“缺绿病” |
| hypochlorite<br><br>n. 次氯酸盐 | hypo-(在下, 低于), chlorite(词: 亚氯酸盐)<br>由“在下”与“亚氯酸盐”共同限定词义, 表示“次氯酸盐” |
| perchlorate<br><br>n. 高氯酸盐 | per-(通过, 贯穿), chlorate(词: 氯酸盐)<br>由“通过”与“氯酸盐”共同限定词义, 表示“高氯酸盐” |


### chol(e)

胆汁

| 单词 | 拆解 |
| --- | --- |
| cholelithiasis<br><br>n. 胆石病 | **chole(胆汁)**, **lith(石)**, -iasis(疾病名称)<br>由“胆汁”与“石”共同限定词义, 表示“胆石病” |
| choleric<br><br>adj. 易怒的, 性情暴躁的; 生气的 | 经古法语和拉丁语借自希腊语 kholerikos“胆汁的”<br>按古体液说由胆汁过盛引申为易怒的 |
| cholesterol<br><br>n. 胆固醇 | **chole(胆汁)**, sterol(词: 固醇)<br>最初从胆汁相关材料中识别的固醇, 即胆固醇 |
| choline<br><br>n. 胆碱 | **chol(胆汁)**, -ine(…的)<br>围绕“胆汁”这一核心含义构成, 表示“胆碱” |


### chrom(o),chromat(o)

颜色, 色素; 铬

| 单词 | 拆解 |
| --- | --- |
| chromosome<br><br>n. 染色体 | **chromo(颜色, 色素)**, -some(…的)<br>围绕“颜色”这一核心含义构成, 表示“染色体” |
| photochrome<br><br>n. 彩色照片 | **photo(光)**, **chrom(颜色, 色素)**, e(连接字母)<br>由“光”与“颜色”共同限定词义, 表示“彩色照片” |
| chromatin<br><br>n. 染色质 | **chromat(颜色, 色素)**, -in(…素)<br>围绕“颜色”这一核心含义构成, 表示“染色质” |
| chromatogram<br><br>n. 色层谱 | **chromato(颜色, 色素)**, **gram(书写, 记录)**<br>围绕“颜色”这一核心含义构成, 表示“色层谱” |
| achromatic<br><br>adj. 非彩色的 | a-(无, 不, 非), **chromat(颜色, 色素)**, -ic(…的)<br>否定或缺少“颜色”所指的性质, 因此表示“非彩色的” |


### chron(o)

时间

| 单词 | 拆解 |
| --- | --- |
| synchronize<br><br>v. 同时发生; 同步 | 由 syn“共同”、chronos“时间”与 ize“使成”构成<br>使时间一致、同步 |
| chronicity<br><br>n. 长期性; 慢性 | **chron(时间)**, -icity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“长期性” |
| chronicle<br><br>n. 年代记; 记录; 编年史<br>v. 把...载入编年史 | **chron(时间)**, -icle(小)<br>在前词基础上加“-le”构成名词或动词, 表示“年代史” |
| chronograph<br><br>n. 计时器 | **chrono(时间)**, **graph(写, 画)**<br>记录或描绘“时间”的方法, 即“记时器” |
| chronology<br><br>n. 年代学; 年表; 事件发生顺序表 | **chrono(时间)**, -logy(…学, …研究)<br>以“时间”为研究对象的学科, 即“年代学” |
| chronometer<br><br>n. 精密计时器; 天文钟 | **chrono(时间)**, **meter(测量器, 仪表)**<br>测量“时间”的仪器或方法, 即“精密计时器” |
| synchronism<br><br>n. 同时发生; 同步性 | 由 syn“共同”与 chron“时间”形成<br>多个事件在同一时间发生的状态, 即同步 |
| chronic<br><br>adj. 长期的; 慢性的; 惯常的 | **chron(时间)**, -ic(…的)<br>表示与“时间”有关或具有该特征, 即“长期的, 慢性的” |
| synchronous<br><br>adj. 同时发生的; 一致的 | synchronize→synchron(词: 同步), -ous(…的)<br>在前词基础上加“-ous”构成形容词, 表示“同时发生的” |


### chrys(o)

金黄色; 金

| 单词 | 拆解 |
| --- | --- |
| chrysanthemum<br><br>n. [植] 菊(花) | **chrys(金黄色)**, **anth(花)**, -em(行为的结果), -um(名词词尾)<br>名称原意为金黄色的花, 即菊花 |
| chrysoberyl<br><br>n. 金绿宝石 | **chryso(金黄色)**, beryl(词: 绿宝石)<br>围绕“金黄色”这一核心含义构成, 表示“金绿宝石” |
| chrysoprase<br><br>n. 绿玉髓 | 源自希腊语 chrysos“金”与 prason“韭葱”<br>以金黄至葱绿色命名的宝石 |


### cid, cis

切, 杀

| 单词 | 拆解 |
| --- | --- |
| decide<br><br>v. 决定; 裁决; 下决心 | de-(脱离, 取消, 除去), **cid(切, 杀)**, e(连接字母)<br>从多个选项中切断其余可能, 留下一个决定 |
| incise<br><br>v. 切开; 雕刻 | in-(向内, 进入), **cis(切, 杀)**, e(连接字母)<br>向材料内部切入, 即切开、雕刻 |
| circumcision<br><br>n. 包皮环切; 环切术 | 源自拉丁语 circumcisio, 由 circum“环绕”与 caedere“切”构成<br>环绕切除包皮的手术 |
| excision<br><br>n. 切除; 除去; 割掉 | 源自拉丁语 excisio“切除”, 由 ex“向外”与 caedere“切”构成<br>从整体中切除 |
| fratricide<br><br>n. 杀兄弟(或姊妹)的行为; 杀兄弟(或姊妹)的人 | **fratr(兄弟)**, i(连接字母), **cid(切, 杀)**, e(连接字母)<br>由“兄弟”与“杀”共同限定词义, 表示“杀兄弟(或姊妹)的行为” |
| homicide<br><br>n. 杀人 (者) | 源自拉丁语 homicidium, 由 homo“人”与 caedere“杀”构成<br>杀人行为或杀人者 |
| incisor<br><br>n. 门牙; 切牙 | 源自拉丁语 incidere“切入”<br>用于切断食物的门齿 |
| suicide<br><br>n. 自杀 (者); n-自杀 | 源自拉丁语 sui（自己）与 caedere（杀）, 表示自杀 |
| concise<br><br>adj. 简明的; 简洁的; 简要的 | con-(与, 共同), cis-(在这一边), e(连接字母)<br>切除不必要的部分 |
| decisive<br><br>adj. 决定性的 | 与 decide“切断、决定”同源, 最终来自拉丁语 decidere<br>能够切断犹豫、确定结果的 |
| fungicidal<br><br>adj. 杀 (霉) 菌剂的; 杀真菌剂的 | **fung(履行, 执行)**, i(连接字母), **cid(切, 杀)**, -al(…的)<br>能够杀灭真菌, 因此表示杀真菌的或杀真菌剂的 |


### cine, cinema, cinemat(o)

运动; 电影

| 单词 | 拆解 |
| --- | --- |
| cine<br><br>n. 电影; 电影院 | **cine(电影)**<br>作为 cinema 的截短形式, 表示电影或电影院 |
| cinema<br><br>n. 电影院; 电影; 影片; 电影工业; 电影制片 (技) 术 | **cinema(电影)**<br>整词核心义即电影, 也指放映电影的场所 |
| cinemascope<br><br>n. 一种宽银幕电影 | **cinema(电影)**, **scop(镜, 观察)**, e(连接字母)<br>用于宽银幕电影呈现的系统 |
| cinematograph<br><br>n. 电影摄影 (或放映) 机 | **cinemato(运动)**, **graph(写, 画)**<br>围绕“电影”这一核心含义构成, 表示“电影摄影 (或放映) 机” |
| cinematography<br><br>n. 电影摄影术; 电影摄影学 | cinematograph(词: 电影摄影机), -y(活动)<br>在前词基础上加“-y”构成名词, 表示“电影摄影术” |
| cinematic<br><br>adj. 电影的 | **cinemat(电影)**, -ic(…的)<br>围绕“电影”这一核心含义构成, 表示“电影的” |


### ciner

灰, 骨灰

| 单词 | 拆解 |
| --- | --- |
| incinerate<br><br>v. 焚化; 焚毁; 烧成灰烬 | in-(向内, 进入), **ciner(灰, 骨灰)**, -ate(做, 使)<br>通过高温彻底燃烧将其化为灰烬 |
| incinerator<br><br>n. 焚化炉; 垃圾焚烧炉 | incinerate→incinerat(词: 焚化), -or(物)<br>用于集中高温焚烧生活或工业垃圾的炉具设施 |


### circ

圆, 环

| 单词 | 拆解 |
| --- | --- |
| circulate<br><br>v. (使)循环; (使)流通; 传播; 流传 | **circ(圆, 环)**, -ulate(做, 使)<br>使沿环形路线运行, 即循环或流通 |
| encircle<br><br>v. 围绕 | en-(进入, 包围), circle(词: 环绕)<br>使进入圆圈包围之中, 即"环绕" |
| circle<br><br>n. 圆; 圈; 环状物 | **circ(圆, 环)**, -le(小, 物)<br>词根本身即表示“圆”, 整词沿用该义 |
| circlet<br><br>n. 小圈; 环形饰物 | **circ(圆, 环)**, -let(小)<br>围绕“圆”这一核心含义构成, 表示“小圈” |
| circuit<br><br>n. 电路; 回路; 巡回; 环道<br>v. 绕…环行 | **circ(圆, 环)**, u(连接字母), **it(行, 走)**<br>绕一圈行走的路线, 引申为电路或巡回路线 |
| circulator<br><br>n. 传播者; 散布者 | circulate→circulat(词: 流通), -or(人)<br>由“流通”派生为当前词义 |
| microcircuit<br><br>n. 微型电路 | **micro(微, 小)**, circuit(词: 电路)<br>由“微”与“电路”共同限定词义, 表示“微型电路” |
| semicircle<br><br>n. 半圆; 半圆弧线; 半圆形 | semi-(半, 部分地), circle(词: 圆)<br>圆的一半, 即半圆 |
| circuitous<br><br>adj. 迂回的; 绕行的 | **circ(圆, 环)**, u(连接字母), **it(行, 走)**, -ous(…的)<br>在前词基础上加“-ous”构成形容词, 表示“迂回的” |
| circular<br><br>adj. 圆形的; 环形的; 迂回的 | **circ(圆, 环)**, -ular(…的)<br>围绕“圆”这一核心含义构成, 表示“圆形的, 环形的” |


### cirr(i), cirr(o)

触毛, 卷须; 卷云

| 单词 | 拆解 |
| --- | --- |
| cirrus<br><br>n. 触毛; 触须; 卷须; 卷云 | **cirr(触毛, 卷须)**, -us(名词词尾)<br>词根本身即表示“触毛”, 整词沿用该义 |
| cirrocumulus<br><br>n. 卷积云 | **cirr(i), cirr(o)(触毛, 卷须; 卷云)**, **cumul(o)(堆, 积; 积云)**, -us(物)<br>呈卷状丝缕与小球堆积形态的高云, 即卷积云 |


### cit

唤起, 激起; 召唤, 引用

| 单词 | 拆解 |
| --- | --- |
| cite<br><br>v. 引用; 提及; 举例; 传唤; 嘉奖 | **cit(召唤, 引用)**, e(连接字母)<br>词根本身即表示“引用”, 整词沿用该义 |
| excite<br><br>v. 使激动; 引起; 激起 | ex-(出, 向外), **cit(唤起, 激起)**, e(连接字母)<br>把情绪或活动激发出来, 因此表示使兴奋、刺激 |
| incite<br><br>v. 鼓舞; 刺激; 煽动 | in-(向内, 进入), **cit(唤起, 激起)**, e(连接字母)<br>以“激起”为语义核心构成, 表示“鼓舞, 刺激, 煽动” |
| recite<br><br>v. 背诵; 朗诵; 逐一讲述 | re-(回, 向后, 再次), **cit(召唤, 引用)**, e(连接字母)<br>把记住或写下的内容重新引用、念出, 即背诵、朗诵 |
| solicit<br><br>v. 恳求; 请求 | **soli(单独)**, **cit(唤起, 激起)**<br>不断激起对方注意并恳切请求, 因此表示恳求、征求 |
| exciting<br><br>adj. 令人激动的; 令人兴奋的; 使人激动的 | ex-(出, 向外), **cit(唤起, 激起)**, -ing(…的)<br>能够把情绪激发出来的, 即令人兴奋的 |


### citr(i)

柑橘, 柠檬

| 单词 | 拆解 |
| --- | --- |
| citral<br><br>n. 柠檬醛 | 源自 citrus“柑橘”形成的化学名称<br>表示具有柠檬香气的醛类化合物 |
| citrate<br><br>n. 柠檬酸盐 | 构词锚点：citr 表示“柑橘, 柠檬”; -ate 在此为化学命名词尾, 不取动词义<br>围绕“柠檬”这一核心含义构成, 表示“柠檬酸盐” |
| citrin<br><br>n. 柠檬素; 维生素 P | **citr(柑橘, 柠檬)**, -in(…素)<br>由“柠檬”与“…素”构成相关物质名称, 即“柠檬素, 维生素 P” |
| citrine<br><br>n. 柠檬色; 黄水晶<br>adj. 似柠檬的; 柠檬色的 | **citr(柑橘, 柠檬)**, -ine(…的)<br>围绕“柠檬”这一核心含义构成, 表示“似柠檬的, 柠檬色的” |
| citrus<br><br>n. 柠檬; 柑橘 | **citr(柑橘, 柠檬)**, -us(名词词尾)<br>围绕“柑橘”这一核心含义构成, 表示“柠檬, 柑橘” |
| citric<br><br>adj. 柠檬(性)的 | **citr(柑橘, 柠檬)**, -ic(…的)<br>表示与“柠檬”有关或具有该特征, 即“柠檬(性)的” |


### claim, clam

叫喊

| 单词 | 拆解 |
| --- | --- |
| declaim<br><br>v. 作慷慨激昂的演说; 雄辩; 朗诵 | de-(一再等加强意义), **claim(叫喊)**<br>把话大声、正式地说出来, 因此表示慷慨演说、朗诵 |
| exclaim<br><br>v. 呼喊; 惊叫 | ex-(出, 向外), **claim(叫喊)**<br>大声叫出 |
| proclaim<br><br>v. 宣布; 声明; 表明 | pro-(向前, 前进), **claim(叫喊)**<br>面向公众高声说出, 因此表示宣告、声明 |
| acclaim<br><br>n. 赞扬; 欢呼; 欢迎<br>v. 拥护; (为…)喝彩; 称誉; 誉为 | ac-(到, 朝, 向), **claim(叫喊)**<br>众人朝某人高声呼喊赞誉, 因此表示喝彩、称赞 |
| acclamation<br><br>n. 欢呼; 喝彩 | ac-(到, 朝, 向), **clam(叫喊)**, -ation(行为, 结果)<br>众人朝某人高声呼喊赞誉, 因此表示欢呼、喝彩 |
| clamour<br><br>n. 喧嚷; 吵闹 | **clam(叫喊)**, -our(性质, 状态)<br>在前词基础上加“-our”构成名词, 表示“喧嚷” |
| exclamation<br><br>n. 呼喊; 惊叫; 感叹词; 惊叹语 | ex-(出, 向外), **clam(叫喊)**, -ation(行为, 结果)<br>把强烈情绪高声喊出来, 因此表示惊呼、感叹 |


### clar

清楚, 明白

| 单词 | 拆解 |
| --- | --- |
| clarify<br><br>v. 澄清; 阐明; 使...明晰 | **clar(清楚, 明白)**, -ify(…化, 做…)<br>围绕“清楚”这一核心含义构成, 表示“澄清,阐明,使...明晰” |
| declare<br><br>v. 宣布; 申报; 宣告; 宣称; 声称 | de-(一再等加强意义), **clar(清楚, 明白)**, e(连接字母)<br>把事情清楚地说出来, 即宣布 |
| clarification<br><br>n. 澄清; 阐明 | **clar(清楚, 明白)**, i(连接字母), -fication(…化, 做…)<br>围绕“清楚”这一核心含义构成, 表示“澄清, 阐明” |
| clarion<br><br>n. 尖音号角<br>adj. 清澈响亮的 | **clar(清楚, 明白)**, -ion(行为, 结果)<br>围绕“清楚”这一核心含义构成, 表示“号角” |
| clarity<br><br>n. 清澈; 透明; 明晰 | **clar(清楚, 明白)**, -ity(性质, 状态)<br>表示与“清楚”有关的性质或状态, 即“清澈” |
| declaration<br><br>n. 声明; 宣言; 宣布 | de-(一再等加强意义), **clar(清楚, 明白)**, -ation(行为, 结果)<br>把原本不明之事公开讲清, 因此表示声明、宣言 |
| declarer<br><br>n. 宣告者; 声明者 | declare→declar(词: 声明), -er(人)<br>在前词基础上加“-er”构成名词, 表示“宣告者” |
| declarative<br><br>adj. 公告的; 宣言的; 说明的 | declare→declar(词: 声明), -ative(…的)<br>在前词基础上加“-ative”构成形容词, 表示“公告的” |


### cli, clin, clen, cliv

倾, 斜

| 单词 | 拆解 |
| --- | --- |
| decline<br><br>n. 下降; 衰退<br>v. 下降; 减少; 婉拒 | de-(下降, 降低), **clin(倾, 斜)**, e(连接字母)<br>向下倾斜, 引申为下降或衰退 |
| recline<br><br>v. 使向后靠; 斜倚 | re-(回, 向后, 再次), **clin(倾, 斜)**, e(连接字母)<br>由“向后”与“倾”共同限定词义, 表示“使向后靠” |
| anticline<br><br>n. [地] 背斜 | anti-(反对, 相反), **clin(倾, 斜)**, e(连接字母)<br>由“反对”与“斜”共同限定词义, 表示“背斜” |
| climax<br><br>n. 顶点; 高潮 | **cli(倾, 斜)**, **max(大)**<br>斜线上最高点 |
| declension<br><br>n. 倾斜; 衰落; 衰退 | de-(下降, 降低), **clen(倾, 斜)**, -sion(行为, 结果)<br>词形向不同语法形式发生偏转, 因此表示变格; 也可指倾斜、衰退 |
| declination<br><br>n. 倾斜; 下倾; 衰落 | de-(下降, 降低), **clin(倾, 斜)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“倾斜” |
| inclination<br><br>n. 倾向; 意向; 趋势; 倾斜(度) | in-(向内, 进入), **clin(倾, 斜)**, -ation(行为, 结果)<br>向内倾斜靠拢的行为, 即"倾向" |
| proclivity<br><br>n. 癖性; 倾向 | pro-(向前, 前进), **cliv(倾, 斜)**, -ity(性质, 状态)<br>由“向前”与“倾”共同限定词义, 表示“癖性, 倾向” |


### clud, clus, clos

关闭

| 单词 | 拆解 |
| --- | --- |
| conclude<br><br>v. 结束; 完结; 终了; 推断出; 得出结论 | con-(与, 共同), **clud(关闭)**, e(连接字母)<br>把讨论或过程完全关闭, 因此表示结束; 也可表示得出结论 |
| disclose<br><br>v. 揭露; 使公开 | dis-(否定, 相反), **clos(关闭)**, e(连接字母)<br>解除封闭, 使原来隐藏的内容显露, 因此表示揭露、公开 |
| enclose<br><br>v. 围住; 包围; 随函附上; 封入 | en-(进入, 包围), **clos(关闭)**, e(连接字母)<br>关在里面 |
| exclude<br><br>v. 排除; 排斥; 拒绝 | ex-(出, 向外), **clud(关闭)**, e(连接字母)<br>由“除去”与“关闭”共同限定词义, 表示“排除, 排斥” |
| include<br><br>v. 包含; 包括; 关住 | in-(向内, 进入), **clud(关闭)**, e(连接字母)<br>把事物封入一个整体之中, 即包括 |
| occlude<br><br>v. 使闭塞; 使堵塞 | oc-(对着, 朝向, 在前), **clud(关闭)**, e(连接字母)<br>由“对着”与“关闭”共同限定词义, 表示“使闭塞” |
| preclude<br><br>v. 防止; 阻止; 排除 | pre-(先于, 预先), **clud(关闭)**, e(连接字母)<br>预先把门关上, 使某事无法发生, 因此表示阻止、排除 |
| conclusion<br><br>n. 结束; 结论 | con-(与, 共同), **clus(关闭)**, -ion(行为, 结果)<br>过程被关闭后的终点或推理结果, 即结束、结论 |
| recluse<br><br>n. 隐遁者; 遁世者<br>adj. 隐遁的; 偏僻的 | re-(回, 向后, 再次), **clus(关闭)**, e(连接字母)<br>把自己关起、远离社会的人, 即隐士; 也表示隐居的 |
| conclusive<br><br>adj. 结论的; 总结性的; 最终的 | 源自晚期拉丁语 conclusivus, 与 conclude“结束、得出结论”同源<br>能够结束争论、确定结论的 |
| exclusive<br><br>adj. 独有的; 排他的 | ex-(出, 向外), **clus(关闭)**, -ive(…的)<br>把其他一切关在外面的, 即"唯一的, 专有的" |


### cogn

知道

| 单词 | 拆解 |
| --- | --- |
| recognize<br><br>v. 认识; 承认 | re-(回, 向后, 再次), **cogn(知道)**, -ize(…化, 使成)<br>再次知道并确认某对象, 即认出或承认 |
| cognition<br><br>n. 识; 认识力; 认识的结果 | **cogn(知道)**, -ition(行为, 结果)<br>知道、认识和处理信息的过程 |
| cognizance<br><br>n. 识; 察知; 审理 | **cogn(知道)**, -iz(…化, 使成), -ance(性质, 状态)<br>形成认识和知晓的状态 |
| precognition<br><br>n. 预知; 前知能力 | 由 pre“在前”与 cognition“认知”构成<br>事件发生前的知觉 |
| coral<br><br>adj. 珊瑚色的<br>n. 珊瑚 | **coral(珊瑚)**<br>核心义即珊瑚, 也由其典型颜色转化为形容词 |
| coralline<br><br>n. 珊瑚虫; 珊瑚状动物; 珊瑚状构造<br>adj. 珊瑚的; 由珊瑚组成的 | **coral(珊瑚)**, l(连接字母), -ine(…的)<br>围绕“珊瑚”这一核心含义构成, 表示“珊瑚的, 珊瑚藻的, 珊瑚色的” |
| cognitive<br><br>adj. 认识的; 认知的 | **cogn(知道)**, -itive(…的)<br>在前词基础上加“-itive”构成形容词, 表示“认识的” |
| cognizant<br><br>adj. 认识的; 知道的 | 19世纪由 cognizance“认知、知悉”直接形成<br>表示知道、意识到的 |
| recognizable<br><br>adj. 可认识的; 可认出的; 可公认的 | recognize→recogniz(词: 认出, 承认), -able(可…的)<br>具有足够特征而能够被认出的 |


### coral

珊瑚

| 单词 | 拆解 |
| --- | --- |
| coral<br><br>adj. 珊瑚色的<br>n. 珊瑚 | **coral(珊瑚)**<br>核心义即珊瑚, 也由其典型颜色转化为形容词 |
| coralline<br><br>n. 珊瑚虫; 珊瑚状动物; 珊瑚状构造<br>adj. 珊瑚的; 由珊瑚组成的 | **coral(珊瑚)**, l(连接字母), -ine(…的)<br>围绕“珊瑚”这一核心含义构成, 表示“珊瑚的, 珊瑚藻的, 珊瑚色的” |


### cord

心

| 单词 | 拆解 |
| --- | --- |
| accord<br><br>n. 协议; 符合; 和谐<br>v. 符合; 给予; 使一致 | ac-(到, 朝, 向), **cord(心)**<br>强化“心”这一动作或状态, 因此表示“一致” |
| accordance<br><br>n. 协调; 一致; 调和 | ac-(到, 朝, 向), **cord(心)**, -ance(性质, 状态)<br>在前词基础上加“-ance”构成名词, 表示“协调” |
| concord<br><br>n. 一致; 协调; 和谐 | con-(与, 共同), **cord(心)**<br>心在一起 |
| cordiality<br><br>n. 诚心; 热诚; 亲切 | cordial(词: 兴奋剂), -ity(性质, 状态)<br>由“兴奋剂”派生为当前词义 |
| discord<br><br>n. 不调和; 不和<br>v. 不一致; 刺耳 | dis-(否定, 相反), **cord(心)**<br>心不在一起 |
| discordance<br><br>n. 不一致; 不调和; 不和 | discord(词: 不一致), -ance(性质, 状态)<br>在前词基础上加“-ance”构成名词, 表示“不一致” |
| record<br><br>n. 记录; 履历; 档案<br>v. 记录; 记载; 标明<br>adj. 创纪录的 | re-(回, 向后, 再次), **cord(心)**<br>以备回忆之用 |
| recorder<br><br>n. 记录者; 录音机 | record(词: 记录), -er(人)<br>在前词基础上加“-er”构成名词, 表示“记录者” |
| cordate<br><br>adj. 心脏形的 | 构词锚点：cord 表示“心”; -ate 在此为形容词词尾, 不取动词义<br>围绕“心”这一核心含义构成, 表示“心脏形的” |
| cordial<br><br>adj. 衷心的; 诚心的; 真诚的 | **cord(心)**, i(连接字母), -al(…的)<br>表示与“心”有关或具有该特征, 即“衷心的, 诚心的, 真诚的” |


### corn

角

| 单词 | 拆解 |
| --- | --- |
| cornea<br><br>n. 角膜 | 源自中世纪拉丁语 cornea tela“角质的组织”, 核心 cornu 表示角<br>眼球前方透明、角质般坚韧的膜 |
| corner<br><br>n. 角; 拐角 | **corn(角)**, -er(物)<br>形成角的位置或区域 |
| cornet<br><br>n. 小号; 短号 | **corn(角)**, -et(小)<br>围绕“角”这一核心含义构成, 表示“小号, 短号” |
| unicorn<br><br>n. 独角兽 | uni-(一, 单一), **corn(角)**<br>由“一”与“角”共同限定词义, 表示“独角兽” |


### corp, corpor

体

| 单词 | 拆解 |
| --- | --- |
| incorporate<br><br>v. 包含; 并入; 吸收; (使)合并; 注册成立 | in-(向内, 进入), **corpor(体)**, -ate(做, 使)<br>使某部分进入一个整体, 即纳入或合并 |
| corporation<br><br>n. 社团; 法人; 公司; 企业 | **corpor(体)**, -ation(行为, 结果)<br>把成员组成一个法律上的整体, 即法人团体或公司 |
| corps<br><br>n. 兵团; (陆军)特种部队; (从事某工作或活动的)一群人 | **corp(体)**, s(连接字母)<br>围绕“体”这一核心含义构成, 表示“兵团, (陆军)特种部队, (从事某工作或活动的)一群人” |
| corpse<br><br>n. 死尸; 尸体 | 经古法语 cors 借自拉丁语 corpus“身体”<br>后来词义专化为尸体 |
| corpuscle<br><br>n. 血球; 细胞; 小体; 微粒 | **corp(体)**, -us(名词词尾), -cle(小)<br>围绕“体”这一核心含义构成, 表示“血球” |
| incorporator<br><br>n. 合并者; 团体成员 | incorporate→incorporat(词: 合并的), -or(人)<br>由“合并的”派生为当前词义 |
| corporal<br><br>adj. 肉体的; 身体的 | **corpor(体)**, -al(…的)<br>表示与“体”有关或具有该特征, 即“肉体的, 身体的” |
| corporate<br><br>adj. 社团的; 法人的; 团体的 | 构词锚点：corpor 表示“体”; -ate 在此为形容词词尾, 不取动词义<br>围绕“体”这一核心含义构成, 表示“社团的, 法人的” |
| corporative<br><br>adj. 社团的; 法人的 | **corpor(体)**, -ative(…的)<br>在前词基础上加“-ative”构成形容词, 表示“社团的” |
| corporeal<br><br>adj. 肉体的; 物质的 | **corpor(体)**, -eal(…的)<br>围绕“体”这一核心含义构成, 表示“肉体的, 物质的” |
| corpulent<br><br>adj. 肥胖的 | **corp(体)**, -ulent(多…的, 充满…的)<br>围绕“体”这一核心含义构成, 表示“肥胖的” |


### cosm(o)

世界, 宇宙

| 单词 | 拆解 |
| --- | --- |
| cosmics<br><br>n. 宇宙学 | **cosm(世界, 宇宙)**, -ics(…学)<br>在前词基础上加“-ics”构成名词, 表示“宇宙学” |
| cosmology<br><br>n. 宇宙论; 宇宙学 | **cosmo(世界, 宇宙)**, -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“宇宙论” |
| cosmonaut<br><br>n. 宇宙航行员 | **cosmo(世界, 宇宙)**, **naut(船)**<br>由“宇宙”与“船”共同限定词义, 表示“宇宙航行员” |
| cosmopolis<br><br>n. 国际都市 | **cosmo(世界, 宇宙)**, **polis(城市)**<br>由“世界”与“城市”共同限定词义, 表示“国际都市” |
| cosmopolitanism<br><br>n. 世界主义 | **cosmo(世界, 宇宙)**, **polit(政治)**, -an(…的), -ism(主义)<br>把自己视为世界共同体成员的思想 |
| macrocosm<br><br>n. 宏观世界; 宏观宇宙 | **macro(长, 大)**, **cosm(世界, 宇宙)**<br>由“宏”与“世界”共同限定词义, 表示“宏观世界, 宏观宇宙” |
| microcosm<br><br>n. 微观世界; 微观宇宙; 小天地; 小世界 | **micro(微, 小)**, **cosm(世界, 宇宙)**<br>由“微”与“世界”共同限定词义, 表示“微观世界, 微观宇宙” |
| cosmic<br><br>adj. 宇宙的; 极大的 | **cosm(世界, 宇宙)**, -ic(…的)<br>表示与“宇宙”有关或具有该特征, 即“宇宙的” |


### cour, cours, cur, curs

跑

| 单词 | 拆解 |
| --- | --- |
| occur<br><br>v. 发生; 出现 | oc-(对着, 朝向, 在前), **cur(跑)**<br>事情迎面运行到眼前, 引申为发生、出现 |
| recur<br><br>v. 再发生; 重新浮现 | re-(回, 向后, 再次), **cur(跑)**<br>再次运行到眼前, 即再发生或重新出现 |
| concourse<br><br>n. 集合; 汇合; 总汇; 中央大厅 | con-(与, 共同), **cours(跑)**, e(连接字母)<br>人流共同汇聚之处, 因此表示集合、中央大厅 |
| concurrence<br><br>n. 同时发生; 同意; 一致 | con-(与, 共同), **curr(跑)**, -ence(性质, 状态)<br>多件事共同运行、同时发生, 引申为同时发生或意见一致 |
| courier<br><br>n. 信使; 送急件的人 | **cour(跑)**, -ier(人)<br>围绕“跑”这一核心含义构成, 表示“信使” |
| course<br><br>n. 课程; (一道)菜; 过程; 进程 | **cours(跑)**, e(连接字母)<br>本义奔跑的路线, 引申为学习或事情推进的进程, 即"课程"; 也指宴席依次上桌的"一道菜" |
| cursive<br><br>adj. 草书的; 草书体的<br>n. 草书; 草书原稿 | **curs(跑)**, -ive(…的)<br>围绕“跑”这一核心含义构成, 表示“(字迹) 草写的” |
| currency<br><br>n. 流行; 流通; 通货; 通用; 货币 | **cur(跑)**, r(连接字母), -ency(性质, 状态)<br>处于流通运行状态的事物, 引申为货币或通行程度 |
| intercourse<br><br>n. 交往; 交际; 交流 | inter-(在...之间), **cours(跑)**, e(连接字母)<br>人或信息在彼此之间往来, 因此表示交往、交流 |
| precursor<br><br>n. 先行者; 先驱者; 前任; 前辈 | pre-(先于, 预先), **curs(跑)**, -or(人)<br>跑在前面、预示后来事物的人或事, 即先驱、前兆 |
| succour<br><br>n. 解救; 援助者<br>v. 解救; 援助 | suc-(在下, 向下), **cour(跑)**<br>随后赶到 |
| cursory<br><br>adj. 仓促的; 草率的 | **curs(跑)**, -ory(…的)<br>围绕“跑”这一核心含义构成, 表示“仓促的, 草率的” |


### cover

遮, 盖

| 单词 | 拆解 |
| --- | --- |
| discover<br><br>v. 发现; 暴露; 显示 | dis-(否定, 相反), **cover(遮, 盖)**<br>移开遮盖, 使原先隐藏之物显现, 因此表示发现 |
| recover<br><br>v. 恢复; 痊愈; 重新获得; 收回; 挽回 | re-(回, 向后, 再次), **cover(遮, 盖)**<br>重新取得并恢复原有状态, 因此表示康复、找回 |
| uncover<br><br>v. 发现; 揭开; 揭露 | un-(无, 不, 非), **cover(遮, 盖)**<br>去掉覆盖物, 使内容显露, 因此表示揭开、发现 |
| coverage<br><br>n. 覆盖范围; 新闻报道; 保险范围; 涉及范围 | **cover(遮, 盖)**, -age(总称, 集合)<br>围绕“遮”这一核心含义构成, 表示“所包括的范围 (或区域、数额等)” |
| coverlet<br><br>n. 床罩 | **cover(遮, 盖)**, -let(小)<br>围绕“遮”这一核心含义构成, 表示“床罩” |
| covert<br><br>n. 树丛; 隐藏处<br>adj. 隐蔽的; 偷偷摸摸的; 隐密的 | 经古法语 covert“被覆盖的”传入, 与 cover 同源<br>由被覆盖引申为隐藏的, 也可转化作名词表示隐蔽处 |
| discovery<br><br>n. 发现 | discover(词: 发现), -y(活动)<br>在前词基础上加“-y”构成名词, 表示“发现” |
| recovery<br><br>n. 痊愈; 收回; 复得; 恢复 | recover(词: 恢复), -y(活动)<br>恢复到正常或健康状态的过程 |


### cracy

统治, 政体

| 单词 | 拆解 |
| --- | --- |
| aristocracy<br><br>n. 贵族统治 | aristo(词: 贵族), **cracy(统治, 政体)**<br>由“贵族”与“统治”共同限定词义, 表示“贵族统治” |
| autocracy<br><br>n. 独裁 (政治); 专制 (制度) | auto-(自己, 自动), **cracy(统治, 政体)**<br>由“自己”与“统治”共同限定词义, 表示“独裁 (政治)” |
| autocrat<br><br>n. 独裁者; 暴君 | auto-(自己, 自动), **crat(统治者)**<br>由“自己”与“统治者”共同限定词义, 表示“独裁者” |
| bureaucracy<br><br>n. 官僚制度; 官僚作风 | bureau(词: 办公处), **cracy(统治, 政体)**<br>由“办公桌”与“统治”共同限定词义, 表示“官僚政治, 官僚主义” |
| bureaucrat<br><br>n. 官僚 | 由 bureau“行政机构”与 crat“统治者、官员”构成, 仿法语 bureaucrate<br>行政机构中的官僚 |
| democracy<br><br>n. 民主; 民主政治; 民主政体; 民主主义 | **demo(人民)**, **cracy(统治, 政体)**<br>由人民统治的政体, 即"民主" |
| theocracy<br><br>n. 神权政治; 僧侣政治 | **theo(神)**, **cracy(统治, 政体)**<br>由“神”与“统治”共同限定词义, 表示“神权政治” |
| autocratic<br><br>adj. 独裁的; 专制的 | autocrat(词: 独裁者), -ic(…的)<br>在前词基础上加“-ic”构成形容词, 表示“独裁的” |


### crat

统治者

| 单词 | 拆解 |
| --- | --- |
| aristocracy<br><br>n. 贵族统治 | aristo(词: 贵族), **cracy(统治, 政体)**<br>由“贵族”与“统治”共同限定词义, 表示“贵族统治” |
| autocracy<br><br>n. 独裁 (政治); 专制 (制度) | auto-(自己, 自动), **cracy(统治, 政体)**<br>由“自己”与“统治”共同限定词义, 表示“独裁 (政治)” |
| autocrat<br><br>n. 独裁者; 暴君 | auto-(自己, 自动), **crat(统治者)**<br>由“自己”与“统治者”共同限定词义, 表示“独裁者” |
| bureaucracy<br><br>n. 官僚制度; 官僚作风 | bureau(词: 办公处), **cracy(统治, 政体)**<br>由“办公桌”与“统治”共同限定词义, 表示“官僚政治, 官僚主义” |
| bureaucrat<br><br>n. 官僚 | 由 bureau“行政机构”与 crat“统治者、官员”构成, 仿法语 bureaucrate<br>行政机构中的官僚 |
| democracy<br><br>n. 民主; 民主政治; 民主政体; 民主主义 | **demo(人民)**, **cracy(统治, 政体)**<br>由人民统治的政体, 即"民主" |
| theocracy<br><br>n. 神权政治; 僧侣政治 | **theo(神)**, **cracy(统治, 政体)**<br>由“神”与“统治”共同限定词义, 表示“神权政治” |
| autocratic<br><br>adj. 独裁的; 专制的 | autocrat(词: 独裁者), -ic(…的)<br>在前词基础上加“-ic”构成形容词, 表示“独裁的” |


### crani(o)

头盖

| 单词 | 拆解 |
| --- | --- |
| craniotomy<br><br>n. 颅骨切开术; 破头盖术 | **cranio(头盖)**, **tomy(切, 割)**<br>切开“头盖”的术式, 即“颅骨切开术, 破头盖术” |
| cranium<br><br>n. 头盖; 脑壳; 头盖骨 | **crani(头盖)**, -um(名词词尾)<br>包围脑部的头盖骨 |
| cranial<br><br>adj. 头盖的; 头盖骨的; 头的 | **crani(头盖)**, -al(…的)<br>围绕“头盖”这一核心含义构成, 表示“头盖的, 头盖骨的” |


### cre, cret, creas

生长, 增长

| 单词 | 拆解 |
| --- | --- |
| decrease<br><br>n. 减少<br>v. 减小; 减少 | de-(下降, 降低), **creas(生长, 增长)**, e(连接字母)<br>使原有增长向下退减, 因此表示减少、下降 |
| increase<br><br>n. 增加; 增长<br>v. 增加; 增大 | in-(向内, 进入), **creas(生长, 增长)**, e(连接字母)<br>进入持续增长的状态, 即增加 |
| concrete<br><br>n. 混凝土<br>adj. 具体的; 实在的 | con-(与, 共同), **cret(生长, 增长)**, e(连接字母)<br>各成分共同凝结、长成一个整体, 引申为具体的或混凝土 |
| decrement<br><br>n. 减少; 减缩; 消耗; 减缩量 | de-(下降, 降低), **cre(生长, 增长)**, -ment(行为, 过程)<br>使增长量减去一部分, 因此表示减少、减量 |
| increment<br><br>n. 增长; 增加量; 增额; 定期加薪 | in-(向内, 进入), **cre(生长, 增长)**, -ment(结果)<br>增长形成的结果, 即增量 |
| increasing<br><br>adj. 增加的; 增长的; 增强的 | increase→increas(词: 增加), -ing(…的)<br>正在增加或呈增长趋势的 |
| incremental<br><br>adj. 增长的; 增值的 | increment(词: 增加), -al(…的)<br>由“增加”派生为当前词义 |


### creat

做, 创造

| 单词 | 拆解 |
| --- | --- |
| create<br><br>v. 创造; 创作; 引起; 产生 | **creat(做, 创造)**, e(连接字母)<br>做出原先不存在的事物, 即创造 |
| creation<br><br>n. 天地万物; 宇宙; [the C-] 创世; 创造(物); 创作(物) | **creat(做, 创造)**, -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“创造” |
| creativity<br><br>n. 创造力 | **creat(做, 创造)**, -ivity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“创造力” |
| creator<br><br>n. 创造者; 创作者; [the C-] 造物主; 上帝 | **creat(做, 创造)**, -or(人)<br>在前词基础上加“-or”构成名词, 表示“创造者” |
| creature<br><br>n. 创造物; 生物; 动物 | **creat(做, 创造)**, -ure(行为, 结果)<br>在前词基础上加“-ure”构成名词, 表示“创造物” |
| recreation<br><br>n. 娱乐; 消遣 | re-(回, 向后, 再次), **creat(做, 创造)**, -ion(行为, 结果)<br>通过休闲活动重新恢复精力; 也可表示再创造 |
| creative<br><br>adj. 有创造力的; 创造性的; 创作的; 产生的; 引起的 | **creat(做, 创造)**, -ive(…的)<br>在前词基础上加“-ive”构成形容词, 表示“有创造力的” |
| recreational<br><br>adj. 消遣的; 娱乐的 | recreation(词: 消遣), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“消遣的” |


### cred

相信, 信任

| 单词 | 拆解 |
| --- | --- |
| accredit<br><br>v. 相信; 认可; 委任; 把……归于 | 源自拉丁语 accredere“给予信任”, 由 ad“向”与 credere“相信”形成<br>正式给予信任和资格, 即认可、授权 |
| credence<br><br>n. 信任; 凭证; 证件 | **cred(相信, 信任)**, -ence(性质, 状态)<br>表示与“信任”有关的性质或状态, 即“信任” |
| credential<br><br>n. 国书; 凭据; 证明书 | **cred(相信, 信任)**, -ent(…的), -ial(…的)<br>在前词基础上加“-ent”、“-al”构成名词或形容词, 表示“信任的” |
| credit<br><br>n. 信用; 信任; 声誉; 学分; 赊购<br>v. 归功于; 相信 | 源自拉丁语 creditum“受托之物、借贷”, 与 credere“相信”相关<br>基于信任允许延期付款, 发展为信用、赊购和学分 |
| credo<br><br>n. 信条; [宗]信经 | 源自拉丁语 credo（我相信）, 表示宗教信经或个人信条 |
| credulity<br><br>n. 轻信; 易信 | 源自拉丁语 credulitas, 核心 credere 表示相信<br>过于容易相信的性质 |
| creed<br><br>n. 信条; 信念 | 源自拉丁语 credo“我相信”<br>由信仰宣言引申为信条 |
| discredit<br><br>n. 无信用; 丢脸; 不名誉<br>v. 不信; 怀疑; 使丢脸 | dis-(否定, 相反), credit(词: 信任)<br>由“否定”与“信任”共同限定词义, 表示“不信任” |
| credible<br><br>adj. 可信的; 有根据的 | **cred(相信, 信任)**, -ible(可…的)<br>围绕“相信”这一核心含义构成, 表示“可信的, 可靠的” |
| creditable<br><br>adj. 可信的 | credit(词: 信用), -able(可…的)<br>由“信用”派生为当前词义 |
| incredible<br><br>adj. 难以置信的 | in-(无, 不, 非), **cred(相信, 信任)**, -ible(可…的)<br>达到无法相信的程度, 即难以置信的 |
| incredulous<br><br>adj. 不轻信的; 怀疑的 | in-(无, 不, 非), **cred(相信, 信任)**, -ulous(…的)<br>否定或缺少“相信”所指的性质, 因此表示“不轻信的, 怀疑的” |


### crit,cris

评断, 决定

| 单词 | 拆解 |
| --- | --- |
| criticise<br><br>v. 批评; 批判; 评论 | critic(词: 批评家), -ise(…化, 使成)<br>在前词基础上加“-ise”构成动词, 表示“批评” |
| crisis<br><br>n. 危机; 决定性时刻; 危机关头; 转折点 | **cris(评断, 决定)**, -is(性质, 状态)<br>到了必须作出判断和决定的转折点, 因此表示危机、关键时刻 |
| criterion<br><br>n. 标准; 准则 | 直接借自希腊语 kriterion“判断的尺度”<br>表示用于评判的标准或准则 |
| critic<br><br>n. 批评家; 挑剔的人 | **crit(评断, 决定)**, -ic(人)<br>负责作出评断的人, 即批评家、评论家 |
| criticism<br><br>n. 批评; 指责; 评论 | 由 critic“批评者、评论者”派生为行为名词<br>表示分析评价, 常指指出缺点的批评 |
| critique<br><br>n. 批评; 批判; 批评法; 评论(文) | 借自法语 critique, 源自希腊语 kritike“判断的艺术”<br>以分析判断为核心的评论 |
| critical<br><br>adj. 评论(性)的; 批判(性)的; 关键的; 危急的 | **crit(评断, 决定)**, -ical(…的)<br>表示与“评断”有关或具有该特征, 即“批评的” |


### cruc(i)

十字

| 单词 | 拆解 |
| --- | --- |
| crucify<br><br>v. 把⋯钉死在十字架上; 折磨; 使苦恼 | **cruci(十字)**, -fy(…化, 做…)<br>围绕“十字”这一核心含义构成, 表示“把⋯钉死在十字架上” |
| cruise<br><br>v. 乘船游览; 巡航; 以平稳的速度行驶<br>n. 乘船游览 | 17世纪借自荷兰语 kruisen“交叉航行”, 与 cross 同源<br>由来回航行发展为巡航或乘船游览 |
| crucifer<br><br>n. 十字花植物; [宗] 仪仗队中捧十字架者 | **cruci(十字)**, **fer(带, 拿)**<br>携带或承载“十字”的事物, 即“仪仗队中捧十字架者, 十字花植物” |
| crucifix<br><br>n. 耶稣钉在十字架上的图像; 十字架 | **cruci(十字)**, fix(词: 固定)<br>由“十字”与“固定”共同限定词义, 表示“耶稣钉在十字架上的图像” |
| cruciform<br><br>adj. 十字形的 | **cruci(十字)**, -form(…形状的)<br>围绕“十字”这一核心含义构成, 表示“十字形 (的)” |
| cruiser<br><br>n. 巡洋舰 | cruise→cruis(词: 巡航), -er(物)<br>由“巡航”派生为当前词义 |
| crusade<br><br>n. 十字军 | 经法语和西班牙语借入, 来自拉丁语 crux“十字架”<br>原指以十字架为标志的宗教远征 |
| crux<br><br>n. 十字形; 十字架形; 关键; 重要之点 | 直接借自拉丁语 crux“十字架”<br>由关键交叉点引申为问题的核心 |
| crucial<br><br>adj. 至关重要的; 关键性的 | **cruci(十字)**, -al(…的)<br>原指道路交叉处般的关键点, 引申为至关重要的 |
| cruciate<br><br>adj. 十字形的 | 构词锚点：cruci 表示“十字”; -ate 在此为形容词词尾, 不取动词义<br>围绕“十字”这一核心含义构成, 表示“十字形的” |
| cruciferous<br><br>adj. 带有十字架的; 十字花科的 | crucifer(词: 仪仗队中捧十字架者), -ous(…的)<br>在前词基础上加“-ous”构成形容词, 表示“带有十字架的” |


### cry(o)

冷, 冻

| 单词 | 拆解 |
| --- | --- |
| cryobiology<br><br>n. 低温生物学 | **cryo(冷, 冻)**, **bio(生命, 生物)**, -logy(…学, …研究)<br>以“冷、生物”为研究对象的学科, 即“低温生物学” |
| cryogen<br><br>n. 致冷剂; 冷冻剂 | **cryo(冷, 冻)**, **gen(出生, 产生)**<br>由“冷”与“出生”共同限定词义, 表示“致冷剂, 冷冻剂” |
| cryogenics<br><br>n. 低温学; 低温实验法 | cryogen(词: 致冷剂), -ics(…学)<br>由“致冷剂”派生为当前词义 |
| cryolite<br><br>n. 冰晶石 | 由希腊语 kryos“冰冷”与 lithos“石”构成<br>因外观似冰而得名的冰晶石 |
| cryosurgery<br><br>n. 冷冻手术 | **cryo(冷, 冻)**, surgery(词: 外科)<br>由“冷”与“外科、手术”共同限定词义, 表示“冷冻手术” |


### crypt(o)

隐藏, 秘密

| 单词 | 拆解 |
| --- | --- |
| decrypt<br><br>v. 解密; 破译 | de-(脱离, 取消, 除去), **crypt(隐藏, 秘密)**<br>去除密码造成的遮蔽, 使内容重新可读, 即解密 |
| crypto<br><br>n. 秘密成员; 秘密支持者 | cryptocurrency 的截短形式时表示加密货币; 也可作 crypto- 的口语名词, 指隐秘支持者或秘密事物 |
| cryptogram<br><br>n. 密码; 暗记; 暗号; 密码文 | **crypto(隐藏, 秘密)**, **gram(书写, 记录)**<br>由“秘密”与“文字”共同限定词义, 表示“密码(文), 暗号(文)” |
| cryptography<br><br>n. 密码学; 密码术 | cryptograph(词: 密码), -y(活动)<br>在前词基础上加“-y”构成名词, 表示“密码学, 密码术” |
| cryptology<br><br>n. 隐语; 密码术 | **crypto(隐藏, 秘密)**, -logy(…学, …研究)<br>以“隐藏”为研究对象的学科, 即“隐语” |


### crystall(o)

晶体, 水晶

| 单词 | 拆解 |
| --- | --- |
| crystallize<br><br>v. 使结晶; 使定形; 具体化; 明朗化 | **crystall(晶体, 水晶)**, -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“使结晶” |
| crystallite<br><br>n. 雏晶; 微晶 | **crystall(晶体, 水晶)**, -ite(矿物)<br>微小的晶体单位, 即雏晶或微晶 |
| crystallography<br><br>n. 结晶学 | **crystallo(晶体, 水晶)**, **graph(写, 画)**, -y(活动)<br>记录或描绘“晶体”的方法, 即“结晶学” |
| crystalline<br><br>adj. 水晶的; 水晶般的; 清澈透明的 | **crystall(晶体, 水晶)**, -ine(…的)<br>在前词基础上加“-ine”构成形容词, 表示“水晶的” |


### cub, cumb

躺, 卧

| 单词 | 拆解 |
| --- | --- |
| incubate<br><br>v. 孵化; 孵(卵); 培养(细胞; 细菌等); 有(传染病在体内)潜伏 | in-(向内, 进入), **cub(躺, 卧)**, -ate(做, 使)<br>由“向内”与“躺”共同限定词义, 表示“孵化, 孵(卵), 培养(细胞、细菌等), 有(传染病在体内)潜伏” |
| concubine<br><br>n. 姘妇 | 源自拉丁语 concubina, 由 con“共同”与 cubare“躺卧”构成<br>与某人同居但非正式配偶的女性 |
| cubicle<br><br>n. 小卧室; 小室 | **cub(躺, 卧)**, -icle(小)<br>围绕“卧”这一核心含义构成, 表示“小卧室” |
| incubation<br><br>n. 孵卵; 伏巢; 孵化 | in-(向内, 进入), **cub(躺, 卧)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“孵卵” |
| incubator<br><br>n. 孵化器; 孵化员 | in-(向内, 进入), **cub(躺, 卧)**, -ator(物)<br>让卵、细胞或早产儿在内部稳定发育的装置, 即孵化器、保育箱 |
| cubism<br><br>n. (20 世纪初艺术的)立体主义 | cube→cub(词: 立方体), -ism(主义)<br>以立方体式几何形体表现对象的艺术流派, 即立体主义 |
| cubist<br><br>n. 立体派艺术家 | cube→cub(词: 立方体), -ist(人)<br>从事立体主义创作的人, 即立体派艺术家 |
| cuboid<br><br>n. 骰骨; 立方体<br>adj. 立方形的; 骰骨的 | cube→cub(词: 立方体), -oid(似…的（物）)<br>形状像立方体的物体, 即长方体或立方形物体 |
| cubical<br><br>adj. 立方体的; 立方的 | cube→cub(词: 立方体), -ical(…的)<br>具有立方体形状的, 即立方的 |


### cub(i)

立方, 立方体

| 单词 | 拆解 |
| --- | --- |
| cube<br><br>n. 立方体; 三次方; 三次需; 立方形的东西 | 经拉丁语借自希腊语 kybos“立方体、骰子”<br>表示六面方正的立方体 |
| cubical<br><br>adj. 立方体的, 立方的 | cube→cub(词: 立方体), -ical(…的)<br>具有立方体形状的, 即立方的 |
| cubism<br><br>n. 立体派 | cube→cub(词: 立方体), -ism(主义)<br>以立方体式几何形体表现对象的艺术流派, 即立体主义 |
| cubist<br><br>n. 立体派艺术家 | cube→cub(词: 立方体), -ist(人)<br>从事立体主义创作的人, 即立体派艺术家 |
| cuboid<br><br>n. 骰骨; 立方体<br>adj. 立方形的; 骰骨的 | cube→cub(词: 立方体), -oid(似…的（物）)<br>形状像立方体的物体, 即长方体或立方形物体 |


### cult

崇拜; 耕作, 培养

| 单词 | 拆解 |
| --- | --- |
| cultivate<br><br>v. 耕作; 培养 | 源自拉丁语 cultivāre（耕作、培育）, 与 Base 中的 cult 同源 |
| agriculture<br><br>n. 农业; 农艺; 农学 | **agri(田地, 土地)**, **cult(耕作, 培养)**, -ure(行为, 结果)<br>耕田种地 |
| agriculturist<br><br>n. 农学家 | agriculture→agricultur(词: 农业), -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“农学家” |
| apiculture<br><br>n. 养蜂(业) | 由拉丁语 apis“蜜蜂”与 culture“培育”构成<br>培育蜜蜂, 即养蜂业 |
| arboriculture<br><br>n. 树木栽培(学) | arbor(词: 树), i(连接字母), **cult(耕作, 培养)**, -ure(行为, 结果)<br>由“树木”与“栽培”共同限定词义, 表示“树木栽培(学)” |
| cultivator<br><br>n. 耕作者; 栽培者 | cultivate→cultiv(词: 培养, 耕作), -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“耕作者” |
| culture<br><br>n. 文化; 文明; 教养 | **cult(耕作, 培养)**, -ure(行为, 结果)<br>由培养所形成的结果 |
| floriculture<br><br>n. 养花; 花卉栽培; 花艺 | **flori(花)**, **cult(耕作, 培养)**, -ure(行为, 结果)<br>由“花”与“栽培”共同限定词义, 表示“养花, 花卉栽培, 花艺” |
| pisciculture<br><br>n. 养鱼学; 养鱼术; 鱼类养殖; 养鱼业 | **pisci(鱼)**, **cult(耕作, 培养)**, -ure(行为, 结果)<br>由“鱼”与“养殖”共同限定词义, 表示“养鱼, 鱼类养殖, 养鱼业” |
| cultivable<br><br>adj. 可耕的; 可栽培的; 可培养的; 可教化的 | cultivate→cultiv(词: 耕作), -able(可…的)<br>可以耕作或培育的 |
| cultural<br><br>adj. 文化的; 文化上的 | culture→cultur(词: 文化, 培养), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“文化的, 文化上的” |


### cumber, cumbr

妨碍

| 单词 | 拆解 |
| --- | --- |
| encumber<br><br>v. 妨害; 阻碍; 拖累 | en-(进入, 包围), **cumber(妨碍)**<br>由“进入”与“妨碍”共同限定词义, 表示“妨害, 阻碍” |
| encumbrance<br><br>n. 妨害; 阻碍; 累赘 | en-(进入, 包围), **cumbr(妨碍)**, -ance(性质, 状态)<br>由“进入”与“妨碍”共同限定词义, 表示“妨害, 阻碍” |
| cumbersome<br><br>adj. 笨重的; 麻烦的 | **cumber(妨碍)**, -some(…的)<br>围绕“妨碍”这一核心含义构成, 表示“笨重的” |


### cumul(o)

堆, 积; 积云

| 单词 | 拆解 |
| --- | --- |
| cumulate<br><br>v. 堆积; 累积<br>adj. 堆积的; 累积的 | **cumul(堆, 积)**, -ate(做, 使)<br>围绕“积”这一核心含义构成, 表示“堆积的, 累积的” |
| cumulation<br><br>n. 堆积; 累积; 蓄积 | **cumul(堆, 积)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“堆积” |
| cumulonimbus<br><br>n. 积雨云 | **cumulo(堆, 积)**, nimbus(词: 雨云)<br>由“积云”与“雨云”共同限定词义, 表示“积雨云” |
| cumulus<br><br>n. 一堆; 积云 | **cumul(积云)**, -us(名词词尾)<br>围绕“积”这一核心含义构成, 表示“一堆” |
| cumulative<br><br>adj. 累积的; 渐增的; 累加的 | **cumul(堆, 积)**, -ative(…的)<br>一层层堆积增加的, 即累积的 |


### cur

关心, 注意

| 单词 | 拆解 |
| --- | --- |
| secure<br><br>v. 固定; 获得; 保证<br>adj. 无虑的; 安心的; 安全的 | se-(离开, 分开), **cur(关心, 注意)**, e(连接字母)<br>不用挂念 |
| accuracy<br><br>n. 准确(性); 精确(性) | ac-(到, 朝, 向), **cur(关心, 注意)**, -acy(性质, 状态)<br>对细节充分留意, 从而达到准确、精确的状态 |
| cure<br><br>n. 治愈; 疗法; 药剂<br>v. 治愈; 消除; 腌制 | 经古法语借自拉丁语 cura“照料、治疗”<br>由照料病人发展为医治、治愈, 并可转化作名词 |
| curiosity<br><br>n. 好奇心 | **cur(关心, 注意)**, i(连接字母), -osity(性质, 状态)<br>围绕“关心”这一核心含义构成, 表示“好奇心” |
| manicurist<br><br>n. 指甲修剪师 | **mani(手)**, **cur(关心, 注意)**, -ist(人)<br>专门护理手和指甲的人 |
| security<br><br>n. 安全; 证券 | se-(离开, 分开), **cur(关心, 注意)**, -ity(性质, 状态)<br>无忧 |
| accurate<br><br>adj. 准确的; 正确无误的 | 构词锚点：ac 表示“到, 朝, 向”; cur 表示“关心, 挂念, 注意”; -ate 在此为形容词词尾, 不取动词义<br>对细节认真关照, 使结果精确无误, 因此表示准确的 |
| curative<br><br>adj. 治疗的; 治愈的; 有效的<br>n. 药品 | **cur(关心, 注意)**, -ative(…的)<br>围绕“关心”这一核心含义构成, 表示“治疗的, 治愈的, 有效的” |
| curious<br><br>adj. 好奇的; 好求知的 | **cur(关心, 注意)**, -ious(…的)<br>表示与“关心”有关或具有该特征, 即“好奇的, 好求知的” |
| incurable<br><br>adj. 不可医治的; 医不好的 | in-(无, 不, 非), **cur(关心, 注意)**, -able(可…的)<br>否定或缺少“关心”所指的性质, 因此表示“不可医治的, 医不好的” |
| insecure<br><br>adj. 不安全的 | in-(无, 不, 非), secure(词: 安全的)<br>否定或缺少“安全的。见下”所指的性质, 因此表示“不安全的” |


### cupr(i), cupr(o)

铜

| 单词 | 拆解 |
| --- | --- |
| cuprum<br><br>n. 铜 | **cupr(铜)**, -um(化学元素或物质)<br>词根本身即表示“铜”, 整词沿用该义 |
| cupric<br><br>adj. (含)铜的; 二价铜的 | **cupr(铜)**, -ic(…的)<br>表示与“铜”有关或具有该特征, 即“(含)铜的” |


### cyan(o)

蓝, 青; 氰

| 单词 | 拆解 |
| --- | --- |
| cyanide<br><br>n. 氰化物 | **cyan(蓝, 青)**, -ide(化合物)<br>围绕“氰”这一核心含义构成, 表示“氰化物” |
| cyanine<br><br>n. 花青 | **cyan(蓝, 青)**, -ine(…的)<br>围绕“青”这一核心含义构成, 表示“花青” |
| cyanosis<br><br>n. 发绀; 青紫 | **cyan(蓝, 青)**, -osis(状态, 过程)<br>围绕“青”这一核心含义构成, 表示“发绀, 青紫” |
| cyanotype<br><br>n. 晒蓝法; 晒蓝图 | **cyano(蓝, 青)**, **typ(印, 模型)**, e(连接字母)<br>由“蓝”与“样板、图案”共同限定词义, 表示“晒蓝法” |
| hemocyanin<br><br>n. 血蓝蛋白 | **hemo(血)**, **cyan(蓝, 青)**, -in(…素)<br>由“血”与“蓝”共同限定词义, 表示“血蓝蛋白” |


### cycl(o)

圆, 环; 轮

| 单词 | 拆解 |
| --- | --- |
| cycle<br><br>n. 自行车; 循环; 周期<br>v. 骑车 | **cycl(圆, 环)**, e(连接字母)<br>循环 |
| cyclone<br><br>n. 气旋; 龙卷风 | **cycl(圆, 环)**, -one(酮类化合物)<br>围绕“圆”这一核心含义构成, 表示“气旋” |
| cyclorama<br><br>n. 圆形画景 | **cycl(圆, 环)**, **orama(观看, 景象)**<br>由“圆”与“景”共同限定词义, 表示“圆形画景” |
| tetracycline<br><br>n. 四环素 | tetra-(四), **cycl(圆, 环)**, -ine(…的)<br>由“四”与“环”共同限定词义, 表示“四环素” |
| unicycle<br><br>n. 独轮脚踏车 | uni-(一, 单一), **cycl(圆, 环)**, e(连接字母)<br>由“一”与“轮”共同限定词义, 表示“独轮脚踏车” |
| cyclical<br><br>adj. 周期的; 循环的; 轮转的 | cycle→cycl(词: 循环), -ical(…的)<br>按周期循环发生的 |
| encyclical<br><br>adj. 普遍传递的; 广泛传阅的 | en-(进入, 包围), **cycl(圆, 环)**, -ical(…的)<br>沿完整范围循环传递、供各处阅读的, 因此表示广泛传阅的 |


### cyn(o)

犬

| 单词 | 拆解 |
| --- | --- |
| cynic<br><br>adj. 犬儒学派的<br>n. 犬儒学派的人; 玩世不恭的人; 愤世嫉俗者 | **cyn(犬)**, -ic(…的)<br>围绕“犬”这一核心含义构成, 表示“犬儒学派的人, 玩世不恭的人, 愤世嫉俗者” |
| cynicism<br><br>n. [C-] 犬儒主义; 犬儒哲学; 愤世嫉俗; 玩世不恭 | cynic(词: 犬儒学派的人), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“犬儒主义, 犬儒哲学” |
| cynical<br><br>adj. 愤世嫉俗的; 玩世不恭的; 冷嘲热讽的 | cynic(词: 愤世嫉俗者), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“愤世嫉俗的” |


### cyst(i), cyst(o)

囊, 膀胱

| 单词 | 拆解 |
| --- | --- |
| cyst<br><br>n. 囊肿; 膀胱; 胞囊 | **cyst(i), cyst(o)(囊, 膀胱)**<br>体内充满液体或半流质物质的囊状病变结构 |
| cystic<br><br>adj. 囊性的; 胆囊的; 膀胱的 | **cyst(i), cyst(o)(囊, 膀胱)**, -ic(…的)<br>具有囊肿结构或与胆囊、膀胱相关的 |


### cyt(o)

细胞

| 单词 | 拆解 |
| --- | --- |
| cytochemistry<br><br>n. 细胞化学 | **cyto(细胞)**, chemistry(词: 化学)<br>由“细胞”与“化学”共同限定词义, 表示“细胞化学” |
| cytochrome<br><br>n. 细胞色素 | **cyto(细胞)**, **chrom(颜色, 色素)**, e(连接字母)<br>由“细胞”与“色素”共同限定词义, 表示“细胞色素” |
| cytogenetics<br><br>n. [复] 细胞遗传学 | 由 cyto“细胞”与 genetics“遗传学”构成<br>研究染色体和细胞遗传的学科 |
| cytology<br><br>n. 细胞学 | **cyto(细胞)**, -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“细胞学” |
| cytoplasm<br><br>n. 细胞质 | **cyto(细胞)**, **plasm(原生质, 原浆)**<br>由“细胞”与“原生质”共同限定词义, 表示“细胞质” |
| monocyte<br><br>n. 单核细胞; 单核白血球 | mono-(单一, 独), **cyt(细胞)**, e(连接字母)<br>由“单一”与“细胞”共同限定词义, 表示“单核细胞, 单核白血球” |
| oocyte<br><br>n. 卵母细胞 | **oo(卵)**, **cyt(o)(细胞)**, e(连接字母)<br>雌性卵巢内未成熟或成熟的原始生殖细胞, 即卵母细胞 |
| phagocytosis<br><br>n. 吞噬(细胞)作用; 噬菌作用 | **phag(吃, 食)**, o(连接元音), **cyt(细胞)**, -osis(状态, 过程)<br>由“吃”与“细胞”共同限定词义, 表示“吞噬(细胞)作用, 噬菌作用” |
