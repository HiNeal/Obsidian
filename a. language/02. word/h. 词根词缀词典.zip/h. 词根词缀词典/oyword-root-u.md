## oyword-root-u


### ultim, ult

最后

| 单词 | 拆解 |
| --- | --- |
| penultimate<br><br>adj. 倒数第二的 | 构词锚点：pen 表示“几乎”; ultim 表示“最后”; -ate 在此为名词或形容词词尾, 不取动词义<br>几乎是最后一个 |
| ultimatum<br><br>n. 最后通牒 | 源自拉丁语 ultimatum“最后之物”, 来自 ultimus“最后的”<br>不接受便采取行动的最后条件 |
| ulterior<br><br>adj. 将来的; 较远的 | 源自拉丁语 ulterior“更远的、较后的”<br>表示未公开的进一步意图 |
| ultimate<br><br>adj. 最后的; 最终的; 极限的 | 构词锚点：ultim 表示“最后”; -ate 在此为形容词词尾, 不取动词义<br>围绕“最后”这一核心含义构成, 表示“最后的, 最末的, 最终的” |
| ultimo<br><br>adj. 上月的 | 源自拉丁语 ultimo mense（上个月）, 旧式商务用语中表示“上月的” |


### umbr

阴影

| 单词 | 拆解 |
| --- | --- |
| penumbra<br><br>n. 半影; (日; 月食的) 半影 | pen-(几乎), **umbr(阴影)**, a(连接字母)<br>由“几乎”与“阴影”共同限定词义, 表示“半影” |
| umbra<br><br>n. 暗影 | **umbr(阴影)**, a(连接字母)<br>围绕“阴影”这一核心含义构成, 表示“暗影” |
| umbrage<br><br>n. 树荫; 阴影; 不快; 生气 | 源自拉丁语 umbra“阴影”形成的古法语 ombrage<br>由被阴影笼罩引申为不快、受冒犯 |
| umbrella<br><br>n. 雨伞; 伞 | **umbr(阴影)**, -ella(小)<br>原指带来一小片阴影的遮蔽物, 后来指雨伞 |


### und

波浪

| 单词 | 拆解 |
| --- | --- |
| abound<br><br>v. 大量存在; 有许多 | 源自拉丁语 abundare（溢出、充满）, 本义像水漫出边界, 引申为大量存在 |
| inundate<br><br>v. 泛滥; 淹没 | in-(向内, 进入), **und(波浪)**, -ate(做, 使)<br>使波浪涌入并覆盖某地, 即淹没 |
| inundation<br><br>n. 泛滥; 洪水 | 源自拉丁语 inundatio, 由 in“进入、覆盖”与 unda“波浪”构成<br>洪水覆盖; 引申为大量涌入 |
| redundant<br><br>adj. 多余的; 累赘的; 冗余的; 被解雇裁减的 | 源自拉丁语 redundare（溢出）, 由多余地溢出发展为冗余的 |


### un(i)

单一

| 单词 | 拆解 |
| --- | --- |
| reunite<br><br>v. 再联合; 重聚 | 由 re“再次”与 unite“联合”构成<br>再次团聚或统一 |
| disunion<br><br>n. 不统一; 不联合; 不团结; 分裂 | 由 dis“分开”与 union“联合”构成<br>联合关系的破裂 |
| reunification<br><br>n. 重新统一; 再统一 | 由 re“再次”与 unification“统一”构成<br>重新统一 |
| triune<br><br>n. 三个一组<br>adj. 三位一体的 | tri-(三, 三次), un-(无, 不, 非), e(连接字母)<br>三合一 |
| unanimity<br><br>n. 全体一致; 一致同意 | un-(一, 单一), **anim(生命; 心意; 精神; 气息)**, -ity(性质, 状态)<br>众人如同具有同一个心意的状态, 即全体一致 |
| unicorn<br><br>n. 独角兽 | uni-(一, 单一), **corn(角)**<br>由“一”与“角”共同限定词义, 表示“独角兽” |
| unifier<br><br>n. 使成一体者; 统一者 | unify→unifi(词: 统一), -er(人)<br>由“统一”派生为当前词义 |
| uniform<br><br>n. 制服<br>adj. 统一的; 一致的 | uni-(一, 单一), **form(形状, 形式)**<br>具有统一形式的; 名词指制服 |
| unionism<br><br>n. 联合主义; 工联主义 | union(词: 联合), -ism(主义)<br>表示与“联合”有关的性质或状态, 即“联合主义” |
| unilateral<br><br>adj. 单边的; 单方面的; 片面的 | uni-(一, 单一), **later(边)**, -al(…的)<br>由“单一”与“边”共同限定词义, 表示“单边的, 单方面的, 片面的” |
| unique<br><br>adj. 惟一的; 独一无二的 | 经法语 unique 进入英语, 源自拉丁语 unicus（唯一的） |
| united<br><br>adj. 统一的; 联合的 | unite→unit(词: 联合), -ed(…的)<br>由“联合”派生为当前词义 |


### up

上, 向上

| 单词 | 拆解 |
| --- | --- |
| uphold<br><br>v. 支持; 维护; 维持(判决); 支撑 | **up(上, 向上)**, hold(词: 支持)<br>由“上”与“持”共同限定词义, 表示“支持” |
| uproot<br><br>v. 连根拔; 根除; 灭绝; 赶走; 迁离 | **up(上, 向上)**, root(词: 根)<br>向上+根, 即"连根拔起" |
| upbeat<br><br>n. 上升; 兴旺 | up(词: 向上), beat(词: 节拍)<br>原指小节前的弱拍, 引申为乐观上扬 |
| updraft<br><br>adj. 向上通风的 | **up(上, 向上)**, **draft(拉)**<br>由“向上”与“拉”共同限定词义, 表示“向上排风, 向上通风” |
| upgrade<br><br>v. 升级; 提高档次<br>n. 升级; 提升<br>adv. 往上坡 | up(词: 向上), grade(词: 等级)<br>把等级向上提高, 即升级 |
| upland<br><br>n. 山地; 高地; 高原<br>adj. 高地的; 山地的 | up(词: 高处), land(词: 土地)<br>高处的土地 |
| uplift<br><br>n. 抬起; 道德的向上; 精神的高涨<br>v. 提高; 抬起; 上升 | **up(上, 向上)**, lift(词: 提高)<br>由“上”与“举”共同限定词义, 表示“高举, 提高, 上升, 升起” |
| upside<br><br>n. 上面; 上部; 有利方面; 乐观面 | up(词: 上方), side(词: 一面)<br>位于上方的一面; 引申为有利面 |
| upsurge<br><br>n. 增长; 高潮<br>v. 高涨; 涌起 | up(词: 向上), surge(词: 涌动)<br>突然向上增长或高涨 |
| upturn<br><br>n. 情况好转; 向上趋势<br>v. 向上; 转朝上; 翻转 | **up(上, 向上)**, turn(词: 翻转)<br>由“向上”与“转”共同限定词义, 表示“(使)向上, (使)朝上, 翻转” |
| upper<br><br>adj. 上(面)的; 上首的; (河的)上流的; (议会)上院的; 地表层的 | **up(上, 向上)**, p(连接字母), -er(更…)<br>位置更靠上的 |
| upstanding<br><br>adj. 直立的; 竖立的; 体态优美的; 诚实的; 正直的 | **up(上, 向上)**, **stand(站立)**, -ing(…的)<br>向上直立的, 引申为正直可靠的 |


### ur(o)

尿

| 单词 | 拆解 |
| --- | --- |
| urinate<br><br>v. 排尿; 撒尿; 小便 | urine→urin(词: 尿), -ate(做, 使)<br>排出尿液, 即排尿 |
| albuminuria<br><br>n. 蛋白尿 | albumin(词: 白蛋白), **ur(尿)**, -ia(性质, 状态)<br>由“白蛋白”与“尿”共同限定词义, 表示“蛋白尿” |
| diuresis<br><br>n. 利尿; 多尿 | 源自希腊语 dia“通过” + ourein“排尿”<br>使尿液排出增多的过程, 即利尿、多尿 |
| diuretic<br><br>adj. 利尿的<br>n. 利尿剂 | 源自希腊语 diouretikos“促进排尿的”<br>促进尿液排出的药物 |
| polyuria<br><br>n. 多尿 (症) | poly-(多, 复), **ur(尿)**, -ia(性质, 状态)<br>由“多”与“尿”共同限定词义, 表示“多尿 (症)” |
| uraemia<br><br>n. 尿毒症 | **ur(尿)**, **aem(血)**, -ia(性质, 状态)<br>尿素等废物进入血液的病症, 即尿毒症 |
| urine<br><br>n. 尿 | **ur(尿)**, -ine(…的)<br>围绕“尿”这一核心含义构成, 表示“尿” |
| urologist<br><br>n. 泌尿学家 | uro-(词: 尿抑胃素), -logist(…学家)<br>由“尿抑胃素”派生为当前词义 |
| urology<br><br>n. 泌尿学 | **uro(尿)**, -logy(…学, …研究)<br>以“尿”为研究对象的学科, 即“泌尿学” |
| uric<br><br>adj. 尿的; 在尿中发现的 | **ur(尿)**, -ic(…的)<br>表示与“尿”有关或具有该特征, 即“尿的” |


### uran(i), uran(o)

天, 天空; 上颚; 铀

| 单词 | 拆解 |
| --- | --- |
| uranium<br><br>n. 铀 | **urani(铀)**, -um(化学元素或物质)<br>元素铀 |
| Uranus<br><br>n. 天王; 天王星; [希神] 伏拉纳斯神 | **uran(天, 天空)**, -us(名词词尾)<br>围绕“天”这一核心含义构成, 表示“伏拉纳斯神, 天王” |


### urb(i)

城市

| 单词 | 拆解 |
| --- | --- |
| conurbation<br><br>n. 集合城市(拥有卫星城市的大都市; 如伦敦等) | con-(与, 共同), **urb(城市)**, -ation(行为, 结果)<br>几个城市共同组成的大城市 |
| suburb<br><br>n. 郊区, 郊外, 近郊 | sub-(在下, 向下), **urb(城市)**<br>位于主要城市近旁的区域, 即郊区、近郊 |
| suburban<br><br>n. 郊区居民<br>adj. 郊区的 | suburb(词: 郊区), -an(…的)<br>与城市外围郊区有关的 |
| urbanism<br><br>n. 城市居民的生活方式 | 由 urban“城市的”形成 urbanism<br>城市居民的生活方式及城市化特征 |
| urbanite<br><br>n. 城市居民 | urban(词: 城市的), -ite(人)<br>在前词基础上加“-ite”构成名词, 表示“城市居民” |
| urbanity<br><br>n. 文雅; 温文尔雅 | urbane→urban(词: 彬彬有礼的), -ity(性质, 状态)<br>由“彬彬有礼的”派生为当前词义 |
| urbanization<br><br>n. 都市化 | urban(词: 习惯于都市的), -ization(行为, …化)<br>在前词基础上加“-ization”构成名词, 表示“都市化” |
| exurban<br><br>adj. 城市远郊的 | exurb(词: 远郊地区), -an(…的)<br>在前词基础上加“-an”构成形容词, 表示“城市远郊的” |
| interurban<br><br>adj. 城市与城市之间的 | inter-(在...之间), **urb(城市)**, -an(…的)<br>由“在…之间”与“城市”共同限定词义, 表示“城市与城市之间的” |


### urg

驱动

| 单词 | 拆解 |
| --- | --- |
| urge<br><br>n. 强烈欲望; 冲动<br>v. 催促; 极力主张 | 源自拉丁语 urgere“推动、压迫”<br>表示强烈推动某人行动或强烈欲望 |
| urgency<br><br>n. 紧急; 迫切; 强求; 催促; 紧急的事 | **urg(驱动)**, -ency(性质, 状态)<br>在前词基础上加“-ency”构成名词, 表示“紧急” |
| urgent<br><br>adj. 紧急的; 急迫的; 强求的; 催促的 | **urg(驱动)**, -ent(…的)<br>在前词基础上加“-ent”构成形容词, 表示“紧急的” |


### urgy

工作, 工艺

| 单词 | 拆解 |
| --- | --- |
| metallurgist<br><br>n. 冶金学家 | metallurgy→metallurg(词: 冶金学), -ist(人)<br>从事冶金研究或生产的人 |
| metallurgy<br><br>n. 冶金学; 冶金术 | 由希腊语 metallon“金属、矿”与 ergon“工作”构成<br>提取和加工金属的技术 |
| metallurgical<br><br>adj. 冶金 (学) 的 | 由 metallurgy“冶金学”派生<br>与金属提取、加工有关的 |


### us,ut, util

用

| 单词 | 拆解 |
| --- | --- |
| peruse<br><br>v. 精读; 细读 | 晚期中古英语中本义为“彻底使用、仔细检查”, 由 per“彻底”与 use 结合<br>仔细阅读或审查 |
| usurp<br><br>v. 篡夺; 夺取; 侵占 | 经古法语借自拉丁语 usurpare“取得使用、篡取”<br>未经权利而夺取职位或权力 |
| utilize<br><br>v. 利用; 使用 | **util(用)**, -ize(…化, 使成)<br>围绕“用”这一核心含义构成, 表示“利用” |
| usage<br><br>n. 使用; 用法; 惯例; 习惯用法 | use→us(词: 使用), -age(行为, 结果)<br>使用方式或惯例 |
| user<br><br>n. 使用者; 用户; 使用物; [律] 权利的实际享有(或行使) | use→us(词: 使用), -er(人)<br>由“使用”派生为当前词义 |
| usurpation<br><br>n. 篡夺; 夺取; 侵占 | usurp(词: 篡夺), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“篡夺” |
| utensil<br><br>n. 器皿; 用具 | 源自拉丁语 utensilis（可供使用的）, 后来指用具 |
| utilitarian<br><br>n. 功利主义者<br>adj. 实用的; 功利主义的 | utility→utilit(词: 功用), -arian(人)<br>以实际功用为判断标准的人; 也可转化为形容词 |
| utilitarianism<br><br>n. 功利主义 | utilitarian(词: 功利主义的), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“功利主义” |
| utility<br><br>n. 效用; 有用; 实用; 功利 | **util(用)**, -ity(性质, 状态)<br>表示与“用”有关的性质或状态, 即“效用, 有用, 实用, 功利” |
| utilization<br><br>n. 利用 | utilize→utiliz(词: 利用), -ation(行为, 结果)<br>由“利用”派生为当前词义 |
| usable<br><br>adj. 可用的; 能用的; 合用的; 便于使用的 | use→us(词: 使用), -able(可…的)<br>可以使用的 |
| used<br><br>adj. 旧的; 用旧了的; 习惯于…的 | use→us(词: 使用), -ed(…的)<br>由“使用”派生为当前词义 |
| useful<br><br>adj. 有用的; 有益的; 实用的; 有帮助的 | use(词: 使用), -ful(充满…的)<br>由“使用”派生为当前词义 |
| usual<br><br>adj. 通常的; 平常的; 惯常的; 惯例的 | 源自拉丁语 usualis（惯常使用的）, 表示通常的 |
| inutile<br><br>adj. 无用的; 无益的 | in-(无, 不, 非), **ut(用)**, -ile(…的)<br>否定或缺少“用”所指的性质, 因此表示“无用的” |
