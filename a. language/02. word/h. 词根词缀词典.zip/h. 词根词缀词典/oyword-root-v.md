## oyword-root-v


### vac(u)

空

| 单词 | 拆解 |
| --- | --- |
| evacuate<br><br>v. 撤离; (从危险的地方)撤出; 排空(胃肠); 排泄(粪便) | e-(出, 向外), **vacu(空)**, -ate(做, 使)<br>使事物呈现“出”与“空”与“做”所表达的状态, 即“疏散(居民)” |
| vacate<br><br>v. 使腾空; 腾出; 搬出 | **vac(空)**, -ate(做, 使)<br>围绕“空”这一核心含义构成, 表示“使腾空” |
| evacuation<br><br>n. 疏散; 撤空; 搬空 | evacuate→evacu(词: 疏散), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“疏散” |
| evacuee<br><br>n. 被疏散的人员 | evacuate→evacu(词: 疏散), -ee(接受动作的人)<br>在前词基础上加“-ee”构成名词, 表示“被疏散的人员” |
| vacancy<br><br>n. 空; 空白; 空处; 空虚 | **vac(空)**, -ancy(性质, 状态)<br>围绕“空”这一核心含义构成, 表示“空” |
| vacation<br><br>n. 假期; 休假<br>v. 休假 | **vac(空)**, -ation(行为, 结果)<br>空闲的状态 |
| vacuity<br><br>n. 空; 空白; 空虚 | **vacu(空)**, -ity(性质, 状态)<br>表示与“空”有关的性质或状态, 即“空, 空白, 空虚” |
| vacuum<br><br>n. 真空; 真空状态; 真空度<br>v. 用真空吸尘器清扫<br>adj. 真空的 | **vacu(空)**, -um(名词词尾)<br>物质被移除后形成的空无空间, 即真空 |
| vacant<br><br>adj. 空缺; 茫然; 空的; 闲置的 | **vac(空)**, -ant(…的)<br>围绕“空”这一核心含义构成, 表示“空缺, 茫然, 空的, 闲置的” |
| vacuous<br><br>adj. 空的; 空洞的; 空虚的 | **vacu(空)**, -ous(…的)<br>表示与“空”有关或具有该特征, 即“空的” |


### vaccin

牛痘

| 单词 | 拆解 |
| --- | --- |
| vaccinate<br><br>v. 给……接种疫苗 | **vaccin(牛痘)**, -ate(做, 使)<br>围绕“牛痘”这一核心含义构成, 表示“给…种牛痘, 给…接种疫苗, 施种牛痘, 进行预防接种” |
| vaccine<br><br>n. 牛痘苗; 疫苗<br>adj. 疫苗的; 牛痘的 | **vaccin(牛痘)**, e(连接字母)<br>最早利用牛痘材料预防天花, 后来泛指疫苗 |
| vaccinia<br><br>n. 牛痘 | **vaccin(牛痘)**, -ia(性质, 状态)<br>围绕“牛痘”这一核心含义构成, 表示“牛痘” |


### vad, vas

行, 走

| 单词 | 拆解 |
| --- | --- |
| evade<br><br>v. 逃避; 规避; 躲避; 逃脱; 难倒 | e-(出, 向外), **vad(行, 走)**, e(连接字母)<br>从原来的路径向外走开, 因此表示逃避、躲开 |
| invade<br><br>v. 侵入; 侵略; 侵犯; 入侵; 侵扰 | in-(向内, 进入), **vad(行, 走)**, e(连接字母)<br>由“进入”与“走”共同限定词义, 表示“侵入, 侵略” |
| pervade<br><br>v. 弥漫; 渗透; 遍及; 充满 | per-(通过, 贯穿), **vad(行, 走)**, e(连接字母)<br>从头到尾走遍并充满各处, 因此表示弥漫、遍及 |
| evasion<br><br>n. 逃避; 躲避; 回避 | e-(出, 向外), **vas(行, 走)**, -ion(行为, 结果)<br>向外走开以躲避追查或责任, 因此表示逃避、回避 |
| invader<br><br>n. 入侵者; 侵略者; 侵犯者 | in-(向内, 进入), **vad(行, 走)**, -er(人)<br>走入他人领地实施侵犯的人 |
| invasion<br><br>n. 入侵; 侵略 | in-(向内, 进入), **vas(行, 走)**, -ion(行为, 结果)<br>强行走入他方境内的行为, 即"入侵" |
| invasiveness<br><br>n. 侵略性; 侵袭性 | invasive(词: 侵略性的), -ness(性质, 状态)<br>在前词基础上加“-ness”构成名词, 表示“侵略性” |
| invasive<br><br>adj. 入侵的; 侵略的; 侵袭的 | 与 invade“进入、侵入”同源<br>侵入性的; 医学上需进入身体的 |
| pervasive<br><br>adj. 弥漫的; 渗透的; 遍布的; 充满的 | 与 pervade“遍及”同源, 源自拉丁语 pervadere“走遍”<br>遍布各处的 |


### vag

走, 漫游

| 单词 | 拆解 |
| --- | --- |
| extravagance<br><br>n. 过分; 过度; 浪费; 奢侈 | extra-(超过, 额外), **vag(走, 漫游)**, -ance(性质, 状态)<br>走出范围之外的 |
| vagabond<br><br>n. 流浪者; 浪子; 流氓<br>v. 到处流浪<br>adj. 流浪的; 漂泊的; 浪荡的 | 经古法语借自晚期拉丁语 vagabundus“漫游的”, 与 vagari“游荡”同源<br>四处流浪的人 |
| vagrant<br><br>adj. 漂泊的; 流浪的; 游荡的<br>n. 流浪汉; 漂泊者; 无赖 | **vag(走, 漫游)**, r(连接字母), -ant(…的)<br>围绕“漫游”这一核心含义构成, 表示“流浪的” |
| extravagant<br><br>adj. 过分的; 过度的; 浪费的; 奢侈的 | extra-(超过, 额外), **vag(走, 漫游)**, -ant(…的)<br>漫游到正常界限之外, 因此表示过度的、奢侈的 |
| vague<br><br>adj. 含糊的; 模糊的 | 源自拉丁语 vagus“游荡、不确定的”, 经法语进入英语<br>表示边界或意义不明确的 |


### val,vail

强

| 单词 | 拆解 |
| --- | --- |
| avail<br><br>n. 益处; 效用; 效果<br>v. 有帮助; 有益; 有用 | 源自古法语 valoir“有价值、有效力”, 与拉丁语 valere“强健、有价值”相关<br>具有实际效力并能派上用场, 即有助于 |
| prevail<br><br>v. 流行; 盛行; 获胜; 占优势 | pre-(先于, 预先), **vail(强)**<br>力量占据上风, 因此表示获胜; 由此也可表示盛行 |
| evaluate<br><br>v. 评价; 评估 | e-(出, 向外), **val(值, 价值)**, u(连接字母), -ate(做, 使)<br>把事物的价值衡量出来, 因此表示估价、评价 |
| convalescence<br><br>n. 逐渐恢复健康 | con-(彻底, 完全, 加强), **val(强)**, -escence(开始或正在形成某种状态)<br>在前词基础上加“-escence”构成名词, 表示“逐渐恢复健康” |
| invalid<br><br>n. 病人; 残废者<br>adj. 有病的; 无效的 | in-(无, 不, 非), valid(词: 有法律效力的)<br>没有效力或不成立的; 另有重音不同的名词义 |
| invalidity<br><br>n. (因病残)丧失工作能力 | invalid(词: 病人), -ity(性质, 状态)<br>由“病人”派生为当前词义 |
| valour<br><br>n. 勇猛; 英勇 | **val(强)**, -our(性质, 状态)<br>内在强健勇敢的品质, 即英勇 |
| equivalent<br><br>adj. 等同的; 等价的<br>n. 对等物; 等价物 | **equi(相等)**, **val(值, 价值)**, -ent(…的)<br>由“相等”与“值”共同限定词义, 表示“相等的, 相当的, 等量的, 等(值)的” |
| evaluation<br><br>n. 评价; 估值 | 与 evaluate“评估价值”同源, 核心 value 表示价值<br>判断价值、质量或程度的过程 |
| valuable<br><br>adj. 有价值的; 贵重的; 宝贵的 | **valu(值, 价值)**, -able(可…的)<br>能够体现较高价值的 |
| value<br><br>n. 价值; 价格; 购买力<br>v. 评价; 估价; 重视 | **value(值, 价值)**<br>围绕“值”这一核心含义构成, 表示“价值, 价格, 有用性, 重要性, 价值观, 社会准则” |
| available<br><br>adj. 可获得的; 可利用的<br>n. adj可获得的 | 源自 avail“有价值、有效力”加 -able 形成<br>原指有效可用, 后来表示可以获得或使用 |
| prevailing<br><br>adj. 占优势的; 主要的; 流行的; 盛行的; 通行的 | 词形来源：prevail + ing-form |
| convalescent<br><br>adj. 恢复健康的; 渐愈的 | con-(彻底, 完全, 加强), **val(强)**, -escent(开始或正在形成…的)<br>在前词基础上加“-escent”构成形容词, 表示“恢复健康的” |
| valiant<br><br>adj. 勇猛的 | **val(值, 价值)**, i(连接字母), -ant(…的)<br>围绕“值”这一核心含义构成, 表示“勇猛的” |
| valorous<br><br>adj. 勇猛的; 英勇的 | valor(词: 英勇), -ous(…的)<br>具有英勇品质的 |
| invaluable<br><br>adj. 极其宝贵的; 无价的 | in-(无, 不, 非), value→valu(词: 价值), -able(可…的)<br>具有…性质的 |


### val, value

值, 价值

| 单词 | 拆解 |
| --- | --- |
| equivalent<br><br>adj. 等同的; 等价的<br>n. 对等物; 等价物 | **equi(相等)**, **val(值, 价值)**, -ent(…的)<br>由“相等”与“值”共同限定词义, 表示“相等的, 相当的, 等量的, 等(值)的” |
| evaluate<br><br>v. 评价; 评估 | e-(出, 向外), **val(值, 价值)**, u(连接字母), -ate(做, 使)<br>把事物的价值衡量出来, 因此表示估价、评价 |
| evaluation<br><br>n. 评价, 估价 | 与 evaluate“评估价值”同源, 核心 value 表示价值<br>判断价值、质量或程度的过程 |
| invaluable<br><br>adj. 无价的, 非常贵重的 | in-(无, 不, 非), value→valu(词: 价值), -able(可…的)<br>具有…性质的 |
| valuable<br><br>adj. 有价值的; 贵重的; 宝贵的 | **valu(值, 价值)**, -able(可…的)<br>能够体现较高价值的 |
| value<br><br>n. 价值; 价格; 购买力<br>v. 评价; 估价; 重视 | **value(值, 价值)**<br>围绕“值”这一核心含义构成, 表示“价值, 价格, 有用性, 重要性, 价值观, 社会准则” |


### van, void

空, 无

| 单词 | 拆解 |
| --- | --- |
| avoid<br><br>v. 避免; 避开 | 源自古法语 esvuidier“使空出”, 核心与 void“空”相关<br>由把空间清空发展为避开、避免 |
| evanesce<br><br>v. 逐渐消失; 消散 | e-(出, 向外), **van(空, 无)**, -esce(开始…, 正在…)<br>开始向外消散并归于空无, 即逐渐消失 |
| evanescence<br><br>n. 消失; 消散 | 源自拉丁语 evanescere“消散”, 与 vanish 同源<br>逐渐消失、短暂易逝的性质 |
| vanish<br><br>n. 消失; 绝迹<br>v. 突然消失; 绝迹 | **van(空, 无)**, -ish(做, 使)<br>变为空无, 即消失 |
| vanity<br><br>n. 空虚; 浮夸; 虚荣心; 自负; 自大 | **van(空, 无)**, -ity(性质, 状态)<br>内在空虚却重视外表的状态, 引申为虚荣 |
| evanescent<br><br>adj. 很快消失的 | 与 evanesce“逐渐消失”同源<br>很快消逝的 |
| vain<br><br>adj. 徒劳的; 无益的; 不成功的; 自负的; 爱虚荣的 | 经法语 vain 进入英语, 源自拉丁语 vanus（空的、无结果的） |
| void<br><br>n. 空虚; 空间; 空白<br>adj. 无效的; 空的 | **void(空, 无)**<br>围绕“空”这一核心含义构成, 表示“空的, 缺的” |
| voidable<br><br>adj. 可使无效的; 可以取消的 | **void(空, 无)**, -able(可…的)<br>在前词基础上加“-able”构成形容词, 表示“可使无效的” |


### van

先, 前

| 单词 | 拆解 |
| --- | --- |
| advance<br><br>n. 前进; 进展; 预付款<br>v. 前进; 推进; 预付 | ad-(到, 朝, 向), **van(先, 前)**, -ce(构成抽象名词)<br>推向更靠前的位置, 即"前进"; 引申指提前支付的款项, "预付款" |
| advantage<br><br>n. 优点; 优势; 好处 | 经古法语 avantage 进入英语, 核心来自 avant“在前”<br>处在前面或更有利的位置, 即优势 |
| disadvantage<br><br>n. 不利地位; 不利条件; 坏处 | dis-(否定, 相反), advantage(词: 优势)<br>缺少或失去有利条件, 因此表示不利、坏处 |
| vanguard<br><br>n. 前卫; 先头部队; 尖兵; (社会政治运动的)先锋(队); 领导者 | **van(先, 前)**, guard(词: 护卫队)<br>由“先”与“护卫队”共同限定词义, 表示“前卫, 先头部队, 尖兵” |
| advanced<br><br>adj. 先进的; 高级的 | advance→advanc(词: 前进), -ed(…的)<br>由“前进”派生为当前词义 |
| advantageous<br><br>adj. 有利的 | advantage(词: 优势), -ous(…的)<br>在前词基础上加“-ous”构成形容词, 表示“有利的” |


### vari(o)

变化

| 单词 | 拆解 |
| --- | --- |
| vary<br><br>adj. 各种各样的 variety<br>n. 变 化 variable<br>v. 改变; 变更; 变化 | 源自拉丁语 variare（使多样、改变）, 表示变化 |
| invariance<br><br>n. 不变性 | 由 invariant“不变的”派生<br>在变换中保持不变的性质 |
| variability<br><br>n. 变化性; 易变; 变异性 | **vari(变化)**, -ability(可…性)<br>围绕“变化”这一核心含义构成, 表示“变化性” |
| variance<br><br>n. 变化; 分歧; 不一致; (统计学)方差 | **vari(变化)**, -ance(性质, 状态)<br>表示与“变化”有关的性质或状态, 即“变化, 变动, 变异” |
| variate<br><br>n. 变量 | 构词锚点：vari 表示“变化”; -ate 在此为名词或形容词词尾, 不取动词义<br>围绕“变化”这一核心含义构成, 表示“变量” |
| variation<br><br>n. 变化; 变动; 变体; 变异; 变奏 | **vari(变化)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“变化” |
| variety<br><br>n. 品种; 变化; 多样化 | **vari(变化)**, -ety(性质, 状态)<br>围绕“变化”这一核心含义构成, 表示“多样化” |
| invariable<br><br>adj. 不变的; 恒定的 | in-(无, 不, 非), **vari(变化)**, -able(可…的)<br>否定或缺少“变化”所指的性质, 因此表示“不变的” |
| invariant<br><br>adj. 不变的; 恒定的 | 由 in“不”与 variant“变化的”构成<br>不随条件变化的 |
| varied<br><br>adj. 多变化的; 各种各样的; 改变了的 | **vari(变化)**, -ed(…的)<br>围绕“变化”这一核心含义构成, 表示“多变化的” |
| various<br><br>adj. 各种各样的; 不同的; 种种的 | **vari(变化)**, -ous(…的)<br>表示与“变化”有关或具有该特征, 即“各种各样的, 不同的” |


### varic(o)

静脉曲张

| 单词 | 拆解 |
| --- | --- |
| varicocele<br><br>n. 精索静脉曲张 | 由 varico“静脉曲张”与 cele“膨出、疝”构成<br>精索静脉曲张 |
| varicose<br><br>adj. 静脉曲张的; 治疗静脉曲张用的 | **varic(o)(静脉曲张)**, -ose(…的)<br>静脉管壁薄弱导致血液淤滞、静脉异常扩张膨出扭曲的病理状态 |


### vas(i), vas(o), vascul(o)

管, 血管

| 单词 | 拆解 |
| --- | --- |
| vasectomy<br><br>n. 输精管切除术 | 由 vas“输精管”与 ectomy“切除术”构成<br>输精管切除术 |
| vasoconstriction<br><br>n. 血管缩小 | 由 vaso“血管”与 constriction“收缩”构成<br>血管收缩 |
| vasoconstrictor<br><br>n. 血管收缩神经<br>adj. 血管收缩的 | 由 vaso“血管”与 constrictor“收缩物”构成<br>使血管收缩的神经或药物 |
| vasopressin<br><br>n. 后叶加(血)压素; 加压素 | **vaso(管, 血管)**, **press(压, 逼迫)**, -in(…素)<br>由“血管”与“压”共同限定词义, 表示“后叶加(血)压素, 加压素” |
| vasospasm<br><br>n. 血管痉挛 | **vaso(管, 血管)**, spasm(词: 痉挛)<br>由“血管”与“痉挛”共同限定词义, 表示“血管痉挛” |
| vasomotor<br><br>adj. 血管舒缩的 | **vaso(管, 血管)**, motor(词: 运动的)<br>与血管收缩舒张运动有关的 |


### veget

生长, 有活力; 植物, 蔬菜

| 单词 | 拆解 |
| --- | --- |
| vegetable<br><br>n. 蔬菜; 植物人<br>adj. 植物的; 蔬菜的 | **veget(生长, 有活力; 植物, 蔬菜)**, -able(可…的)<br>源于具有旺盛生命力生长的植物, 现指供食用的蔬菜 |
| vegetation<br><br>n. 植被; 植物; 草木 | **veget(生长, 有活力; 植物, 蔬菜)**, -ation(行为, 结果)<br>覆盖于特定地表区域所有植物群落的总称 |


### velop

包, 裹

| 单词 | 拆解 |
| --- | --- |
| develop<br><br>v. 发展; 形成; 开发; 显影; 成长 | 源自法语 développer“展开、揭开包裹”<br>由逐步展开引申为发展、开发, 不把 de- 误解为下降 |
| envelop<br><br>v. 包住; 裹住; 遮盖 | en-(进入, 包围), **velop(包, 裹)**<br>由“包围”与“裹住”共同限定词义, 表示“包住, 裹住” |
| development<br><br>n. 发展; 开发; 生长; 研制; 新情况 | develop(词: 发展), -ment(行为, 过程)<br>在前词基础上加“-ment”构成名词, 表示“发展” |
| envelope<br><br>n. 信封; 外裹物; 外层 | en-(进入, 包围), **velop(包, 裹)**, e(连接字母)<br>包裹在物体外面的封套, 即信封 |


### ven(t)

来

| 单词 | 拆解 |
| --- | --- |
| circumvent<br><br>v. 包围; 围绕 | circum-(四周, 周围), **vent(来)**<br>从四周来 |
| contravene<br><br>v. 违反; 触犯; 抵触; 与⋯相冲突; 反驳 | contra-(反对, 相反), **ven(来)**, e(连接字母)<br>来作对 |
| intervene<br><br>v. 干涉; 干预; 调停; 介入; 发生于其间 | inter-(在...之间), **ven(来)**, e(连接字母)<br>来到两方之间介入事情, 因此表示干预、调停 |
| avenue<br><br>n. 途径; (城镇的)大街; 选择; 林荫道(尤指通往大住宅者) | 经法语 avenue 进入英语, 原指到达某处的通道<br>后来指林荫道, 并引申为实现目标的途径 |
| contravention<br><br>n. 违反; 触犯; 抵触; 反驳 | contra-(反对, 相反), **vent(来)**, -ion(行为, 结果)<br>由“反对”与“来”共同限定词义, 表示“违反, 触犯” |
| convention<br><br>n. 惯例; 传统手法; 习俗; 大型会议 | con-(与, 共同), **vent(来)**, -ion(行为, 结果)<br>惯例 |
| event<br><br>n. 事件; 大事; 事变; 偶然事件 | e-(出, 向外), **vent(来)**<br>发生出来之事 |
| eventuality<br><br>n. 可能发生的事; 不测事件 | eventual(词: 最后的), -ity(性质, 状态)<br>由“最后的”派生为当前词义 |
| intervenor<br><br>n. 干涉者; 介入者 | intervene→interven(词: 插入), -or(人)<br>由“插入”派生为当前词义 |
| invention<br><br>n. 发明; 创造; 发明物 | in-(向内, 进入), **vent(来)**, -ion(行为, 结果)<br>使原本不存在的事物来到现实中, 因此表示发明、创造 |
| preventer<br><br>n. 预防者; 防止者; 阻止者; 预防药 | pre-(先于, 预先), **vent(来)**, -er(人)<br>先来者 |
| revenue<br><br>n. (公司; 组织的)收入; (政府的)税收; 财政收入; （公司、组织的）收入; （政府的）税收 | 经法语 revenu（返回的收入）进入英语, 指周期性返回的财政收入 |
| eventful<br><br>adj. 多事的; 充满大事的; 多变故的 | event(词: 事件), -ful(充满…的)<br>由“事件”派生为当前词义 |
| inventive<br><br>adj. 发明创造的; 有发明才能的 | invent(词: 发明), -ive(…的)<br>在前词基础上加“-ive”构成形容词, 表示“发明创造的” |


### venge

惩罚

| 单词 | 拆解 |
| --- | --- |
| avenge<br><br>v. 为…报仇 | 源自古法语 avengier“为受害者报复”, 与 vengeance 同源<br>为所受伤害施加惩罚, 即报仇 |
| revenge<br><br>n. 报复; 报仇; 复仇<br>v. 报复; 向……报仇 | re-(回, 向后, 再次), **venge(惩罚)**<br>把惩罚回施给伤害自己的人, 因此表示报复、复仇 |
| vengeance<br><br>n. 报仇, 复仇 | **venge(惩罚)**, -ance(性质, 状态)<br>表示与“惩罚”有关的性质或状态, 即“报仇, 复仇” |
| vengeful<br><br>adj. 有报仇心理的, 谋报复的; (利于)报复的 | **venge(惩罚)**, -ful(充满…的)<br>围绕“惩罚”这一核心含义构成, 表示“有报仇心理的, 谋报复的” |


### ventr(i), ventr(o)

腹

| 单词 | 拆解 |
| --- | --- |
| ventricle<br><br>n. 心室; 脑室 | **ventr(i), ventr(o)(腹)**, -icle(小)<br>心脏或脑部内部形似小腹腔的中空腔室 |
| ventriloquist<br><br>n. 口技表演者; 腹语表演者 | **ventr(i), ventr(o)(腹)**, **loqu, locu(说, 言)**, -ist(人)<br>发音时嘴唇不动、仿佛由腹部发出声音的口技艺人 |


### ver(i)

真实

| 单词 | 拆解 |
| --- | --- |
| verify<br><br>v. 证实; 核实; 查清 | **ver(真实)**, -ify(…化, 做…)<br>确认某事为真实, 即核实 |
| veracity<br><br>n. 真实性; 确实; 准确(性); 诚实; 讲实话 | **ver(真实)**, -acity(性质, 状态)<br>在前词基础上加“-acity”构成名词, 表示“真实性” |
| verification<br><br>n. 证实; 核实; 证明 | **veri(真实)**, -fication(…化, 做…)<br>在前词基础上加“-fication”构成名词, 表示“证实” |
| verifier<br><br>n. 核实者; 检验者; 核实器; 检验器 | **veri(真实)**, -fier(做…的人或物)<br>在前词基础上加“-fier”构成名词, 表示“核实者” |
| verisimilitude<br><br>n. 逼真(的事物); 貌似真实(的事物) | **veri(真实)**, **simil(相同, 相似)**, -itude(性质, 状态)<br>由“真实”与“相似”共同限定词义, 表示“逼真, 貌似真实(的事物)” |
| verity<br><br>n. 真实性; 事实 | **ver(真实)**, -ity(性质, 状态)<br>表示与“真实”有关的性质或状态, 即“真实性” |
| verifiable<br><br>adj. 可证实的; 可核实的; 可检验的 | verify→verifi(词: 核实; 证实), -able(可…的)<br>能够被核实或证实的 |
| veritable<br><br>adj. 确实的; 真正的; 名符其实的 | 源自古法语 veritable“真实的”, 核心与拉丁语 veritas“真理”相关<br>确实符合事实或名称, 即真正的 |
| very<br><br>adj. 真实的; 真正的; 真的; 十足的 | 源自古法语 verai“真实的”, 最终与拉丁语 verus“真实”相关<br>由“真实地”强化程度, 发展为副词“非常” |
| verily<br><br>adv. 真正地; 肯定地; 真实地; 忠实地 | **veri(真实)**, -ly(…地)<br>围绕“真实”这一核心含义构成, 表示“真正地” |


### verb(i)

言, 词

| 单词 | 拆解 |
| --- | --- |
| verbalize<br><br>v. 用词语描述; 使变为动词 | verbal(词: 动词的), -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“用词语描述” |
| adverb<br><br>n. 副词 | ad-(到, 朝, 向), **verb(言, 词)**<br>附加到动词、形容词等旁边修饰其意义的词, 即副词 |
| proverb<br><br>n. 谚语; 格言; 箴言 | pro-(向前, 前进), **verb(言, 词)**<br>把一句话公开说出并流传下来, 因此表示谚语、格言 |
| verb<br><br>n. 动词 | **verb(言, 词)**<br>表示语言中的词, 语法上专指动词 |
| verbiage<br><br>n. 冗词; 赘语 | **verbi(言, 词)**, -age(总称, 集合)<br>围绕“词”这一核心含义构成, 表示“冗词, 赘语” |
| adverbial<br><br>adj. 副词的; 状语的 | adverb(词: 副词), -ial(…的)<br>在前词基础上加“-ial”构成形容词, 表示“副词的” |
| proverbial<br><br>adj. 谚语的; 格言式的 | proverb(词: 谚语), -ial(…的)<br>在前词基础上加“-ial”构成形容词, 表示“谚语的” |
| verbal<br><br>adj. 词语的; 言语的; 动词的; 口头的 | **verb(言, 词)**, -al(…的)<br>表示与“言”有关或具有该特征, 即“词语的, 言语的” |
| verbose<br><br>adj. 冗长的; 啰唆的 | 源自拉丁语 verbosus“多话的”, 核心 verbum 表示“词、话语”<br>使用过多话语, 即冗长啰唆的 |
| verbatim<br><br>adv. 逐字地; 照字面地 | **verb(言, 词)**, -atim(逐…地)<br>围绕“言”这一核心含义构成, 表示“逐字地” |


### verm(i)

蠕虫

| 单词 | 拆解 |
| --- | --- |
| vermin<br><br>n. 害虫; 寄生虫 | 源自拉丁语 vermis（蠕虫）, 由蠕虫扩展指令人厌恶或有害的虫兽 |
| vermiform<br><br>adj. 蠕虫状的; 蚯蚓形的 | **vermi(蠕虫)**, -form(…形状的)<br>围绕“蠕虫”这一核心含义构成, 表示“蠕虫状的, 蚯蚓形的” |


### vers(i)

诗

| 单词 | 拆解 |
| --- | --- |
| verse<br><br>n. 诗; 韵文; 诗句<br>v. 用诗表达; 作诗 | 古英语经拉丁语 versus“转弯、犁沟、诗行”传入, 核心与 vertere“转”相关<br>由一行文字发展为诗行、诗节和韵文 |
| versification<br><br>n. 诗体; 韵律; (散文原作等的) 韵文稿; 作诗 (法) | **versi(诗)**, -fication(…化, 做…)<br>围绕“诗”这一核心含义构成, 表示“作诗 (法)” |


### vers, vert

转

| 单词 | 拆解 |
| --- | --- |
| advertise<br><br>v. 登广告; 为⋯做广告; 大肆宣扬 | ad-(到, 朝, 向), **vert(转)**, -ise(…化, 使成)<br>使事物呈现“到”与“转”与“…化, 使成”所表达的状态, 即“登广告, 为⋯做广告” |
| convert<br><br>v. 使转变; 转换 | con-(与, 共同), **vert(转)**<br>使“转”共同结合或发挥作用, 因此表示“转变, 改造” |
| divert<br><br>v. 使转向; 使分心; 转移(注意力); 供消遣 | di-(分开, 分离), **vert(转)**<br>转离 |
| adversity<br><br>n. 逆境; 不幸; 苦难 | ad-(到, 朝, 向), **vers(转)**, -ity(性质, 状态)<br>逆境 |
| advertisement<br><br>n. 广告; 登广告 | advertise(词: 做广告), -ment(物)<br>制作并发布出来的广告内容或广告作品 |
| anniversary<br><br>adj. 周年纪念的<br>n. 周年纪念日 | **ann(年)**, i(连接字母), **vers(转)**, -ary(物)<br>每年循环回到的纪念日期 |
| controversy<br><br>n. 争论; 矛盾; 冲突; !!争议; 辩论 | contro-(反对, 相反), **vers(转)**, -y(活动)<br>双方观点朝相反方向转动、争执, 因此表示争议、论战 |
| diversion<br><br>n. 娱乐; 消遣; 转向; 转移 | di-(分开, 分离), **vers(转)**, -ion(行为, 结果)<br>由学习或工作中转移开 |
| extrovert<br><br>n. 外向性格的人 | extro-(在外, 向外), **vert(转)**<br>由“以外, 超过”与“转”共同限定词义, 表示“外向性格的人” |
| introversion<br><br>n. 内向; 内省; 内弯; 内翻 | intro-(向内, 在内), **vers(转)**, -ion(行为, 结果)<br>由“向内”与“转”共同限定词义, 表示“内向” |
| introvert<br><br>n. 个性内向者<br>v. 使内向; 使内弯; 内陷<br>adj. 性格内向的 | intro-(向内, 在内), **vert(转)**<br>由“向内”与“转”共同限定词义, 表示“使(思想)内向, 内省, 使内弯” |
| subversive<br><br>adj. 从事颠覆的; 破坏性的<br>n. 破坏分子; 颠覆分子 | sub-(在下, 向下), **vers(转)**, -ive(…的)<br>从根基处把现有秩序翻转, 因此表示颠覆性的 |
| version<br><br>n. 译文; 译本; 翻译; 改写本; 版本 | **vers(转)**, -ion(行为, 结果)<br>围绕“转”这一核心含义构成, 表示“译文, 译本” |
| vertigo<br><br>n. 晕眩 | 直接借自拉丁语 vertigo“旋转、眩晕”, 与 vertere“转”相关<br>感觉周围旋转的眩晕 |
| adverse<br><br>adj. 逆的; 相反的; 敌对的; 不友好的; 不利的 | ad-(到, 朝, 向), **vers(转)**, e(连接字母)<br>转向对立面 |
| irreversible<br><br>adj. 不可逆的; 不能取消的; 不能翻 转的 | ir-(无, 不, 非), re-(回, 向后, 再次), **vers(转)**, -ible(可…的)<br>否定或缺少“回、转”所指的性质, 因此表示“不能倒转的” |
| traversable<br><br>adj. 可横过的; 能横越的 | tra-(横过, 越过), **vers(转)**, -able(可…的)<br>由“横过”与“转”共同限定词义, 表示“可横过的, 能横越的” |
| versatile<br><br>adj. 可转动的; 万向的; 多方面适用的; 万用的; 多才多艺的 | **vers(转)**, -atile(易于…的)<br>围绕“转”这一核心含义构成, 表示“多才多艺的, 用途广泛的” |


### ves, vesic(o)

膀胱; 囊, 泡

| 单词 | 拆解 |
| --- | --- |
| vesicle<br><br>n. 泡; 囊; 小泡; 泡囊 | **ves, vesic(o)(膀胱; 囊, 泡)**, -icle(小)<br>由脂质双分子层包被、在细胞内负责转运物质或递质的微小囊状膜泡, 即囊泡 |
| vesicular<br><br>adj. 小囊(状)的; 小泡(状)的; 肺气泡的 | **ves(囊, 泡)**, -icular(…的)<br>具有小囊或小泡形状的, 因此表示小囊状、小泡状的 |


### vest

衣服

| 单词 | 拆解 |
| --- | --- |
| divest<br><br>v. 脱去; 剥夺 | di-(分开, 分离), **vest(衣服)**<br>把衣物或权利从某人身上剥离, 因此表示脱去、剥夺 |
| invest<br><br>v. 赋子; 投资; 投入 | in-(向内, 进入), **vest(衣服)**<br>原指给人穿上职位服饰, 后来发展为把资金投入事业 |
| travesty<br><br>n. 滑稽模仿; 谐谑化 | 源自意大利语 travestire（改换衣装）, 由“换装”引申为歪曲原作、拙劣模仿 |
| vestment<br><br>n. 外衣; 制服; 法衣; 祭服; [复]衣服 | **vest(衣服)**, -ment(物)<br>穿在身上的衣物, 尤指礼服或法衣 |
| vestry<br><br>n. 教堂的法衣室(置放法衣; 圣器等) | **vest(衣服)**, -ry(行为, 状态)<br>围绕“衣服”这一核心含义构成, 表示“教堂的法衣室(置放法衣、圣器等)” |
| vesture<br><br>n. 衣服; 衣裳; 覆盖物<br>v. 给穿衣服 | **vest(衣服)**, -ure(行为, 结果)<br>围绕“衣服”这一核心含义构成, 表示“衣服, 罩衣, 罩袍, 覆盖物” |
| vested<br><br>adj. 法律规定的; 既定的; 既得的; 穿着衣服(尤指祭服)的 | **vest(衣服)**, -ed(…的)<br>围绕“衣服”这一核心含义构成, 表示“穿着衣服(尤指祭服)的, 法律规定的” |


### vi(a), vey

路

| 单词 | 拆解 |
| --- | --- |
| convey<br><br>v. 传达; 运送; 输送; 表达; 传递 | con-(与, 共同), **vey(路)**<br>把某物带着一道运往别处, 因此表示运输或传达 |
| deviate<br><br>v. 离开; 背离(正道); 离题; 偏离 | de-(脱离, 取消, 除去), **vi(路)**, -ate(做, 使)<br>由“脱离”与“路”共同限定词义, 表示“离开” |
| obviate<br><br>v. 排除; 消除; 避免 | ob-(对着, 朝向, 在前), **vi(路)**, -ate(做, 使)<br>不在路上 |
| conveyance<br><br>n. 运输(工具) | convey(词: 运输), -ance(性质, 状态)<br>在前词基础上加“-ance”构成名词, 表示“运输” |
| deviation<br><br>n. 偏离; 背离; 偏差; 违背 | de-(脱离, 取消, 除去), **via(路)**, -tion(行为, 结果)<br>离开原定道路或标准的行为, 即偏离 |
| triviality<br><br>n. 琐事; 琐碎; 平凡 | trivial(词: 琐碎的), -ity(性质, 状态)<br>由“琐碎的”派生为当前词义 |
| via<br><br>n. 道路; 管道<br>prep. 经由; 经过; 通过 | **via(路)**<br>沿某条道路经过, 引申为“通过、经由” |
| viaduct<br><br>n. 高架桥; 跨线桥; 旱桥; 栈道 | **via(路)**, **duct(引, 导)**<br>把道路引过山谷或障碍的桥梁, 即高架桥、旱桥 |
| viaticum<br><br>n. (古罗马官吏因公外出的) 旅费 (或供应品); 旅行的费用 (或用品) | **via(路)**, -tic(…的), -um(名词词尾)<br>为上路旅行准备的费用或用品 |
| devious<br><br>adj. 迂回偏远的; 不坦诚的; 狡猾的 | de-(脱离, 取消, 除去), **vi(路)**, -ous(…的)<br>由“脱离”与“路”共同限定词义, 表示“远离大路的, 偏远的” |
| obvious<br><br>adj. 明显的; 明白的 | ob-(对着, 朝向, 在前), **vi(路)**, -ous(…的)<br>摆在大路上的 |
| previous<br><br>adj. 早先的; 先前的 | pre-(先于, 预先), **vi(路)**, -ous(…的)<br>走在前面的 |
| trivial<br><br>adj. 不重要的; 琐碎的; 微不足道的 | tri-(三, 三次), **vi(路)**, -al(…的)<br>原指三岔路口随处可见的普通事物, 后来表示琐碎的、不重要的 |


### vibr(o)

振动

| 单词 | 拆解 |
| --- | --- |
| vibrate<br><br>v. (使) 颤动; (使) 振动; (使) 震动; （使）振动; （使）摇摆 | **vibr(振动)**, -ate(做, 使)<br>快速来回摆动或使其振动 |
| vibrance<br><br>n. 振动 | **vibr(振动)**, -ance(性质, 状态)<br>表示与“振动”有关的性质或状态, 即“振动” |
| vibraphone<br><br>n. 一种电颤振打击乐器 | **vibr(振动)**, a(连接字母), **phon(声音)**, e(连接字母)<br>由“振动”与“声音”共同限定词义, 表示“一种电颤振打击乐器” |
| vibration<br><br>n. 颤动; 振动; 震动 | **vibr(振动)**, -ation(行为, 结果)<br>围绕“振动”这一核心含义构成, 表示“颤动” |
| vibrato<br><br>n. (演奏或演唱时的)颤动效果; (轻微的)颤音 | 源自意大利语 vibrato（振动的）, 表示演唱或演奏时音高有规律的轻微波动, 即颤音 |
| vibrator<br><br>n. 颤动者; 振动器; 振子; (按摩用)颤震器 | **vibr(振动)**, -ator(物)<br>产生振动的装置 |
| vibrant<br><br>adj. 充满生机的; 生气勃勃的; 精力充沛的; 鲜艳的 | **vibr(振动)**, -ant(…的)<br>围绕“振动”这一核心含义构成, 表示“充满生机的, 生气勃勃的, 精力充沛的, 鲜艳的” |


### vict, vinc

征服, 战胜

| 单词 | 拆解 |
| --- | --- |
| convict<br><br>n. 囚犯<br>v. 定罪 | con-(与, 共同), **vict(征服, 战胜)**<br>以证据彻底说服法庭其有罪, 因此表示定罪; 名词指罪犯 |
| convince<br><br>v. 使确信; 使信服; 说服 | con-(与, 共同), **vinc(征服, 战胜)**, e(连接字母)<br>使“征服”共同结合或发挥作用, 因此表示“使确信, 使信服” |
| victimize<br><br>v. 使牺牲; 使受害; 欺骗 | victim(词: 牺牲者), -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“使牺牲” |
| conviction<br><br>n. 信念; 坚定; 深信; 判罪; 定罪 | con-(与, 共同), **vict(征服, 战胜)**, -ion(行为, 结果)<br>内心被证据完全说服, 因此表示确信; 法律上也指定罪 |
| victim<br><br>n. 受害者; 牺牲者; 受骗者; 牺牲 (品) | 直接借自拉丁语 victima“祭牲”<br>后来泛指遭受伤害或损失的人 |
| victor<br><br>n. 胜利者<br>adj. 胜利的 | **vict(征服, 战胜)**, -or(人)<br>表示从事或具有“战胜”特征的人, 即“胜利者 (的), 战胜者 (的), 得胜者 (的)” |
| victory<br><br>n. 胜利; 战胜; 克服; 成功 | 源自拉丁语 victoria“胜利”, 与 victor“胜利者”相关<br>表示战胜对手或困难的结果 |
| victorious<br><br>adj. 胜利的; 战胜的; 得胜的 | victor(词: 胜利的), -ious(…的)<br>在前词基础上加“-ious”构成形容词, 表示“胜利的” |


### vid, vis

看

| 单词 | 拆解 |
| --- | --- |
| advise<br><br>v. 向…提意见; 建议; 作顾问; 劝告; 通知 | ad-(到, 朝, 向), **vis(看)**, e(连接字母)<br>向别人提出自己的看法 |
| provide<br><br>v. 作准备; 预防; 提供; 装备; 供给 | pro-(向前, 前进), **vid(看)**, e(连接字母)<br>预先见到而作准备 |
| revise<br><br>v. 修订; 修正; 修改 | re-(回, 向后, 再次), **vis(看)**, e(连接字母)<br>再看一遍 |
| adviser<br><br>n. 顾问; 劝告者 | advise→advis(词: 劝告), -er(人)<br>由“劝告”派生为当前词义 |
| evidence<br><br>n. 明显; 明白; 迹象; 证据; 根据 | e-(出, 向外), **vid(看)**, -ence(性质, 状态)<br>让事实清楚显现、可被看见的材料, 即证据 |
| revisionism<br><br>n. 修正主义 | revision(词: 校订), -ism(主义)<br>由“校订”派生为当前词义 |
| supervision<br><br>n. 监督; 管理 | super-(上), **vis(看)**, -ion(行为, 结果)<br>从上面往下看 |
| supervisor<br><br>n. 监视者; 监督(人); 管理人; 管理者; 监督者 | super-(上), **vis(看)**, -or(人)<br>从上监看者 |
| television<br><br>n. 电视 | **tele(远)**, **vis(看)**, -ion(行为, 结果)<br>由远处通过电波传来的可观看的图像 |
| visa<br><br>n. 签证; 签准 | **vis(看)**, a(连接字母)<br>审查后的签字 |
| visage<br><br>n. 外观; 外表; 面容 | 源自拉丁语 visus“看见、外观”形成的古法语 visage“面容”<br>呈现在他人眼前的脸, 即面容 |
| vision<br><br>n. 视; 视力; 视觉 | **vis(看)**, -ion(行为, 结果)<br>看的能力, 即"视力" |
| visit<br><br>n. 访问; 参观; 拜访<br>v. 访问; 拜访; 视察 | 源自拉丁语 visitare“去看、探望”<br>前往某处看望、参观或停留 |
| invisible<br><br>adj. 无形的; 看不见的 | in-(无, 不, 非), **vis(看)**, -ible(可…的)<br>不能被看见的, 即"不可见的" |
| provident<br><br>adj. 有远见的 | 源自拉丁语 providens“预见的”, 与 provide 同源<br>能预见需要并预作准备的 |
| supervisory<br><br>adj. 监管的; 管理的 | supervise→supervis(词: 监督), -ory(…的)<br>由“监督”派生为当前词义 |
| visual<br><br>adj. 看的; 视觉的; 视力的 | **vis(看)**, -ual(…的)<br>围绕“看”这一核心含义构成, 表示“视力的, 视觉的” |


### vig

活, 活力

| 单词 | 拆解 |
| --- | --- |
| vigil<br><br>n. 守夜; 值夜; 警戒 | 经古法语借自拉丁语 vigilia“清醒、守夜”<br>保持清醒进行守夜或警戒 |
| vigilance<br><br>n. 警戒; 警惕(性); 警醒症; 失眠症 | vigil(词: 警戒), -ance(性质, 状态)<br>在前词基础上加“-ance”构成名词, 表示“警戒” |
| vigo(u)r<br><br>n. 活力; 精力; 力量; 气势; (法律)效力 | 源自拉丁语 vigor“活力”<br>表示体力和生命力; 英式可拼 vigour |
| vigilant<br><br>adj. 警备着的; 警惕着的; 警醒的 | **vigil(警醒, 警惕)**, -ant(…的)<br>在前词基础上加“-ant”构成形容词, 表示“警备着的” |
| vigorous<br><br>adj. 精力充沛的; 强有力的; 充满活力的; 活跃的 | vigor(词: 活力), -ous(…的)<br>充满活力、强健有力的 |


### vir

绿; 男, 男子

| 单词 | 拆解 |
| --- | --- |
| virility<br><br>n. 男子气概; 刚劲有力; 生殖能力; 强健 | **vir(男, 男子)**, -ility(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“男子的” |
| virile<br><br>adj. 男性的; 有男性生殖力的; 有男子气概的; 精力充沛的; 强有力的 | **vir(男, 男子)**, -ile(…的)<br>具有男子气概或旺盛活力的 |


### vir(i), vir(o), vir(u)

病毒

| 单词 | 拆解 |
| --- | --- |
| virology<br><br>n. 病毒学 | **viro(病毒)**, -logy(…学, …研究)<br>以“病毒”为研究对象的学科, 即“病毒学” |
| virulence<br><br>n. 毒性; 毒力; 恶意; 刻毒 | **viru(病毒)**, -lence(性质, 状态)<br>围绕“病毒”这一核心含义构成, 表示“毒力, 毒性” |
| virus<br><br>n. 病毒; 传染毒; (精神; 道德方面的)毒素; 毒害; 恶毒 | 源自拉丁语 virus“毒液、毒素”<br>由致病毒性这一核心意象记忆为病毒 |
| virulent<br><br>adj. 剧毒的; 致命的; 恶毒的; 狂暴强烈的 | **viru(病毒)**, -lent(…的)<br>在前词基础上加“-lent”构成形容词, 表示“剧毒的” |


### visc(o)

黏

| 单词 | 拆解 |
| --- | --- |
| viscoelasticity<br><br>n. 黏弹性 | viscoelastic(词: 粘弹性的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“黏弹性” |
| viscometer<br><br>n. 黏滞计; 黏度计 | **visco(黏)**, **meter(测量器, 仪表)**<br>测量“黏”的仪器或方法, 即“黏滞计, 黏度计” |
| viscose<br><br>n. 粘胶; 纤维胶 | 源自拉丁语 viscosus“黏的”, 核心 viscum 表示“黏胶”<br>由黏稠溶液制成的黏胶纤维, 即粘胶 |
| viscosity<br><br>n. 黏性; 黏滞性; 黏滞度 | **visc(黏)**, -osity(性质, 状态)<br>在前词基础上加“-osity”构成名词, 表示“黏性” |
| viscoelastic<br><br>adj. 黏弹性的 | **visco(黏)**, **elast(弹性)**, -ic(…的)<br>由“黏”与“弹性”共同限定词义, 表示“黏弹性的” |
| viscous<br><br>adj. 黏滞的; 黏性的 | **visc(黏)**, -ous(…的)<br>表示与“黏”有关或具有该特征, 即“黏滞的, 黏性的” |


### viscer(o)

内脏

| 单词 | 拆解 |
| --- | --- |
| viscera<br><br>n. 内脏; 脏腑; 内容; 内部的东西 | 直接来自拉丁语 viscus 的复数 viscera“内脏”<br>身体内部器官; 引申为内部部分 |
| visceral<br><br>adj. 出自内心的; 本能的; 内脏的 | **viscer(内脏)**, -al(…的)<br>表示与“内脏”有关或具有该特征, 即“内脏的, 脏腑的” |


### vit

生命, 活力

| 单词 | 拆解 |
| --- | --- |
| vitalize<br><br>v. 给与⋯生命力; 使有生气 | vital(词: 生命的), -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“给与⋯生命力” |
| revitalization<br><br>n. 再生; 新生; 恢复元气 | re-(回, 向后, 再次), **vit(生命, 活力)**, -al(…的), -ization(行为, …化)<br>由“再次”与“生命”共同限定词义, 表示“再生” |
| vitality<br><br>n. 生命力; 生气; 活力 | vital(词: 生命的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“生命力” |
| vitals<br><br>n. (人体的) 重要器官; 要害; 命根子; 命脉 | 由 vital“生命攸关的”转化并使用复数集合形式<br>指体温、脉搏等生命体征 |
| vitamin(e)<br><br>n. 维生素; 维他命 | 由拉丁语 vita（生命）与 amine（胺）混成; 末尾 e 后来因并非所有维生素都是胺而删除 |
| vital<br><br>adj. (有) 生命的; 充满活力的; 致命的; 生命攸关的 | **vit(生命, 活力)**, -al(…的)<br>关乎生命活力的, 即"至关重要的" |


### viv(i)

活

| 单词 | 拆解 |
| --- | --- |
| revival<br><br>n. 再生; 复活, 苏醒 | re-(回, 向后, 再次), **viv(活)**, -al(行为, 过程)<br>重新活过来的过程, 即复活、复兴 |
| revive<br><br>v. (使)苏醒; 复活; 重新使用; （使）苏醒; （使）复兴 | re-(回, 向后, 再次), **viv(活)**, e(连接字母)<br>使生命重新出现, 即复苏 |
| survive<br><br>v. 幸存; 存活; 比…活得长; 生存 | 源自拉丁语 supervivere（活过、比…活得久）, 表示幸存 |
| survivor<br><br>n. 幸存者, 残存者 | survive→surviv(词: 比...活得长), -or(人)<br>由“比...活得长”派生为当前词义 |
| viable<br><br>adj. 能生存的; 可实行的 | **vi(路)**, -able(可…的)<br>围绕“路”这一核心含义构成, 表示“可实施的, 切实可行的, 可生存的, 能独立发展的” |
| viva<br><br>n. 万岁; 万岁的呼声 | 借自意大利语或西班牙语 viva“愿……长久活着”, 来自拉丁语 vivere“生活”<br>表示“万岁”的欢呼 |
| vivacious<br><br>adj. 活泼开朗的; 充满生气的; 快活的 | **viv(活)**, -acious(…的)<br>围绕“活”这一核心含义构成, 表示“活泼的, 快活的, 有生气的” |
| vivacity<br><br>n. 活泼; 快活; 有生气; 轻松愉快 | **viv(活)**, -acity(性质, 状态)<br>围绕“活”这一核心含义构成, 表示“活泼” |
| vivarium<br><br>n. (由人工造成、环境与动植物所处的自然条件相似的)动物(或植物)园 | **viv(活)**, -arium(场所, 地点)<br>围绕“活”这一核心含义构成, 表示“(由人工造成、环境与动植物所处的自然条件相似的)动物(或植物)园” |
| vivid<br><br>adj. 活泼的; 有生气的 | **viv(活)**, -id(…的)<br>围绕“活”这一核心含义构成, 表示“活泼的” |
| vivisect<br><br>v. 解剖(动物活体); 进行动物活体解剖 | **vivi(活)**, **sect(切, 分)**<br>由“活”与“切”共同限定词义, 表示“解剖(动物活体)” |
| vivisection<br><br>n. 活体解剖 | **vivi(活)**, **sect(切, 分)**, -ion(行为, 结果)<br>对活体进行切开研究的行为 |


### voc, vok

声音, 叫喊

| 单词 | 拆解 |
| --- | --- |
| advocate<br><br>n. 提倡者; 拥护者<br>v. 提倡; 鼓吹 | ad-(到, 朝, 向), **voc(声音, 叫喊)**, -ate(人; 物)<br>站到某人一边为其发声, 因此表示倡导者或拥护 |
| provoke<br><br>v. 挑衅; 激怒; 激起; 煽动; 引起 | pro-(向前, 前进), **vok(声音, 叫喊)**, e(连接字母)<br>向前呼喊并把反应激出来, 因此表示激起、挑衅 |
| revoke<br><br>v. 撤回; 撤销 | re-(回, 向后, 再次), **vok(声音, 叫喊)**, e(连接字母)<br>把先前发出的命令或许可叫回, 因此表示撤销、废除 |
| vocalize<br><br>v. 发声; 唱; 说 | vocal(词: 嗓音的), -ize(…化, 使成)<br>由“嗓音的”派生为当前词义 |
| convocation<br><br>n. 召集; 集合 | con-(与, 共同), **voc(声音, 叫喊)**, -ation(行为, 结果)<br>叫到一起来 |
| evocation<br><br>n. 唤起; 召唤 | e-(出, 向外), **voc(声音, 叫喊)**, -ation(行为, 结果)<br>叫出 |
| vocabulary<br><br>n. 词汇(量); 词汇表 | 源自拉丁语 vocabularium（词语清单）, 核心 vocabulum 意为名称、词 |
| vocalist<br><br>n. 歌唱家; 声乐家 | vocal(词: 歌唱的), -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“歌唱家” |
| equivocal<br><br>adj. 模棱两可的; 含糊其辞的; 意义不明确的; 令人怀疑的 | **equi(相等)**, **voc(声音, 叫喊)**, -al(…的)<br>一语作两种解释均可的 |
| irrevocable<br><br>adj. 不可挽回的; 不可撤销的 | ir-(无, 不, 非), re-(回, 向后, 再次), **voc(声音, 叫喊)**, -able(可…的)<br>否定或缺少“回、声音”所指的性质, 因此表示“不可挽回的” |
| provocative<br><br>adj. 挑衅的; 激怒的; 激起…的 | pro-(向前, 前进), **voc(声音, 叫喊)**, -ative(…的)<br>把反应或情绪呼唤、激发出来, 因此表示挑衅的、引发思考的 |
| vocal<br><br>adj. 有声的; 用语言表达的; 口述的; 歌唱的 | **voc(声音, 叫喊)**, -al(…的)<br>表示与“声音”有关或具有该特征, 即“直言不讳的” |


### vol, volunt

意志, 自愿

| 单词 | 拆解 |
| --- | --- |
| benevolence<br><br>n. 仁慈; 善心; 善行; 慈善 | bene-(好, 善), **vol(意志, 自愿)**, -ence(性质, 状态)<br>怀有善良意愿并愿意行善的状态, 即仁慈、善心 |
| malevolence<br><br>n. 恶意; 恶毒的行为 | male-(坏, 恶, 不良), **vol(意志, 自愿)**, -ence(性质, 状态)<br>由“恶”与“意志”共同限定词义, 表示“恶意” |
| volition<br><br>n. 意志(力) | **vol(意志, 自愿)**, -ition(行为, 结果)<br>围绕“意志”这一核心含义构成, 表示“意志(力)” |
| voluntariness<br><br>n. 自愿; 志愿; 自动; 受主观意志控制 | voluntary→voluntari(词: 自动的), -ness(性质, 状态)<br>由“自动的”派生为当前词义 |
| voluntarism<br><br>n. 唯意志论; 自愿捐助主义 | **volunt(意志, 自愿)**, -ar(…的), -ism(主义)<br>表示与“意志”有关的性质或状态, 即“唯意志论” |
| volunteer<br><br>n. 志愿者; 义工<br>v. 自愿做; 志愿提供<br>adj. 志愿的 | **volunt(意志, 自愿)**, -eer(人)<br>围绕“自愿”这一核心含义构成, 表示“志愿者, 自愿参加者” |
| benevolent<br><br>adj. 乐善好施的; 慈善的 | 源自拉丁语 bene volens, 字面为“希望好事”<br>希望他人安好, 即仁慈的 |
| involuntary<br><br>adj. 非自愿的; 非故意的 | in-(无, 不, 非), **volunt(意志, 自愿)**, -ary(…的)<br>否定或缺少“自愿”所指的性质, 因此表示“非自愿的” |
| malevolent<br><br>adj. 恶意的; 恶毒的 | 源自拉丁语 male volens, 字面为“希望坏事”<br>对他人怀有恶意的 |
| volitional<br><br>adj. 意志(力)的 | volition(词: 行使意志), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“意志” |
| voluntary<br><br>adj. 志愿的; 自愿的; 故意的 | **volunt(意志, 自愿)**, -ary(…的)<br>围绕“自愿”这一核心含义构成, 表示“志愿的, 自愿的” |


### volcan, vulcan

火山

| 单词 | 拆解 |
| --- | --- |
| volcanic<br><br>adj. 火山的; 猛烈的<br>n. 火山岩 | **volcan(火山)**, -ic(…的)<br>围绕“火山”这一核心含义构成, 表示“火山(性)的, 由火山作用所引起的, 有火山的, 火山似的” |
| volcanism<br><br>n. 火山作用; 火山现象; 火山活动 | 由 volcano“火山”形成<br>岩浆活动及相关火山现象 |
| volcano<br><br>n. 火山 | 经意大利语 volcano 进入英语, 名称与罗马火神 Vulcan 相关<br>指喷发熔岩、火山灰的地质构造 |
| volcanology<br><br>n. 火山学 | volcano(词: 火山), -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“火山学” |
| Vulcan<br><br>n. 火和锻冶之神); 火神; [v-] 锻冶者; 铁匠; [罗神] 伏尔甘(或译武尔坎 | **vulcan(火山)**<br>围绕“火山”这一核心含义构成, 表示“伏尔甘(或译武尔坎, 火和锻冶之神), 火神” |


### volv, volu, volut, volt

滚, 转

| 单词 | 拆解 |
| --- | --- |
| convolute<br><br>v. 卷绕; 旋绕 | con-(与, 共同), **volut(滚, 转)**, e(连接字母)<br>使“卷”共同结合或发挥作用, 因此表示“卷绕, 旋绕” |
| evolve<br><br>v. (使)进化; 逐步发展; 演化 | e-(出, 向外), **volv(滚, 转)**, e(连接字母)<br>从卷合状态向外滚动展开, 即"进化" |
| revolve<br><br>v. (使)旋转; 公转; 反复思考 | re-(回, 向后, 再次), **volv(滚, 转)**, e(连接字母)<br>反复转动、绕中心旋转, 因此表示旋转、围绕 |
| evolution<br><br>n. 进化; 进展; 演化 | e-(出, 向外), **volut(滚, 转)**, -ion(行为, 结果)<br>像卷轴逐步展开一样发展变化, 即演化 |
| evolutionism<br><br>n. 进化论 | evolution(词: 进化), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“进化论” |
| evolutionist<br><br>n. 进化论者 | evolution(词: 进化), -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“进化论者” |
| involvement<br><br>n. 卷入; 牵连; 包含 | in-(向内, 进入), **volv(滚, 转)**, e(连接字母), -ment(行为, 过程)<br>被卷入其中的行为或过程, 即参与 |
| revolt<br><br>n. 反叛; 起义; 反抗<br>v. 反叛; 造反; 厌恶 | re-(回, 向后, 再次), **volt(滚, 转)**<br>转向对立面 |
| revolution<br><br>n. 革命; 剧烈的变革; 旋转; 周转; 巨大变化 | re-(回, 向后, 再次), **volut(滚, 转)**, -ion(行为, 结果)<br>原指完整转动一周, 后来比喻制度发生根本翻转, 即革命 |
| revolutionary<br><br>adj. 革命性的; 革新的<br>n. 革命者; 革命的 | revolution(词: 革命), -ary(…的)<br>与革命有关的, 或带来根本性变革的 |
| revolver<br><br>n. 左轮手枪; 转炉; 旋转者 | revolve→revolv(词: 旋转), -er(物)<br>带旋转弹巢的手枪, 也可泛指旋转物 |
| volume<br><br>n. (书)卷; 体积; 容积; 音量; （书）卷 | 源自拉丁语 volumen（卷起来的书卷）, 由书卷大小发展为容量、体积 |
| volution<br><br>n. 涡旋; 旋圈; 螺环 | **volut(滚, 转)**, -ion(行为, 结果)<br>围绕“滚”这一核心含义构成, 表示“涡旋” |
| Volvo<br><br>n. (汽车品牌)沃尔沃 | 品牌名取自拉丁语 volvo（我滚动）, 以车轮滚动作为记忆锚点 |
| voluble<br><br>adj. 易旋转的; (言词)流利的 | **volu(滚, 转)**, **ble(可…的)**<br>围绕“转”这一核心含义构成, 表示“易旋转的” |


### vor

吃

| 单词 | 拆解 |
| --- | --- |
| carnivore<br><br>n. 食肉动物; 食虫植物 | **carni(肉)**, **vor(吃)**, e(连接字母)<br>吃肉的(动物), 即"食肉动物" |
| devour<br><br>n. 吞吃; 狼吞虎咽地吃<br>v. 吞食; 狼吞虎咽地吃 | 源自拉丁语 devorare（吞下）, 核心 vorare 意为吞食, 表示狼吞虎咽 |
| carnivorous<br><br>adj. 食肉的; 以肉为食的 | **carni(肉)**, **vor(吃)**, -ous(…的)<br>以肉为食的, 即"食肉的" |
| herbivorous<br><br>adj. 食草的; 以草为食的 | **herb(草)**, i(连接字母), **vor(吃)**, -ous(…的)<br>吃草的, 即"食草的" |
| insectivorous<br><br>adj. 食虫的; 以虫为食的 | insect(词: 昆虫), i(连接字母), **vor(吃)**, -ous(…的)<br>以昆虫为食的, 即"食虫的" |
| omnivorous<br><br>adj. 什么食物都吃的; 杂食性的 | omni-(全, 总, 泛), **vor(吃)**, -ous(…的)<br>由“全”与“吃”共同限定词义, 表示“什么食物都吃的, 杂食性的” |
| voracious<br><br>adj. 狼吞虎咽的; 贪吃的; 贪婪的; 贪得无厌的 | **vor(吃)**, -acious(…的)<br>围绕“吃”这一核心含义构成, 表示“狼吞虎咽的, 贪吃的” |


### vot

发誓

| 单词 | 拆解 |
| --- | --- |
| devote<br><br>v. 奉献; 把……奉献(给); 把… 专用(于); 献身; 投入 | de-(一再等加强意义), **vot(发誓)**, e(连接字母)<br>以誓言把自己交付给某事, 因此表示献身、致力 |
| devotion<br><br>n. 忠诚; 热爱; 奉献 | devote→devot(词: 投入于), -ion(行为, 结果)<br>由“投入于”派生为当前词义 |
| vote<br><br>n. 投票; 选票; 投票权<br>v. 投票; 表决 | **vot(发誓)**, e(连接字母)<br>围绕“发誓”这一核心含义构成, 表示“投票(权)” |
| voting<br><br>n. 投票; 选举<br>adj. 投票的; 选举的 | **vot(发誓)**, -ing(行为, 过程)<br>在前词基础上加“-ing”构成名词或形容词, 表示“投票” |
| votable<br><br>adj. 有选举权的; 有投票权的; 可付表决的 | **vot(发誓)**, -able(可…的)<br>围绕“发誓”这一核心含义构成, 表示“有选举权的, 有投票权的” |
| votive<br><br>adj. (因誓约而)奉献的; 还原的 | **vot(发誓)**, -ive(…的)<br>表示与“发誓”有关或具有该特征, 即“(因誓约而)奉献的” |
