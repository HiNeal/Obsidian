## oyword-root-t


### tac, tic

沉默

| 单词 | 拆解 |
| --- | --- |
| reticence<br><br>n. 沉默寡言; 缄默; 谨慎保留 | 源自拉丁语 reticentia“沉默”, 来自 reticere“保持沉默”<br>不愿多说、有所保留 |
| reticent<br><br>adj. 沉默寡言的; 有保留的; (艺术风格等)有节制的; 谨严的 | 源自拉丁语 reticens“保持沉默的”<br>沉默寡言、有保留的 |
| tacit<br><br>adj. 缄默的; 心照不宣的; 不言而喻的 | 源自拉丁语 tacitus“沉默的、未说出的”<br>表示虽未明说却被理解或默许的 |
| taciturn<br><br>adj. 沉默寡言的; 不苟言笑的; 一本正经的 | 英语内部没有可靠的同步构词边界<br>表示习惯沉默、很少说话的 |


### tach, tack

钉

| 单词 | 拆解 |
| --- | --- |
| attach<br><br>v. 附上; 使依恋 | at-(到, 朝, 向), **tach(钉)**<br>朝向某物钉牢固定, 即"附着" |
| detach<br><br>v. 分开; 拆开; 派遣; 分遣; （使）分离 | de-(脱离, 取消, 除去), **tach(钉)**<br>把固定用的连接解除, 使一部分脱离, 因此表示拆下、分离 |
| attachment<br><br>n. 附件; 附属装置; 依恋 | 经古法语 attachement 借入, 与 attach“系牢、附着”同源<br>由系在一起引申为附件或依恋 |
| attack<br><br>n. 攻击; 袭击; 发作<br>v. 攻击; 抨击; 着手处理 | at-(到, 朝, 向), **tack(钉)**<br>像把钉子钉向目标一样猛烈冲击, 由此表示攻击 |
| attacker<br><br>n. 攻击者 | attack(词: 攻击), -er(人)<br>在前词基础上加“-er”构成名词, 表示“攻击者” |
| detachment<br><br>n. 分离; 拆卸; 分遣队; 超然公正 | 经法语 détachement 借入, 与 detach“分离”同源<br>由分开引申为超然或分遣队 |
| tackle<br><br>n. 用具; 器材<br>v. 处理; 应对; 解决 | 日耳曼语源, 早期与绳索、装备有关<br>由使用装备控制目标发展为处理问题、擒抱或处理球 |
| detached<br><br>adj. 分离的; 孤立的; 超然的; 分遣的; 派遣的 | detach(词: 分离), -ed(…的)<br>在前词基础上加“-ed”构成形容词, 表示“分离的” |


### tacho, tachy

快速, 速度

| 单词 | 拆解 |
| --- | --- |
| tachometer<br><br>n. 速度计; 流速计 | **tacho(速度, 快速)**, **meter(测量器, 仪表)**<br>测量“速度”的仪器或方法, 即“速度计” |
| tachycardia<br><br>n. 心动过速; 心搏过速 | 由表示“快速”的 tachy- 与表示“心脏”的 cardi- 结合<br>指心率异常加快的状态 |
| tachymeter<br><br>n. 准距计; 速测仪 | **tachy(速度, 快速)**, **meter(测量器, 仪表)**<br>测量“快速”的仪器或方法, 即“准距计, 速测仪” |
| tachyon<br><br>n. 超光速粒子 | **tachy(速度, 快速)**, -on(粒子)<br>围绕“快速”这一核心含义构成, 表示“超光速粒子” |


### tact, tag, tang, ting

接触

| 单词 | 拆解 |
| --- | --- |
| contact<br><br>n. 接触; 联系; 熟人<br>v. 联系; 联络 | con-(与, 共同), **tact(接触)**<br>使“接触”共同结合或发挥作用, 因此表示“接触, 联系” |
| contagion<br><br>n. 接触传染; 传染病 | con-(与, 共同), **tag(接触)**, -ion(行为, 结果)<br>使“接触”共同结合或发挥作用, 因此表示“接触传染” |
| tactic<br><br>n. 策略; 战术 | 源自希腊语 taktikē“排列、布置的艺术”<br>表示为实现具体目标采用的战术 |
| contagious<br><br>adj. 接触传染的; 有传染性的 | con-(与, 共同), **tag(接触)**, -ious(…的)<br>彼此共同接触到的, 即"具有传染性的" |
| contingent<br><br>adj. 偶然的; 临时的; 有条件的 | con-(与, 共同), **ting(接触)**, -ent(…的)<br>原指偶然碰到一起, 后来表示偶然的、有条件的 |
| intact<br><br>adj. 未触动的; 完整的 | in-(无, 不, 非), **tact(接触)**<br>否定或缺少“接触”所指的性质, 因此表示“未触动的” |
| intangible<br><br>adj. 不可捉摸的; 捉摸不透的 | in-(无, 不, 非), **tang(接触)**, -ible(可…的)<br>否定或缺少“接触”所指的性质, 因此表示“不可捉摸的, 捉摸不透的” |
| tactful<br><br>adj. 机智的; 老练的; 圆滑的 | **tact(接触)**, -ful(充满…的)<br>围绕“接触”这一核心含义构成, 表示“机智的” |
| tactile<br><br>adj. (有) 触觉的; 能触知的 | **tact(接触)**, -ile(…的)<br>围绕“接触”这一核心含义构成, 表示“(有) 触觉的” |
| tangible<br><br>adj. 可触知的; 现实的 | **tang(接触)**, -ible(可…的)<br>围绕“接触”这一核心含义构成, 表示“可触知的, 现实的” |


### tail

剪, 切

| 单词 | 拆解 |
| --- | --- |
| curtail<br><br>v. 缩短; 限制; 减缩 | 经古法语 courtault“被截短的”相关形式进入英语<br>表示缩短或削减 |
| detail<br><br>n. 细节; 详情<br>v. 详述; 选派; 画详图 | de-(脱离, 取消, 除去), **tail(剪, 切)**<br>从整体中切分出的细小部分, 即细节 |
| retail<br><br>n. 零售<br>v. 零售; 以……价格销售<br>adj. 零售的 | re-(回, 向后, 再次), **tail(剪, 切)**<br>把大批货物切分成小份出售, 因此表示零售 |
| retailer<br><br>n. 零售商 | retail(词: 零售), -er(人)<br>在前词基础上加“-er”构成名词, 表示“零售商” |
| tail<br><br>n. 尾巴; 尾状物; 末尾部分; 后部; 底部 | 指动物身体后端的尾部<br>也可转化作动词表示跟踪 |
| tailgate<br><br>n. (车辆后部可移动的) 尾板; 后挡板 | tail(词: 尾部), gate(词: 门板)<br>车辆尾部可开合的门板 |
| tailing<br><br>n. (半嵌在墙内的砖; 石的) 嵌入部分; 尾砂 | tail(词: 尾部; 残余物), -ing(物)<br>留在主体之后的尾部或残余物, 可指尾砂、嵌入部分 |
| tailor<br><br>n. 裁缝<br>v. 量身定制; 调整 | **tail(剪, 切)**, -or(人)<br>原指从事裁剪的人, 即裁缝; 名词转化为动词后表示专门制作、调整 |
| tailored<br><br>adj. (似) 裁缝做的; 特制的; 定做的; 时髦的; 干净利索的 | 词形来源：tailor + ed-form |


### tain, ten, tin

持, 守

| 单词 | 拆解 |
| --- | --- |
| abstain<br><br>v. 戒; 避免; 避开 | 经古法语借自拉丁语 abstinere, 由 ab“离开”与 tenere“握住”构成<br>记忆为把自己握住、不去做, 即戒绝 |
| detain<br><br>v. 拘留; 扣押; 阻住; 留住 | de-(下降, 降低), **tain(持, 守)**<br>把人扣住、不让离开, 因此表示拘留、耽搁 |
| obtain<br><br>v. 取得; 获得; 得到; 买到 | ob-(对着, 朝向, 在前), **tain(持, 守)**<br>朝目标把握持有到手, 即"获得" |
| sustain<br><br>v. 维持; 支撑; 遭受; 蒙受 | sus-(在下, 从下支撑), **tain(持, 守)**<br>从下方托住以使之继续存在, 即支撑、维持 |
| abstention<br><br>n. 戒; 避免; 避开 | 源自拉丁语 abstentio, 是 abstain 的名词形式<br>记忆为主动克制、不参与的行为 |
| abstinence<br><br>n. 节制; 禁欲 | ab-(脱离, 离去), **stin(站立)**, -ence(性质, 状态)<br>把自己从欲望或行为中抽离并克制, 因此表示节制、禁欲 |
| container<br><br>n. 容器; 集装箱 | con-(与, 共同), **tain(持, 守)**, -er(物)<br>把内容物保持在其中的容器 |
| containerization<br><br>n. 集装箱化 | container(词: 集装箱), -ization(行为, …化)<br>在前词基础上加“-ization”构成名词, 表示“集装箱化” |
| content<br><br>n. 含量; 目录; 容量; [复]内容<br>adj. 满足的<br>v. 使满足 | con-(与, 共同), **tent(伸)**<br>共同伸展的边界内所容纳之物, 即内容; 形容词义引申为愿望限于已有之物而满足 |
| continuity<br><br>n. 连续性; 持续性; 连贯性 | con-(与, 共同), **tin(持, 守)**, u(连接字母), -ity(性质, 状态)<br>共同保持握住不中断的状态, 即连续性 |
| maintenance<br><br>n. 维护; 保养; 维持; (依法应负担的)生活费; 抚养费 | **main(留, 居住)**, **ten(持, 守)**, -ance(性质, 状态)<br>使事物持续保持原有状态, 因此表示维持、保养 |
| tenacity<br><br>n. 紧握; 坚持; 固执 | **ten(持, 守)**, -acity(性质, 状态)<br>围绕“握”这一核心含义构成, 表示“紧握, 坚持” |
| tenure<br><br>n. 保有; 占有; 占有权; 占有期 | **ten(持, 守)**, -ure(行为, 结果)<br>围绕“握”这一核心含义构成, 表示“保有, 占有” |
| maintainable<br><br>adj. 可保持的; 可维持的 | maintain(词: 维持), -able(可…的)<br>能够被维持或保养的 |
| pertinent<br><br>adj. 恰当的; 相干的 | per-(通过, 贯穿), **tin(持, 守)**, -ent(…的)<br>属于··· |


### tard

慢

| 单词 | 拆解 |
| --- | --- |
| retard<br><br>v. 迟缓; 妨碍 | re-(回, 向后, 再次), **tard(慢)**<br>把进程向后拖慢, 因此表示延缓、妨碍 |
| retardancy<br><br>n. 阻滞性; 阻止性 | 由 retardant“阻滞的”派生<br>延缓或阻止的性质 |
| tardiness<br><br>n. 缓慢; 迟; 不情愿; 拖拉 | **tard(慢)**, i(连接字母), -ness(性质, 状态)<br>表示与“慢”有关的性质或状态, 即“缓慢” |
| tardy<br><br>adj. 缓慢的; 迟钝的 | **tard(慢)**, -y(充满…的, 有…特征的, 像…的)<br>在前词基础上加“-y”构成形容词, 表示“缓慢的” |


### techn(o)

技术, 工艺

| 单词 | 拆解 |
| --- | --- |
| technic<br><br>adj. 技巧; 技能; 技术的; 工艺的<br>n. 技巧, 技能; 技术的, 工艺的 | **techn(技术, 工艺)**, -ic(…的)<br>围绕“技术”这一核心含义构成, 表示“技巧, 技能” |
| technicality<br><br>n. 技术性, 专门性; 技术细节; 术语, 专门语 | technical(词: 技术上的), -ity(性质, 状态)<br>由“技术上的”派生为当前词义 |
| technician<br><br>n. 技术员; 技师 | **techn(技术, 工艺)**, -ician(人)<br>围绕“技术”这一核心含义构成, 表示“技术员” |
| technique<br><br>n. 技巧; 方法; 技术 | 直接借自法语 technique, 源自希腊语 tekhnikos（技艺的）, 表示技术、方法 |
| technocracy<br><br>n. 专家政治, 技术统治 | **techno(技术, 工艺)**, **cracy(统治, 政体)**<br>由“技术”与“统治”共同限定词义, 表示“专家政治, 技术统治” |
| technocrat<br><br>n. 专家政治论者, 专家治国论者 | **techno(技术, 工艺)**, **crat(统治者)**<br>围绕“统治者”这一核心含义构成, 表示“专家政治论者, 专家治国论者” |
| technology<br><br>n. 科技; 技术 | **techno(技术, 工艺)**, -logy(…学, …研究)<br>对技术工艺的系统研究, 也泛指技术体系 |


### tect

覆盖

| 单词 | 拆解 |
| --- | --- |
| detect<br><br>v. 侦察; 侦查; 发觉; 察觉 | de-(一再等加强意义), **tect(覆盖)**<br>揭去覆盖之物使显现, 即"探查, 感知" |
| protect<br><br>v. 保护; 防护 | pro-(向前, 前进), **tect(覆盖)**<br>在前方遮盖挡护, 即"保护" |
| detection<br><br>n. 侦查; 发觉 | 与 detect“揭开、发现”同源, 源自拉丁语 detegere“揭去覆盖”<br>揭开隐藏事物的行为 |
| detective<br><br>adj. 侦探的<br>n. 侦探 | detect(词: 侦查), -ive(…的)<br>从事侦查的人 |
| detector<br><br>n. 察觉者; 发觉者; 探测器 | detect(词: 察觉), -or(人)<br>负责察觉目标的人; 也可引申指探测装置 |
| protection<br><br>n. 保护; 护卫; 防护物 | protect(词: 保护), -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“保护” |
| protectionism<br><br>n. 保护(贸易)主义 | protection(词: 保护), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“保护” |
| protector<br><br>n. 保护者; 保护器 | protect(词: 保护), -or(人)<br>在前词基础上加“-or”构成名词, 表示“保护者” |
| protective<br><br>adj. 保护的; 防护的 | protect(词: 保护), -ive(…的)<br>在前词基础上加“-ive”构成形容词, 表示“保护的” |
| unprotected<br><br>adj. 无掩护的; 没有防卫的; 未设防的 | un-(无, 不, 非), protect(词: 保护), -ed(…的)<br>否定或缺少“保护”所指的性质, 因此表示“无掩护的” |


### tel(e), tel(o)

远; 目的, 末端

| 单词 | 拆解 |
| --- | --- |
| telegram<br><br>n. 电报 | **tele(远)**, **gram(书写, 记录)**<br>由远方通过电波传来的文字 |
| telephone<br><br>n. 电话; 电话机<br>v. 打电话 | **tel(e), tel(o)(远; 目的, 末端)**, **phon(o)(声音)**<br>将声音信号远距离传输的通信装置 |
| telescope<br><br>n. 望远镜<br>v. 缩短; 嵌合 | **tel(e), tel(o)(远; 目的, 末端)**, **scop(镜, 观察; 目标)**<br>用于远距离观察天体或远处景物的光学仪器 |


### tempor(o)

时

| 单词 | 拆解 |
| --- | --- |
| contemporaneous<br><br>adj. 同时代的; 同时发生的 | con-(与, 共同), **tempor(时)**, -aneous(…的)<br>在前词基础上加“-aneous”构成形容词, 表示“同时代的” |
| contemporary<br><br>adj. 当代的; 同时代的<br>n. 同时代的人 | con-(与, 共同), **tempor(时)**, -ary(…的)<br>使“时”共同结合或发挥作用, 因此表示“同时代的(人), 同龄的(人)” |
| extemporaneous<br><br>adj. 临时的, 当场的; 无准备的 | ex-(出, 向外), **tempor(时)**, -aneous(…的)<br>在计划时间之外的 |
| tempo<br><br>n. 拍子; 速度 | 借自意大利语 tempo“时间、速度”, 源自拉丁语 tempus“时间”<br>音乐进行的速度 |
| temporal<br><br>adj. 时间的; (语法)时态的; 短暂的 | **tempor(时)**, -al(…的)<br>围绕“时”这一核心含义构成, 表示“颞骨[肌, 动脉等], 太阳穴, 世俗的权力, 一时的事物” |
| temporary<br><br>adj. 暂时的, 临时的 | **tempor(时)**, -ary(…的)<br>只属于某一时段的, 即"临时的" |


### tempt

蔑视; 尝试

| 单词 | 拆解 |
| --- | --- |
| contempt<br><br>n. 轻蔑; 轻视; 受辱; 丢脸; 藐视 | con-(与, 共同), **tempt(尝试)**<br>把某人或某事看得很低, 因此表示轻视、蔑视 |
| contemptible<br><br>adj. 卑鄙的; 不齿的; 可轻视的 | con-(彻底, 完全, 加强), **tempt(蔑视)**, -ible(可…的)<br>在前词基础上加“-ible”构成形容词, 表示“卑鄙的” |
| contemptuous<br><br>adj. 蔑视的; 轻蔑的; 傲慢的 | contempt(词: 轻蔑), -uous(…的)<br>在前词基础上加“-uous”构成形容词, 表示“蔑视的, 轻蔑的” |


### tempt, tent

尝试

| 单词 | 拆解 |
| --- | --- |
| attempt<br><br>n. 尝试; 企图<br>v. 试图; 尝试 | at-(到, 朝, 向), **tempt(尝试)**<br>向目标伸手尝试, 因此表示试图、尝试 |
| tempt<br><br>v. 诱惑; 引诱; 吸引; 冒…的险 | **tempt(尝试)**<br>围绕“尝试”这一核心含义构成, 表示“引诱, 诱惑” |
| temptation<br><br>n. 引诱(物); 诱惑(物) | **tempt(尝试)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“引诱” |
| temptress<br><br>n. 引诱人的女人; 妖妇 | **tempt(尝试)**, -ress(女性, 雌性)<br>在前词基础上加“-ress”构成名词, 表示“引诱人的女人” |
| tentative<br><br>adj. 暂定的; 犹豫的; 试探性的<br>n. 尝试; 试验性提议 | **tent(尝试)**, -ative(…的)<br>处于试探性尝试阶段的, 即"暂时的, 初步的" |
| temperate<br><br>adj. (气候)温和的; 温带的; 有节制的; 心平气和的 | **temper(调和, 节制)**, -ate(…的)<br>受到节制、不过热也不过冷的 |
| tempting<br><br>adj. 引诱人的; 吸引人的 | tempt(词: 诱惑), -ing(…的)<br>能够诱使人产生欲望的, 即吸引人的 |


### tend, tens, tent

伸

| 单词 | 拆解 |
| --- | --- |
| attend<br><br>v. 出席; 照料; 护理; 专心处理; 参加 | at-(到, 朝, 向), **tend(伸)**<br>把心思伸向某处并在场, 因此表示"出席"; 引申指用心照料, "专心处理" |
| distend<br><br>v. (使)扩张; (使)膨胀; (使)肿胀 | dis-(否定, 相反), **tend(伸)**<br>向四面分开伸展, 即"膨胀" |
| extend<br><br>v. 伸出; 扩大; 扩展; 扩张 | ex-(出, 向外), **tend(伸)**<br>向外伸长或扩大, 因此表示伸出、延长 |
| attention<br><br>n. 注意(力); 关心 | attend→attent(词: 注意), -ion(行为, 结果)<br>把心思伸向某个对象的行为或状态, 即注意 |
| contention<br><br>n. 争论; 论点; 争辩; 观点 | con-(与, 共同), **tent(伸)**, -ion(行为, 结果)<br>双方朝同一目标伸手争夺, 引申为争论、竞争或主张 |
| extensibility<br><br>n. 可伸展性; 可扩张性 | ex-(出, 向外), **tens(伸)**, -ibility(可…性)<br>能够向外伸展、延长的性质, 即可伸展性 |
| hypertension<br><br>n. 高血压 | hyper-(超过, 极度), **tens(伸)**, -ion(行为, 结果)<br>血管承受过高张力的状态, 即高血压 |
| intensity<br><br>n. 强度; 强烈 | intense→intens(词: 强烈的), -ity(性质, 状态)<br>达到强烈程度的性质或状态 |
| ostentation<br><br>n. 夸示; 卖弄; 铺张; 风头主义 | 源自拉丁语 ostentatio“展示、炫示”<br>刻意展示财富或能力 |
| tendency<br><br>n. 趋向; 倾向; 趋势; 倾向性 | **tend(伸)**, -ency(性质, 状态)<br>围绕“伸”这一核心含义构成, 表示“趋向, 倾向, 趋势” |
| tent<br><br>n. 帐篷 | **tent(伸)**<br>把布料撑开、拉紧形成的遮蔽物, 即帐篷 |
| extensive<br><br>adj. 广泛的; 宽阔的 | ex-(出, 向外; 除去, 离开; 超过, 彻底), **tens(伸)**, -ive(…的)<br>向外充分伸展展开地, 即"广泛地" |
| intense<br><br>adj. 紧张的; 强烈的; 剧烈的 | in-(向内, 进入), **tens(伸)**, e(连接字母)<br>像被拉紧一样处于高度紧张状态, 因此表示强烈的 |
| ostensible<br><br>adj. 可公开的; 显然的; 外表的; 诡称的 | 源自拉丁语 ostensibilis“可展示的”, 与 ostend“显示”同源<br>表面所显示的, 未必真实 |
| tendentious<br><br>adj. 有倾向性的; 有偏见的; 有争议的 | **tend(伸)**, -ent(…的), -ious(…的)<br>在前词基础上加“-ent”、“-ious”构成形容词, 表示“有倾向性的” |


### tep(e)

微温

| 单词 | 拆解 |
| --- | --- |
| tepid<br><br>adj. 微温的; 温热的; 不太热烈的; 不冷不热的 | **tep(微温)**, -id(…的)<br>围绕“微温”这一核心含义构成, 表示“微温的” |
| tepidity<br><br>n. 微温; 温热; 不热情 | **tep(e)(微温)**, -id(…的), -ity(性质, 状态)<br>温度微温或态度不冷不热的状态 |


### term, termin

界限, 期限

| 单词 | 拆解 |
| --- | --- |
| determine<br><br>v. 决定; 查明; 确定; 决心 | de-(一再等加强意义), **termin(界限, 期限)**, e(连接字母)<br>把界限明确下来, 即确定或决定 |
| exterminate<br><br>v. 根除; 灭绝; 消除 | ex-(出, 向外), **termin(界限, 期限)**, -ate(做, 使)<br>逐出某一范围 |
| determination<br><br>n. 决心; 坚定; 果断 | de-(一再等加强意义), **termin(界限, 期限)**, -ation(行为, 结果)<br>为事情划定界限、作出定论, 因此表示决定或决心 |
| terminal<br><br>adj. 晚期的; 致命的; 末端的; 极限的<br>n. 航站楼; 终点站; 终端(机); 接线端 | **termin(界限, 期限)**, -al(…的)<br>在前词基础上加“-al”构成名词或形容词, 表示“末端” |
| terminator<br><br>n. 终止者; 结尾物 | **termin(界限, 期限)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“终止者” |
| terminus<br><br>n. 终点站; 界标; 边界 | **termin(界限, 期限)**, -us(名词词尾)<br>在前词基础上加“-us”构成名词, 表示“终点” |
| terminable<br><br>adj. 可终止的; 有期限的 | **termin(界限, 期限)**, -able(可…的)<br>围绕“界限”这一核心含义构成, 表示“可终止的” |
| termly<br><br>adv. 定期地<br>adj. 定期的 | **term(界限, 期限)**, -ly(…的)<br>围绕“期限”这一核心含义构成, 表示“(指事物发生、款项支付等)定期的(地)” |


### terr(i), ter

土地, 陆地; 怕, 恐

| 单词 | 拆解 |
| --- | --- |
| inter<br><br>v. 埋葬 | 经古法语 enterrer 借入, 源自拉丁语 in terra“置入土中”<br>把遗体埋入地下 |
| deter<br><br>v. 阻止; 制止 | 源自拉丁语 dēterrēre（吓退、阻止）, 由“使恐惧而退却”发展而来 |
| terrify<br><br>v. 使恐惧; 使非常害怕 | **terr(怕, 恐)**, -ify(…化, 做…)<br>使人进入恐惧状态 |
| terrorize<br><br>v. 使恐怖; 恐吓 | terror(词: 恐怖), -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“使恐怖” |
| extraterrestrial<br><br>adj. 地球外的; 地球大气圈外的 | extra“在……之外”与 terrestrial“地球的”构成<br>来自地球之外的 |
| Mediterranean<br><br>adj. 地中海的; 地中海地区的<br>n. 地中海 | 源自拉丁语 medius“中间”与 terra“陆地”<br>意为“陆地之间的海”, 即地中海 |
| terrace<br><br>n. 露天平台; 阳台; 阶梯看台; 梯田; 阶地 | **terr(土地, 陆地)**, -ace(构成名词)<br>围绕“土地”这一核心含义构成, 表示“大阳台, 露天平台” |
| terrain<br><br>n. 地面; 地带; 地域; 地形 | 源自法语 terrain“土地、地面”<br>表示一片土地的地面形态, 即地形或地势 |
| territory<br><br>n. 领土; 领地 | 源自拉丁语 territorium“某城周围的土地”, 核心 terra 表示“土地”<br>由土地界定的区域, 即领土 |
| deterrence<br><br>n. 威慑; 吓住; 制止 | de-(脱离, 取消, 除去), **terr(怕, 恐)**, -ence(性质, 状态)<br>使人因害怕后果而离开某种行动的状态, 即威慑、遏制 |
| terror<br><br>n. 恐惧; 恐慌 | 源自拉丁语 terror“强烈恐惧”<br>表示极度恐惧或造成恐惧的人物 |
| terrorism<br><br>n. 恐怖行为; 恐怖主义 | terror(词: 恐怖), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“恐怖行为” |
| terrorist<br><br>n. 恐怖主义者; 恐怖分子 | terror(词: 恐怖), -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“恐怖主义者” |
| deterrent<br><br>adj. 威慑的; 吓住的; 制止的 | deter→deterr(词: 威慑), -ent(…的)<br>能够阻止某种行为的事物或措施 |
| terrible<br><br>adj. 可怕的; 糟糕的; 严重的 | **terr(怕, 恐)**, -ible(可…的)<br>围绕“怕”这一核心含义构成, 表示“可怕的, 骇人的” |
| terrific<br><br>adj. 极好的; 惊人的; 很大的; 很强的 | 源自拉丁语 terrificus“造成恐惧的”<br>原指可怕的, 后来在口语中发展为极好的 |


### test(i)

证据, 验证

| 单词 | 拆解 |
| --- | --- |
| attest<br><br>v. 证明; 证实 | at-(到, 朝, 向), **test(证据, 验证)**<br>把证据带到某项主张旁加以证明, 因此表示证实、作证 |
| testify<br><br>v. 作证; 证明 | **test(证据, 验证)**, -ify(…化, 做…)<br>正式提供证据或作证 |
| contest<br><br>n. 比赛; 竞赛<br>v. 争取; 质疑; 争辩 | con-(与, 共同), **test(证据, 验证)**<br>双方共同要求证明自己更优, 因此表示竞争、争夺 |
| protest<br><br>n. 抗议; 反对<br>v. 抗议; 反对; 申辩 | pro-(向前, 前进; 在前, 预先; 赞成, 支持), **test(证据, 验证)**<br>在公众面前公开声明反对, 即抗议 |
| testament<br><br>n. 确实的证明; 实证; 信仰的声明 | 经古法语借自拉丁语 testamentum“见证、遗嘱”, 与 testis“证人”相关<br>确实的证明或遗嘱性声明 |
| tester<br><br>n. 测试仪; 测试员 | **test(证据, 验证)**, -er(物)<br>用于测试的仪器, 也可指负责测试的人 |
| testimonial<br><br>n. (能力; 资格; 品德等的) 证明书; 介绍信; 鉴定书 | **testi(证据, 验证)**, **moni(状态, 结果)**, -al(…的)<br>围绕“证据”这一核心含义构成, 表示“(能力、资格、品德等的) 证明书, 介绍信” |
| testimony<br><br>n. 证据; 证明; 声明; 表明 | **test(i)(证据, 验证)**, -mony(状态, 结果)<br>在法庭等正式场合提供证明事实的陈述, 即“证词; 证据; 证明” |


### text

织, 编织

| 单词 | 拆解 |
| --- | --- |
| context<br><br>n. 上下文; 语境; 背景; 来龙去脉 | con-(与, 共同), **text(织, 编织)**<br>像把线共同织在一起, 前后文字也共同构成语境 |
| pretext<br><br>n. 借口; 托词<br>v. 以...为借口 | pre-(先于, 预先), **text(织, 编织)**<br>预先编造的话 |
| text<br><br>n. 课文; 本文; 正文 | **text(织, 编织)**<br>围绕“织”这一核心含义构成, 表示“课文” |
| textbook<br><br>n. 教科书; 课本 | **text(织, 编织)**, book(词: 书)<br>围绕“书”这一核心含义构成, 表示“教科书, 课本” |
| textile<br><br>n. 纺织品<br>adj. 纺织的 | **text(织, 编织)**, -ile(…的)<br>围绕“织”这一核心含义构成, 表示“纺织品” |
| texture<br><br>n. (织物的) 组织; 结构; 织物; (文章的) 结构 | **text(织, 编织)**, -ure(状态)<br>围绕“织”这一核心含义构成, 表示“(织物的) 组织, 结构” |
| contextual<br><br>adj. (按照) 上下文的 | context(词: 上下文), -ual(…的)<br>由“上下文”派生为当前词义 |
| textual<br><br>adj. 本文的; 正文的; 原文的 | **text(织, 编织)**, -ual(…的)<br>围绕“织”这一核心含义构成, 表示“本文的” |


### the(o)

神

| 单词 | 拆解 |
| --- | --- |
| atheism<br><br>n. 无神论 | a-(无, 不, 非), **the(神)**, -ism(主义)<br>否定或缺少“神”所指的性质, 因此表示“无神论” |
| atheist<br><br>n. 无神论者 | a-(无, 不, 非), **the(神)**, -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“无神论者” |
| pantheist<br><br>n. 泛神论者 | pan-(全, 总, 泛), **the(神)**, -ist(人)<br>认为神存在于万物之中的人, 即泛神论者; pan- 在此是‘全部’ |
| pantheon<br><br>n. 万神殿; 众神 | 源自希腊语 pan“全部”与 theos“神”<br>供奉全部神祇的神殿, 亦指众神 |
| theocracy<br><br>n. 神权政治; 僧侣政治 | **theo(神)**, **cracy(统治, 政体)**<br>由“神”与“统治”共同限定词义, 表示“神权政治” |
| theologian<br><br>n. 神学研究者; 神学家 | theology→theologi(词: 神学), -an(…的)<br>由“神学”派生为当前词义 |
| theology<br><br>n. 神学; 宗教理论 | **the(o)(神)**, -logy(…学, …研究)<br>研究神和宗教信仰理论的学科, 即神学 |
| theistic<br><br>adj. 有神论的 | **the(神)**, -istic(…的)<br>围绕“神”这一核心含义构成, 表示“有神论的” |


### therap(y)

治疗, 疗法

| 单词 | 拆解 |
| --- | --- |
| phototherapy<br><br>n. 光线疗法 | **photo(光)**, **therapy(治疗, 疗法)**<br>由“光”与“疗法”共同限定词义, 表示“光线疗法” |
| therapeutics<br><br>n. 治疗学 | **therapeut(治疗)**, -ics(…学)<br>研究治疗方法的学科, 即治疗学 |
| therapy<br><br>n. 治疗; 疗法; 治疗力; 治疗效果; 理疗 | **therapy(治疗, 疗法)**<br>核心义即治疗或疗法 |
| therapeutic(al)<br><br>adj. 治疗(学)的; 疗法的 | **therapeut(治疗)**, -ical(…的)<br>与治疗或疗法有关的 |


### therm(o)

热

| 单词 | 拆解 |
| --- | --- |
| hypothermia<br><br>n. 体温过低 | hypo-(在下, 低于), **therm(热)**, -ia(性质, 状态)<br>由“低于”与“温”共同限定词义, 表示“体温过低” |
| isotherm<br><br>n. 等温线; 恒温线 | iso-(相等, 相同), **therm(热)**<br>由“相等”与“温”共同限定词义, 表示“等温线, 恒温线” |
| thermal<br><br>adj. 热的; 热量的; 温泉的<br>n. 上升温暖气流 | **therm(热)**, -al(…的)<br>表示与“热”有关或具有该特征, 即“热量的” |
| thermogenesis<br><br>n. 生热(作用) | **thermo(热)**, **gen(出生, 产生)**, -esis(行为, 过程)<br>由“热”与“出生”共同限定词义, 表示“生热(作用)” |
| thermometer<br><br>n. 温度计; 寒暑表 | **thermo(热)**, **meter(测量器, 仪表)**<br>热+测量器, 即"温度计" |
| thermoluminescence<br><br>n. 热发光 | **thermo(热)**, **lumin(光, 照)**, -escence(开始或正在形成某种状态)<br>由“热”与“光”共同限定词义, 表示“热发光” |
| thermos<br><br>n. 热水瓶 | 20世纪取自希腊语 thermos“热的”, 后成为保温瓶商标及通名<br>记忆点是“保持热度的容器” |
| hydrothermal<br><br>adj. 热液的; 水热作用的 | **hydro(水)**, **therm(热)**, -al(…的)<br>由“水”与“热”共同限定词义, 表示“热液的, 水热作用的” |
| thermophilic<br><br>adj. 喜温的 | **thermo(热)**, **phil(爱)**, -ic(…的)<br>偏爱温热环境并在其中生长良好, 因此表示喜温的 |


### tim

怕

| 单词 | 拆解 |
| --- | --- |
| intimidate<br><br>v. 恐吓; 威胁 | in-(向内, 进入), **tim(怕)**, -id(…的), -ate(做, 使)<br>使心里害怕 |
| intimidation<br><br>n. 恫吓; 恐吓; 威胁 | intimidate→intimid(词: 恐吓), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“恫吓” |
| intimidator<br><br>n. 威吓者 | intimidate→intimid(词: 恐吓), -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“威吓者” |
| timidity<br><br>n. 胆怯; 怯懦; 羞怯 | timid(词: 胆小的), -ity(性质, 状态)<br>由“胆小的”派生为当前词义 |
| timid<br><br>adj. 胆怯的; 易受惊的; 胆小的; 羞怯的 | **tim(怕)**, -id(…的)<br>围绕“怕”这一核心含义构成, 表示“胆怯的, 易受惊的” |
| timorous<br><br>adj. 胆小的; 易受惊的; 畏怯的 | 源自拉丁语 timor“恐惧”加形容词后缀形成<br>表示胆怯、容易害怕的 |


### tir

拉, 引

| 单词 | 拆解 |
| --- | --- |
| retire<br><br>v. 引退; 退休; 退职; 撤退; 退却 | re-(回, 向后, 再次), **tir(拉, 引)**, e(连接字母)<br>把自己从工作或活动中向后拉开, 因此表示退休、退出 |
| tire<br><br>v. 疲劳; 累; 厌倦; 厌烦 | 使疲劳义与轮胎名词义具有不同历史发展<br>应按语境分别记忆 |
| attire<br><br>n. 服装; 盛装<br>v. 使穿衣; 打扮 | 源自古法语 atirier“装备、整理”, 与表示次序、排列的日耳曼语词相关<br>由给人装备整理发展为穿衣和服装 |
| retiree<br><br>n. 退休者; 退职者; 退役者 | retire→retir(词: 隐居), -ee(接受动作的人)<br>由“隐居”派生为当前词义 |
| retirement<br><br>n. 退休; 引退; 撤退 | retire(词: 退休), -ment(行为, 过程)<br>在前词基础上加“-ment”构成名词, 表示“退休” |
| tirade<br><br>n. 长篇的演说; 冗长的演说 | 源自法语 tirade（长篇激烈讲话）, 记忆锚点为持续不断的一大段言辞 |
| retired<br><br>adj. 退休的; 退职的 | retire→retir(词: 隐居), -ed(…的)<br>由“隐居”派生为当前词义 |
| tired<br><br>adj. 疲劳的; 累的; 厌倦的; 厌烦的 | tire→tir(词: 使疲劳), -ed(…的)<br>感到疲劳的, 也可表示厌倦的 |
| tiresome<br><br>adj. 使人疲劳的; 令人厌倦的; 讨厌的 | tire(词: 疲劳), -some(…的)<br>使人疲劳厌烦的 |
| tiring<br><br>adj. 引起疲劳的; 令人厌倦的 | tire→tir(词: 使疲劳), -ing(…的)<br>使人感到疲劳或厌倦的 |


### toler

忍受, 忍耐

| 单词 | 拆解 |
| --- | --- |
| tolerate<br><br>v. 忍受; 容忍; 宽恕; 默认; 有耐(药)力 | **toler(忍受, 忍耐)**, -ate(做, 使)<br>在前词基础上加“-ate”构成动词, 表示“忍受” |
| tolerability<br><br>n. 可忍性; 尚可 | **toler(忍受, 忍耐)**, -ability(可…性)<br>在前词基础上加“-ability”构成名词, 表示“可忍性” |
| tolerance<br><br>n. 宽容; 容忍; 耐受力; 公差容许偏差 | **toler(忍受, 忍耐)**, -ance(性质, 状态)<br>表示与“忍受”有关的性质或状态, 即“宽容” |
| toleration<br><br>n. 忍受; 容忍; 宽恕; 默认; 信仰自由 | **toler(忍受, 忍耐)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“忍受” |
| tolerable<br><br>adj. 可忍受的; 可容忍的; 可宽恕的; 尚可的; 过得去的 | **toler(忍受, 忍耐)**, -able(可…的)<br>围绕“忍受”这一核心含义构成, 表示“可忍受的” |
| tolerant<br><br>adj. 忍受的; 容忍的; 宽恕的; 有耐药力的 | **toler(忍受, 忍耐)**, -ant(…的)<br>在前词基础上加“-ant”构成形容词, 表示“忍受的” |


### tom(y)

切, 割

| 单词 | 拆解 |
| --- | --- |
| anatomy<br><br>n. 解剖; 解剖学; 剖析; 解析 | ana-(向上), **tom(切, 割)**, -y(活动)<br>切开“向上”的术式, 即“解剖, 解剖学, 剖析, 解析” |
| atom<br><br>n. 原子(较早期原子被误以为是不能再分的最小的物质) | a-(无, 不, 非), **tom(切, 割)**<br>不能再分割的 |
| atomics<br><br>n. 原子工艺学 | atom(词: 原子), -ics(…学)<br>在前词基础上加“-ics”构成名词, 表示“原子工艺学” |
| atomism<br><br>n. 原子论; 原子学说 | atom(词: 原子), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“原子论” |


### ton

音; 雷

| 单词 | 拆解 |
| --- | --- |
| intone<br><br>v. 发长音; 吟诵; 吟咏 | in-(向内, 进入), **ton(音)**, e(连接字母)<br>发音 |
| baritone<br><br>n. 男中音; 男中音歌手 | 借自意大利语 baritono, 源自希腊语 bary“重、低沉”与 tonos“音调”<br>音调低沉的男中音 |
| intonation<br><br>n. 语调; 音调 | in-(向内, 进入), **ton(音)**, -ation(行为, 结果)<br>给语句配上高低起伏的声调, 即语调 |
| monotony<br><br>n. 单音; 单调; 无变化 | 由希腊语 monos“单一”与 tonos“音调”构成<br>单一音调引申为单调乏味 |
| semitone<br><br>n. 半音 (休止) | semi-(半, 部分地), **ton(音)**, e(连接字母)<br>由“半”与“音”共同限定词义, 表示“半音 (休止)” |
| tonality<br><br>n. 音调 | **ton(音)**, -ality(性质, 状态)<br>表示与“音”有关的性质或状态, 即“音调” |
| tone<br><br>n. 音调, 声调; 语气, 腔调; 色调, 色彩; 风格, 基调; 紧致度<br>v. (使)更结实, 增强; 调和, 协调 | **ton, ston(音; 雷)**, e(连接字母)<br>原指琴弦拉紧发出的声音高低刻度, 引申指说话的语气腔调、光谱中颜色的深浅色调以及肌肉的紧致状态 |
| undertone<br><br>n. 低音; 小声 | under-(在下, 低于), **ton(音)**, e(连接字母)<br>由“低于”与“音”共同限定词义, 表示“低音” |
| atonal<br><br>adj. 无调的; 不成调的 | a-(无, 不, 非), **ton(音)**, -al(…的)<br>否定或缺少“音”所指的性质, 因此表示“无调的” |
| diatonic<br><br>adj. 全音阶的 | dia-(通过, 穿过), **ton(音)**, -ic(…的)<br>由“通过”与“音”共同限定词义, 表示“全音阶的” |
| monotonous<br><br>adj. 单 (音) 调的 | mono-(单一, 独), **ton(音)**, -ous(…的)<br>由“单一”与“音”共同限定词义, 表示“单 (音) 调的” |


### torp

麻木

| 单词 | 拆解 |
| --- | --- |
| torpor<br><br>n. 麻痹; 麻木; 迟钝; 蛰伏 | 源自拉丁语 torpor“麻木、迟钝”<br>表示活动和反应显著降低的状态 |
| torpid<br><br>adj. 麻痹的; 麻木的; 呆钝的; 迟钝的; 蛰伏的 | **torp(麻木)**, -id(…的)<br>围绕“麻木”这一核心含义构成, 表示“麻痹的” |


### tort, tors

扭

| 单词 | 拆解 |
| --- | --- |
| contort<br><br>v. 扭弯; 扭歪; 曲解 | con-(与, 共同), **tort(扭)**<br>使“扭”共同结合或发挥作用, 因此表示“扭弯” |
| extort<br><br>v. 强取; 逼取; 敲诈; 勒索 | ex-(出, 向外), **tort(扭)**<br>扭走 |
| contortion<br><br>n. 扭弯; 扭歪; 曲解 | contort(词: 扭弯), -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“扭弯” |
| contortionist<br><br>n. 善做柔体表演的杂技演员 | contortion(词: 扭弯), -ist(人)<br>由“扭弯”派生为当前词义 |
| distortion<br><br>n. 弄歪(嘴; 脸等) | dis-(否定, 相反), **tort(扭)**, -ion(行为, 结果)<br>扭离正形 |
| torment<br><br>n. 使人痛苦的东西; 折磨者; 苦痛<br>v. 使苦恼; 纠缠; 歪曲 | 经古法语借自拉丁语 tormentum“扭转装置、刑具”, 与 torquere“扭”同源<br>由刑具引申为折磨和痛苦 |
| torsion<br><br>n. 扭转; 扭力 | **tors(扭)**, -ion(行为, 结果)<br>围绕“扭”这一核心含义构成, 表示“扭转” |
| torso<br><br>n. (人体的)躯干 | 源自意大利语 torso（躯干）, 记忆锚点是去掉头和四肢后保留的身体主体 |
| torture<br><br>n. 折磨; 酷刑<br>v. 折磨; 拷打 | **tort(扭)**, -ure(行为, 结果)<br>围绕“扭”这一核心含义构成, 表示“拷打, 折磨, (使)痛苦” |
| torturer<br><br>n. 拷问者; 虐待者 | torture→tortur(词: 拷问), -er(人)<br>由“拷问”派生为当前词义 |
| tortuous<br><br>adj. 弯弯曲曲的; 拐弯抹角的 | **tort(扭)**, -uous(…的)<br>围绕“扭”这一核心含义构成, 表示“弯弯曲曲的” |


### tour, tor

转, 巡回

| 单词 | 拆解 |
| --- | --- |
| contour<br><br>n. 轮廓<br>v. 画轮廓<br>adj. 显示轮廓的 | con-(与, 共同), **tour(转, 巡回)**<br>沿物体周围转行所勾勒的线, 即轮廓、外形 |
| detour<br><br>n. 绕路; 迂回<br>v. 绕道 | de-(脱离, 取消, 除去), tour(词: 行程)<br>离开原定行程绕行, 即绕道 |
| tour<br><br>n. 旅游; 观光旅行; 任期<br>v. 旅行; 周游; 巡回 | **tour(转, 巡回)**<br>到处转悠 |
| tourer<br><br>n. 旅游车 | **tour(转, 巡回)**, -er(物)<br>用于长途旅行的车辆 |
| touring<br><br>n. 游览<br>adj. 游览的 | **tour(转, 巡回)**, -ing(行为, 过程)<br>在前词基础上加“-ing”构成名词或形容词, 表示“游览” |
| tourism<br><br>n. 旅游业; 观光业 | 由 tour“旅行、巡游”形成 tourism<br>旅行活动及其行业, 即旅游业 |
| tourist<br><br>n. 旅行者; 游客 | **tour(转, 巡回)**, -ist(人)<br>在前词基础上加“-ist”构成名词, 表示“旅游者” |
| torrent<br><br>n. 激流, 洪流 | 源自拉丁语 torrens（奔流的、沸腾的）, 表示急流 |


### tox(i)

毒

| 单词 | 拆解 |
| --- | --- |
| detoxify<br><br>v. 解毒 | 由 de“去除”、toxic“毒”与 fy“使成”构成<br>去除毒性 |
| antitoxin<br><br>n. 抗毒素(血清) | anti-(反对, 相反), **tox(毒)**, -in(…素)<br>由“反对”与“毒”与“…素”构成相关物质名称, 即“抗毒素(血清)” |
| detoxification<br><br>n. 解毒 | de-(脱离, 取消, 除去), **toxi(毒)**, -fication(…化, 做…)<br>把有毒物质除去或转为无毒的过程, 即解毒 |
| endotoxin<br><br>n. 内毒素 | endo-(在内, 内部), **tox(毒)**, -in(…素)<br>由“在内”与“毒”共同限定词义, 表示“内毒素” |
| toxaemia<br><br>n. 毒血症; 血中毒症 | **tox(毒)**, **aem(血)**, -ia(性质, 状态)<br>由“毒”与“血”共同限定词义, 表示“毒血症” |
| toxicity<br><br>n. 毒性; 毒力 | **tox(毒)**, -icity(性质, 状态)<br>围绕“毒”这一核心含义构成, 表示“毒性, 毒力” |
| toxicology<br><br>n. 毒理学; 毒物学 | 由 toxico“毒物”与 logy“研究”构成<br>研究毒物及其作用的学科 |
| toxoid<br><br>n. 类毒素 | **tox(毒)**, -oid(似…的（物）)<br>形状像“毒”, 即“类毒素” |
| neurotoxic<br><br>adj. 毒害神经的 | **neuro(神经)**, **tox(毒)**, -ic(…的)<br>由“神经”与“毒”共同限定词义, 表示“毒害神经的” |
| toxic<br><br>adj. 有毒的 | **tox(毒)**, -ic(…的)<br>表示与“毒”有关或具有该特征, 即“有毒的” |


### tract

拖, 引

| 单词 | 拆解 |
| --- | --- |
| subtract<br><br>v. 减; 减去; 去掉 | sub-(在下, 向下), **tract(拖, 引)**<br>从整体下面抽走一部分, 因此表示减去、扣除 |
| attraction<br><br>n. 吸引(力); 有吸引力的事物(或人); 具有吸引力的事物 | at-(到, 朝, 向), **tract(拖, 引)**, -ion(行为, 结果)<br>把人或物拉向某处的作用, 因此表示吸引、吸引力 |
| attractor<br><br>n. 有吸引力的人(或物) | attract(词: 吸引), -or(物)<br>产生吸引作用的人或事物, 构词核心为吸引物 |
| contract<br><br>n. 合同; 契约<br>v. 收缩; 感染; 订立合同 | con-(与, 共同), **tract(拖, 引)**<br>双方共同拉拢约定, 即"合同" |
| contraction<br><br>n. 订约; 收缩 | contract(词: 订约), -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“订约” |
| distract<br><br>n. 转移(注意力); 使分心<br>v. 分散(注意力); 使(人)分心; 弄昏; 迷惑 | dis-(否定, 相反), **tract(拖, 引)**<br>把注意力引开 |
| extractor<br><br>n. 提取者; 抽出器 | extract(词: 提取), -or(人)<br>在前词基础上加“-or”构成名词, 表示“提取者” |
| retraction<br><br>n. 缩回; 收回; 撤回 | re-(回, 向后, 再次), **tract(拖, 引)**, -ion(行为, 结果)<br>把伸出之物向后拉回, 因此表示缩回、撤回 |
| traction<br><br>n. 拖; 牵引; 牵引力 | **tract(拖, 引)**, -ion(行为, 结果)<br>围绕“拖”这一核心含义构成, 表示“拖, 牵引” |
| extractable<br><br>adj. 可抽出的 | ex-(出, 向外), **tract(拖, 引)**, -able(可…的)<br>能够从内部向外拉出, 因此表示可抽取的 |
| tractable<br><br>adj. 温顺的; 易管教的 | **tract(拖, 引)**, -able(可…的)<br>易拉拢的 |


### trem

颤抖

| 单词 | 拆解 |
| --- | --- |
| tremble<br><br>v. 发抖; 摇晃<br>n. 战栗; 颤抖 | 核心意象是身体不由自主地快速轻微抖动, 由此表示发抖、哆嗦或震颤 |
| trembling<br><br>adj. 发抖的; 战栗的 | 词形来源：tremble + ing-form |
| tremolo<br><br>n. 震音(装置) | 借自意大利语 tremolo“颤动的”, 与 tremare“颤抖”相关<br>音乐中的震音效果 |
| tremor<br><br>n. 震颤; 颤抖; 震动; 战栗 | 源自拉丁语 tremor“颤抖”<br>表示轻微震动或身体颤抖 |
| tremendous<br><br>adj. 可怕的; 极大的; 非常的; 巨大的 | **trem(颤抖)**, -end(应被…的), -ous(…的)<br>令人颤抖的 |
| tremulous<br><br>adj. 震颤的; 发抖的; 胆小的; 动摇的; 不稳定的 | **trem(颤抖)**, -ulous(…的)<br>围绕“颤抖”这一核心含义构成, 表示“震颤的, 发抖的” |


### tribut

给, 献

| 单词 | 拆解 |
| --- | --- |
| contribute<br><br>v. 贡献; 捐献; 促成; 撰稿 | con-(与, 共同), **tribut(给, 献)**, e(连接字母)<br>共同向某事投入资源或努力, 即贡献、促成 |
| attribute<br><br>n. 属性; 特质<br>v. 认为甲是因为乙; 把甲的原因归于乙 | at-(到, 朝, 向), **tribut(给, 献)**, e(连接字母)<br>把某种性质或原因给予某人某物, 因此表示归因、属性 |
| contribution<br><br>n. 贡献(物) | con-(与, 共同), **tribut(给, 献)**, -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“贡献” |
| contributory<br><br>adj. 贡献的; 捐助的<br>n. 贡献者; 捐助者 | contribute→contribut(词: 捐助), -ory(…的)<br>在前词基础上加“-ory”构成名词或形容词, 表示“贡献的, 捐助的, 应捐助的, 起一份作用的” |
| distribution<br><br>n. 分发; 分配; 分布 | dis-(分离, 除去), **tribut(给, 献)**, -ion(行为, 结果)<br>把事物分开给予不同对象的过程, 即分配或分布 |
| distributor<br><br>n. 分发者; 分配者; 散布者; 分配器 | distribute→distribut(词: 分配), -or(人)<br>负责分配的人或机构; 也可引申指分配装置 |
| tributary<br><br>adj. 支流的; 纳贡的; 从属的<br>n. 支流; 纳贡者; 属国 | **tribut(给, 献)**, -ary(…的)<br>围绕“给”这一核心含义构成, 表示“进贡的, 纳贡的, (河)支流的” |
| tribute<br><br>n. 颂词; 致敬; 贡物; 贡品; 证明 | **tribut(给, 献)**, e(连接字母)<br>向权威献上的贡物, 也可表示敬意 |
| attributive<br><br>adj. 归属的; 属性的; 定语的 | attribute→attribut(词: 属性), -ive(…的)<br>由“属性”派生为当前词义 |
| distributable<br><br>adj. 可分发的; 可分成类的 | dis-(否定, 相反), **tribut(给, 献)**, -able(可…的)<br>由“分离”与“给”共同限定词义, 表示“可分发的, 可分成类的” |


### trop

转

| 单词 | 拆解 |
| --- | --- |
| tropic<br><br>n. 回归线 | **trop(转)**, -ic(…的)<br>太阳到此往回转 |
| tropical<br><br>adj. 热带的; 位于回归线之间的 | **trop, stroph(转)**, -ic(…的), -al(…的)<br>太阳直射点在此发生转向的回归线区域, 即热带 |
| entropy<br><br>n. 熵; (系统的)混乱程度 | en-(在...内, 进入...之中), **trop, stroph(转)**, -y(性质, 状态)<br>物理系统中能量转化及混乱度量 |


### tru, trust

信任, 忠诚

| 单词 | 拆解 |
| --- | --- |
| truism<br><br>n. 自明之理; 不言而喻的话 | 由 true“真实、自明”形成 truism<br>真实到无需论证的陈述, 即不言自明的话 |
| trust<br><br>n. 信任; 信托; 托拉斯<br>v. 信任; 相信 | **trust(信任, 忠诚)**<br>核心义为信任, 也可转化作动词表示托付、信赖 |
| true<br><br>adj. 真实的; 真正的; 忠实的; 精准的<br>adv. 笔直地; 正确地 | **tru(信任, 忠诚)**, e(连接字母)<br>围绕“忠诚”这一核心含义构成, 表示“真的, 真实的, 确实的, 忠实的, 忠诚的” |


### trud, trus

推, 冲

| 单词 | 拆解 |
| --- | --- |
| extrude<br><br>v. 逐出; 赶走; 挤压出; 喷出 | ex-(出, 向外), **trud(推, 冲)**, e(连接字母)<br>把材料向外推出, 因此表示挤出; 也可表示逐出 |
| intrude<br><br>v. 侵入; 入侵; 闯入; 侵扰 | in-(向内, 进入), **trud(推, 冲)**, e(连接字母)<br>由“进入”与“推”共同限定词义, 表示“侵入, 入侵” |
| protrude<br><br>v. 使伸出; 使突出 | pro-(向前, 前进), **trud(推, 冲)**, e(连接字母)<br>向前推 |
| extruder<br><br>n. 挤压机 | extrude→extrud(词: 挤出), -er(物)<br>由“挤出”派生为当前词义 |
| extrusion<br><br>n. 逐出; 挤压; 喷出 | ex-(出, 向外), **trus(推, 冲)**, -ion(行为, 结果)<br>把材料向外挤出的过程, 即挤出、突出 |
| intruder<br><br>n. 入侵者; 闯入者 | intrude→intrud(词: 闯入), -er(人)<br>由“闯入”派生为当前词义 |
| intrusion<br><br>n. 侵入; 闯入; 侵犯; 侵扰性的事物; 占用 | in-(向内, 进入), **trus(推, 冲)**, -ion(行为, 结果)<br>向内推挤冲入的行为, 即侵入 |
| protrusion<br><br>n. 伸出; 突出; 突出部分 | 与 protrude“向前伸出”同源, 源自拉丁语 protrudere<br>突出或突出部分 |
| intrusive<br><br>adj. 入侵的; 闯入的 | 与 intrude“闯入”同源, 源自拉丁语 intrudere<br>未经允许进入或强加的 |


### tum(e)

肿

| 单词 | 拆解 |
| --- | --- |
| tumescent<br><br>adj. 略为肿大的, 稍许肿胀的 | **tum(肿)**, -escent(开始或正在形成…的)<br>在前词基础上加“-escent”构成形容词, 表示“略为肿大的, 稍许肿胀的” |
| tumo(u)r<br><br>n. 肿瘤; 肿块; 赘生物 | 源自拉丁语 tumor“肿胀”<br>表示异常肿块; 英式拼作 tumour, 美式拼作 tumor |
| tummy<br><br>n. 肚子 | 19世纪英语儿童或口语形式, 由 stomach 的非正式变体发展, 具体缩合路径不确定<br>作为本土口语表示肚子 |
| tumulus<br><br>n. 冢, 古坟 | 直接借自拉丁语 tumulus“土堆、坟冢”<br>覆盖古墓的土丘 |


### turb(o)

混乱, 骚动; 旋转, 漩涡

| 单词 | 拆解 |
| --- | --- |
| perturb<br><br>v. 使紊乱; 扰乱; 烦扰 | per-(通过, 贯穿), **turb(混乱, 骚动)**<br>由“通过”与“混乱”共同限定词义, 表示“使紊乱, 扰乱” |
| perturbation<br><br>n. 紊乱; 扰乱; 不安; 烦扰 | 源自拉丁语 perturbatio“扰乱”, 与 perturb 同源<br>扰动、焦虑或轨道摄动 |
| turbulence<br><br>n. 骚动; 骚乱; 汹涌; 狂暴 | **turb(混乱, 骚动)**, -ulence(性质, 状态)<br>围绕“混乱”这一核心含义构成, 表示“骚动, 骚乱” |
| turbine<br><br>n. 透平(机); 叶轮机; 汽轮(机); 涡轮(机) | 源自拉丁语 turbo“旋转物、漩涡”<br>利用旋转叶轮转换流体能量的机器, 即涡轮机 |
| turbojet<br><br>n. 涡轮喷气发动机; 涡轮喷气飞机 | turbo(词: 涡轮增压器), jet(词: 喷气发动机)<br>由涡轮驱动压气机的喷气发动机 |
| turboprop<br><br>n. 涡轮螺旋桨发动机 | 由 turbo“涡轮”与 propeller“螺旋桨”截短合成<br>以燃气涡轮驱动螺旋桨的发动机 |
| perturbative<br><br>adj. 扰乱性的; 烦扰性的 | perturb(词: 扰乱), -ative(…的)<br>在前词基础上加“-ative”构成形容词, 表示“扰乱性的” |
| turbid<br><br>adj. 混浊的; 污浊的; 混乱的 | **turb(混乱, 骚动)**, -id(…的)<br>围绕“混乱”这一核心含义构成, 表示“混浊的, 污浊的” |
| turbulent<br><br>adj. 动荡混乱的; 汹涌狂暴的; 骚乱的 | **turb(混乱, 骚动)**, -ulent(多…的, 充满…的)<br>在前词基础上加“-ulent”构成形容词, 表示“骚动的” |
| undisturbed<br><br>adj. 没受干扰的 | un-(无, 不, 非), disturb(词: 打扰), -ed(…的)<br>未受打扰的 |


### turg

肿

| 单词 | 拆解 |
| --- | --- |
| turgid<br><br>adj. 肿胀的; 浮肿的; 饱满的; 华而不实的 | **turg(肿)**, -id(…的)<br>围绕“肿”这一核心含义构成, 表示“肿胀的, 浮肿的” |
| turgor<br><br>n. 膨胀度; 充盈 | **turg(肿)**, -or(状态)<br>植物细胞因充满水分而表现出的膨胀充盈状态 |


### tut, tuit

监视, 看管

| 单词 | 拆解 |
| --- | --- |
| intuit<br><br>v. 直观; 由直觉知道 | in-(向内, 进入), **tuit(监视, 看管)**<br>直接由视觉获得 |
| intuition<br><br>n. 直观; 直觉; 直觉到的事物 | intuit(词: 由直觉知道), -ion(行为, 结果)<br>无需有意识推理而直接知道的过程或能力 |
| tutelage<br><br>n. 监护; 保护; 指导; 辅导 | 源自拉丁语 tutela“保护、监护”<br>表示处于他人保护、监护或指导之下 |
| tutor<br><br>n. 家庭教师; 指导教师; 监护人; （英国大学或学院中的）导师<br>v. 辅导; 指导 | **tut(监视, 看管)**, -or(人)<br>原指负责看护、指导的人, 即导师; 名词转化为动词后表示辅导 |
| tutorial<br><br>adj. 导师的; 辅导的<br>n. 辅导课; 指导期 | tutor(词: 家庭教师), -ial(…的)<br>由“家庭教师”派生为当前词义 |
| tutorship<br><br>n. 家庭教师 (或指导教师; 监护人等) 的地位 (或职位; 权力) | tutor(词: 家庭教师), -ship(性质, 状态)<br>在前词基础上加“-ship”构成名词, 表示“家庭教师” |
| intuitive<br><br>adj. 直觉的; 直观的 | intuit(词: 由直觉知道), -ive(…的)<br>依靠直觉即可理解或操作的 |


### typ(o)

类型, 典型; 印, 模型

| 单词 | 拆解 |
| --- | --- |
| typify<br><br>v. 作为...的典型; 代表; 象征 | **typ(类型, 典型)**, -ify(…化, 做…)<br>围绕“典型”这一核心含义构成, 表示“作为...的典型, 代表” |
| prototype<br><br>n. 原型机; 样品; 雏形 | **proto(第一, 原始)**, type(词: 类型)<br>最早制成、供后续版本参考的原型 |
| type<br><br>n. 类型; 典型; 印刷字体<br>v. 打字; 测定血型 | **typ(类型, 典型)**, e(连接字母)<br>词根本身即表示“类型”, 整词沿用该义 |
| typer<br><br>n. 打字员 | **typ(印, 模型)**, -er(人)<br>在前词基础上加“-er”构成名词, 表示“打字员” |
| typewriter<br><br>n. 打字机 | type(词: 打字), writer(词: 书写器具)<br>用于打字书写的机器 |
| typing<br><br>n. 打字; 打字术; 打字工作; 打字稿 | **typ(印, 模型)**, -ing(行为, 过程)<br>围绕“打字”这一核心含义构成, 表示“打字” |
| typist<br><br>n. 打字者; 打字员 | **typ(印, 模型)**, -ist(人)<br>表示从事或具有“打字”特征的人, 即“打字者” |
| typography<br><br>n. (活版) 印刷术; 排印 | **typo(类型, 典型)**, **graph(写, 画)**, -y(活动)<br>记录或描绘“类型”的方法, 即“(活版) 印刷术” |
| typoscript<br><br>n. 打字稿; 打字文件 | **typo(类型, 典型)**, **script(写)**<br>用打字方式写成的稿件, 即打字稿 |
| typical<br><br>adj. 典型的; 代表性的; 象征性的 | **typ(类型, 典型)**, -ical(…的)<br>表示与“典型”有关或具有该特征, 即“典型的, 代表性的” |
