## oyword-root-x


### xanth(o)

黄

| 单词 | 拆解 |
| --- | --- |
| xanthine<br><br>n. 黄质; 黄嘌呤 | **xanth(黄)**, -ine(…的)<br>围绕“黄”这一核心含义构成, 表示“黄质” |
| xanthophyl(l)<br><br>n. 叶黄素 | **xantho(黄)**, **phyll(叶)**<br>围绕“黄”这一核心含义构成, 表示“叶黄素” |


### xen(o)

异

| 单词 | 拆解 |
| --- | --- |
| xenia<br><br>n. 种子直感; 异粉性 | **xen(异)**, -ia(性质, 状态)<br>围绕“异”这一核心含义构成, 表示“种子直感” |
| xenograft<br><br>n. 异种皮移植 | **xeno(异)**, graft(词: 移植)<br>由“异”与“移植”共同限定词义, 表示“异种皮移植” |
| xenophobe<br><br>n. 畏惧和憎恨外国人(或事物)的人 | **xeno(异)**, **phob(怕, 厌恶)**, e(连接字母)<br>对“异”产生强烈恐惧或厌恶, 即“畏惧和憎恨外国人(或事物)的人” |
| xenophobia<br><br>n. 对外国人(或事物)的畏惧和憎恨 | 由 xeno“外国人、陌生者”与 phobia“恐惧”构成<br>对外国人或陌生事物的恐惧排斥 |
| xenophobic<br><br>adj. 畏惧和憎恨外国人(或事物)的 | xenophobia→xenophob(词: 无端畏惧和憎恨外国人), -ic(…的)<br>在前词基础上加“-ic”构成形容词, 表示“畏惧和憎恨外国人的” |


### xer(o)

干燥

| 单词 | 拆解 |
| --- | --- |
| xeric<br><br>adj. 缺乏维持生命的水分的; 沙漠的; 干旱的; 旱生植物的 | **xer(干燥)**, -ic(…的)<br>表示与“干燥”有关或具有该特征, 即“缺乏维持生命的水分的, 沙漠的, 干旱的” |
| xerophyte<br><br>n. 旱生植物 | **xer(o)(干燥)**, **phyt(o)(植物)**<br>适应干旱缺水恶劣环境生长的植物 |


### xiph(i), xiph(o)

剑

| 单词 | 拆解 |
| --- | --- |
| xiphoid<br><br>n. 剑突<br>adj. 剑状的 | **xiph(i), xiph(o)(剑)**, -oid(似…的（物）)<br>形状扁薄如剑刃前端的软骨骨质突起, 特指胸骨最下端的剑突 |
| xiphoiditis<br><br>n. 剑突炎 | **xiph(i), xiph(o)(剑)**, -oid(似…的（物）), -itis(…炎)<br>胸骨剑突软骨部位发生的发炎疼痛 |


### xyl(o)

木

| 单词 | 拆解 |
| --- | --- |
| xylophone<br><br>n. 木琴 | **xylo(木)**, **phon(声音)**, e(连接字母)<br>木制的发音器 |
| xylose<br><br>n. [化]木糖 | **xyl(木)**, -ose(糖)<br>围绕“木”这一核心含义构成, 表示“木糖” |
