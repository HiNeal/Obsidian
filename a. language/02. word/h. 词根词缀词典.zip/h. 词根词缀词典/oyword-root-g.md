## oyword-root-g


### gam(o)

结合, 婚姻

| 单词 | 拆解 |
| --- | --- |
| polygamy<br><br>n. 多配偶; 一夫多妻; 一妻多夫 | poly-(多, 复), **gam(结合, 婚姻)**, -y(活动)<br>由“多”与“婚姻”共同限定词义, 表示“多配偶” |
| monogamous<br><br>adj. 一夫一妻制的 | mono-(单一, 独), **gam(结合, 婚姻)**, -ous(…的)<br>由“单一”与“婚姻”共同限定词义, 表示“一夫一妻制的” |


### gastr(o)

胃, 腹

| 单词 | 拆解 |
| --- | --- |
| gastrectomy<br><br>n. 胃切开术 | 由 gastr“胃”与 ectomy“切除术”构成<br>胃的部分或全部切除术 |
| gastritis<br><br>n. 胃炎 | **gastr(胃, 腹)**, -itis(…炎)<br>“胃”发生炎症, 即“胃炎” |
| gastronomy<br><br>n. 美食法; 烹调法 | **gastro(胃, 腹)**, **nomy(法则, 管理)**<br>研究吃的方法 |


### ge(o)

地

| 单词 | 拆解 |
| --- | --- |
| apogee<br><br>n. [天] 远地点 | 经法语或现代拉丁语借自希腊语 apogaion, 由 apo“远离”与 ge“地球”构成<br>原指离地球最远点, 引申为顶峰 |
| geographer<br><br>n. 地理学家 | **geo(地)**, **graph(写, 画)**, -er(人)<br>记录或描绘“地”的方法, 即“地理学家” |
| geography<br><br>n. 地理 (学) | **geo(地)**, **graph(写, 画)**, -y(活动)<br>对地球的描述 |
| geology<br><br>n. 地质; 地质学 | **geo(地)**, -logy(…学, …研究)<br>以“地”为研究对象的学科, 即“地质学” |
| geologist<br><br>n. 地质学者 | **geo(地)**, -logist(…学家)<br>在前词基础上加“-logist”构成名词, 表示“地质学者” |
| geometry<br><br>n. 几何形状; 几何图形; 几何(学); 几何结构 | **geo(地)**, **metr(测量)**, -y(活动)<br>原指测量土地, 后来发展为研究空间形状的几何学 |
| geomorphology<br><br>n. 地貌学 | **geo(地)**, **morpho(形)**, -logy(…学, …研究)<br>研究地表形态及其形成过程的学科, 即地貌学 |
| geoscience<br><br>n. 地球科学 | **geo(地)**, science(词: 科学)<br>研究地球系统的科学 |
| geothermal<br><br>adj. 地热的; 地温的 | **geo(地)**, **therm(热)**, -al(…的)<br>由“地”与“热”共同限定词义, 表示“地热的” |


### gen, gener, germ

出生, 产生; 族, 种类

| 单词 | 拆解 |
| --- | --- |
| generate<br><br>n. 产生; 一代人)<br>v. 产生; 引起 (generation | **gener(出生, 产生)**, -ate(做, 使)<br>使新的事物产生出来 |
| germinate<br><br>v. 发芽; 开始生长 | 源自拉丁语 germinare“发芽、萌生”, 核心 germen 意为“芽、胚”<br>种子长出最初的幼芽, 引申指想法萌生 |
| abiogenesis<br><br>n. 自然发生; 无生源说 | a-(无, 不, 非), **bio(生命, 生物)**, **gen(出生, 产生)**, -esis(行为, 过程)<br>以“生命、出生”为语义核心构成, 表示“自然发生” |
| eugenics<br><br>n. 优生学 | eu-(良好, 优美), **gen(出生, 产生)**, -ics(…学)<br>以“优美、出生”为研究对象的学科, 即“优生学” |
| gene<br><br>n. 基因 | **gene(出生, 产生)**<br>围绕“出生”这一核心含义构成, 表示“基因” |
| generation<br><br>n. 生殖; 产生; 一代; —代（约 20至 30年） | **gener(出生, 产生)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“生殖” |
| genesis<br><br>n. 起源; 发生; 创始 | **gen(出生, 产生)**, -esis(行为, 过程)<br>围绕“出生”这一核心含义构成, 表示“起源” |
| genetics<br><br>n. [复] 遗传学 | 20 世纪初由希腊语 genesis（产生、起源）造出, 指研究遗传的学科 |
| genius<br><br>n. 天才; 天赋; 天资 | **gen(出生, 产生)**, i(连接字母), -us(名词词尾)<br>原指与生俱来的守护精神, 后来表示天赋、天才 |
| germ<br><br>n. 细菌; 微生物 | **germ(出生, 产生)**<br>围绕“出生”这一核心含义构成, 表示“细菌, 病菌” |
| miscegenation<br><br>n. 人种混杂; 混血 | **misc(混杂, 混合)**, e(连接字母), **gen(出生, 产生)**, -ation(行为, 结果)<br>由“混杂”与“种类”共同限定词义, 表示“人种混杂, 混血” |
| pathogen<br><br>n. 病原体 | **patho(疾病, 疗法)**, **gen(出生, 产生)**<br>产生疾病的生物或因子, 即病原体 |
| autogenous<br><br>adj. 自然发生的; 自体发生的 | auto-(自己, 自动), **gen(出生, 产生)**, -ous(…的)<br>由“自己”与“出生”共同限定词义, 表示“自然发生的, 自体发生的” |
| congenial<br><br>adj. 同族的; 同类的; 意气相投的; 令人愉快的 | con-(与, 共同), **gen(出生, 产生)**, -ial(…的)<br>使“种类”共同结合或发挥作用, 因此表示“同族的, 同类的” |
| congenital<br><br>adj. 先天的; 与生俱来的 | 源自拉丁语 congenitus“与生俱来的”<br>表示出生时已经存在的 |
| genial<br><br>adj. 亲切的; 温和的 | **gen(出生, 产生)**, -ial(…的)<br>性情好的 |
| genuine<br><br>adj. 真诚的; 真正的 | **gen(出生, 产生)**, u(连接字母), -ine(…的)<br>天生就有的 |
| heterogeneous<br><br>adj. 异族的; 异类的 | hetero-(不同, 异类), **gen(出生, 产生)**, -eous(…的)<br>由“异类”与“种类”共同限定词义, 表示“异族的, 异类的” |
| indigenous<br><br>adj. 本土的; 土生的 | 源自拉丁语 indigena（本地出生者）, 表示本土的、原生的 |
| ingenious<br><br>adj. 机灵的; 巧妙的 | in-(向内, 进入), **gen(出生, 产生)**, -ious(…的)<br>仿佛才智与生俱来并能产生巧思的, 即聪明、有创意的 |
| ingenuous<br><br>adj. 坦率的; 天真的 | in-(向内, 进入), **gen(出生, 产生)**, u(连接字母), -ous(…的)<br>保有出生时未经掩饰的自然状态, 即坦率、天真的 |


### ger, gest

做, 管理; 携带, 承担

| 单词 | 拆解 |
| --- | --- |
| congest<br><br>v. 充满; 拥挤 | con-(与, 共同), **gest(携带, 承担)**<br>把太多事物带到一起而塞满, 因此表示拥挤、充满 |
| exaggerate<br><br>v. 夸张; 夸大 | ex-(出, 向外), ag-(到, 朝, 向), **ger(携带, 承担)**, -ate(做, 使)<br>原指把土堆高, 后来比喻把事实说得过大, 即夸张 |
| suggest<br><br>v. 建议; 暗示 | sug-(在下, 向下), **gest(携带, 承担)**<br>含蓄地传递信息 |
| exaggeration<br><br>n. 夸大; 夸张 | exaggerate→exaggerat(词: 夸大), -ion(行为, 结果)<br>把程度说得过大的行为 |
| gesture<br><br>n. 手势; 姿势; (外交等方面的) 姿态; 表示 | **gest(携带, 承担)**, -ure(行为, 结果)<br>围绕“携带”这一核心含义构成, 表示“手势, 姿势” |
| belligerent<br><br>adj. 好战的 | **bell(战斗, 战争)**, i(连接字母), **ger(携带, 承担)**, -ent(…的)<br>把战争带向他人, 因此表示好战的、交战的 |


### glaci

冰

| 单词 | 拆解 |
| --- | --- |
| glacier<br><br>n. 冰河, 冰川 | 经法语 glacier 进入英语, 核心来自 glace“冰”<br>指长期积累并缓慢流动的大型冰体 |
| glaciology<br><br>n. 冰河学; 冰川学; 冰河特征 | **glaci(冰)**, o(连接元音), -logy(…学, …研究)<br>以“冰”为研究对象的学科, 即“冰河学, 冰川学” |
| glacial<br><br>adj. 冰的; 冰状的; 冰河的 | **glaci(冰)**, -al(…的)<br>与冰相关的, 即"冰川的" |
| postglacial<br><br>adj. 冰河后期的 | post-(在后, 之后), **glaci(冰)**, -al(…的)<br>由“在后”与“冰”共同限定词义, 表示“冰河后期的” |
| subglacial<br><br>adj. 冰川下的; 冰河下的 | sub-(在下, 向下), **glaci(冰)**, -al(…的)<br>由“在下”与“冰”共同限定词义, 表示“冰川下的, 冰河下的” |


### gloss, glot

舌, 语言

| 单词 | 拆解 |
| --- | --- |
| epiglottis<br><br>n. 舌根软骨; 会厌 | epi-(在...上, 覆盖, 在...旁, 靠近), **glot(舌, 语言)**, t(连接字母), -is(性质, 状态)<br>位于声门上方、吞咽时覆盖声门的软骨, 即会厌 |
| glossary<br><br>n. 词汇表; 术语 (或特殊用语汇编) | **gloss(舌, 语言)**, -ary(物)<br>汇集专门词语及解释的表, 即词汇表 |
| glottis<br><br>n. 声门 | 源自希腊语 glottis, 来自 glotta“舌”<br>喉部声带之间的声门 |
| polyglot<br><br>n. 使用多种语言的人; 多种文字对照本<br>adj. 多种语言的; 多种文字对照的 | poly-(多, 复), **glot(舌, 语言)**<br>由“多”与“语言”共同限定词义, 表示“多种语言的” |
| glottal<br><br>adj. 声门的 | **glot(舌, 语言)**, t(连接字母), -al(…的)<br>表示与“舌”有关或具有该特征, 即“声门的” |
| hypoglossal<br><br>adj. 舌下的 | hypo-(在下, 低于), **gloss(舌, 语言)**, -al(…的)<br>由“在下”与“舌”共同限定词义, 表示“舌下的” |


### gn, gnor, gnos

知道, 了解

| 单词 | 拆解 |
| --- | --- |
| diagnose<br><br>v. 诊断; 判断 | dia-(通过, 穿过), **gnos(知道, 了解)**, e(连接字母)<br>通过症状深入辨认疾病, 因此表示诊断 |
| ignore<br><br>v. 忽视; 不理睬 | i-(无, 不, 非), **gnor(知道, 了解)**, e(连接字母)<br>否定或缺少“知道”所指的性质, 因此表示“忽视, 不理睬” |
| recognize<br><br>v. 认识; 承认 | re-(回, 向后, 再次), **cogn(知道)**, -ize(…化, 使成)<br>再次知道并确认某对象, 即认出或承认 |
| cognition<br><br>n. 识; 认识力; 认识的结果 | **cogn(知道)**, -ition(行为, 结果)<br>知道、认识和处理信息的过程 |
| cognizance<br><br>n. 识; 察知; 审理 | **cogn(知道)**, -iz(…化, 使成), -ance(性质, 状态)<br>形成认识和知晓的状态 |
| prognosis<br><br>n. 预知 | pro-(向前, 前进), **gnos(知道, 了解)**, -is(性质, 状态)<br>由“向前”与“知道”共同限定词义, 表示“预知” |
| ignorant<br><br>adj. 无知的; 没有学识的; 愚昧的 | i-(无, 不, 非), **gnor(知道, 了解)**, -ant(…的)<br>不了解或缺乏知识的 |
| recognizable<br><br>adj. 可认识的; 可认出的; 可公认的 | recognize→recogniz(词: 认出, 承认), -able(可…的)<br>具有足够特征而能够被认出的 |


### gon

角

| 单词 | 拆解 |
| --- | --- |
| diagonal<br><br>adj. 对角线(的); 斜纹的; 对角线的<br>n. 对角线(的); 斜纹织物 | dia-(通过, 穿过), **gon(角)**, -al(…的)<br>穿过两个角的线 |
| goniometer<br><br>n. 测角计 | 由希腊语 gonia“角”与 meter“测量器”构成<br>测量角度的仪器 |
| pentagon<br><br>n. 五角形; (the P-)五角大楼 | penta-(五), **gon(角)**<br>由“五”与“角”共同限定词义, 表示“五角形” |
| trigonometric<br><br>adj. 三角学的; 三角法的 | 由 trigon“ 三角形”与表示“测量”的 -metric 结合<br>表示与三角测量或三角函数有关的 |


### grad, gred

步, 级; 行走

| 单词 | 拆解 |
| --- | --- |
| degradation<br><br>n. 堕落; 退化; 恶化; 降解; 降级 | de-(下降, 降低), **grad(步, 级)**, -ation(行为, 结果)<br>从较高等级向下退落, 因此表示降级、退化或降解 |
| downgrade<br><br>n. 下坡; 降级<br>v. 使降级; 贬低<br>adv. 往下坡方向 | down(词: 下), **grad(步, 级)**, e(连接字母)<br>由“下”与“级”共同限定词义, 表示“降级, 贬低” |
| grader<br><br>n. 把东西分类别的人(或机器) | **grad(步, 级)**, -er(人)<br>负责分级的人; 也可引申指分级机器 |
| gradient<br><br>adj. 渐升的; 渐降的; 步行的<br>n. 倾斜度; 梯度; 坡度 | **grad(步, 级)**, -ient(…的)<br>逐级升降所形成的斜度或变化率 |
| graduate<br><br>n. 毕业生<br>v. 毕业 | **grad(步, 级)**, u(连接字母), -ate(做, 使)<br>在学业上走完某一步 |
| ingredient<br><br>n. 原料; 组成部分; 成分; 因素 | in-(向内, 进入), **gred(步, 级)**, -ient(人; 物)<br>进入混合物之中的组成物, 即成分 |
| postgraduate<br><br>n. 研究生 | post-(在后, 之后), graduate(词: 毕业)<br>毕业之后继续深造 |
| undergraduate<br><br>n. 尚未毕业者; 大学肄业生 | under-(在下, 低于), graduate(词: 毕业生)<br>由“在下”与“毕业、毕业生”共同限定词义, 表示“尚未毕业者, 大学肄业生” |
| upgrade<br><br>v. 升级; 提高档次<br>n. 升级; 提升<br>adv. 往上坡 | up(词: 向上), grade(词: 等级)<br>把等级向上提高, 即升级 |
| gradual<br><br>adj. 逐渐的 | **grad(步, 级)**, -ual(…的)<br>具有步性质的, 引申为逐渐的 |


### gram

书写, 记录

| 单词 | 拆解 |
| --- | --- |
| cryptogram<br><br>n. 密码; 暗记; 暗号; 密码文 | **crypto(隐藏, 秘密)**, **gram(书写, 记录)**<br>由“秘密”与“文字”共同限定词义, 表示“密码(文), 暗号(文)” |
| diagram<br><br>n. 图表; 示意图; 表格; 桌子; 图解 table | dia-(通过, 穿过), **gram(书写, 记录)**<br>用线条划分绘出的图 |
| gram(me)<br><br>n. (国际重量单位) 克 | 借自希腊语 grámma（小重量单位）; gramme 是英式旧拼法 |
| grammar<br><br>n. 语法; 语法书 | **gram(书写, 记录)**, m(连接字母), -ar(…的)<br>语言、文字 |
| grammarian<br><br>n. 语法学家; 文法家 | grammar(词: 语法), -ian(人; 语言)<br>研究语法的人 |
| gramophone<br><br>n. 留声机 | **gram(书写, 记录)**, o(连接元音), **phon(声音)**, e(连接字母)<br>由“书写”与“声音”共同限定词义, 表示“留声机” |
| hologram<br><br>n. 综合衍射图; 全息图 | **holo(全)**, **gram(书写, 记录)**<br>由“全”与“书写”共同限定词义, 表示“综合衍射图, 全息图” |
| kilogram<br><br>n. 千克; 公斤 | kilo-(千), **gram(书写, 记录)**<br>由“千”与“书写”共同限定词义, 表示“千克, 公斤” |
| parallelogram<br><br>n. 平行四边形 | parallel(词: 平行的), o(连接元音), **gram(书写, 记录)**<br>具有两组平行边的图形 |
| phonogram<br><br>n. 音标文字; 表音符号; 唱片; 录音片 | **phono(声音)**, **gram(书写, 记录)**<br>由“声音”与“文字”共同限定词义, 表示“音标文字, 表音符号” |
| program(me)<br><br>n. 程序; 计划; 方案; 大纲; 节目 (单) | 源自希腊语 prógramma（公开书写的通知）; programme 是英式拼法 |
| seismogram<br><br>n. 震波图; 地震波曲线 | **seismo(地震)**, **gram(书写, 记录)**<br>由“地震”与“书写”共同限定词义, 表示“震波图, 地震波曲线” |
| telegram<br><br>n. 电报 | **tele(远)**, **gram(书写, 记录)**<br>由远方通过电波传来的文字 |


### gran

谷物, 颗粒

| 单词 | 拆解 |
| --- | --- |
| granulate<br><br>v. 使成颗粒; 使成粒状 | granule→granul(词: 小粒), -ate(做, 使)<br>由“小粒”派生为当前词义 |
| granary<br><br>n. 谷仓; 粮仓; 产粮区 | **gran(谷物, 颗粒)**, -ary(场所)<br>储存谷物的场所, 即谷仓 |
| grange<br><br>n. 田庄; 农庄 | **gran(谷物, 颗粒)**, **ge(地)**<br>产粮之地 |
| granularity<br><br>n. 颗粒状 | granular(词: 颗粒状的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“颗粒状” |
| granulator<br><br>n. 砂糖成粒器 | granulate→granulat(词: 成粒状), -or(物)<br>由“成粒状”派生为当前词义 |
| granule<br><br>n. 颗粒; 细粒 | **gran(谷物, 颗粒)**, -ule(小)<br>在前词基础上加“-ule”构成名词, 表示“颗粒” |
| granular<br><br>adj. 颗粒状的 | **gran(谷物, 颗粒)**, -ular(…的)<br>围绕“颗粒”这一核心含义构成, 表示“颗粒状的” |


### graph

写, 画

| 单词 | 拆解 |
| --- | --- |
| chronograph<br><br>n. 计时器 | **chrono(时间)**, **graph(写, 画)**<br>记录或描绘“时间”的方法, 即“记时器” |
| graphics<br><br>n. 制图学; 制图法 | **graph(写, 画)**, -ics(…学)<br>以“写”为研究对象的学科, 即“制图学, 制图法” |
| historiography<br><br>n. 编史工作 | 由 history“历史”与 graphy“书写、研究”构成<br>历史书写方法或史学史 |
| ideograph<br><br>n. 表意文字; 意符 | **ideo(思想, 概念)**, **graph(写, 画)**<br>记录或描绘“思想”的方法, 即“表意文字” |
| micrograph<br><br>n. 微观图; 显微图 | **micro(微, 小)**, **graph(写, 画)**<br>记录或描绘“微”的方法, 即“微观图, 显微图” |
| monograph<br><br>n. 专题论文; 专题著作 | mono-(单一, 独), **graph(写, 画)**<br>记录或描绘“单一”的方法, 即“专题论文, 专题著作” |
| polygraph<br><br>n. 多产作家; 复写器 | poly-(多, 复), **graph(写, 画)**<br>记录或描绘“多”的方法, 即“多产作家” |
| photographer<br><br>n. 摄影者 | **photo(光)**, **graph(写, 画)**, -er(人)<br>把实物的影子录下来的人 |
| stereograph<br><br>n. 立体照片 | **stereo(坚固, 实心)**, **graph(写, 画)**<br>记录或描绘“立体的”的方法, 即“立体照片” |
| telegraph<br><br>n. 电报; 电报机 | **tele(远)**, **graph(写, 画)**<br>从远方通过电波传过来的文字 |
| biographic<br><br>adj. 传记的; 传记体的 | **bio(生命, 生物)**, **graph(写, 画)**, -ic(…的)<br>记录或描绘“生命”的方法, 即“传记的, 传记体的” |
| orthographic<br><br>adj. 正字法的 | ortho-(正确, 直), **graph(写, 画)**, -ic(…的)<br>记录或描绘“正确”的方法, 即“正字法的” |


### grat

愉快; 感激

| 单词 | 拆解 |
| --- | --- |
| gratify<br><br>v. 使满足; 使满意; 使高兴 | 源自拉丁语 gratificari“使感激、使喜悦”, 核心 gratus 表示令人愉快<br>使愿望得到满足 |
| congratulation<br><br>n. 祝贺; 庆贺 | 源自拉丁语 congratulatio, 与 congratulate“共同表示喜悦”同源<br>对他人喜事表达祝贺 |
| gratification<br><br>n. 满足; 满意; 喜悦; 令人欣慰的事 | **grat(愉快)**, i(连接字母), -fication(…化, 做…)<br>围绕“令人愉快的”这一核心含义构成, 表示“满足, 满意, 喜悦” |
| gratitude<br><br>n. 感激; 感谢; 感恩 | **grat(感激)**, -itude(性质, 状态)<br>感激、感谢的状态 |
| gratuity<br><br>n. 赏金; 退职金 | **grat(愉快)**, u(连接字母), -ity(性质, 状态)<br>让人高兴之物 |
| grateful<br><br>adj. 令人愉快的; 感激的; 感谢的 | **grat(感激)**, e(连接字母), -ful(充满…的)<br>内心充满感激的 |
| gratifying<br><br>adj. 令人愉快的; 可喜的 | 词形来源：gratify + ing-form |
| gratuitous<br><br>adj. 免费的; 无偿的; 无缘无故的 | **grat(愉快)**, u(连接字母), -itous(…的)<br>原指无偿给予的恩惠, 因此表示免费的; 又引申为无缘无故的 |


### grav, griev, grief

重

| 单词 | 拆解 |
| --- | --- |
| aggravate<br><br>v. 加重, 加剧, 使恶化 | ag-(到, 朝, 向), **grav(重)**, -ate(做, 使)<br>强化“重”这一动作或状态, 因此表示“加重, 加剧, 使恶化” |
| gravitate<br><br>v. 受重力作用 | gravity→gravit(词: 重力), -ate(做, 使)<br>受重力吸引而移动, 也引申为趋向 |
| grieve<br><br>v. 悲痛; 伤心; 使悲痛; 使伤心 | **griev(重)**, e(连接字母)<br>词根本身即表示“悲伤”, 整词沿用该义 |
| grave<br><br>n. 坟墓; 死亡<br>adj. 严重的; 重大的; 沉重的; 庄重的; 严肃的 | 形容词义由表示“重”的 grav 引申为“严重的”; 名词“坟墓”是同形词, 两个义项分别记忆 |
| gravida<br><br>n. 孕妇 | 医学拉丁语词, 表示处于怀孕状态的女性<br>英语内部没有可靠的同步词根词缀切分 |
| gravitation<br><br>n. 万有引力; 地心吸力; 引力作用; 吸引力; 趋势 | 与 gravitate“受重力吸引”同源, 核心 gravis 表示重<br>物体因重力相互吸引的现象 |
| gravity<br><br>n. 严重(性); 庄重; 重力; 地球引力 | **grav(重)**, -ity(性质, 状态)<br>表示与“重”有关的性质或状态, 即“地球引力, 重力” |
| grief<br><br>n. 悲伤; 悲痛; 不幸; 灾难; 伤心事 | 经古法语 grief 进入英语, 远源与拉丁语 gravis“沉重”相关<br>像重压在心上的悲痛 |
| grievance<br><br>n. 不满; 不平; 冤情; 苦情 | **griev(重)**, -ance(性质, 状态)<br>表示与“重”有关的性质或状态, 即“不满, 不平” |
| gravid<br><br>adj. 怀孕的 | **grav(重)**, -id(…的)<br>负重的 |


### greg

群, 聚集

| 单词 | 拆解 |
| --- | --- |
| aggregate<br><br>n. 合计; 总数; 骨料; 混凝料<br>v. 合计; 总计<br>adj. 总数的; 总计的 | ag-(到, 朝, 向), **greg(群, 聚集)**, -ate(做, 使)<br>把分散个体聚成一群, 因此表示集合、合计 |
| congregate<br><br>v. 聚集; 集合<br>adj. 聚集的 | con-(与, 共同), **greg(群, 聚集)**, -ate(做, 使)<br>共同聚在一群之中, 即"聚集" |
| aggregation<br><br>n. 聚集; 聚集物 | 源自拉丁语 aggregatio, 与 aggregate“聚集”同源<br>记忆为把个体聚成一群 |
| segregation<br><br>n. 分开; 离群; 隔离 | se-(离开, 分开), **greg(群, 聚集)**, -ation(行为, 结果)<br>由“分开”与“群”共同限定词义, 表示“分开” |
| segregationist<br><br>n. (各族) 隔离主义者 | segregation(词: 隔离), -ist(人)<br>由“隔离”派生为当前词义 |
| congregational<br><br>adj. 集合的 | congregation(词: 集合), -al(…的)<br>由“集合”派生为当前词义 |
| egregious<br><br>adj. 异乎寻常的; 惊人的; 极端恶劣的 | e-(出, 向外), **greg(群, 聚集)**, -ious(…的)<br>出众的 |
| gregarious<br><br>adj. 群居的; 爱社交的 | **greg(群, 聚集)**, -ar(…的), -ious(…的)<br>表示与“群”有关或具有该特征, 即“群居的” |


### gress

行走

| 单词 | 拆解 |
| --- | --- |
| aggress<br><br>v. 侵略; 侵入; 攻击 | ag-(到, 朝, 向), **gress(行走)**<br>朝对方步步进逼, 因此表示侵入、攻击 |
| digress<br><br>v. 离开主题; 入歧路 | di-(分开, 分离), **gress(行走)**<br>脱离正道而行 |
| aggression<br><br>n. 侵略; 入侵 | aggress(词: 侵略), -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“侵略” |
| aggressor<br><br>n. 侵略者 | aggress(词: 侵略), -or(人)<br>在前词基础上加“-or”构成名词, 表示“侵略者” |
| congress<br><br>n. 代表大会; 国会; 议会 | con-(与, 共同), **gress(行走)**<br>走到一起 |
| congressman<br><br>n. 国会议员 | congress(词: 国会), man(词: 人)<br>国会中的议员 |
| ingress<br><br>n. 进入; 进入权; 入口处; 通道 | in-(向内, 进入), **gress(行走)**<br>由“进入”与“行走”共同限定词义, 表示“进入” |
| progress<br><br>n. 进步; 进展; 前进<br>v. 进步; 发展; 前进 | pro-(向前, 前进), **gress(行走)**<br>由“前进”与“行走”共同限定词义, 表示“前进, 进展” |
| retrogression<br><br>n. 倒退; 退步; 退化 | retro-(回, 向后), **gress(行走)**, -ion(行为, 结果)<br>向后走并退回较低阶段, 因此表示倒退、退化 |
| transgressor<br><br>n. 犯法者; 违背者 | trans-(横过, 越过), **gress(行走)**, -or(人)<br>越过法律或道德界线的人, 即违法者、违背者 |
| aggressive<br><br>adj. 好斗的; 积极进取的; 侵略的 | ag-(到, 朝, 向), **gress(行走)**, -ive(…的)<br>主动朝对方逼近的, 引申为攻击性强或进取的 |
| regressive<br><br>adj. 倒退的; 回归的 | re-(回, 向后, 再次), **gress(行走)**, -ive(…的)<br>向后行走、退回较早状态, 因此表示倒退的、回归的 |


### grudge

怨恨; 不愿

| 单词 | 拆解 |
| --- | --- |
| begrudge<br><br>v. 妒忌; 对⋯不满 | be-(全体, 遍及, 充分), **grudge(怨恨)**<br>对给予他人某物心有不愿, 因此表示妒忌、不满 |
| grudge<br><br>n. 怨恨; 恶意<br>v. 怀恨; 嫉妒; 吝惜 | **grudge(怨恨)**<br>核心义为持续怀有怨恨, 也可表示不情愿给予 |
| grudging<br><br>adj. 不愿的; 勉强的; 吝啬的 | 词形来源：grudge + ing-form |


### gymn(o)

裸

| 单词 | 拆解 |
| --- | --- |
| gymnasium<br><br>n. 体育馆; 健身房 | 经拉丁语借自希腊语 gymnasion“锻炼场”, 来自 gymnos“裸体”<br>古希腊裸体训练的场所, 后指体育馆 |
| gymnast<br><br>n. 体育家; 体操家 | **gymn(裸)**, -ast(人)<br>赤膊光腿锻炼身体的人 |
| gymnastics<br><br>n. 体操; 体操训练 | gymnast(词: 体操运动员), -ics(…学)<br>在前词基础上加“-ics”构成名词, 表示“体操” |


### gyn, gynec(o), gynaeco

女人, 雌性

| 单词 | 拆解 |
| --- | --- |
| androgyny<br><br>n. 半男半女; 具备雌雄二性 | **andro(雄性, 男人)**, **gyn(女人, 雌性)**, -y(性质, 状态)<br>由“男人”与“女人”共同限定词义, 表示“半男半女” |
| gyn(a)ecologist<br><br>n. 妇科医生 | 由希腊语 gyne“女人、女性”与 logist“研究、诊治者”构成<br>诊治女性生殖系统疾病的医生 |
| gyn(a)ecology<br><br>n. 妇科学; 妇科 | **gynaeco(女人, 雌性)**, -logy(…学, …研究)<br>在前词基础上加“-logy”构成名词, 表示“妇科学” |
| misogynist<br><br>n. 厌恶女人的人 | **miso(憎恨, 厌恶)**, **gyn(女人, 雌性)**, -ist(人)<br>由“厌恶”与“女人”共同限定词义, 表示“厌恶女人的人” |
| misogyny<br><br>n. 厌女症; 厌女癖; 厌恶女人 | **miso(憎恨, 厌恶)**, **gyn(女人, 雌性)**, y(连接字母)<br>在前词基础上加“-y”构成名词, 表示“厌女症” |


### gyr(o)

环, 旋转

| 单词 | 拆解 |
| --- | --- |
| gyrate<br><br>v. 旋转; 不停地转动<br>adj. 旋涡状的 | **gyr(环, 旋转)**, -ate(做, 使)<br>围绕“旋转”这一核心含义构成, 表示“旋转, 回旋” |
| gyration<br><br>n. 旋转; 回旋 | **gyr(环, 旋转)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“旋转” |
| gyroplane<br><br>n. 旋翼机 | **gyro(环, 旋转)**, plane(词: 飞机)<br>由“旋转”与“飞机”共同限定词义, 表示“旋翼机” |
| gyroscope<br><br>n. 旋转仪; 回旋仪 | **gyro(环, 旋转)**, **scop(镜, 观察)**, e(连接字母)<br>由“旋转”与“观察”共同限定词义, 表示“旋转仪, 回旋仪” |
| gyratory<br><br>adj. 旋转的 | **gyr(环, 旋转)**, -atory(…的)<br>在前词基础上加“-atory”构成形容词, 表示“旋转的” |
