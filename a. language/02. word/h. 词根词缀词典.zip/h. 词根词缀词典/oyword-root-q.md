## oyword-root-q


### qual

性质, 特征

| 单词 | 拆解 |
| --- | --- |
| qualify<br><br>v. (使)具有资格; (使)胜任; (使)合适; 使具备资格; 使有权 | **qual(性质, 特征)**, -ify(…化, 做…)<br>使性质, 引申为使具备资格 |
| quale<br><br>n. 可感受的特性(尤指从实体中概括的特性) | **qual(性质, 特征)**, e(连接字母)<br>特征, 引申为可感受的特性 |
| qualification<br><br>n. 资格; 合格; 限定; 条件; 合格证明 | **qual(性质, 特征)**, i(连接字母), -fication(…化, 做…)<br>使符合其性质特征 |
| quality<br><br>n. 质(量); 品质; 特性; 质量 | **qual(性质, 特征)**, -ity(性质, 状态)<br>性质的性质, 引申为质量 |
| qualitative<br><br>adj. 定性的; 性质的; 质量的 | quality→qualit(词: 性质; 质量), -ative(…的)<br>与性质或质量而非数量有关的 |


### quant

量, 数量

| 单词 | 拆解 |
| --- | --- |
| quantify<br><br>v. 确定数量 | **quant(量, 数量)**, -ify(…化, 做…)<br>把性质转化为可测量的数量 |
| quantitate<br><br>v. 测定(或估计)...的数量; 用数量表示 | quantity→quantit(词: 数量), -ate(做, 使)<br>测定或用数值表示数量 |
| quantize<br><br>v. 使量子化 | **quant(量, 数量)**, -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“使量子化” |
| quanta<br><br>n. 量; 定量; 份额; 总量 | **quant(量, 数量)**, a(连接字母)<br>词根本身即表示“量”, 整词沿用该义 |
| quantity<br><br>n. 分量; 数量; (数)量 | **quant(量, 数量)**, -ity(性质, 状态)<br>表示与“数量”有关的性质或状态, 即“数量” |
| quantization<br><br>n. 量子化 | **quant(量, 数量)**, -ization(行为, …化)<br>在前词基础上加“-ization”构成名词, 表示“量子化” |
| quantitative<br><br>adj. 定量的; (数)量的 | 由 quantity“数量”派生, 最终源自拉丁语 quantus“多少”<br>与数量或测量有关的 |


### quer, quest, quir, quis

寻找, 询问

| 单词 | 拆解 |
| --- | --- |
| acquire<br><br>v. 获得; 购得; 得到 | ac-(到, 朝, 向), **quir(寻找, 询问)**, e(连接字母)<br>努力寻求并把某物取得到手, 因此表示获得、习得 |
| conquer<br><br>v. 攻克; 征服; 破除; 克服; 战胜 | con-(与, 共同), **quer(寻找, 询问)**<br>通过彻底搜寻、争取而取得胜利, 因此表示征服、战胜 |
| require<br><br>v. 需要; 需求; 规定; 命令 | re-(回, 向后, 再次), **quir(寻找, 询问)**, e(连接字母)<br>反复、郑重地寻求某物, 因此表示需要、要求 |
| conqueror<br><br>n. 征服者; 胜利者 | conquer(词: 征服), -or(人)<br>在前词基础上加“-or”构成名词, 表示“征服者” |
| conquest<br><br>n. 攻取; 征服; 克服 | con-(与, 共同), **quest(寻找, 询问)**<br>通过追寻、争夺而彻底取得某地或目标, 因此表示征服 |
| inquiry<br><br>n. 打听; 询问; 调查; 查问 | in-(向内, 进入), **quir(寻找, 询问)**, -y(活动)<br>以“询问”为语义核心构成, 表示“打听, 询问” |
| query<br><br>n. 疑问; 询问<br>v. 怀疑; 询问 | **quer(寻找, 询问)**, y(连接字母)<br>提出问题以寻求信息, 即询问或查询 |
| question<br><br>n. 问题; 询问<br>v. 询问; 审问; 怀疑 | **quest(寻找, 询问)**, -ion(行为, 结果)<br>围绕“问”这一核心含义构成, 表示“问题, 疑问, 不确定, 难题” |
| questionaire<br><br>n. 问卷; 调查表 | 原词是 questionnaire 的误拼; 规范词由 question 加法语来源的 -naire 构成, 表示问卷 |
| request<br><br>n. 请求; 需要; 申请书<br>v. 请求; 要求; 邀请 | re-(回, 向后, 再次), **quest(寻找, 询问)**<br>郑重地寻求或索取某事, 因此表示请求、要求 |
| requirement<br><br>n. 需要(的东西); 要求; 必要条件 | require(词: 需要), -ment(结果)<br>被正式提出并必须满足的需要或条件, 即要求 |
| inquisitive<br><br>adj. 好奇的; 好问的 | in-(向内, 进入), **quis(寻找, 询问)**, -itive(…的)<br>以“问”为语义核心构成, 表示“好奇的, 好问的” |
| prerequisite<br><br>n. 先决条件<br>adj. 必备的 | pre-(先于, 预先), requisite(词: 必需品)<br>在其他条件之前必须具备的条件 |


### qui, quiet

静

| 单词 | 拆解 |
| --- | --- |
| quiescence<br><br>n. 静止; 沉寂; 休眠; 被遏制状态 | **qui(静)**, -escence(开始或正在形成某种状态)<br>围绕“静”这一核心含义构成, 表示“静止, 沉寂” |
| quiet<br><br>n. 安静; 闲适; 平静<br>v. 平静下来; 使平静; 使平息<br>adj. 安静的; 静止的; 寂静的 | **quiet(静)**<br>核心义为安静, 可转化作名词、形容词和动词 |
| quietude<br><br>n. 平静; 寂静; 宁静 | 源自拉丁语 quietudo“安静、休息”<br>宁静的状态 |
| quietus<br><br>n. 偿清; 寂灭; 死; 平息; 制止 | **quiet(静)**, -us(名词词尾)<br>围绕“静”这一核心含义构成, 表示“偿清” |
| quiescent<br><br>adj. 静止的; 沉寂的; 休眠的; 被遏制的 | **qui(静)**, -escent(开始或正在形成…的)<br>在前词基础上加“-escent”构成形容词, 表示“静止的” |


### quot

引用, 数目

| 单词 | 拆解 |
| --- | --- |
| quota<br><br>n. 配额; 定额; 指标; 限额 | 源自拉丁语 quota“第多少、分得的一份”<br>表示预先分配或规定的数量份额 |
| quotation<br><br>n. 引用; 引证; 引文; 引语; 报价单 | **quot(引用, 数目)**, -ation(行为, 结果)<br>围绕“引用”这一核心含义构成, 表示“引用, 引证” |
| quote<br><br>v. 引用; 引述; 报价; 复述<br>n. 引文; 报价 | **quot(引用, 数目)**, e(连接字母)<br>引述他人的原话, 也可表示报价 |
| quotient<br><br>n. 份额; 应分得的部分 | **quot(引用, 数目)**, -ient(人; 物)<br>除法运算所得的数, 即商 |
| quotable<br><br>adj. 可引用 (或引证) 的; 适于引用 (或引证) 的 | **quot(引用, 数目)**, -able(可…的)<br>围绕“引用”这一核心含义构成, 表示“可引用 (或引证) 的” |
