## oyword-root-d


### dactyl(o)

指, 趾

| 单词 | 拆解 |
| --- | --- |
| pterodactyl<br><br>n. 翼手龙; 翼龙 | **pter(翼, 翅)**, o(连接元音), **dactyl(o)(指, 趾)**<br>具有由极度延长的第四指支撑皮膜飞行的史前翼龙 |
| dactylology<br><br>n. 手语; 指语 | **dactyl(o)(指, 趾)**, -logy(…学, …研究)<br>用手指动作和手势进行信息交流与表达的语言系统 |


### dec

可接受, 适当

| 单词 | 拆解 |
| --- | --- |
| decorate<br><br>v. 装饰; 装潢; 授予勋章 | decor(词: 装饰风格), -ate(做, 使)<br>使某处具有装饰效果 |
| decency<br><br>n. 正派; 得体; 彬彬有礼; 礼仪 | **dec(可接受, 适当)**, -ency(性质, 状态)<br>围绕“可接受的”这一核心含义构成, 表示“端庄, 体面” |
| decoration<br><br>n. 装饰品; 装潢; 勋章; 奖章 | decor(词: 装饰), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“装饰” |
| decent<br><br>adj. 得体的; 正派的; 像样的; 亲切和善的 | **dec(可接受, 适当)**, -ent(…的)<br>符合可接受标准的, 即得体或尚可的 |


### dem(o)

人民

| 单词 | 拆解 |
| --- | --- |
| democratize<br><br>v. 民主化; 使民主化 | democrat(词: 民主主义者), -ize(…化, 使成)<br>在前词基础上加“-ize”构成动词, 表示“民主化” |
| democracy<br><br>n. 民主; 民主政治; 民主政体; 民主主义 | **demo(人民)**, **cracy(统治, 政体)**<br>由人民统治的政体, 即"民主" |
| democrat<br><br>n. 民主主义者; 民主人士 | **demo(人民)**, **crat(统治者)**<br>围绕“统治者”这一核心含义构成, 表示“民主主义者” |
| demagogue<br><br>n. 煽动者; 蛊惑民心的政客 | 源自希腊语 demagogos, 由 demos“人民”与 agogos“引导者”构成<br>煽动民众的政治人物 |
| demography<br><br>n. 人口统计学 | **demo(人民)**, **graph(写, 画)**, -y(活动)<br>记录或描绘“人民”的方法, 即“人口统计学” |
| endemicity<br><br>n. 地方性; 风土性 | endemic(词: 地方病), -ity(性质, 状态)<br>由“地方病”派生为当前词义 |
| epidemiologist<br><br>n. 流行病学者 | epidemiology→epidemiolog(词: 流行病学), -ist(人)<br>研究流行病学的人 |
| epidemiology<br><br>n. 流行病学 | 由希腊语 epi“在……之中”、demos“人群”与 logy“研究”构成<br>研究疾病在人群中分布的学科 |
| pandemic<br><br>adj. 大流行的; 普遍的; 全世界的 | pan-(全, 总, 泛), **dem(人民)**, -ic(…的)<br>影响所有地区广大人群的, 即大流行的 |
| demotic<br><br>adj. 民众的 | **demo(人民)**, -tic(…的)<br>围绕“人民”这一核心含义构成, 表示“民众的” |


### demn, damn

伤害, 惩罚

| 单词 | 拆解 |
| --- | --- |
| condemn<br><br>v. 谴责; 指责 | con-(与, 共同), **demn(伤害, 惩罚)**<br>通过正式判断使某人承担惩罚, 因此表示谴责、判罪 |
| indemnify<br><br>v. 保护; 赔偿 | in-(无, 不, 非), **demn(伤害, 惩罚)**, i(连接字母), -fy(…化, 做…)<br>使人免受损害, 或补偿已经发生的损失, 即保障、赔偿 |
| condemnation<br><br>n. 谴责; 定罪 | condemn(词: 谴责), -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“谴责” |
| damage<br><br>n. 损害; 损失; 赔偿金<br>v. 损害; 破坏 | 经古法语 damage 进入英语, 源自拉丁语 damnum“损失”<br>表示造成的损害或损失 |
| damnation<br><br>n. 指责; 罚入地狱 | **damn(伤害, 惩罚)**, -ation(行为, 结果)<br>围绕“伤害”这一核心含义构成, 表示“指责” |
| indemnification<br><br>n. 保障; 保护; 赔偿; 补偿 | 源自 indemnify（赔偿、保障）形成的名词, 表示赔偿、保障或免责 |
| indemnity<br><br>n. 保护; 赦免; 赔偿; 赔偿物 | 源自拉丁语 indemnitas, 由 in“无”与 damnum“损失”构成<br>使免受损失的保障或赔偿 |


### dendr(i), dendr(o)

树

| 单词 | 拆解 |
| --- | --- |
| dendrite<br><br>n. 树枝石 | **dendr(树)**, -ite(矿物)<br>形状像树枝的结晶或结构, 即树枝晶 |
| dendrology<br><br>n. 树木学 | **dendr(i), dendr(o)(树)**, -logy(…学, …研究)<br>专门研究树木及其分类生长的学科 |


### dent(i), dent(o)

牙齿

| 单词 | 拆解 |
| --- | --- |
| dentist<br><br>n. 牙医生 | **dent(牙齿)**, -ist(人)<br>围绕“牙齿”这一核心含义构成, 表示“牙医生” |
| denture<br><br>n. 一副牙齿; 全口假牙 | **dent(牙齿)**, -ure(行为, 结果)<br>围绕“牙齿”这一核心含义构成, 表示“一副牙齿” |
| dental<br><br>adj. 牙齿的; 牙科的; 齿音的; 牙的 | **dent(牙齿)**, -al(…的)<br>表示与“牙齿”有关或具有该特征, 即“牙齿的, 牙科的” |
| dentate<br><br>adj. 牙齿的; 齿状的 | 构词锚点：dent 表示“牙齿”; -ate 在此为形容词词尾, 不取动词义<br>围绕“牙齿”这一核心含义构成, 表示“牙齿的” |
| interdental<br><br>adj. 牙间的 | inter-(在...之间), **dent(牙齿)**, -al(…的)<br>由“在…之间”与“牙齿”共同限定词义, 表示“牙间的” |


### derm(o), dermat(o)

皮肤

| 单词 | 拆解 |
| --- | --- |
| derma<br><br>n. 真皮; 皮肤 | 直接来自希腊语 derma“皮肤”<br>医学中表示真皮或皮肤 |
| dermatitis<br><br>n. 皮炎; 皮肤炎 | **dermat(皮肤)**, -itis(…炎)<br>“皮肤”发生炎症, 即“皮炎, 皮肤炎” |
| dermatology<br><br>n. 皮肤学; 皮肤病学 | **dermato(皮肤)**, -logy(…学, …研究)<br>以“皮肤”为研究对象的学科, 即“皮肤学” |
| dermatologist<br><br>n. 皮肤学家; 皮肤病学家 | **dermato(皮肤)**, -logist(…学家)<br>在前词基础上加“-logist”构成名词, 表示“皮肤学家” |
| xeroderma<br><br>n. 干皮病 | **xero(干燥)**, derma(词: 皮肤)<br>由“干燥”与“皮肤”共同限定词义, 表示“干皮病” |


### dexter, dextr(o)

右

| 单词 | 拆解 |
| --- | --- |
| dexterity<br><br>n. 灵巧; 敏捷; 聪明; 伶俐; 惯用右手 | **dexter(右)**, -ity(性质, 状态)<br>表示与“右”有关的性质或状态, 即“灵巧, 敏捷” |
| dextrose<br><br>n. 葡萄糖; [化] 右旋糖 | **dextr(右)**, -ose(糖)<br>围绕“右”这一核心含义构成, 表示“右旋糖, 葡萄糖” |
| dexter<br><br>adj. 右边的; 预兆吉利的 | **dexter(右)**<br>表示右侧的; 古代观念中右侧也与吉兆相关 |
| dexterous<br><br>adj. 灵巧的; 敏捷的; 聪明的; 伶俐的; 用右手的 | **dexter(右)**, -ous(…的)<br>在前词基础上加“-ous”构成形容词, 表示“灵巧的, 敏捷的” |


### di

日

| 单词 | 拆解 |
| --- | --- |
| dial<br><br>n. 表盘; (钟表等的)针盘; (仪表等的)标度盘; (电话的)拨号盘<br>v. 拨(电话号码); 用标度测量; 拨（电话号码） | 源自中世纪拉丁语 diale（与日有关的仪器）, 最初指日晷盘面, 后来指刻度盘 |
| diarist<br><br>n. 记日记者 | diary→diar(词: 日记), -ist(人)<br>撰写日记的人 |
| diary<br><br>n. 日记; 日记簿 | 源自拉丁语 diarium（每日记录、每日津贴）, 核心 dies 意为一天 |
| meridian<br><br>n. 子午线; 经线; 顶点<br>adj. 子午线的; 最高点的; 顶点的 | 源自拉丁语 meridianus“正午的”, 由 medius“中间”与 dies“日”相关形式构成<br>太阳正午所在南北线, 即子午线 |


### dic, dict

说, 言词

| 单词 | 拆解 |
| --- | --- |
| abdicate<br><br>v. 退位; 放弃(职位; 权力等) | ab-(脱离, 离去), **dic(说, 言词)**, -ate(做, 使)<br>公开声明自己离开王位或职责, 因此表示退位、放弃权力 |
| addict<br><br>v. 沉溺于 | 现代名词由旧动词 addict“使归属、使沉溺”逆构而来, 该动词源自拉丁语 addicere“判给”<br>由被判归某物引申为成瘾者 |
| dedicate<br><br>v. 奉献; 题献词于(书; 艺术作品等)上 | de-(一再等加强意义), **dic(说, 言词)**, -ate(做, 使)<br>以正式言辞把自己或作品交付给某人某事, 即奉献、题献 |
| predict<br><br>v. 预测; 预知 | pre-(先于, 预先), **dict(说, 言词)**<br>事先说出来, 即"预测" |
| vindicate<br><br>v. 辩护; 证明无罪 | 源自拉丁语 vindicare“主张权利、解放、惩罚”<br>通过证据维护权利或证明无罪 |
| benediction<br><br>n. 祝福 | bene-(好, 善), **dict(说, 言词)**, -ion(行为, 结果)<br>说出祝福的好话, 因此表示祝福、赐福祈祷 |
| dictator<br><br>n. 独裁者; 专政者 | **dict(说, 言词)**, -ator(人)<br>围绕“说”这一核心含义构成, 表示“独裁者, 专政者” |
| dictionary<br><br>n. 字典; 词典; 辞典 | **dict(说, 言词)**, -ion(行为, 结果), -ary(物)<br>汇集词语及其释义的书, 即词典 |
| dictum<br><br>n. 格言; 名言 | **dict(说, 言词)**, -um(名词词尾)<br>被说出并流传的话, 即格言或权威断语 |
| indictment<br><br>n. 控告; 起诉; 起诉书 | in-(向内, 进入), **dict(说, 言词)**, -ment(结果)<br>正式说出罪名后形成的起诉或起诉书 |
| malediction<br><br>n. 咒骂; 诽谤 | male-(坏, 恶, 不良), **dict(说, 言词)**, -ion(行为, 结果)<br>说出恶毒、伤害性的话, 因此表示咒骂、诅咒 |
| predicament<br><br>n. 困境 | 源自拉丁语 praedicamentum（所断言的类别、处境）, 现代记忆锚点是被判定并困在一种难以脱身的处境中 |
| verdict<br><br>n. 判决 | **ver(真实)**, **dict(说, 言词)**<br>围绕“说”这一核心含义构成, 表示“判决” |
| contradictory<br><br>adj. 相互矛盾的; 对立的; 不一致的<br>n. 对立的一方; 正反对(命题) | contra-(反对, 相反), **dict(说, 言词)**, -ory(…的)<br>由“反对”与“说”共同限定词义, 表示“对立的一方, 正反对(命题)” |
| indicative<br><br>adj. 表示的; 指示的 | in-(向内, 进入), **dic(说, 言词)**, -ative(…的)<br>把内在信息说出或指向某事的, 即表示、指示的 |
| predictable<br><br>adj. 可预测的; 可预见的 | predict(词: 预言), -able(可…的)<br>在前词基础上加“-able”构成形容词, 表示“可预言的” |


### dipl(o)

双, 复

| 单词 | 拆解 |
| --- | --- |
| diploid<br><br>n. 二倍体<br>adj. 双重的; 双倍的 | **dipl(双, 复)**, -oid(似…的（物）)<br>形状像“二”, 即“二倍 (的)” |
| diplomacy<br><br>n. 外交 (手腕); 交际手段 | **diplo(双, 复)**, m(连接字母), -acy(性质, 状态)<br>发展双边关系 |
| diplopia<br><br>n. 复视 | 由希腊语 diplo“双”与 ops“视觉”构成<br>一个物体看成两个, 即复视 |


### dit

给

| 单词 | 拆解 |
| --- | --- |
| edit<br><br>v. 编辑 | e-(出, 向外), **dit(给)**<br>原指把作品整理后给出、出版, 因此表示编辑 |
| extradite<br><br>v. 引渡 (逃犯; 战俘等); 使 (逃犯等) 被引渡 | extra-(在外, 向外), **dit(给)**, e(连接字母)<br>转交出 |
| editor<br><br>n. 编者; 编辑 | edit(词: 编辑), -or(人)<br>整理并发表作品的人, 即编辑 |
| editorship<br><br>n. 编辑的职位; 编辑工作 | editor(词: 编辑), -ship(性质, 状态)<br>在前词基础上加“-ship”构成名词, 表示“编辑的职位” |
| extradition<br><br>n. 引渡 | 经法语借自拉丁语 ex“向外”与 traditio“交付”构成的新拉丁词<br>把嫌疑人交付给另一司法辖区 |
| tradition<br><br>n. 传统 | tra-(横过, 越过), **dit(给)**, -ion(行为, 结果)<br>传给后人 |
| traditionalism<br><br>n. 传统主义 | traditional(词: 传统的), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“传统主义” |
| traditional<br><br>adj. 传统的 | tradition(词: 传统), -al(…的)<br>在前词基础上加“-al”构成形容词, 表示“传统的” |


### divid, divis

分

| 单词 | 拆解 |
| --- | --- |
| divide<br><br>v. 分开; 划分; 分裂; 除以<br>n. 分歧; 界线 | **divid(分)**, e(连接字母)<br>把整体分成若干部分, 即划分、除 |
| individualize<br><br>v. 使个性化 | individual(词: 人), -ize(…化, 使成)<br>由“人”派生为当前词义 |
| subdivide<br><br>v. 再分; 重分; 细分 | sub-(在下, 向下), **divid(分)**, e(连接字母)<br>由“在下”与“分”共同限定词义, 表示“再分, 重分” |
| dividend<br><br>n. 被除数; 股息; 红利 | **divid(分)**, -end(应被…的)<br>围绕“分”这一核心含义构成, 表示“被除数” |
| divider<br><br>n. 划分者; 分裂者; 间隔物; 分配器; 除数 | **divid(分)**, -er(人)<br>负责划分的人; 也可引申指分隔物或除数 |
| divisibility<br><br>n. 可分性 | **divis(分)**, -ibility(可…性)<br>围绕“分”这一核心含义构成, 表示“可分性” |
| division<br><br>n. 分开; 分割; 分配; 部门; 除法 | **divis(分)**, -ion(行为, 结果)<br>在前词基础上加“-ion”构成名词, 表示“分开” |
| divorce<br><br>n. 离婚; 分离<br>v. 离婚; 使分离 | 源自拉丁语 divortium（分开、岔开）, 由夫妻道路分开引申为离婚 |
| individual<br><br>n. 个人; 个体<br>adj. 单独的; 个别的; 独特的; 与众不同的 | in-(无, 不, 非), **divid(分)**, u(连接字母), -al(…的)<br>不可再分割的单个存在, 即个体的 |
| individualism<br><br>n. 个人主义 | individual(词: 个人), -ism(主义)<br>强调个人权利与自主性的思想 |
| individuality<br><br>n. 个性 | individual(词: 人), -ity(性质, 状态)<br>由“人”派生为当前词义 |
| divisible<br><br>adj. 可分的 | **divis(分)**, -ible(可…的)<br>在前词基础上加“-ible”构成形容词, 表示“可分的” |


### do, don, dow

给, 予

| 单词 | 拆解 |
| --- | --- |
| condone<br><br>v. 宽恕 | con-(与, 共同), **don(给, 予)**, e(连接字母)<br>给予宽容 |
| donate<br><br>v. 捐赠; 捐献 | **don(给, 予)**, -ate(做, 使)<br>围绕“给”这一核心含义构成, 表示“赠, 赠送” |
| endow<br><br>v. 捐赠; 赋予 | en-(进入, 包围), **dow(给, 予)**<br>把财产或能力给予某人, 因此表示捐赠、赋予 |
| anecdote<br><br>n. 轶事; 奇闻 | 源自希腊语 anekdotos（未出版的）, 原指未公开的记述, 后来指轶事 |
| donation<br><br>n. 捐赠; 赠品 | **don(给, 予)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“捐赠” |
| donator<br><br>n. 捐赠者 | **don(给, 予)**, -ator(人)<br>在前词基础上加“-ator”构成名词, 表示“捐赠者” |
| donee<br><br>n. 受赠人 | **don(给, 予)**, -ee(接受动作的人)<br>在前词基础上加“-ee”构成名词, 表示“受赠人” |
| donor<br><br>n. 赠与者 | **don(给, 予)**, -or(人)<br>在前词基础上加“-or”构成名词, 表示“赠与者” |
| dot<br><br>n. 嫁妆; 圆点; 点<br>v. 点缀; 在... 上打点 | 现代英语内部没有可靠的同步构词边界<br>指极小的圆点, 也可转化作动词表示点缀 |


### doc, doct, dog, dox

教; 观点; 荣耀

| 单词 | 拆解 |
| --- | --- |
| indoctrinate<br><br>v. 灌输; 教 | in-(向内, 进入), doctrine→doctrin(词: 教义), -ate(做, 使)<br>反复把某套教义或观念灌输进人的思想中 |
| orthodox<br><br>adj. 普遍接受的; 正统的; 规范的; 正统信仰的 | ortho-(正确, 直), **dox(观点)**<br>持有被认可为正确观点的, 即正统的 |


### dom

家

| 单词 | 拆解 |
| --- | --- |
| domesticate<br><br>v. 驯化(植物或者动物) | domestic(词: 驯养的), -ate(做, 使)<br>在前词基础上加“-ate”构成动词, 表示“驯养” |
| dominate<br><br>v. 统治; 支配; 控制; 占优势 | **domin(统治, 控制)**, -ate(做, 使)<br>对他人或局面实施统治控制 |
| dome<br><br>n. 圆屋顶; 拱顶; 大厦 | 经法语借自希腊语 doma“房屋”, 后受意大利语 duomo 影响<br>由建筑物发展为圆顶 |
| domestic<br><br>adj. 国内的; 家庭的; 驯养的<br>n. 国货; 佣人 | 源自拉丁语 domesticus（家庭的）, 核心 domus 意为家 |
| domesticity<br><br>n. 家庭生活; 家务; 家事 | domestic(词: 家庭的), -ity(性质, 状态)<br>在前词基础上加“-ity”构成名词, 表示“家庭生活” |
| domicile<br><br>n. 住处; 户籍 | 经法语借自拉丁语 domicilium“住所”, 核心 domus 表示家<br>法律或日常意义上的住所 |
| domiciliary<br><br>adj. 住处的; 户籍的 | domicile→domicili(词: 住所), -ary(…的)<br>在前词基础上加“-ary”构成形容词, 表示“住处的” |
| dominant<br><br>adj. 首要的; 占重要地位的 | **domin(主人)**, -ant(…的)<br>处于支配地位, 因此表示占优势的、主要的 |
| indomitable<br><br>adj. 不可征服的; 不屈不挠的 | 源自拉丁语 indomitabilis, 由 in“不可”与 domitare“驯服”构成<br>无法被驯服、不可征服的 |
| predominant<br><br>adj. 占优势的; 主要的; 突出的 | 与 predominate“占优势”同源, 源自拉丁语 prae“在前”与 dominari“统治”<br>占主导地位的 |


### dorm

睡眠

| 单词 | 拆解 |
| --- | --- |
| dorm<br><br>n. [美] 宿舍 | 由 dormitory 截短构词<br>表示供学生等集体居住的宿舍 |
| dormancy<br><br>n. 休眠; 蛰伏; 潜伏; 不活动状态 | **dorm(睡眠)**, -ancy(性质, 状态)<br>围绕“睡眠”这一核心含义构成, 表示“休眠, 蛰伏” |
| dormitory<br><br>n. 学生宿舍; 集体宿舍; (大学)学生宿舍 | 源自拉丁语 dormitorium“睡眠的场所”<br>供多人睡眠居住的场所, 即宿舍 |
| dormant<br><br>adj. 睡着的; 休眠的; (动物等)冬眠的; （动物等）冬眠的 | **dorm(睡眠)**, -ant(…的)<br>在前词基础上加“-ant”构成形容词, 表示“休眠的” |


### draw, drag, draft

拉

| 单词 | 拆解 |
| --- | --- |
| drag<br><br>v. 拖; 拽; 拉 | **drag(拉)**<br>核心动作是拖、拉 |
| draw<br><br>v. 画; 拉; 吸引; 拔出 | **draw(拉)**<br>核心动作是拉; 绘画义来自拉动笔形成线条 |
| withdraw<br><br>v. 撤离; 撤退; 收回; 提（款） | with-(收回, 撤回), **draw(拉)**<br>向后拉回, 因此表示撤回、退出或取款 |
| draft<br><br>n. 草稿; 汇票; 征兵<br>v. 起草; 拟定; 征召 | **draft(拉)**<br>草稿义由初步拟定引申 |
| drawback<br><br>n. 缺点; 欠缺; 障碍; 退款 | **draw(拉)**, back(词: 向后地)<br>把进展向后拉的不利因素, 因此表示缺点、障碍 |
| drawer<br><br>n. 抽屉 | **draw(拉)**, -er(物)<br>可以向外拉出的抽屉 |
| drawing<br><br>n. 图画; 绘画; 制图(技巧) | **draw(拉)**, -ing(物)<br>由线条拉画形成的图像, 即图画或素描 |


### drom(o)

跑

| 单词 | 拆解 |
| --- | --- |
| aerodrome<br><br>n. 飞机场 | **aero(空中, 空气)**, **drom(跑)**, e(连接字母)<br>供航空器起降、运行的场地, 即飞机场 |
| dromedary<br><br>n. 善跑的骆驼; 单峰骆驼 | 源自希腊语 dromas“奔跑者”<br>以善于长途奔跑得名, 特指单峰骆驼 |
| hippodrome<br><br>n. 跑马场; 赛马场; 马戏场 | **hippo(马)**, **drom(跑)**, e(连接字母)<br>跑马的地方 |
| syndrome<br><br>n. 综合症状; 典型意见; 典型表现 | syn-(共同), **drom(跑)**, e(连接字母)<br>一组症状共同出现、同时发展, 因此表示综合征 |


### du, dou

二, 双

| 单词 | 拆解 |
| --- | --- |
| double<br><br>n. 两倍; 替身<br>v. 加倍; 折叠<br>adj. 双重的; 双人的 | 经法语进入英语, 源自拉丁语 duplus（两倍的）, 表示双倍或成对 |
| doubt<br><br>n. 怀疑; 疑惑<br>v. 怀疑; 不信 | 经古法语 douter 借自拉丁语 dubitare“犹豫”<br>由内心犹豫发展为怀疑 |
| dualism<br><br>n. 双重性; 二元性; 二元论 | dual(词: 双重的), -ism(主义)<br>在前词基础上加“-ism”构成名词, 表示“双重性” |
| duality<br><br>n. 两重性; 二元性 | dual(词: 双重的), -ity(性质, 状态)<br>由“双重的”派生为当前词义 |
| duet<br><br>n. 二重唱; 二重奏 | **du(二, 双)**, -et(小)<br>围绕“二”这一核心含义构成, 表示“二重唱” |
| duplication<br><br>n. 成双; 成倍; 重复 | **du(二, 双)**, **plic(折, 折叠)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“成双” |
| duplicity<br><br>n. 二重性; 口是心非 | 源自拉丁语 duplicitas“双重性”, 核心 duplex 表示双重<br>表里两套而形成欺骗 |
| doubtful<br><br>adj. 怀疑的; 可疑的 | doubt(词: 怀疑), -ful(充满…的)<br>在前词基础上加“-ful”构成形容词, 表示“怀疑的” |
| dual<br><br>adj. 双的; 二重的; 二元的 | **du(二, 双)**, -al(…的)<br>表示与“双”有关或具有该特征, 即“双的” |
| duplex<br><br>adj. 二重的; 二倍的; 双的 | **du(二, 双)**, **plex(重叠)**<br>由两个部分重叠或组成的, 即复式或双工的 |


### duc, duct

引, 导

| 单词 | 拆解 |
| --- | --- |
| abduct<br><br>v. 诱拐; 劫持 | ab-(脱离, 离去), **duct(引, 导)**<br>把人从原处强行引走, 因此表示诱拐、劫持 |
| conduce<br><br>v. 引致; 导致; 有助于 | con-(与, 共同), **duc(引, 导)**, e(连接字母)<br>使“引导”共同结合或发挥作用, 因此表示“引致, 导致” |
| deduce<br><br>v. 推断; 演绎; 推论 | de-(脱离, 取消, 除去), **duc(引, 导)**, e(连接字母)<br>从已知事实中把结论引出, 即推断、演绎 |
| educate<br><br>v. 教导; 训练; (在学校)教育; 教养 | e-(出, 向外), **duc(引, 导)**, -ate(做, 使)<br>把人的能力引导出来并加以培养, 因此表示教育、训练 |
| induce<br><br>n. 产生<br>v. 劝诱; 引起; 引诱; 劝说 | in-(向内, 进入), **duc(引, 导)**, e(连接字母)<br>把某结果引导出来, 即诱发或劝使 |
| reduce<br><br>v. 减少; 缩减; 减小 | re-(回, 向后, 再次), **duc(引, 导)**, e(连接字母)<br>引导着往回收缩, 即"减少" |
| adduction<br><br>n. 引证; 引用 | ad-(到, 朝, 向), **duct(引, 导)**, -ion(行为, 结果)<br>把肢体向身体中线引近, 因此表示内收; 也可泛指引入 |
| conductor<br><br>n. (乐团等)指挥; 售票员; 列车员; 导体; 指导者 | con-(与, 共同), **duct(引, 导)**, -or(人)<br>引导乐团或乘客的人; 也可引申指传导电流的材料 |
| deduction<br><br>n. 减法; 扣除; 扣除额 | de-(脱离, 取消, 除去), **duct(引, 导)**, -ion(行为, 结果)<br>把一部分从整体中引走, 即扣除; 也引申为推论 |
| education<br><br>n. 教育 | e-(出, 向外), **duc(引, 导)**, -ation(行为, 结果)<br>把人的潜能引导出来并加以培养, 因此表示教育 |
| inducement<br><br>n. 引诱; 劝诱 | induce(词: 引诱), -ment(行为, 过程)<br>在前词基础上加“-ment”构成名词, 表示“引诱” |
| introducer<br><br>n. 引进者; 介绍人 | intro-(向内, 在内), **duc(引, 导)**, -er(人)<br>由“向内”与“引”共同限定词义, 表示“引进者” |
| productivity<br><br>n. 生产率; 生产能力 | pro-(向前, 前进), **duct(引, 导)**, -ivity(性质, 状态)<br>把成果持续带出的能力或效率, 即生产率、生产能力 |
| seduction<br><br>n. 诱惑; 勾引 | se-(离开, 分开), **duct(引, 导)**, -ion(行为, 结果)<br>把人从原来的方向引开, 因此表示诱惑、勾引 |
| viaduct<br><br>n. 高架桥; 跨线桥; 旱桥; 栈道 | **via(路)**, **duct(引, 导)**<br>把道路引过山谷或障碍的桥梁, 即高架桥、旱桥 |
| introductory<br><br>adj. 引导的; 入门的 | intro-(向内, 在内), **duct(引, 导)**, -ory(…的)<br>把读者或听众引入主题, 因此表示介绍的、导言的 |
| producible<br><br>adj. 可制出的; 可生产的 | pro-(向前, 前进), **duc(引, 导)**, -ible(可…的)<br>能够被向前带出并制造出来, 因此表示可生产的 |


### dur

持续, 耐久

| 单词 | 拆解 |
| --- | --- |
| endure<br><br>v. 忍耐; 容忍; 持久; 持续; 忍受 | en-(进入, 包围), **dur(持续, 耐久)**, e(连接字母)<br>使自己保持坚韧、持续承受, 因此表示忍耐或持久 |
| durable<br><br>adj. 耐用的; 耐久的; 长期的; 长久的; 持久的<br>n. (durables)耐用品 | **dur(持续, 耐久)**, -able(可…的)<br>围绕“耐久”这一核心含义构成, 表示“(durables)耐用品” |
| duration<br><br>n. 持续; 持久; 期间 | **dur(持续, 耐久)**, -ation(行为, 结果)<br>在前词基础上加“-ation”构成名词, 表示“持续” |
| endurance<br><br>n. 耐久力; 忍耐力 | en-(进入, 包围), **dur(持续, 耐久)**, -ance(性质, 状态)<br>由“进入”与“耐久”共同限定词义, 表示“耐久力, 忍耐力” |
| obdurate<br><br>adj. 执拗的; 顽固的 | 构词锚点：ob 表示“对着, 朝向, 在前”; dur 表示“持续, 耐久”; -ate 在此为形容词词尾, 不取动词义<br>长期硬着心、不肯改变, 因此表示顽固的、执拗的 |
| during<br><br>prep. 在…期间 | **dur(持续, 耐久)**, -ing(行为, 过程)<br>围绕“持续”这一核心含义构成, 表示“在…期间” |


### dyn, dynam(o)

力

| 单词 | 拆解 |
| --- | --- |
| dynamics<br><br>n. 动力学; 动态 | **dynam(力, 力量)**, -ics(…学)<br>以“力”为研究对象的学科, 即“动力学” |
| dynamite<br><br>n. 甘油炸药 | **dynam(力, 力量)**, -ite(矿物)<br>具有强大爆炸力的物质, 即炸药 |
| dynamometer<br><br>n. 测力计 | **dynamo(力, 力量)**, **meter(测量器, 仪表)**<br>测量“力”的仪器或方法, 即“测力计” |
| dynasty<br><br>n. 王朝; 朝代 | 源自希腊语 dynasteia（统治、权力）, 表示同一家族连续统治的时期 |
| dyne<br><br>n. (力的单位)达因 | **dyn(力, 力量)**, e(连接字母)<br>物理学中的力单位“达因” |
| electrodynamics<br><br>n. 电动力学 | **electr(电)**, o(连接元音), **dynam(力, 力量)**, -ics(…学)<br>以“电、力”为研究对象的学科, 即“电动力学” |
| hydrodynamics<br><br>n. 流体力学 | **hydro(水)**, **dynam(力, 力量)**, -ics(…学)<br>以“水、力”为研究对象的学科, 即“流体力学” |
| dynamic<br><br>adj. 充满活力的; 动态的 | **dynam(力, 力量)**, -ic(…的)<br>充满力量与活力的, 即动态的、有活力的 |
