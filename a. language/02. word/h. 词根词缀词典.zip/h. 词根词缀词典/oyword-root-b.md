## oyword-root-b


### ban

禁止

| 单词 | 拆解 |
| --- | --- |
| abandon<br><br>v. 放弃; 丢弃; 抛弃 | 源自古法语短语 à bandon“任凭处置、受支配”<br>由“任其处置、不再照管”发展为抛弃或放弃 |
| banish<br><br>v. 流放; 放逐; 驱逐出境 | **ban(禁止)**, -ish(…的)<br>围绕“禁止”这一核心含义构成, 表示“流放, 放逐, 驱逐出境” |
| ban<br><br>n. 禁令<br>v. 禁止; 取缔 | **ban(禁止)**<br>核心义即禁止, 可转化作名词表示禁令 |
| bandit<br><br>n. 强盗; 土匪; 歹徒 | 源自意大利语 bandito“被放逐者、强盗”<br>表示以抢劫为生的匪徒 |
| banal<br><br>adj. 平庸的; 陈腐的 | **ban(禁止)**, -al(…的)<br>原指公共征用地上人人可用之物, 引申为普通到"陈腐的" |


### bar(o)

重, 压

| 单词 | 拆解 |
| --- | --- |
| barite<br><br>n. 重晶石 | **bar(重, 压)**, -ite(矿物)<br>密度较大的含钡矿物, 即重晶石 |
| baritone<br><br>n. 男中音; 男中音歌手 | 借自意大利语 baritono, 源自希腊语 bary“重、低沉”与 tonos“音调”<br>音调低沉的男中音 |
| barometer<br><br>n. 气压计; 气压表 | **baro(重, 压)**, **meter(测量器, 仪表)**<br>测量“压”的仪器或方法, 即“气压计, 气压表” |
| baric<br><br>adj. 气压的 | **bar(栏栏, 障碍)**, -ic(…的)<br>围绕“栏栏”这一核心含义构成, 表示“气压的” |


### bar

栏栏, 障碍

| 单词 | 拆解 |
| --- | --- |
| embargo<br><br>v. 禁运 | 借自西班牙语 embargo“扣押、阻碍”, 与 bar“阻拦”无直接现代合成关系<br>官方禁止贸易或行动的命令 |
| embarrass<br><br>v. 使窘迫; 妨碍; 使尴尬; 使局促不安 | 经法语 embarrasser 进入英语, 原指设置障碍、堵住, 后来指使窘迫 |
| barrack<br><br>n. 营房; 棚屋 | 18世纪由复数 barracks 逆构成单数, barracks 经法语 baraque“棚屋”传入<br>供士兵集体居住的营房 |
| barrage<br><br>n. 火网; 弹幕射击; 拦河坝 | 19世纪借自法语 barrage, 来自 barrer“设置障碍、拦住”<br>由拦河设施引申为火力或言语的密集轰击 |
| barrel<br><br>n. 桶; 筒 | 经古法语 baril 进入英语<br>指中部鼓起、两端收窄的圆筒容器 |
| barricade<br><br>n. 路障; 街垒 | 源自法语 barricade“路障”<br>为阻断通行而设置的障碍物 |


### bas(i)

基底; 碱

| 单词 | 拆解 |
| --- | --- |
| base<br><br>n. 基础; 基地; 底部<br>v. 基于; 以……为基础 | **bas(基底)**, e(连接字母)<br>位于底部并起支撑作用的基础, 也可转化作动词 |
| basement<br><br>n. 地下室; 地窖; 底层 | base(词: 底部), -ment(场所)<br>由“底部”派生为当前词义 |
| basin<br><br>n. 盆; 盆地 | 源自古法语 bacin（盆、容器）, 核心意象是中央低凹、能够盛水的盆状结构 |
| basis<br><br>n. 基础; 基准; 基点; 方式; 基本规律 | **bas(基底)**, -is(性质, 状态)<br>表示与“基”有关的性质或状态, 即“基础, 基准, 基点, 方式, 基本规律” |
| basic<br><br>adj. 基本的; 基础的; 碱的; 碱性的 | **bas(基底)**, -ic(…的)<br>基础 |


### bat

打, 战斗

| 单词 | 拆解 |
| --- | --- |
| abate<br><br>v. 减少; 削弱 | 源自古法语 abatre“打倒、降低”, 由方向成分 a- 与 battre“击打”形成<br>由打倒压低发展为减弱、缓和 |
| batter<br><br>v. 连续猛击; 重击 | 源自古法语 battre“击打”<br>表示连续猛击或重击 |
| debate<br><br>n. 辩论; 讨论<br>v. 争论; 辩论 | de-(一再等加强意义), **bat(打, 战斗)**, e(连接字母)<br>双方以论点相互交锋, 因此表示辩论、争论; 不是字面‘打下对手’ |
| baton<br><br>n. 指挥棒; 接力棒; 警棍; 司令棒 | 源自法语 bâton“棍、棒”<br>表示指挥棒、接力棒等细长棍状物 |
| batsman<br><br>n. 击球手 | bat(词: 球棒), s(连接字母), man(词: 人)<br>持球棒击球的人, 即击球手 |
| battalion<br><br>n. 营(军队单位); 大批 | 源自意大利语 battaglione“大队、战斗队伍”<br>表示军队编制中的营, 也可泛指大队人马 |
| battery<br><br>n. 电池; (一系列; 一组)相似之物; 殴打罪; （物品的）一组 | **batt(打, 战斗)**, -ery(行为)<br>由连续击打或一组共同作战的器物, 发展出炮组、电池组等集合义 |
| battle<br><br>n. 战斗; 战役; 斗争<br>v. 搏斗; 奋斗 | 名词“战斗、战役”直接转化为动词“与……战斗” |
| combat<br><br>n. 战斗; 格斗<br>v. 与……搏斗; 防止 | com-(与, 共同), **bat(打, 战斗)**<br>使“战斗”共同结合或发挥作用, 因此表示“战斗” |
| combatant<br><br>n. 争斗者; 格斗者 | combat(词: 战斗), -ant(人; 物)<br>参与战斗的人, 即战斗员 |
| rebate<br><br>n. 减少; 回扣; 折扣 | re-(回, 向后, 再次), **bat(打, 战斗)**, e(连接字母)<br>把原价削减并返还一部分, 因此表示折扣、回扣 |
| combative<br><br>adj. 好斗的 | combat(词: 争斗), -ive(…的)<br>由“争斗”派生为当前词义 |


### bath(o), bathy

深, 深海

| 单词 | 拆解 |
| --- | --- |
| bathymetry<br><br>n. 海洋测深学; 海洋测深术 | **bath(o), bathy(深, 深海)**, **meter(测量; 测量器, 仪表)**, -y(活动)<br>测定水体深度及测绘海底三维起伏地貌的学科, 即水深测量学 |
| bathysphere<br><br>n. 深海潜水球; 深海观察圆球 | **bath(o), bathy(深, 深海)**, **spher(o)(球)**<br>用于深海探险与科学观察的耐高压球形潜水装置 |


### bell, bel

战斗, 战争

| 单词 | 拆解 |
| --- | --- |
| belligerence<br><br>n. 好战性 | **bell(战斗, 战争)**, i(连接字母), **ger(携带, 承担)**, -ence(性质, 状态)<br>把战争带向他人的倾向, 因此表示好战性 |
| rebel<br><br>n. 反叛者; 叛乱分子<br>v. 反叛; 造反 | re-(回, 向后, 再次), **bel(战斗, 战争)**<br>再度开战反抗 |
| rebellion<br><br>n. 叛乱; 反抗 | rebel(词: 反抗), l(连接字母), -ion(行为, 结果)<br>在前词基础上加“-l-”、“-ion”构成名词, 表示“叛乱, 反抗” |
| bellicose<br><br>adj. 好战的; 好斗的 | 源自拉丁语 bellicosus“好战的”, 核心 bellum 表示“战争”<br>具有强烈战争倾向, 即好战的 |
| rebellious<br><br>adj. 反叛的 | rebel→rebell(词: 叛徒), -ious(…的)<br>由“叛徒”派生为当前词义 |


### bi(o)

生命, 生物

| 单词 | 拆解 |
| --- | --- |
| amphibian<br><br>n. 两栖动物<br>adj. 两栖的; 水陆两用的 | amphi-(二者, 两种), **bi(生命, 生物)**, -an(…的)<br>兼具两种生活方式的生物, 即"两栖动物" |
| antibiotic<br><br>adj. 抗菌的<br>n. 抗生素 | anti-(反对, 相反), **bio(生命, 生物)**, t(连接字母), -ic(…的)<br>对抗微生物生命活动的; 转化作名词时指抗生素 |
| biocide<br><br>n. 杀虫剂 | **bio(生命, 生物)**, **cid(切, 杀)**, e(连接字母)<br>由“生命”与“杀”共同限定词义, 表示“杀虫剂” |
| biography<br><br>n. 传记 | **bio(生命, 生物)**, **graph(写, 画)**, -y(活动)<br>记录一个人生命经历的写作活动及其形成的作品, 即传记 |
| biometrics<br><br>n. 生物特征识别 | **bio(生命, 生物)**, metrics(词: 测量指标)<br>通过身体或行为特征进行身份测量识别的技术 |
| biosphere<br><br>n. 生命层; 生物圈 | **bio(生命, 生物)**, sphere(词: 范围)<br>由“生命”与“区域、范围”共同限定词义, 表示“生命层, 生物圈” |
| symbiosis<br><br>n. 共生(现象) | 源自希腊语 symbiosis“共同生活”, 由 syn“共同”与 bios“生命”构成<br>不同生物共同生活 |


### bibli(o)

书

| 单词 | 拆解 |
| --- | --- |
| Bible<br><br>n. 基督教的《圣经》 | 源自希腊语 biblia“书卷”, 原为 biblion“书”的复数<br>多部书卷汇集后专指《圣经》 |
| bibliographer<br><br>n. 书目提要编著人 | **biblio(书)**, **graph(写, 画)**, -er(人)<br>记录或描绘“书”的方法, 即“书目提要编著人” |
| bibliography<br><br>n. 书目提要; 目录学; □参考书目 | **biblio(书)**, **graph(写, 画)**, -y(活动)<br>把书籍记录汇集成的一组书目 |
| bibliomania<br><br>n. 藏书癖 (狂) | **biblio(书)**, **mania(狂热, 精神失常)**<br>由“书”与“狂热”共同限定词义, 表示“藏书癖 (狂)” |


### blanc

白

| 单词 | 拆解 |
| --- | --- |
| blanch<br><br>v. 漂白; 发白 | 经古法语 blanchir 借入, 来自 blanc“白色”<br>使颜色变白或使脸色发白 |
| blancmange<br><br>n. 牛奶冻 | 来自古法语 blanc mangier, 字面为“白色食物”<br>因成品色白而得名的甜点 |
| blank<br><br>n. 空白处<br>adj. 空白的; 茫然的; 没有表情的 | 经古法语 blanc“白色”进入英语<br>由未着色的白色发展为空白、未填写 |
| blastocyst<br><br>n. 胚囊; 胚胞 | **blasto(芽胚)**, **cyst(囊, 膀胱)**<br>由“胚”与“囊”共同限定词义, 表示“胚囊” |
| blastoderm<br><br>n. 胚盘; 胚膜 | **blasto(芽胚)**, **derm(皮肤)**<br>由“胚”与“皮肤”共同限定词义, 表示“胚盘, 胚膜” |


### blast(o)

芽胚; 细胞

| 单词 | 拆解 |
| --- | --- |
| blastocyst<br><br>n. 胚囊; 胚胞 | **blasto(芽胚)**, **cyst(囊, 膀胱)**<br>由“胚”与“囊”共同限定词义, 表示“胚囊” |
| blastoderm<br><br>n. 胚盘; 胚膜 | **blasto(芽胚)**, **derm(皮肤)**<br>由“胚”与“皮肤”共同限定词义, 表示“胚盘, 胚膜” |


### brace, brach

臂

| 单词 | 拆解 |
| --- | --- |
| bracelet<br><br>n. 手镯 | **brace(臂)**, -let(小)<br>戴在手臂或手腕上的小饰物, 即手镯 |
| brachial<br><br>adj. 臂的; 臂状的 | **brach(臂)**, -ial(…的)<br>表示与“臂”有关或具有该特征, 即“臂的, 臂状的” |


### brachy

短

| 单词 | 拆解 |
| --- | --- |
| brachycephalic<br><br>adj. 短头的 | **brachy(短)**, **cephal(o)(头)**, -ic(…的)<br>头骨颅面纵向明显扁平缩短的特征, 特指巴哥犬、斗牛犬等短头颅动物 |
| brachypterous<br><br>adj. 短翅的 | **brachy(短)**, **pter(翼, 翅)**, -ous(…的)<br>翅膀短小或退化的 |


### brady

缓慢

| 单词 | 拆解 |
| --- | --- |
| bradycardia<br><br>n. [医] 心搏缓慢 | 由希腊语 bradys“缓慢”与 kardia“心脏”构成<br>心跳缓慢, 即心动过缓 |
| bradykinin<br><br>n. 缓激肽; 血管舒张素 | 由希腊语 bradys“缓慢”、kinesis“运动”与化学后缀 -in 构成<br>因引起缓慢平滑肌反应而命名的缓激肽 |


### brev(i), brief

短

| 单词 | 拆解 |
| --- | --- |
| abbreviate<br><br>v. 缩短; 缩写; 省略(读物等) | ab-(脱离, 离去), **brevi(短)**, -ate(做, 使)<br>由“脱离”与“短”共同限定词义, 表示“缩短, 缩写, 省略(读物等)” |
| abbreviation<br><br>n. 缩短; 缩写; 省略; 缩写式 | ab-(脱离, 离去), **brevi(短)**, -ation(行为, 结果)<br>把完整形式截去一部分使其变短, 即缩写 |
| brief<br><br>n. 概要; 摘要; 简报<br>v. 向……介绍情况<br>adj. 简短的; 短暂的 | **brief(短)**<br>表示时间或篇幅短; 名词义“摘要”来自简短文本 |
| briefing<br><br>n. 下达简令; 情况的简要介绍(或汇报); 简令; 简要情况 | **brief(短)**, -ing(行为, 过程)<br>在前词基础上加“-ing”构成名词, 表示“下达简令” |
| breve<br><br>n. 短音符号 | **brev(短)**, e(连接字母)<br>表示短音符号或短时值音符 |
| breviary<br><br>n. 摘要; 缩略 | **brevi(短)**, -ary(物)<br>将内容缩短汇集而成的摘要或祈祷书 |
| brevity<br><br>n. 简短; 简洁; 短暂; 短促 | **brev(短)**, -ity(性质, 状态)<br>表示与“短”有关的性质或状态, 即“简短, 简洁” |


### brig

打, 战斗

| 单词 | 拆解 |
| --- | --- |
| brigade<br><br>n. 旅; 队 | **brig(打, 战斗)**, -ade(行为, 结果)<br>围绕“打”这一核心含义构成, 表示“(军)旅, (执行一定任务的)队” |
| brigadier<br><br>n. 旅长 | brigade→brigad(词: 旅), -ier(人)<br>由“旅”派生为当前词义 |
| brigand<br><br>n. 土匪; 强盗 | 经古法语借自意大利语 brigante“争斗者”<br>由非正规士兵引申为强盗 |


### bronch(o)

支气管

| 单词 | 拆解 |
| --- | --- |
| bronchitis<br><br>n. 支气管炎 | **bronch(支气管)**, -itis(…炎)<br>支气管发生炎症, 即支气管炎 |
| bronchopneumonia<br><br>n. 支气管肺炎 | 由 broncho“支气管”与 pneumonia“肺炎”构成<br>累及支气管周围肺组织的肺炎 |
| bronchoscope<br><br>n. 支气管窥镜 | **broncho(支气管)**, **scop(镜, 观察)**, e(连接字母)<br>由“支气管”与“镜”共同限定词义, 表示“支气管窥镜” |
| bronchus<br><br>n. 支气管; 细支气管 | **bronch(支气管)**, -us(名词词尾)<br>词根本身即表示“支气管”, 整词沿用该义 |
| bronchial<br><br>adj. 支气管的; 细支气管的 | **bronch(支气管)**, -ial(…的)<br>围绕“支气管”这一核心含义构成, 表示“支气管的” |
